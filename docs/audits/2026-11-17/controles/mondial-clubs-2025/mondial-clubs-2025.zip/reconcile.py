"""Reconcile official participants to stored matches, preserving native IDs and every exception."""
import csv
import gzip
import hashlib
import json
from collections import Counter, defaultdict
from datetime import date, timedelta
from pathlib import Path
import re
import unicodedata
import zlib

P = Path(__file__).resolve().parent
def read_json(p):
    return json.loads(p.read_bytes())
def digest(b):
    return hashlib.sha256(b).hexdigest()
def write_csv(path, rows):
    with path.open('w', newline='') as f:
        writer = csv.DictWriter(f, fieldnames=list(rows[0]), lineterminator='\n')
        writer.writeheader()
        writer.writerows(rows)
def unpack(t):
    return [dict(zip(t['columns'], x, strict=True)) for x in t['rows']]
def key(s):
    s = unicodedata.normalize('NFKD', s or '').encode('ascii','ignore').decode().lower()
    return ' '.join(re.findall(r'[a-z0-9]+', re.sub(r'\([a-z]{3}\)\s*$', '', s)))
def simple(s):
    return ' '.join(w for w in key(s).split() if w not in ('fc','cf','sc','ac','afc','club','de','do','the','football','futbol','clube'))
def names(s):
    return {key(s), simple(s)} - {''}
def iso(s):
    return date.fromisoformat(s[:10])
def official(sheet):
    d=json.loads(gzip.decompress(sheet.read_bytes()))
    meta=read_json(sheet.with_name(sheet.name.split('.')[0]+'.meta.json'))
    assert meta['sha256']==digest(gzip.decompress(sheet.read_bytes()))
    return d,meta
def main():
    raw=(P/'rds/inputs.json.zlib').read_bytes()
    assert digest(raw)==read_json(P/'rds/receipt.json')['sha256']
    rds=json.loads(zlib.decompress(raw)); assert rds['read_only']=='on'
    detail=unpack(rds['games']); all_games=unpack(rds['nearby'])
    aliases=defaultdict(set)
    mapped={r['fifa_match_id']:r for r in read_json(P/'fixture-proofs.json')}
    clubs=read_json(P/'root-ledger.json')
    for c in clubs:
        for label in (c['vega_name'],c['fifa_name']):aliases[c['vega_root']].update(names(label))
    for g in all_games:
        for k,side in [('home_team_id','h'),('away_team_id','a')]:
            if g[k] in aliases:
                for f in ('name','short','label'):aliases[g[k]].update(names(g[side+f]))
    # All fixtures with other IDs are considered even if competition or season is wrong.
    other=[m for m in all_games if m['edition']!=294]
    candidates=[]
    for m in detail:
        h,a=m['home_team_id'],m['away_team_id']
        record=next((x for x in mapped.values() if x['local_match_id']==m['id']),None)
        days={iso(m['match_date'])} if not record else {iso(record['fifa_local_date']),iso(record['fifa_utc'])}
        days={d+timedelta(days=n) for d in days for n in [-1,0,1]}
        for x in other:
            if not any(x[f] and iso(x[f]) in days for f in ('match_date','kickoff_day')):continue
            for s1,s2 in [('h','a'),('a','h')]:
                def hit(root,s):
                    if x[('home' if s=='h' else 'away')+'_team_id']==root:return 'ID'
                    labels=set().union(*(names(x[s+t]) for t in ['name','label','short']))
                    return 'alias' if labels & aliases[root] else ''
                home_hit,away_hit=hit(h,s1),hit(a,s2)
                if home_hit or away_hit:
                    candidates.append(dict(original=m['id'],other_match=x['id'],other_edition=x['edition'],day=x['match_date'],candidate_home=x['hname'],candidate_away=x['aname'],other_home_score=x['home_score'],other_away_score=x['away_score'],orientation=s1+s2,home_hit=home_hit,away_hit=away_hit,identical_score=(x['home_score'],x['away_score'])==((m['home_score'],m['away_score']) if s1=='h' else (m['away_score'],m['home_score']))))
    storage={g['id']:g for g in detail}
    columns=('team_sheets','lineups','stats','positive_minutes','halves','advanced','events','shots','player_intermediates','player_grades')
    compact=[]; totals=Counter(); players=set(); sides=[]; per=[]; keys=Counter(); subs_fields=Counter(); census=[]
    for f in sorted((P/'lineups').glob('*.json.gz')):
        j,metadata=official(f); mid=j['IdMatch']; m=mapped[mid]; r=storage[m['local_match_id']]
        assert j['IdCompetition']=='10005' and j['IdSeason']=='289175' and r['match_date']==m['local_date']
        assert r['status']=='finished' and r['edition']==294 and r['season_id']==2024
        assert [r['home_team_id'],r['away_team_id'],r['home_score'],r['away_score']]==[m['home_vega'],m['away_vega'],m['home_score'],m['away_score']]
        assert set(r['elo_teams'] or [])=={m['home_vega'],m['away_vega']}
        appeared=set();match_counts=Counter()
        for side,k in [('HomeTeam','home'),('AwayTeam','away')]:
            t=j[side]; tid=t['IdTeam'];assert tid==m[k+'_fifa'] and t['Score']==r[k+'_score']
            roster=t['Players']; ids=[p['IdPlayer']for p in roster]
            assert all(p['IdTeam']==tid and p['IdPlayer'] for p in roster) and len(ids)==len(set(ids))
            starters={p['IdPlayer'] for p in roster if p['Status']==1}
            subs=t.get('Substitutions') or []
            assert all(s['IdTeam']==tid and s['IdPlayerOn'] and s['IdPlayerOff'] for s in subs)
            on={s['IdPlayerOn']for s in subs};off={s['IdPlayerOff']for s in subs}
            played=starters|on|off
            assert len(starters)==11 and played<=set(ids) and not appeared&played
            appeared.update(played);players.update(played)
            shot={'roster':len(roster),'starters':len(starters),'entrants':len(on-starters),'played':len(played),'unused':len(set(ids)-played),'off_without_playing_cue':len(off-starters-on),'sub_events':len(subs),'sub_events_missing_clock':sum(not(s.get('Minute') or '').strip() for s in subs),'bookings':len(t.get('Bookings') or []),'goal_events':len(t.get('Goals') or [])}
            for p in roster:keys.update(i for i,v in p.items() if v is not None)
            for s in subs:subs_fields.update(k for k,v in s.items() if v not in (None,''))
            sides.append(dict(match_vega=r['id'],match_fifa=mid,cote=k,equipe_vega=m[k+'_vega'],equipe_fifa=tid,**shot))
            match_counts.update(shot);totals.update(shot)
            compact.append({'match':mid,'side':tid,'roster':[[p['IdPlayer'],p['Status'],p.get('Position')]for p in roster],'subs':[[s['IdPlayerOn'],s['IdPlayerOff'],s.get('Minute'),s.get('Period')]for s in subs],'goals':len(t.get('Goals')or[]),'bookings':len(t.get('Bookings')or[]),'sha256_raw':metadata['sha256']})
        per.append(dict(match_vega=r['id'],match_fifa=mid,jour_local=m['local_date'],jour_utc=m['fifa_utc'][:10],edition=294,saison_stockage=r['season_id'],titulaires=match_counts['starters'],entrees=match_counts['entrants'],participants=len(appeared),banc=match_counts['unused'],remplacements_sans_minute=match_counts['sub_events_missing_clock'],elo_cotes=len(r['elo_teams']),**{c:r[c] for c in columns}))
        census.append(dict(match_fifa=mid,match_vega=r['id'],source=metadata['url'],sha256=metadata['sha256']))
    playin=storage[1608]; assert len(storage)==64 and len(mapped)==len(per)==63 and set(playin['elo_teams'])=={877,883}
    assert all(not any(r[c] for c in columns) for r in detail)
    assert len({(r['season_id'],r['id'])for r in detail})==64
    out={'rds_utc':rds['at'],'rds_snapshot':rds['snap'],'stockage':2024,'edition':294,'matchs_finale_tournoi':len(per),'cotes':len(sides),'participants_distincts_sur_le_tournoi':len(players),'totaux_fifa':dict(totals),'fifa_player_keys_populated':dict(keys),'sub_fields_nonblank':dict(subs_fields),'rds_finales':{c:sum(r[c] for r in detail if r['id']!=1608) for c in columns},'rds_barrage':{c:playin[c]for c in columns},'elos_finales':sum(r['elo_cotes']for r in per),'elos_barrage':2,'population_date_locale_ou_utc':len(all_games),'autres_editions_matchs':len(other),'autres_une_ou_deux_equipes_reconnues':len(candidates),'autres_deux_equipes_reconnues':sum(bool(r['home_hit'] and r['away_hit']) for r in candidates),'autres_avec_cote_sans_id':sum(m['home_team_id']is None or m['away_team_id']is None for m in other)}
    (P/'resultats.json').write_text(json.dumps(out,indent=2,ensure_ascii=False)+'\n')
    (P/'participants-compacts.json.gz').write_bytes(gzip.compress(json.dumps(compact,separators=(',',':')).encode(),mtime=0))
    write_csv(P/'participations-par-match.csv',sorted(per,key=lambda r:r['match_vega']));write_csv(P/'observations-par-cote.csv',sides);write_csv(P/'sources.csv',census)
    if candidates:write_csv(P/'autres-candidats.csv',candidates)
    print(json.dumps({k:v for k,v in out.items() if k not in ['fifa_player_keys_populated','sub_fields_nonblank']},ensure_ascii=False))
if __name__=='__main__':main()
