"""Check the portable factual extracts. No network, database or third-party Python modules."""
import csv
from collections import Counter
import gzip
from hashlib import sha256
import json
from pathlib import Path
import zlib

root=Path(__file__).resolve().parent
def read(name):return json.loads((root/name).read_bytes())
def verify():
    index=read('fichiers.json')
    for relative,digest in index.items():
        assert sha256((root/relative).read_bytes()).hexdigest()==digest,relative
    observed=read('resultats.json')
    raw=(root/'rds/inputs.json.zlib').read_bytes()
    assert sha256(raw).hexdigest()==read('rds/receipt.json')['sha256']
    rds=json.loads(zlib.decompress(raw));games={r['id']:r for r in (dict(zip(rds['games']['columns'],x,strict=True))for x in rds['games']['rows'])}
    assert rds['read_only']=='on' and len(games)==64
    xwalk={r['fifa_match_id']:r for r in read('fixture-proofs.json')}
    per={int(r['match_vega']):r for r in csv.DictReader((root/'participations-par-match.csv').open())}
    sides={};unique=set();tot=Counter()
    for r in json.loads(gzip.decompress((root/'participants-compacts.json.gz').read_bytes())):
        m=xwalk[r['match']]
        side='home' if r['side']==m['home_fifa'] else 'away'
        assert r['side']==m[side+'_fifa'] and (r['match'],side) not in sides
        native=games[m['local_match_id']]
        assert (native[side+'_team_id'],native[side+'_score'])==(m[side+'_vega'],m[side+'_score'])
        roster={i:st for i,st,_ in r['roster']};assert len(roster)==len(r['roster'])
        starters={i for i,st in roster.items() if st==1};on={i[0]for i in r['subs']};off={i[1]for i in r['subs']}
        played=starters|on|off;assert len(starters)==11 and not off-starters-on and played<=set(roster)
        sides[r['match'],side]=played
        tot.update({'starters':len(starters),'entrants':len(on-starters),'played':len(played),'unused':len(set(roster)-played),'sub_events_missing_clock':sum(not (s[2] or '').strip() for s in r['subs'])});unique|=played
    for fid,m in xwalk.items():
        h=sides[fid,'home'];a=sides[fid,'away'];sql=games[m['local_match_id']]
        assert not h&a and len(h|a)==int(per[sql['id']]['participants'])
        assert sorted(sql['elo_teams'])==sorted([m['home_vega'],m['away_vega']])
        assert sql['season_id']==2024 and sql['edition']==294 and sql['status']=='finished'
    for col in observed['rds_finales']:assert all(not m[col] for m in games.values())
    play=read('barrage-resultats.json');expect=play['equipes']['LAFC']['participants']+play['equipes']['AMERICA']['participants']
    assert expect==36 and sorted(games[1608]['elo_teams'])==[877,883]
    assert len(xwalk)==63 and len(sides)==126 and len(unique)==673 and tot['played']==1996 and tot['unused']==1193
    assert all(observed['totaux_fifa'][k]==v for k,v in tot.items())
    print(json.dumps(dict(matchs=len(xwalk),participations=tot['played'],joueurs=len(unique),bancs=tot['unused'],barrage=expect,notes_stockees=0,elo_cotes=128,fichiers_controles=len(index))))
if __name__=='__main__':verify()
