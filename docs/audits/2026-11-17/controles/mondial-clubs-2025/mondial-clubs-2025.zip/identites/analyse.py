"""One-to-one candidate triage. The private comparison never writes IDs to Vega."""
from collections import Counter,defaultdict
from datetime import datetime
from hashlib import sha256
import bisect
import csv
import gzip
import json
from pathlib import Path
import re
import unicodedata
import zlib
import pymupdf

p=Path(__file__).resolve().parent
cup=p.parent
def j(f):return json.loads(f.read_bytes())
def rows(data):return [dict(zip(data['columns'],r,strict=True)) for r in data['rows']]
def tokens(s):
    s=unicodedata.normalize('NFKD',s or '').casefold().translate(str.maketrans({'ł':'l','ø':'o','đ':'d','ı':'i','æ':'ae','œ':'oe'}))
    return tuple(re.findall(r'[a-z0-9]+',s.encode('ascii','ignore').decode()))
def sig(s):return ''.join(tokens(s))
def compare_names(a,b):
    aa={sig(s)for s in a if len(sig(s))>=3};bb={sig(s)for s in b if len(sig(s))>=3}
    if aa&bb:return 'whole_alias'
    if any(len(tokens(x))>=2 and sorted(tokens(x))==sorted(tokens(y))for x in a for y in b):return 'same_full_tokens'
    return ''
def label(t,k):return {s['Description']for s in t.get(k,[])if s.get('Description')}
def run():
    pdf=cup/'identites/squad-public.pdf'
    assert sha256(pdf.read_bytes()).hexdigest()==j(p/'source.json')['sha256']
    doc=pymupdf.open(pdf);assert len(doc)==32
    cal=json.loads(gzip.decompress((cup/'raw/worldcup2025.gz').read_bytes()))['Results']
    teams={t['IdTeam']:t for m in cal for t in [m['Home'],m['Away']]}
    registry={};editions=set()
    for page in doc:
        lines=[(s['bbox'][0],s['bbox'][1],s['text'].strip()) for b in page.get_text('dict')['blocks']for l in b.get('lines',[])for s in l['spans']if s['text'].strip()]
        assert 'Friday, 4 July 2025' in page.get_text()
        heading=[t for x,y,t in lines if 35<y<39];assert len(heading)==1
        title,country=re.match(r'^(.*) \(([A-Z]{3})\)$',heading[0]).groups()
        if title=='SL Ben…ca' and country=='POR':
            assert 'otamendi' in page.get_text().casefold()
            title='SL Benfica'
        ids=[fid for fid,t in teams.items()if t['IdAssociation']==country and sig(title)in {sig(t['ShortClubName']),*[sig(a)for a in label(t,'TeamName')]}]
        assert len(ids)==1 and ids[0] not in editions,(title,country,ids);fid=ids[0];editions.add(fid)
        rules=sorted({round(r.x0,2) for d in page.get_drawings() for r in [d['rect']] if 43<r.y0<45 and 48<r.y1<50 and r.width<1 and 8<r.x0<426})
        assert len(rules)==8,(title,rules)
        for x,y,dob in lines:
            if not re.fullmatch(r'\d\d/\d\d/\d{4}',dob):continue
            cols=defaultdict(list)
            for xx,yy,tt in lines:
                if abs(yy-y)<0.19:cols[bisect.bisect_right(rules,xx)].append((xx,tt))
            cols=defaultdict(list,{k:[''.join(t for _,t in sorted(parts))]for k,parts in cols.items()})
            assert all(len(cols[i])==1 for i in (0,1,2,5,6,7)),(title,dob,dict(cols))
            assert cols[1][0] in ['GK','DF','MF','FW']
            key=fid,int(cols[0][0]);assert key not in registry
            given=' '.join(cols[3]);last=' '.join(cols[4])
            registry[key]={'dob':datetime.strptime(dob,'%d/%m/%Y').date().isoformat(),'names':set(filter(None,[*cols[2],*cols[5],given+' '+last,last+' '+given]))}
    actors=defaultdict(lambda:{'names':set(),'shirts':set(),'apps':0})
    for f in (cup/'lineups').glob('*.json.gz'):
        g=json.loads(gzip.decompress(f.read_bytes()))
        for k in ['HomeTeam','AwayTeam']:
            t=g[k];on={i['IdPlayerOn']for i in t['Substitutions']}
            for a in t['Players']:
                if a['Status']!=1 and a['IdPlayer'] not in on:continue
                rec=actors[t['IdTeam'],a['IdPlayer']];rec['names']|=label(a,'PlayerName')|label(a,'ShortName');rec['shirts'].add(a['ShirtNumber']);rec['apps']+=1
    assert len(actors)==673 and sum(a['apps']for a in actors.values())==1996
    f=cup.parent/'afcon-participation/rds/inputs.json.zlib';source=j(f.with_name('receipt.json'))
    assert sha256(f.read_bytes()).hexdigest()==source['sha256']
    pool=json.loads(zlib.decompress(f.read_bytes()));by_dob=defaultdict(set);person=defaultdict(lambda:{'names':set(),'core_dates':set(),'stage_dates':set()});by_name=defaultdict(set)
    for r in rows(pool['players']):
        pp=person[r['id']];pp['names'].update(filter(None,[r['name'],r['short_name'],*r['aliases']]))
        if r['birth_date']:pp['core_dates'].add(r['birth_date'])
    for r in rows(pool['staged']):
        pp=person[r['id']];pp['names'].add(r['name'] or '');pp['stage_dates'].add(r['birth_date'])
    for pid,pp in person.items():
        for dob in pp['core_dates']|pp['stage_dates']:by_dob[dob].add(pid)
        for nm in pp['names']:
            if len(sig(nm))>=3:by_name[sig(nm)].add(pid)
    date_order=sorted(by_dob);date_offsets={d:i for i,d in enumerate(date_order)}
    ledger=[];tests=Counter();quality=Counter()
    for (team,player),a in sorted(actors.items()):
        status='shirt_or_listing_missing';dob=None;candidate=None;date_matches=[];warnings=[];fifalink=''
        if len(a['shirts'])==1:
            reg=registry.get((team,next(iter(a['shirts']))))
            if reg:
                fifalink=compare_names(a['names'],reg['names'])
                if fifalink:
                    dob=reg['dob'];names=a['names']|reg['names']
                else:status='shirt_mapped_but_names_not_confirmed'
        if dob:
            all_dobs=by_dob[dob]
            for pid in all_dobs:
                pp=person[pid];match=compare_names(names,pp['names'])
                if not match:continue
                if pp['core_dates']|pp['stage_dates']!={dob}:warnings.append(pid);continue
                date_matches.append(pid)
            status=('conflicting_dob_evidence' if warnings else 'no_exact_alias_and_dob' if not date_matches else 'multiple_exact_alias_and_dob' if len(date_matches)>1 else 'single_core_dob_candidate' if dob in person[date_matches[0]]['core_dates'] else 'single_linked_stage_dob_candidate')
            if status.startswith('single_'):
                candidate=date_matches[0]; theirs=person[candidate]['names']
                strong=any(len(tokens(n))>=2 and len([t for t in tokens(n) if len(t)>1])>=2 and any(sorted(tokens(n))==sorted(tokens(q)) for q in theirs) for n in names)
                quality['two_full_name_elements' if strong else 'short_or_single_name_evidence']+=1
            wrong_dob=date_offsets.get(dob,-1)
            if wrong_dob>=0:
                # Substitute the next known calendar birth date, without changing any alias, for a negative control.
                target_dob=date_order[(date_offsets[dob]+1)%len(date_order)]
                assert target_dob!=dob
                tests['shift_to_nearest_next_known_dob_trials']+=1
                tests['shifted_dob_exact_alias_contacts']+=any(compare_names(names,person[i]['names']) for i in by_dob[target_dob])
            name_only=set().union(*(by_name[sig(n)]for n in names if len(sig(n))>=3))
            tests['multiple_name_only_ids']+=len(name_only)>1;tests['matched_DOB_but_other_name_only_ids']+=bool(candidate and (name_only-{candidate}))
        ledger.append(dict(fifa_team=team,fifa_player=player,appearances=a['apps'],registered_link=fifalink,classification=status,candidate=candidate,accepted_candidates=len(date_matches),conflicts=len(warnings)))
    targets=Counter(r['candidate']for r in ledger if r['candidate'])
    for r in ledger:
        if r['candidate'] and targets[r['candidate']]>1:r['classification']='shared_target_held';r['candidate']=None
    counts=Counter(r['classification']for r in ledger);apps=Counter()
    for r in ledger:apps[r['classification']]+=r['appearances']
    with (p/'private-candidates.csv').open('w',newline='')as out:
        w=csv.DictWriter(out,fieldnames=list(ledger[0]));w.writeheader();w.writerows(ledger)
    summary=dict(fifa_registration_as_of='2025-07-04T14:14Z',pdf_sha256=sha256(pdf.read_bytes()).hexdigest(),pdf_teams=len(editions),named_registrations=len(registry),different_players=len(ledger),appearances=sum(apps.values()),core_snapshot=pool['at'],core_player_rows=len(pool['players']['rows']),dated_nonquarantined_accepted_provider_rows=len(pool['staged']['rows']),core_snapshot_sha256=source['sha256'],whole_name_and_shirt_links=sum(bool(r['registered_link']) for r in ledger),registry_confirmed_appearances=sum(r['appearances'] for r in ledger if r['registered_link']),unique_injective_dob_and_alias_candidates=sum(bool(r['candidate']) for r in ledger),unique_candidate_appearances=sum(r['appearances'] for r in ledger if r['candidate']),players_by_status=dict(sorted(counts.items())),appearances_by_status=dict(sorted(apps.items())),name_strength_among_single_candidates=dict(quality),negative_controls=dict(tests),review_only=True,production_changes=0)
    (p/'synthese.json').write_text(json.dumps(summary,indent=2)+'\n');print(json.dumps(summary))
if __name__=='__main__':run()
