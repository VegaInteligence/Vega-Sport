"""Read one official FIFA team-sheet per final-tournament match, respecting throttling and cached receipts."""
from concurrent.futures import ThreadPoolExecutor
from datetime import datetime,timezone
from hashlib import sha256
from pathlib import Path
from threading import Lock
from time import monotonic,sleep
from urllib.error import HTTPError
from urllib.request import Request,urlopen
import gzip,json
P=Path(__file__).resolve().parent
D=P/'lineups';D.mkdir(exist_ok=True)
lock=Lock();clock=[0.]
def stamp():return datetime.now(timezone.utc).isoformat()
def save(path,raw):
    tmp=path.with_suffix(path.suffix+'.part');tmp.write_bytes(raw);tmp.replace(path)
def get(job):
    year,m=job;id=m['IdMatch'];url='https://api.fifa.com/api/v3/live/football/10005/'+m['IdSeason']+'/'+m['IdStage']+'/'+id+'?language=en'
    body=D/(id+'.json.gz');receipt=D/(id+'.meta.json')
    if body.exists() and receipt.exists():
        raw=gzip.decompress(body.read_bytes());meta=json.loads(receipt.read_bytes())
        if meta['url']==url and meta['sha256']==sha256(raw).hexdigest():return meta
        raise ValueError('Previous receipt drift '+id)
    sample=P/'raw'/('live-final'+str(year)+'.json')
    if sample.exists() and json.loads(sample.read_bytes())['url']==url:
        meta=json.loads(sample.read_bytes());raw=gzip.decompress(sample.with_suffix('.gz').read_bytes());assert sha256(raw).hexdigest()==meta['sha256']
    else:
        for n in range(3):
            with lock:
                pause=clock[0]-monotonic()
                if pause>0:sleep(pause)
                clock[0]=monotonic()+.55
            try:
                with urlopen(Request(url,headers={'User-Agent':'Vega Sport audit of public FIFA match sheets','Accept':'application/json'}),timeout=25) as resp:
                    raw=resp.read();meta={'url':url,'status':resp.status,'date':stamp(),'sha256':sha256(raw).hexdigest(),'size':len(raw)};break
            except HTTPError as err:
                if err.code in (403,429):
                    raise RuntimeError('Official service declined or rate-limited the request, stopped: '+str(err)) from err
                if err.code==404:
                    meta={'url':url,'status':404,'date':stamp()};save(receipt,json.dumps(meta,indent=2).encode());return meta
                if n==2:raise
                sleep(2**n)
            except OSError:
                if n==2:raise
                sleep(2**n)
    j=json.loads(raw);assert j['IdMatch']==id and j['IdSeason']==m['IdSeason'] and j['IdCompetition']=='10005'
    save(body,gzip.compress(raw,mtime=0));save(receipt,json.dumps(meta,indent=2).encode());return meta
def main():
    all_jobs=[]
    for f in sorted((P/'raw').glob('worldcup*.gz')):
        year=int(f.stem[8:]);all_jobs.extend((year,m) for m in json.loads(gzip.decompress(f.read_bytes()))['Results'])
    assert len(all_jobs)==len({m['IdMatch'] for _,m in all_jobs})==63
    done=[]
    # Bounded input batches permit prompt stop on throttling without queuing the whole tournament.
    with ThreadPoolExecutor(max_workers=2) as pool:
        for i in range(0,len(all_jobs),4):
            done.extend(pool.map(get,all_jobs[i:i+4]))
            if i%120==0:print(stamp(),i+len(all_jobs[i:i+4]),flush=True)
    result={'sources':len(done),'successful':sum(m['status']==200 for m in done),'not_found':sum(m['status']==404 for m in done),'bytes':sum(m.get('size',0) for m in done),'completed':stamp()}
    save(P/'lineups-collection.json',json.dumps(result,indent=2).encode());print(result)
if __name__=='__main__':main()
