# Barrage LAFC–Club América du 31 mai 2025

Le LAFC a obtenu la dernière place de la Coupe du monde des clubs en gagnant **2–1 après prolongation**. Les deux équipes ont chacune aligné **11 titulaires et fait entrer 7 remplaçants**. La feuille compte 50 inscrits, 36 participants et 14 joueurs restés sur le banc. Le barrage se compte séparément des 63 rencontres du tournoi principal. [Feuille officielle FIFA](https://api.fifa.com/api/v3/live/football/2y0bs9z3jy1tvxkbgey8ac9p0/a43ylo3ozw62lw2qcnv3hlqfo/3j68z030kvc12z7lap9izaf4k/586ww6p8yj540g0ppkc5n0hzo?language=en)

Les registres [des participants](participations-36.csv), [des inscrits](inscrits-50.csv), [des remplacements](remplacements-14.csv) et [des buts](buts-3.csv) sont recalculés à partir de la feuille FIFA et des observations individuelles. Ces fichiers et les [résultats agrégés](resultats.json) ont exactement les mêmes octets que dans le dossier opérateur. Les notes Vega restent hors mesure.

## Vérifier après extraction

Depuis le dossier extrait, avec Python 3.9 ou ultérieur et le programme standard `shasum`, exécuter les commandes suivantes. Elles vérifient les empreintes des fichiers livrés, les deux corps FIFA après décompression et les sorties recalculées à l’octet près.

```sh
shasum -a 256 -c SHA256SUMS
python3 -I verifier.py --verifier
```

La feuille détaillée FIFA et la réponse littérale `null` de l’autre voie FIFA sont conservées sous `raw/` avec leurs reçus. Le [calendrier](calendrier-barrage.json) conserve les champs des deux lignes correspondant à ce barrage. Le coup d’envoi a eu lieu le 31 mai à 19 h 30, soit le 1er juin à 02 h 30 UTC. Le source calendrier complet couvre également d’autres rencontres. Son URL, sa date de collecte, sa taille et son empreinte se trouvent dans les [reçus complémentaires](sources-complementaires.json).

Les [placements FotMob](placements-fotmob.json) retiennent les champs du match et des 36 participants nécessaires pour contrôler les maillots et les postes. Les [observations Opta](opta-index-extrait.json) sont une transcription des minutes et touches du document indexé. Les minutes totalisent 1 320 de chaque côté. Les deux entrants à 120′, Yeboah et Raposo, ont chacun une minute attribuée et respectivement une et deux touches. Ces valeurs proviennent d’Opta. La réponse directe de son hébergeur lors de l’audit était du HTML. L’empreinte de cette réponse figure parmi les reçus. Le PDF historique reste indisponible au téléchargement direct vérifié.

Les corps HTML du LAFC, de la Concacaf, de la FIFA, de FotMob et de l’hébergeur Opta restent consultables dans la preuve opérateur locale. Les reçus en donnent la provenance. Le lecteur public rejoue les compositions et les tableaux sur les fichiers présents dans cette archive.
