"""Rejoue hors ligne les inscriptions, entrées et observations du seul barrage."""
import csv
import gzip
import hashlib
import io
import json
import re
import sys
import unicodedata
from pathlib import Path

ROOT = Path(__file__).resolve().parent
MODE = sys.argv[1] if len(sys.argv) == 2 else "--verifier"
if MODE not in {"--verifier", "--produire"}:
    raise SystemExit("Usage : python3 verifier.py [--verifier|--produire]")


def source(key):
    receipt = json.loads((ROOT / "raw" / (key + ".json")).read_text())
    body = gzip.decompress((ROOT / "raw" / (key + ".gz")).read_bytes())
    assert receipt["status"] == 200
    assert receipt["octets"] == len(body)
    assert receipt["sha256"] == hashlib.sha256(body).hexdigest()
    return body


def output(name, content):
    path = ROOT / name
    if MODE == "--produire":
        path.write_bytes(content.encode("utf-8"))
    else:
        assert path.read_bytes() == content.encode("utf-8"), name


def table(name, rows):
    buf = io.StringIO()
    writer = csv.DictWriter(buf, fieldnames=list(rows[0]), lineterminator="\n")
    writer.writeheader()
    writer.writerows(rows)
    output(name, buf.getvalue())


def tokens(name):
    return set(re.findall(r"[a-z]+", unicodedata.normalize("NFKD", name).encode("ascii", "ignore").decode().lower()))


def description(i):
    return " ".join(i[0]["Description"].split())


sheet = json.loads(source("secondsheet"))
blank = source("fifasheet")
assert blank == b"null"
registry = json.loads((ROOT / "calendrier-barrage.json").read_bytes())
ids = ["400020111", "586ww6p8yj540g0ppkc5n0hzo"]
selected = [r for r in registry if r["IdMatch"] in ids]
assert len(selected) == 2 and len({r["IdMatch"] for r in selected}) == 2
for r in selected:
    assert r["Date"] == sheet["Date"] == "2025-06-01T02:30:00Z"
    assert (r["Home"]["ShortClubName"], r["Away"]["ShortClubName"]) == ("LAFC", "Club América")
    assert description(r["Stadium"]["Name"]) == "BMO Stadium"
    primary = r["IdMatch"] == ids[0]
    assert (r["IdCompetition"], r["IdSeason"], r["IdStage"]) == (
        ("FCWC_MCQ", "291833", "291834") if primary else
        ("2y0bs9z3jy1tvxkbgey8ac9p0", "a43ylo3ozw62lw2qcnv3hlqfo", "3j68z030kvc12z7lap9izaf4k"))
    path = "/".join([r[k] for k in ("IdCompetition", "IdSeason", "IdStage", "IdMatch")])
    key = "fifasheet" if primary else "secondsheet"
    assert "/live/football/" + path + "?" in json.loads((ROOT / "raw" / (key + ".json")).read_text())["url"]
    assert (r["HomeTeamScore"], r["AwayTeamScore"]) == ((None, None) if primary else (2, 1))
assert sheet["Properties"]["IdStatsPerform"] == sheet["IdMatch"] == ids[1]
assert sheet["LocalDate"][:16] == "2025-05-31T19:30"
assert sheet["SeasonName"][0]["Description"] == "FIFA Club World Cup Play-In 2025"
assert sheet["Winner"] == sheet["HomeTeam"]["IdTeam"]
# Les corps des sites complémentaires restent dans la preuve opérateur.
fm = json.loads((ROOT / "placements-fotmob.json").read_bytes())
assert fm["general"]["matchId"] == "4785581" and fm["general"]["matchTimeUTCDate"] == "2025-06-01T02:30:00.000Z"
opta = json.loads((ROOT / "opta-index-extrait.json").read_text())
samples = {(team, shirt): (name, minutes, touches) for team,shirt,name,minutes,touches in opta["lignes"]}
assert len(samples) == len(opta["lignes"]) == 36

rows, subs, goals, summary = [], [], [], {}
for index, (key, label) in enumerate((("HomeTeam", "LAFC"), ("AwayTeam", "AMERICA"))):
    team = sheet[key]
    alt = fm["lineup"][key[0].lower() + key[1:]]
    assert team["Tactics"] == alt["formation"]
    assert team["Score"] == [2, 1][index]
    players = {r["IdPlayer"]: r for r in team["Players"]}
    assert len(players) == len(team["Players"]) == [24, 26][index]
    assert all(r["IdTeam"] == team["IdTeam"] for r in players.values())
    starters = {i for i,p in players.items() if p["Status"] == 1}
    assert len(starters) == 11
    on_field, entered, exited = set(starters), {}, {}
    for order, s in enumerate(team["Substitutions"], 1):
        into, off = s["IdPlayerOn"], s["IdPlayerOff"]
        assert s["IdTeam"] == team["IdTeam"] and off in on_field and into in players
        assert into not in starters and into not in entered
        on_field.remove(off)
        on_field.add(into)
        assert len(on_field) == 11
        entered[into], exited[off] = s["Minute"], s["Minute"]
        subs.append(dict(equipe=label,ordre_du_cote=order,periode_fifa=s["Period"],minute_fifa=s["Minute"],
                         id_sortant_fifa=off,sortant=description(players[off]["PlayerName"]),
                         id_entrant_fifa=into,entrant=description(players[into]["PlayerName"])))
    assert len(entered) == len(exited) == 7
    played = starters | set(entered)
    shirts = {p["ShirtNumber"] for p in players.values()}
    assert len(shirts) == len(players)
    fm_starters = {int(p["shirtNumber"]): p for p in alt["starters"]}
    fm_subs = {int(p["shirtNumber"]): p for p in alt["entrants"]}
    assert set(fm_starters) == {players[i]["ShirtNumber"] for i in starters}
    assert set(fm_subs) == {players[i]["ShirtNumber"] for i in entered}
    assert set(fm_starters) | set(fm_subs) == {n for t,n in samples if t == label}
    for i,p in players.items():
        shirt, name = p["ShirtNumber"], description(p["PlayerName"])
        alt_p = (fm_starters | fm_subs).get(shirt, {})
        o_name, minutes, touches = samples.get((label, shirt), ("", None, None))
        assert (minutes is not None) == (i in played)
        if i in played:
            assert len(tokens(name) & tokens(o_name)) > 0 and len(tokens(name) & tokens(alt_p["name"])) > 0
            assert minutes > 0 and touches > 0
        rows.append(dict(equipe=label,id_equipe_fifa=team["IdTeam"],id_joueur_feuille_fifa=i,
                         dossard=shirt,nom_fifa=name,statut="titulaire" if i in starters else "entre" if i in entered else "banc_sans_entree",
                         entree_fifa=entered.get(i, ""),sortie_fifa=exited.get(i, ""),
                         position_fifa=p["Position"],id_fotmob_participant=alt_p.get("id", ""),nom_fotmob=alt_p.get("name", ""),
                         poste_match_fotmob=alt_p.get("positionId", ""),nom_opta_index=o_name,minutes_opta_index=minutes,touches_opta_index=touches))
    for g in team["Goals"]:
        assert g["IdTeam"] == team["IdTeam"] and g["IdPlayer"] in played
        if g["IdAssistPlayer"]: assert g["IdAssistPlayer"] in played
        goals.append(dict(equipe=label,minute_fifa=g["Minute"],type_fifa=g["Type"],id_buteur_fifa=g["IdPlayer"],
                          buteur=description(players[g["IdPlayer"]]["PlayerName"]),id_passeur_fifa=g["IdAssistPlayer"],
                          passeur=description(players[g["IdAssistPlayer"]]["PlayerName"]) if g["IdAssistPlayer"] else ""))
    active = [r for r in rows if r["equipe"] == label and r["statut"] != "banc_sans_entree"]
    summary[label] = dict(formation_fifa=team["Tactics"],inscrits=len(players),titulaires=len(starters),
                          entrees=len(entered),joueurs_avec_entree_et_sortie=len(set(entered) & set(exited)),participants=len(active),
                          banc_sans_entree=len(players)-len(active),buts_fifa=len(team["Goals"]),
                          minutes_individuelles_opta_index=sum(r["minutes_opta_index"] for r in active),
                          touches_individuelles_opta_index=sum(r["touches_opta_index"] for r in active))
    assert summary[label]["minutes_individuelles_opta_index"] == 11*120

appearance = [r for r in rows if r["statut"] != "banc_sans_entree"]
assert len(rows) == 50 and len(appearance) == 36 and len(subs) == 14 and len(goals) == 3
assert len({(r["id_equipe_fifa"],r["id_joueur_feuille_fifa"]) for r in rows}) == 50
assert len({r["id_joueur_feuille_fifa"] for r in rows}) == 50
assert sorted((r["dossard"],r["minutes_opta_index"],r["touches_opta_index"]) for r in rows if r["entree_fifa"] == "120'") == [(20,1,1),(21,1,2)]
assert not any(k.lower() in {"minutesplayed","touches","shotsontarget","npxg","expectedgoals"} for team in (sheet["HomeTeam"], sheet["AwayTeam"]) for p in team["Players"] for k in p)
table("inscrits-50.csv", rows)
table("participations-36.csv", appearance)
table("remplacements-14.csv", subs)
table("buts-3.csv", goals)
result = dict(portee="barrage seul",date_utc=sheet["Date"],stade=description(sheet["Stadium"]["Name"]),
              equipes=summary,total_inscrits=50,total_participants=36,total_banc_sans_entree=14,
              identites_vega_et_notes_production="hors mesure",
              seuils_minutes_opta_index={str(n):sum(r["minutes_opta_index"]>=n for r in appearance) for n in (1,15,30,45,60,90)})
output("resultats.json", json.dumps(result, ensure_ascii=False, indent=2)+"\n")
print(json.dumps(result, ensure_ascii=False, sort_keys=True))
