"""Replay the two published FIFA formats; fail on a new table or fixture shape."""
from pathlib import Path
from datetime import datetime
from collections import defaultdict, Counter
import json,csv,re,gzip,unicodedata,hashlib
P=Path(__file__).resolve().parent
def J(path):return json.loads(path.read_bytes())
def sha(blob):return hashlib.sha256(blob).hexdigest()
def g(path):
    b=gzip.decompress(path.read_bytes());return json.loads(b),sha(b)
def out(name,records):
    with (P/name).open('w',newline='') as f:
        w=csv.DictWriter(f,fieldnames=list(records[0]),lineterminator='\n');w.writeheader();w.writerows(records)
def norm(s):return ''.join(c for c in unicodedata.normalize('NFKD',s.lower()) if c.isalnum())
def tokens(s):return sorted(norm(t) for t in re.findall(r'[^\W_]+',s) if norm(t))
def fname(t):return t['TeamName'][0]['Description']
def readpdf(path,txt):
    receipt=J(path.with_suffix('.pdf.json')); b=path.read_bytes()
    assert receipt['status']==200 and b[:5]==b'%PDF-' and receipt['sha256']==sha(b)
    return [page for page in txt.read_text().split('\f') if page.strip()],receipt
def physical_teams(n,efi,home,away,score):
    lines=[x.strip() for x in efi.splitlines() if x.strip()]
    if n in (25,26): # Two real covers wrap both clubs and the score onto a second line
        a,b=re.split(r'\s{2,}',lines[1]),re.split(r'\s{2,}',lines[2])
        h=f'{a[0]} {b[0]}';v=f'{a[2]} {b[2]}';sc=(int(a[1].strip('-')),int(b[1]))
    else:
        m=re.fullmatch(r'(.+?)\s+(\d+)\s*-\s*(\d+)\s+(.+)',lines[1])
        assert m,(n,lines[1]);h,v=m[1],m[4];sc=(int(m[2]),int(m[3]))
    assert norm(h)==norm(home) and norm(v)==norm(away) and tuple(score)==sc,(n,h,home,v,away,sc,score)
def fdpname(s):return norm(s).replace('fi','').replace('fl','') # Some FDP font ligatures have empty ToUnicode
def main():
    fdp={e['number']:e for e in J(P/'fdp-index.json')};games,h=g(P.parent/'raw/worldcup2025.gz');assert h==J(P.parent/'raw/worldcup2025.json')['sha256']
    bygame={n['MatchNumber']:n for n in games['Results']}; assert set(fdp)==set(bygame)==set(range(1,64))
    gradebase={v['match_fifa']:v for v in csv.DictReader((P.parent/'participations-par-match.csv').open())}
    individuals=[];sides=[];files=[];wg=J(P/'global-calendar.json');named_disagreements=[];fixtures=[]
    for n in sorted(bygame):
        ref=bygame[n];mid=ref['IdMatch'];ld=ref['LocalDate'][:10]; date=datetime.fromisoformat(ld).strftime('%-d %B %Y'); score=[ref['HomeTeamScore'],ref['AwayTeamScore']]
        sidesrc,sh=g(P.parent/'lineups'/(mid+'.json.gz'));assert sh==J(P.parent/'lineups'/(mid+'.meta.json'))['sha256']
        home,away=map(fname,[ref['Home'],ref['Away']]);efip=P/'sources/efi'/f'M{n:02d}.pdf';ef,er=readpdf(efip,P/'lecture/efi'/f'M{n:02d}.txt')
        pf=P/'sources/fdp/by-id'/(fdp[n]['id']+'.pdf');fd,fr=readpdf(pf,P/'lecture/fdp/by-id'/(fdp[n]['id']+'.txt'))
        assert fdp[n]['date']==date and re.search(r'\bMatch '+str(n)+r'\b',ef[0],re.I) and date in ef[0]
        physical_teams(n,ef[0],home,away,score)
        m=re.search(r'^\s*(.*?) v\. (.*?) (\d+)-(\d+)\b',fd[0],re.M)
        assert m and fdpname(m[1])==fdpname(home) and fdpname(m[2])==fdpname(away) and list(map(int,m.group(3,4)))==score,(n,m.groups() if m else None,home,away,score)
        team_pdf=[z for z in ef if 'In Possession - Distributions' in z];assert len(team_pdf)==2
        fdp_pdf=[z for z in fd if 'Minutes played' in z];assert len(fdp_pdf)==1
        fdp_tabs=re.split(r'(?m)^\s*#\s+POS\s+NAME\s+MIN\s+',fdp_pdf[0]); assert len(fdp_tabs)==3
        attemptpages=[z for z in ef if 'Attempts at Goal' in z and 'Delivery Type' in z]
        per_team_events=defaultdict(Counter)
        for z in attemptpages:
            c=re.search(r'^Attempts at Goal\s+(.+)\s*$',z,re.M);assert c,(n,z[:140])
            k=norm(c[1]);assert k in (norm(home),norm(away)),(n,k)
            for l in z.splitlines():
                a=re.split(r'\s{2,}',l.strip())
                if len(a)>2 and re.fullmatch(r'[\d+:]+',a[0]): per_team_events[k][a[2]]+=1
        pagesgk=[p for p in ef if re.search(r'^Goal Prevention\s+',p,re.M)];assert len(pagesgk)==2
        assert not any(re.search(r'\bminutes played\b',z,re.I) for z in ef),(n,'new minutes header')
        srcout=dict(number=n,match_fifa=mid,match_vega=gradebase[mid]['match_vega'],date=ld,home=home,away=away,score='-'.join(str(x) for x in score))
        sf=[]
        for si,section in enumerate(['HomeTeam','AwayTeam']):
            side=sidesrc[section];tid=side['IdTeam'];nm=fname(side); on={x['IdPlayerOn'] for x in side['Substitutions']};reg={str(x['ShirtNumber']):x for x in side['Players']}; assert len(reg)==len(side['Players'])
            played={j for j,p in reg.items() if p['Status']==1 or p['IdPlayer'] in on}
            pdf1={};pdf2={}; page=team_pdf[si]; assert norm(re.search(r'^In Possession - Distributions\s+(.+)',page,re.M)[1])==norm(nm)
            for l in page.splitlines():
                m=re.match(r'^\s*(\d+)\s+(.+?)\s{2,}(\S.*)$',l)
                if not m:continue
                vals=m[3].split()
                assert len(vals)==14 and all(re.fullmatch(r'\d+%?',v) for v in vals),(n,l)
                assert m[1] not in pdf1;pdf1[m[1]]=(m[2],int(vals[0]),int(vals[1]),int(vals[-2]),int(vals[-1]))
            for l in fdp_tabs[si+1].splitlines():
                m=re.match(r'^\s*(\d+)\s+(GK|DF|MF|FW)\s+(.+?)\s{2,}(\S.*)$',l)
                if not m:continue
                vals=m[4].split();assert len(vals) in (10,11)
                if len(vals)==10:
                    assert n==21 and '/' in vals[3]
                    vals=[None]+vals
                mins=int(vals[0]) if vals[0] is not None else None
                shots,ot=map(int,vals[4].split('/'));assert m[1] not in pdf2;pdf2[m[1]]=(m[3],mins,shots,ot,m[2],int(vals[1]),int(vals[2]),int(vals[-1]))
            only_kit=(set(pdf1)|set(pdf2))-set(reg);assert not only_kit,(n,tid,only_kit)
            assert set(pdf1)==set(pdf2),(n,tid,sorted(set(pdf1)^set(pdf2)))
            tab=[]
            for j in sorted(set(pdf1)|played,key=int):
                pp=reg[j];v=pdf1.get(j);u=pdf2.get(j)
                name=pp['PlayerName'][0]['Description']
                if v and norm(v[0])!=norm(name):
                    named_disagreements.append((n,tid,j,pp['IdPlayer'],name,v[0]))
                    assert (n,j,name,v[0])==(57,'10','Abderrazzaq HAMED ALLAH','Abderrazak HAMDALLAH')
                if u:
                    # FDP prints family name first. Two embedded fonts omit the fi ligature.
                    pdf_name=u[0].replace('Al e','Alfie').replace('Sou ane','Soufiane')
                    assert tokens(pdf_name)==tokens(name) or (n==57 and j=='10' and pdf_name=='HAMDALLAH Abderrazak'),(n,j,name,pdf_name)
                assert v is None or v[2]<=v[1]
                r=dict(**srcout,side=tid,team=nm,shirt=j,fifa_player=pp['IdPlayer'],name=name,reference_appeared=int(j in played),efi_table=int(bool(v)),fdp_table=int(bool(u)),
                       fdp_position=u[4] if u else None,fifa_position=pp.get('Position'),time_fdp=u[1] if u else None,minute_source_consistent=int(bool(u and u[1] is not None and n!=21)),
                       passes_efi=v[1] if v else None,completed_efi=v[2] if v else None,shots_efi=v[3] if v else None,shots_fdp=u[2] if u else None,on_target_fdp=u[3] if u else None,
                       goals_efi=v[4] if v else None,goals_fdp=u[5] if u else None,gk_conceded_fdp=u[6] if u else None,direct_red_fdp=u[7] if u else None)
                tab.append(r);individuals.append(r)
            opposition=[away,home][si];ev=per_team_events[norm(opposition)];keepers=[r for r in tab if r['fdp_position']=='GK'];assert all(r['fifa_position']==0 for r in keepers),(n,nm)
            gksingle=len(keepers)==1 and n!=21 and keepers[0]['time_fdp']==max(r['time_fdp'] or 0 for r in tab) and keepers[0]['direct_red_fdp']==0
            ps=[r for r in tab if r['reference_appeared']]
            item=dict(**srcout,side=tid,team=nm,reference=len(played),pdf_rows=len(pdf1),pdf_extra=len(set(pdf1)-played),pdf_missing=len(played-set(pdf1)),
                      minutes_explicit=sum(r['time_fdp'] is not None for r in ps),minutes_source_consistent=sum(r['minute_source_consistent'] for r in ps),source_max_minutes=max(r['time_fdp'] or 0 for r in tab),
                      passes_efi=sum(r['passes_efi'] is not None for r in ps),shots_efi=sum(r['shots_efi'] is not None for r in ps),shots_fdp=sum(r['shots_fdp'] is not None for r in ps),on_target_fdp=sum(r['on_target_fdp'] is not None for r in ps),
                      shot_differences=sum(r['shots_efi']!=r['shots_fdp'] for r in ps if r['efi_table'] and r['fdp_table']),
                      gk_count=len(keepers),gk_fifa='|'.join(r['fifa_player'] for r in keepers),gk_shirt='|'.join(r['shirt'] for r in keepers),
                      gk_nominal_if_sole_full_time=int(gksingle),opposing_events_on_target_saved=ev['On Target - Saved']+ev['Deflected On Target - Saved'],
                      opposing_events_off_target_saved=ev['Off Target - Saved']+ev['Deflected Off Target - Saved'],
                      goal_prevention_page=ef.index(pagesgk[si])+1,fdp_stats_page=fd.index(fdp_pdf[0])+1,efi_stats_page=ef.index(page)+1)
            sf.append(item);sides.append(item)
        assert sum(x['reference'] for x in sf)==int(gradebase[mid]['participants'])
        fixtures.append(dict(**srcout,reference=sum(x['reference'] for x in sf),pdf_rows=sum(x['pdf_rows'] for x in sf),
            explicit_fdp_minutes=sum(x['minutes_explicit'] for x in sf),source_consistent_minutes=sum(x['minutes_source_consistent'] for x in sf),
            efi_attempted_completed_shots=sum(x['passes_efi'] for x in sf),fdp_shots_and_on_target=sum(x['shots_fdp'] for x in sf),
            shot_count_differences=sum(x['shot_differences'] for x in sf),fdp_url=fr['url'],fdp_sha256=fr['sha256'],efi_url=er['url'],efi_sha256=er['sha256']))
        for label,k in [('EFI',er),('FDP',fr)]:files.append(dict(number=n,match_fifa=mid,series=label,url=k['url'],utc=k['at_utc'],status=k['status'],bytes=k['bytes'],sha256=k['sha256']))
    out('private-player-fields.csv',individuals);out('coverage-sides.csv',sides);out('coverage-matches.csv',fixtures);out('sources-126.csv',files)
    (P/'names-check.json').write_text(json.dumps(named_disagreements,indent=2,ensure_ascii=False)+'\n')
if __name__=='__main__':main()
