from concurrent.futures import ThreadPoolExecutor
from datetime import datetime,timezone
import os,gzip,hashlib,html,json,re,threading,time
from pathlib import Path
from urllib.parse import urljoin
import requests
P=Path(__file__).resolve().parent
lock=threading.Lock()
last=0.0
def sha(b):return hashlib.sha256(b).hexdigest()
def get(name,url,kind):
    global last
    source=P/'sources'/name
    source.parent.mkdir(parents=True,exist_ok=True)
    rec=source.with_suffix(source.suffix+'.json')
    if rec.exists() and source.exists():
        receipt=json.loads(rec.read_bytes())
        assert sha(source.read_bytes())==receipt['sha256']
        return receipt
    if os.getenv("VEGA_FIFA_OFFLINE")=="1":raise RuntimeError("Offline evidence missing: "+name)
    with lock:
        time.sleep(max(0,0.6-(time.monotonic()-last)))
        last=time.monotonic()
    at=datetime.now(timezone.utc).isoformat()
    r=requests.get(url,timeout=(10,65),headers={'User-Agent':'Vega-Sport evidence review/1.0','Accept':'*/*'})
    b=r.content
    info=dict(url=r.request.url,final=r.url,status=r.status_code,at_utc=at,bytes=len(b),sha256=sha(b),
              content_type=r.headers.get('Content-Type'),last_modified=r.headers.get('Last-Modified'),class_document=kind)
    source.write_bytes(b);rec.write_text(json.dumps(info,indent=2,ensure_ascii=False)+'\n')
    return info
def links(raw):
    return [html.unescape(x).strip() for x in re.findall(r'href\s*=\s*["\']([^"\']+)["\']',raw,re.I)]
hub='https://www.fifatrainingcentre.com/en/game/tournaments/fcwc/2025/post-match-summary-reports.php'
if __name__=='__main__':
    get('hub.html',hub,'training_centre_index')
    get('terms.html','https://www.fifatrainingcentre.com/en/terms-of-service.php','training_centre_terms')
    get('tournament.html','https://www.fifatrainingcentre.com/en/game/tournaments/fcwc/2025/tournament-page--fifa-club-world-cup-2025.php','tournament_directory')
    ids={}
    for val in links((P/'sources/hub.html').read_text()):
        m=re.search(r'/M(\d{2})(?:[ %_-])',val,re.I)
        if m and val.lower().endswith('.pdf'):
            number=int(m[1]);assert number not in ids
            ids[number]=urljoin(hub,val)
    assert sorted(ids)==list(range(1,64))
    (P/'index-63.json').write_text(json.dumps(ids,indent=2,ensure_ascii=False)+'\n')
    sample=get('efi/M63.pdf',ids[63],'training_centre_report')
    assert sample['status']==200 and sample['bytes']<12_000_000
    print('index',len(ids),'final',sample['bytes'],flush=True)
    for n,source in [('63','https://fdp.fifa.org/assetspublic/ce233/r10594/pdf/FullTimeMatchReport-English.pdf'),
                     ('06','https://fdp.fifa.org/assetspublic/ce233/r10550/pdf/FullTimeMatchReport-English.pdf')]:
        get('fdp/M'+n+'.pdf',source,'fifa_full_time_report')
    def one(item):
        no,url=item
        receipt=get('efi/M%02d.pdf'%no,url,'training_centre_report')
        return (no,receipt['status'],receipt['bytes'])
    with ThreadPoolExecutor(max_workers=3) as pool:
        for no,code,size in pool.map(one,sorted(ids.items())):print(no,code,size,flush=True)
