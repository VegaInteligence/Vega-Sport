"""Compare all scheduled kickoffs with the unfiltered FIFA calendar. No other matches are published."""
from datetime import datetime,timedelta,timezone
from collections import defaultdict
from urllib.parse import urlencode
from concurrent.futures import ThreadPoolExecutor
import gzip,json,re,unicodedata,hashlib,time
from collect import P,get
def key(s):
    return ''.join(c for c in unicodedata.normalize('NFKD',s.lower()) if c.isalnum())
def name(t):return t['TeamName'][0]['Description'] if t and t.get('TeamName') else ''
def run():
    fixtures=json.load(gzip.open(P.parent/'raw/worldcup2025.gz'))['Results']
    bydate=defaultdict(list)
    for f in fixtures:bydate[f['Date'][:10]+'T00:00:00Z'].append(f)
    def one(pair):
        utc, fs=pair;ts=datetime.fromisoformat(utc.replace('Z','+00:00'))
        fmt=lambda x:x.strftime('%Y-%m-%dT%H:%M:%SZ')
        url='https://api.fifa.com/api/v3/calendar/matches?'+urlencode(dict([('from',fmt(ts)),('to',fmt(ts+timedelta(hours=23,minutes=59,seconds=59))),('count',500),('language','en')]))
        path='calendar-alternate/'+ts.strftime('%Y%m%d-day')+'.json'
        ack=get(path,url,'global_calendar_kickoff_window')
        out=dict(kickoff=utc,matches=[f['MatchNumber'] for f in fs],sha256=ack['sha256'],url=ack['url'],status=ack['status'])
        if ack['status']!=200 or 'json' not in str(ack['content_type']):return out
        j=json.loads((P/'sources'/path).read_bytes())
        if not isinstance(j,dict) or not isinstance(j.get('Results'),list):out['body']='null-or-no-results';return out
        out['rows']=len(j['Results']);out['continuation']=bool(j.get('ContinuationToken') or j.get('ContinuationHash')); out['candidates']=[]
        for a in j['Results']:
            hm,aw=name(a.get('Home')),name(a.get('Away'))
            for f in fs:
                names={key(name(f['Home'])),key(name(f['Away']))}
                names2={key(hm),key(aw)}
                ab=lambda x:str(x.get('Abbreviation','')).upper() if x else ''
                abbrevs={ab(f['Home']),ab(f['Away'])}
                if (names & names2) or (len(abbrevs)==2 and abbrevs=={ab(a.get('Home')),ab(a.get('Away'))}) or a['IdMatch']==f['IdMatch']:
                    out['candidates'].append(dict(reference=f['MatchNumber'],match=a['IdMatch'],competition=a['IdCompetition'],edition=a['IdSeason'],home=hm,away=aw,kickoff=a['Date']))
        return out
    with ThreadPoolExecutor(max_workers=3) as pool:records=list(pool.map(one,sorted(bydate.items())))
    (P/'global-calendar.json').write_text(json.dumps(records,indent=2,ensure_ascii=False)+'\n')
if __name__=='__main__':run()
