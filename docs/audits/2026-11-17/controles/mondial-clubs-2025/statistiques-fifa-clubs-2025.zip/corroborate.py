from concurrent.futures import ThreadPoolExecutor
from collect import get,P
from datetime import datetime,timezone
import requests,json
U={
'bayern-match':'https://fcbayern.com/en/news/matchreports/2025/06/match-report-club-world-cup-fc-bayern-v-boca-juniors-200625',
'bayern-lineup':'https://fcbayern.com/es/matches/profis/fifa-klub-wm/2025-2026/fc-bayern-muenchen-club-atl-tico-boca-juniors-21-06-2025/lineup',
'botafogo':'https://botafogo.com.br/noticias/palmeiras-1-x-0-botafogo-cmc',
'auckland':'https://www.aucklandcityfc.com/city-undone-by-di-maria-and-orlando-deluge/',
'chelsea':'https://www.chelseafc.com/en/news/article/the-reasons-behind-robert-sanchez-golden-gloves-award',
'opta-final':'https://optaplayerstats.statsperform.com/en_GB/soccer/fifa-club-world-cup-2025-usa/7n3ltxz65zjcd8z9eyr5i2wb8/match/chelsea-vs-paris-saint-germain/8yd1pnmiv3drjrcyjy4urqfx0',
'concacaf-M06.pdf':'https://www.concacaf.com/media/dhuiqv3u/eng-fcwc25-chelsea-2-lafc-0.pdf',
'terms-stats-perform':'https://www.statsperform.com/terms-of-use/',
'fdp-tournament.pdf':'https://fdp.fifa.org/assetspublic/ce233/pdf/CompetitionSummary-English.pdf'
}
def go(it):
 k,u=it
 try:z=get('corroboration/'+k+('' if k.endswith('.pdf') else '.html'),u,'corroborating_publisher');print(k,z['status'],z['bytes'],flush=True)
 except requests.RequestException as e:
  z=dict(url=u,error=type(e).__name__,at_utc=datetime.now(timezone.utc).isoformat());(P/'sources/corroboration'/f'{k}.error.json').write_text(json.dumps(z,indent=2)+'\n');print(k,type(e).__name__,flush=True)
if __name__=='__main__':
 with ThreadPoolExecutor(max_workers=3) as pool:list(pool.map(go,U.items()))
