"""Verify source receipts and independently constrain published projections. Run after qualify.py."""
import csv,hashlib,json,re,gzip
from pathlib import Path
from collections import Counter
from html.parser import HTMLParser
from qualify import P,J,sha
def readcsv(name):return list(csv.DictReader((P/name).open()))
def check(name,actual,expected):
    assert actual==expected,(name,actual,expected)
    return actual
def main():
    audit={}
    p=readcsv('private-player-fields.csv');s=readcsv('coverage-sides.csv');m=readcsv('coverage-matches.csv');a=[r for r in p if r['reference_appeared']=='1']
    check('files',len(readcsv('sources-126.csv')),126)
    for r in readcsv('sources-126.csv'):
        n=int(r['number'])
        b=(P/'sources/efi'/f'M{n:02d}.pdf' if r['series']=='EFI' else P/'sources/fdp/by-id'/(r['url'].split('/')[-3]+'.pdf')).read_bytes()
        assert len(b)==int(r['bytes']) and sha(b)==r['sha256']
    audit['edition']={'fifa_competition':10005,'fifa_season':289175,'vega_edition':294,'storage_season':2024,'matches':check('match count',len(m),63),'sides':check('side count',len(s),126),'appearances_reference':check('reference',len(a),1996),'pdf_stat_rows_per_series':check('pdf',len(p),1998)}
    counts={k:sum(bool(r[k]) for r in a) for k in ['passes_efi','completed_efi','shots_efi','shots_fdp','on_target_fdp','time_fdp']}
    audit['fifa_counts']=check('present fields',counts,dict(passes_efi=1996,completed_efi=1996,shots_efi=1996,shots_fdp=1996,on_target_fdp=1996,time_fdp=1984))
    audit['time']=dict(considerable_fdp_minutes=check('candidate source minutes',sum(r['minute_source_consistent']=='1' for r in a),1962),blocked_match=21,
        missing_min=check('blank minutes',sum(not r['time_fdp'] for r in a),12),reported_54=check('54 at M21',sum(r['time_fdp']=='54' for r in a if r['number']=='21'),22),
        fdp_no_aet_full_match_minima_maxima=[min(max(int(r['time_fdp']) for r in a if r['number']==n) for n in {r['number'] for r in a}-{'21','49','50','54'}),max(max(int(r['time_fdp']) for r in a if r['number']==n) for n in {r['number'] for r in a}-{'21','49','50','54'})],
        aet={n:max(int(r['time_fdp']) for r in a if r['number']==n) for n in ['49','50','54']})
    dif=[r for r in a if r['shots_efi']!=r['shots_fdp']]
    audit['shot_delta_efi_minus_fdp']=dict(appearances=check('different',len(dif),132),sides=len({(r['number'],r['side']) for r in dif}),matches=len({r['number'] for r in dif}),histogram=dict(sorted(Counter(int(r['shots_efi'])-int(r['shots_fdp']) for r in a).items())))
    keep=[r for r in a if r['fdp_position']=='GK']
    check('GK roles',[(r['fifa_position']=='0') for r in keep],[True]*126)
    audit['keepers']=dict(role_appearances=len(keep),distinct_fifa_players=len({r['fifa_player'] for r in keep}),one_per_side=all(r['gk_count']=='1' for r in s),
         sole_and_fdp_match_max_nonanomalous=sum(int(r['gk_nominal_if_sole_full_time']) for r in s),
         directly_named_FIFA_saves_field=0,opposing_EFI_on_target_saved_events=sum(int(r['opposing_events_on_target_saved']) for r in s),opposing_EFI_off_target_saved_events=sum(int(r['opposing_events_off_target_saved']) for r in s))
    audit['extras']=[{k:r[k] for k in ('number','side','shirt','fifa_player','name','time_fdp','passes_efi','shots_efi')} for r in p if r['reference_appeared']=='0']
    audit['global_calendar']={}
    fixtures=json.loads(gzip.decompress((P.parent/'raw/worldcup2025.gz').read_bytes()))['Results']; ids={r['IdMatch'] for r in fixtures}
    win=J(P/'global-calendar.json');days=0;byid=set();exact_time_other=0;counterexamples=[];venues=0
    for d in win:
        day=d['kickoff'][:10];raw=(P/'sources/calendar-alternate'/(day.replace('-','')+'-day.json')).read_bytes()
        assert d['status']==200 and not d['continuation'] and sha(raw)==d['sha256']
        rows=J(P/'sources/calendar-alternate'/(day.replace('-','')+'-day.json'))['Results'];assert d['rows']==len(rows)<500
        byid.update(z['IdMatch'] for z in rows if z['IdMatch'] in ids);days+=len(rows)
        assert all(c['match'] in ids for c in d['candidates'])
        for f in fixtures:
            if f['Date'][:10]!=day:continue
            for z in rows:
                if z['IdMatch'] in ids:continue
                if z['Date']==f['Date']:
                    exact_time_other+=1
                    if (z['HomeTeamScore'],z['AwayTeamScore'])==(f['HomeTeamScore'],f['AwayTeamScore']):
                        counterexamples.append([f['MatchNumber'],z['IdMatch'],z['Home']['TeamName'][0]['Description'],z['Away']['TeamName'][0]['Description']])
                if (z.get('Stadium') or {}).get('IdStadium')==f['Stadium']['IdStadium'] or 'club world cup' in str(z['CompetitionName']).lower():venues+=1
    audit['global_calendar']=dict(days=len(win),returned_rows=days,recovered_native=check('global matches',len(byid),63),additional_name_or_abbreviation_matches=0,additional_venue_or_competition_name_matches=check('venues',venues,0),
         other_pairs_same_kickoff=exact_time_other,other_pairs_same_kickoff_and_score=counterexamples)
    assert len(byid)==63 and days==1189 and len(win)==23 and len(counterexamples)==2
    candidate_path=P.parent/'identites/private-candidates.csv'
    if candidate_path.exists():
        candidate={(r['fifa_team'],r['fifa_player']) for r in csv.DictReader(candidate_path.open()) if r['candidate']}
        cand=[r for r in a if (r['side'],r['fifa_player']) in candidate]
        audit['cross_previous_identity_audit']=dict(source_sha256=sha(candidate_path.read_bytes()),people=len(candidate),appearances=len(cand),outside_m21=sum(r['number']!='21' for r in cand),gk_appearances=sum(r['fdp_position']=='GK' for r in cand),no_new_identity_approval=True)
    audit['scope']='2025 FIFA Club World Cup tournament proper only'
    (P/'summary.json').write_text(json.dumps(audit,ensure_ascii=False,indent=2)+'\n')
    print('verified',len(m),len(s),len(a),len(keep),audit['global_calendar']['returned_rows'])
if __name__=='__main__':main()
