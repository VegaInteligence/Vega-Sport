#!/bin/sh
set -eu
cd "$(dirname "$0")"
export PYTHONDONTWRITEBYTECODE=1
python3 collect.py
python3 collect-fdp.py
python3 calendar-windows.py
python3 qualify.py
python3 verify.py
