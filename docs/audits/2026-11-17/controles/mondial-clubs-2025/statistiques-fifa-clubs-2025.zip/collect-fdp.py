"""Wikimedia pages locate documents. The match number is read from the official PDF."""
from collections import defaultdict
from concurrent.futures import ThreadPoolExecutor
import json, os, re, shutil, subprocess
from pathlib import Path
from collect import P, get, links

FALLBACK = Path.home()/'.cache/codex-runtimes/codex-primary-runtime/dependencies/native/poppler/poppler/bin/pdftotext'
PD = os.getenv('PDFTOTEXT') or shutil.which('pdftotext') or str(FALLBACK)
def extract(src, target):
    target.parent.mkdir(parents=True, exist_ok=True)
    subprocess.run([PD, '-layout', src, target], check=True, capture_output=True)

def main():
    origins=defaultdict(list)
    for suffix in [f'Group_{x}' for x in 'ABCDEFGH']+['knockout_stage']:
        url='https://en.wikipedia.org/wiki/2025_FIFA_Club_World_Cup_'+suffix
        part='discovery/wiki-'+suffix+'.html'
        r=get(part,url,'discovery_index_only')
        assert r['status']==200,(suffix,r)
        for u in sorted(set(links((P/'sources'/part).read_text()))):
            if re.fullmatch(r'https://fdp\.fifa\.org/assetspublic/ce233/r\d+/pdf/FullTimeMatchReport-English\.pdf',u):origins[u].append(suffix)
    def collect(url):
        key=url.split('/')[-3]
        dest=f'fdp/by-id/{key}.pdf';target=P/'lecture/fdp/by-id'/f'{key}.txt'
        q=get(dest,url,'fifa_full_time_report')
        assert q['status']==200,(url,q['status'])
        extract(P/'sources'/dest,target)
        first=target.read_text().split('\f')[0]
        m=re.search(r'#\s*(\d+)\s*\|\s*([\w ]+ 2025)\s*\|',first)
        assert m,(url,first[:450])
        return dict(number=int(m[1]),date=m[2],id=key,url=url,sha256=q['sha256'],locator=origins[url])
    with ThreadPoolExecutor(max_workers=3) as executor:
        items=sorted(executor.map(collect,origins),key=lambda x:x['number'])
    (P/'fdp-index.json').write_text(json.dumps(items,indent=2,ensure_ascii=False)+'\n')
    print(f'{len(items)} unique URL, {len(set(i["number"] for i in items))} match numbers')
    print('missing',sorted(set(range(1,64))-{i['number'] for i in items}))
    for e in sorted((P/'sources/efi').glob('M*.pdf')):
        extract(e,P/'lecture/efi'/e.with_suffix('.txt').name)
if __name__=='__main__': main()
