"""Strict zip with Python 3.9 support."""
from builtins import zip as builtin_zip
from itertools import zip_longest


def zip(*iterables, strict=False):
    if not strict:
        yield from builtin_zip(*iterables)
        return
    missing = object()
    for values in zip_longest(*iterables, fillvalue=missing):
        if any(value is missing for value in values):
            raise ValueError("zip arguments have different lengths")
        yield values
