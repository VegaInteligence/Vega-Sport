# Rejeu hors réseau de la couverture Elo du 18 novembre 2026

Depuis le dossier extrait, exécuter `python3 -B verifier.py` avec Python 3.9 ou ultérieur. Le vérificateur utilise la bibliothèque standard. Ses calculs s’effectuent dans un répertoire temporaire et contrôlent les empreintes de tous les fichiers extraits.

Le paquet porte sur la transaction RDS de 17:53:27 UTC, qui reprend les 44 requêtes exactes de référence, et sur les preuves complémentaires scellées. Il reconstitue 6 447 lignes de couverture et les comparaisons par compétition, saison et entité. Il vérifie aussi la population du run Elo #2099 sur 82 593 rencontres et 165 186 côtés et la couverture des 1 388 côtés sur 19 éditions. Les résultats de lecture Lambda, CloudFront et Vercel sont fournis avec leurs ETags.

Les captures complémentaires distinguent les 235 lignes nationales, dont 153 nommées, 54 emplacements de tirage et 28 redirections, ainsi que les deux rosters indépendants de la Ligue des nations (48 rencontres et 16 équipes, puis 108 et 38). Les dates des deux captures sont préservées séparément.

Les archives de l’incident contiennent uniquement les deux captures binaires utiles à la comparaison des 35 rencontres, 35 anciennes clés et 70 anciens côtés Elo. Le vérificateur distingue leur état actuel en production des résultats d’opérateur obtenus sur PostgreSQL 18 local. Le lecteur hors réseau contrôle ces reçus et les deux ledgers cumulés à 150. Il rejoue les lectures sauvegardées et les calculs de couverture sans relancer le serveur, le worker ni une restauration.

`INVENTAIRE.json` donne le membre exact, sa provenance relative à l’audit, sa taille, son SHA-256 et les adaptations de portabilité. Les anciens liens `reference-1555`, `releve-1705` et `reference-1705` ont été matérialisés en fichiers réguliers. Seuls les fichiers SQL, résultats, reçus, scripts et grilles requis sont inclus. Les script Python de vérification emploient un adaptateur de `zip(..., strict=True)` pour Python 3.9 et vérifient le contenu décompressé pour tolérer les différences d’en-tête gzip entre versions.
