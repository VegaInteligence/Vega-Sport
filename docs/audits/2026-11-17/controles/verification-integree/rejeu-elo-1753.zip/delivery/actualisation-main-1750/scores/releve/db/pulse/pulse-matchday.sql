WITH ids AS (
    SELECT n AS id FROM generate_series(8049,8060) n
    UNION ALL SELECT n FROM generate_series(8290,8301) n
    UNION ALL SELECT n FROM generate_series(8534,8544) n
)
SELECT i.id,
       (SELECT jsonb_agg(jsonb_build_object('id',m.id,'season',m.season_id,'edition',m.competition_season_id,'status',m.status,'source',m.source,'home_id',m.home_team_id,'away_id',m.away_team_id,'home_score',m.home_score,'away_score',m.away_score,'date',m.match_date,'revision',m.revision) ORDER BY m.season_id) FROM core.matches m WHERE m.id=i.id) AS matches,
       (SELECT jsonb_agg(jsonb_build_object('id',p.entity_id,'key',p.provider_key,'current',p.is_current) ORDER BY p.provider_key) FROM core.provider_ids p WHERE p.entity_type='match' AND p.provider='open_matchday' AND p.entity_id=i.id) AS provider_ids,
       (SELECT jsonb_agg(jsonb_build_object('team_id',t.team_id,'run_id',t.run_id,'season_id',t.season_id,'elo_before',encode(float4send(t.elo_before),'hex'),'elo_after',encode(float4send(t.elo_after),'hex'),'expected',encode(float4send(t.expected),'hex'),'result',encode(float4send(t.result),'hex'),'stakes',encode(float4send(t.stakes),'hex')) ORDER BY t.team_id) FROM agg.team_elo t WHERE t.match_id=i.id) AS elo
FROM ids i ORDER BY i.id
