from archive_compat import zip
"""Repeat the 44-query proof and re-create the current score grids without AWS or SQL execution."""
from collections import Counter, defaultdict
import csv
import gzip
import json
from pathlib import Path
import shutil
import subprocess
import sys
from tempfile import TemporaryDirectory

from comparer import capture_validation

ROOT = Path(__file__).resolve().parent


def run(*args):
    subprocess.run([sys.executable, '-B', *(str(x) for x in args)], check=True)


def compare_generated(out, sealed, names):
    for name in names:
        assert (out/name).read_bytes() == (sealed/name).read_bytes(), name


def group_edition_grid():
    with gzip.open(ROOT/'actuel/scores-par-edition.csv.gz','rt',encoding='utf-8') as stream:
        grid = list(csv.DictReader(stream))
    keys = ('competition_id','competition','season_id','season','entity_type')
    metrics = ('recorded_matches','finished','expected_algorithm','actual_valid','missing_from_storage','role_unavailable')
    summary = defaultdict(Counter)
    for row in grid:
        group = summary[tuple(row[k] for k in keys)]
        group['editions'] += 1
        for metric in metrics:
            group[metric] += int(row[metric] or 0)
    with (ROOT/'scores-par-competition-saison-et-entite.csv').open('w', newline='') as destination:
        writer = csv.DictWriter(destination, fieldnames=(*keys,'editions',*metrics), lineterminator='\n')
        writer.writeheader()
        for key,counters in sorted(summary.items()):
            metrics_row = dict(counters)
            if key[-1] != 'player':
                metrics_row['role_unavailable'] = ''
            writer.writerow({**dict(zip(keys,key,strict=True)), **metrics_row})
    return len(summary)


def main():
    old, new = (capture_validation(ROOT/name) for name in ('releve-1705','releve'))
    origin = capture_validation(ROOT/'reference-1555')
    assert len(origin['query_sha256']) == 44
    assert all(origin['query_sha256'][name] == old['query_sha256'][name] == new['query_sha256'][name] for name in origin['query_sha256'])
    assert old['inputs'] == new['inputs'] == origin['inputs']
    with TemporaryDirectory(prefix='vega-elo-1750-') as tmp:
        root = Path(tmp)
        raw = root/'rds'
        shutil.copytree(ROOT/'releve', raw)
        run(raw/'scores/build-score-grid.py')
        run(raw/'verify_grid.py')
        compare_generated(raw/'scores', ROOT/'releve/scores', ('coverage-by-edition-and-entity.csv','coverage-by-season-and-entity.csv','grid-validation.json'))
        run(ROOT/'calculer.py',raw,root/'actuel')
        for filename in ('scores-par-edition.csv.gz','scores-par-saison.csv.gz'):
            assert gzip.decompress((root/'actuel'/filename).read_bytes()) == gzip.decompress((ROOT/'actuel'/filename).read_bytes()), filename
        results = [json.loads((p/'actuel/resultats.json').read_bytes()) for p in (root,ROOT)]
        for result in results:
            result.pop('output_sha256')
        assert results[0] == results[1]
        run(ROOT/'comparer.py',ROOT/'releve-1705',raw,ROOT/'reference-1705',root/'actuel',root/'comparaison')
        compare_generated(root/'comparaison',ROOT/'comparaison',[p.name for p in (ROOT/'comparaison').iterdir()])
    print(json.dumps({'identical_original_queries':44,'current_transaction_queries':len(new['query_sha256']),
                      'competition_season_entity_rows':group_edition_grid(),'status':'pass'}))


if __name__=='__main__':
    main()
