"""Read the exact Elo run metadata and collision candidates for the signed incident."""
def collect(db):
    queries = {
        "run_rows": """SELECT to_jsonb(r) AS run FROM agg.power_runs r WHERE r.id=2097 OR (r.kind='elo' AND r.season_id IS NULL AND r.status='published') ORDER BY r.id""",
        "matchday_candidates": """WITH witnessed(id,home,away,day,provider_key) AS (VALUES (8049,2552,2558,DATE '2026-08-31','ENG_6_national-league-north:2026/2027:2026-08-31|AFC Telford|Bedford'),(8050,2566,2546,DATE '2026-08-31','ENG_6_national-league-north:2026/2027:2026-08-31|Buxton|Merthyr Town'),(8051,2607,5548,DATE '2026-08-31','ENG_6_national-league-north:2026/2027:2026-08-31|Chester|Morecambe'),(8052,2557,2559,DATE '2026-08-31','ENG_6_national-league-north:2026/2027:2026-08-31|Chorley|Brackley Town'),(8053,2580,2590,DATE '2026-08-31','ENG_6_national-league-north:2026/2027:2026-08-31|Harborough|Marine'),(8054,3386,2589,DATE '2026-08-31','ENG_6_national-league-north:2026/2027:2026-08-31|King’s Lynn|Scarborough'),(8055,2588,3387,DATE '2026-08-31','ENG_6_national-league-north:2026/2027:2026-08-31|Macclesfield|Hebburn Town'),(8056,3388,2593,DATE '2026-08-31','ENG_6_national-league-north:2026/2027:2026-08-31|Radcliffe|Darlington'),(8057,2567,2565,DATE '2026-08-31','ENG_6_national-league-north:2026/2027:2026-08-31|South Shields|Spalding United'),(8058,3389,3390,DATE '2026-08-31','ENG_6_national-league-north:2026/2027:2026-08-31|Southport|Hereford'),(8059,2606,3391,DATE '2026-08-31','ENG_6_national-league-north:2026/2027:2026-08-31|Spennymoor|Hednesford'),(8060,2551,2596,DATE '2026-08-31','ENG_6_national-league-north:2026/2027:2026-08-31|Worksop|Oxford City'),(8290,3392,2532,DATE '2026-09-05','ENG_6_national-league-south:2026/2027:2026-09-05|AFC Totton|Hampton & Richmond'),(8291,3393,2535,DATE '2026-09-05','ENG_6_national-league-south:2026/2027:2026-09-05|Billericay|Dorking'),(8292,2560,2602,DATE '2026-09-05','ENG_6_national-league-south:2026/2027:2026-09-05|Chelmsford|Salisbury'),(8293,2579,3394,DATE '2026-09-05','ENG_6_national-league-south:2026/2027:2026-09-05|Dover|Maidenhead'),(8294,2537,2613,DATE '2026-09-05','ENG_6_national-league-south:2026/2027:2026-09-05|Farnborough|Tonbridge'),(8295,2550,2539,DATE '2026-09-05','ENG_6_national-league-south:2026/2027:2026-09-05|Hemel Hempstead|Farnham'),(8296,2599,2533,DATE '2026-09-05','ENG_6_national-league-south:2026/2027:2026-09-05|Horsham FC|Dag & Red'),(8297,2543,2548,DATE '2026-09-05','ENG_6_national-league-south:2026/2027:2026-09-05|Maidstone|Weston-super-Mare'),(8298,3395,2527,DATE '2026-09-05','ENG_6_national-league-south:2026/2027:2026-09-05|Slough|Braintree'),(8299,2614,3396,DATE '2026-09-05','ENG_6_national-league-south:2026/2027:2026-09-05|Torquay|Folkestone'),(8300,2545,2570,DATE '2026-09-05','ENG_6_national-league-south:2026/2027:2026-09-05|Truro|Chesham'),(8301,3397,2573,DATE '2026-09-05','ENG_6_national-league-south:2026/2027:2026-09-05|Walton & Hersham|Ebbsfleet'),(8534,3411,3412,DATE '2026-08-31','ENG_7_northern-premier-league:2026/2027:2026-08-31|Curzon Ashton|Ashton Utd'),(8535,3408,2576,DATE '2026-08-31','ENG_7_northern-premier-league:2026/2027:2026-08-31|Emley|Guiseley'),(8536,2620,3400,DATE '2026-08-31','ENG_7_northern-premier-league:2026/2027:2026-08-31|FC United|Avro'),(8537,2541,3413,DATE '2026-08-31','ENG_7_northern-premier-league:2026/2027:2026-08-31|Gainsborough|Cleethorpes'),(8538,3403,2562,DATE '2026-08-31','ENG_7_northern-premier-league:2026/2027:2026-08-31|Hyde|Bury'),(8539,3404,3405,DATE '2026-08-31','ENG_7_northern-premier-league:2026/2027:2026-08-31|Ilkeston|Quorn'),(8540,3414,3409,DATE '2026-08-31','ENG_7_northern-premier-league:2026/2027:2026-08-31|Lancaster|Workington'),(8541,3401,3407,DATE '2026-08-31','ENG_7_northern-premier-league:2026/2027:2026-08-31|Stockton|Redcar Athletic'),(8542,3399,3402,DATE '2026-08-31','ENG_7_northern-premier-league:2026/2027:2026-08-31|Warrington Rylands|Bamber Bridge'),(8543,3406,3398,DATE '2026-08-31','ENG_7_northern-premier-league:2026/2027:2026-08-31|Whitby|Alfreton'),(8544,3410,2591,DATE '2026-09-01','ENG_7_northern-premier-league:2026/2027:2026-09-01|Leek|Warrington'))
            SELECT w.id, w.provider_key,
                (SELECT array_agg(m.id ORDER BY m.id) FROM core.matches m WHERE m.id=w.id OR
                    (m.match_date=w.day AND ((m.home_team_id,m.away_team_id)=(w.home,w.away) OR (m.home_team_id,m.away_team_id)=(w.away,w.home)))) AS physical_candidates,
                (SELECT jsonb_agg(jsonb_build_object('provider',p.provider,'provider_key',p.provider_key,'entity_id',p.entity_id,'is_current',p.is_current)
                  ORDER BY p.provider,p.provider_key) FROM core.provider_ids p
                    WHERE p.entity_type='match' AND (p.entity_id=w.id OR (p.provider='open_matchday' AND p.provider_key=w.provider_key))) AS key_candidates
            FROM witnessed w ORDER BY w.id""",
        "saudi_fixture": """SELECT m.id,api.public_id('match',m.id) AS public_id,m.status::text,m.match_date::text,m.updated_at,
                   m.home_team_id,m.away_team_id,m.home_team_name,m.away_team_name,m.home_score,m.away_score,m.source::text,
                   p.provider_key
            FROM core.matches m LEFT JOIN LATERAL
                  (SELECT provider_key FROM core.provider_ids p WHERE p.entity_type='match' AND p.provider='pitchapi' AND p.entity_id=m.id AND p.is_current LIMIT 1) p ON true
            WHERE m.competition_season_id=28 AND m.updated_at>'2026-11-18 17:05:26.592852+00'::timestamptz
             AND m.status='finished' ORDER BY m.updated_at DESC LIMIT 10""",
    }
    with db.transaction():
        db.execute("SET TRANSACTION ISOLATION LEVEL REPEATABLE READ READ ONLY")
        db.execute("SET LOCAL TIME ZONE 'UTC'")
        db.execute("SET LOCAL statement_timeout='25s'")
        at,snap,readonly=db.execute("SELECT transaction_timestamp(),pg_current_snapshot()::text,current_setting('transaction_read_only')").fetchone()
        assert readonly == "on"
        result={}
        for name,query in queries.items():
            cur=db.execute(query)
            rows=cur.fetchall()
            assert len(rows)<100,name
            result[name]={"columns":[x.name for x in cur.description],"rows":rows}
        return {"at":at,"snapshot":snap,"readonly":readonly,"result":result}
