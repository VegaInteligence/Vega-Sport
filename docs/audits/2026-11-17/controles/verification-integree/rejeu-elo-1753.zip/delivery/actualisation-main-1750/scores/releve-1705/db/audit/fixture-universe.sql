-- Fixture ownership in core.matches. Archive-ready counts remain outside the Elo gate.
SELECT
 m.source::text AS source,
 m.competition_season_id AS edition_id,
 count(*) AS recorded,
 count(*) FILTER (WHERE m.status = 'finished') AS finished,
 count(*) FILTER (WHERE m.status = 'finished' AND m.home_score IS NOT NULL AND m.away_score IS NOT NULL) AS finished_scored,
 count(*) FILTER (WHERE m.status = 'finished' AND m.home_score IS NOT NULL AND m.away_score IS NOT NULL
  AND m.home_team_id IS NOT NULL AND m.away_team_id IS NOT NULL) AS finished_scored_both_teams,
 count(*) FILTER (WHERE cs.archive_key IS NOT NULL) AS archive_recorded,
 count(*) FILTER (WHERE cs.archive_key IS NOT NULL AND m.status = 'finished'
  AND m.home_score IS NOT NULL AND m.away_score IS NOT NULL
  AND m.home_team_id IS NOT NULL AND m.away_team_id IS NOT NULL) AS archive_finished_scored_both_teams
FROM core.matches m
JOIN core.competition_seasons cs ON cs.id = m.competition_season_id AND cs.season_id = m.season_id
GROUP BY GROUPING SETS ((m.source), (m.source,m.competition_season_id))
ORDER BY 1,2 NULLS FIRST
