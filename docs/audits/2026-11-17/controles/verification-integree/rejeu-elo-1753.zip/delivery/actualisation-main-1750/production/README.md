# Révisions effectivement servies et publication des sélections

Le 18 novembre 2026 à 17:53 UTC, GitHub `main` et l’alias de production `vegasport.vercel.app` pointaient sur `e60e80860e6ad1cfa9f330a4b2c2ce66eb9ef35a`. Le déploiement Vercel `dpl_Bk8YQVmy9GVUnAhm98ae7wa5MHrN` était `READY`. GitHub ne retourne aucun run Actions filtré sur ce commit lui-même. Le commit précédent `30b04f1239` a son run CI réussi `44359340303`. [GitHub](github-main.json) · [Autorité Vercel](vercel-deployment.json) · [Runs GitHub](github-actions-recent.json)

À 18:03 UTC, GitHub `main` et l’alias de production pointent sur `1c5a4340d193d2ffd1406f965e4007fdfb6b97fb`, déploiement `dpl_FH3S2zbdZivSAo9vCXkoaKZqp3RH`, `READY`. Les trois commits intervenus modifient le frontend des tableaux, des tests correspondants et le journal. [GitHub à 18:03](github-main-recheck.json) · [Vercel à 18:03](vercel-recheck.json) · [Fichiers Git comparés](github-vercel-diff.json)

Le worker ECS `vega-v2-worker:143` observé actif utilise le commit `b2e6dd82d36a2ca0f439ec84bf2e5dbbcd3013d9`, digest `sha256:8ecb6624e75135f2e741146fd160fe756e7478a2d18fd1139c16b28c817c67e5`. Son déploiement GitHub `44351541140` s’est terminé avec succès à 16:57:51 UTC. Le Lambda `vega-v2-api` est actif avec le CodeSha256 `rrXidCMW2nHD70WCaIyXWq11mYRQqTjaQufyhcsrcUE=` depuis le 17 novembre à 16:02 UTC. La qualification AWS et celle du frontend reposent sur des autorités séparées. [Worker](worker-running.json) · [Lambda](lambda.json) · [Déploiement GitHub du worker](github-actions-aws.json)

## Valeurs lues par l’application

Les relevés Lambda IAM direct, CloudFront et Vercel concordent sur le classement 2026/2027. Le lecteur de puissance publie `power-ranking-v8`, calculé à 17:16:04.503 UTC. Chaque surface retourne 200 sur les trois trajets échantillonnés et 304 avec l’ETag courant. Les trois anciens ETags de la France conduisent à une nouvelle réponse 200. [Reçu HTTP](reader-observations.json) · [Comparaison](observation.json)

| Sélection | Elo au relevé antérieur | Elo à 17:54 | Rang |
| --- | ---: | ---: | --- |
| Espagne | 1 707,53 | 1 745,41 | 1 → 1 |
| Angleterre | 1 681,09 | 1 699,80 | 2 → 2 |
| France | 1 668,46 | 1 691,44 | 3 → 3 |
| Pays-Bas | 1 581,09 | 1 652,57 | 8 → 4 |

La série France passe de 57 à 97 points. La nouvelle série commence le 13 juillet 1930. L’index expose toujours 153 sélections nommées et 54 classées. Ces mesures de lecture portent sur l’API au moment du premier déploiement relevé.

À 17:56:33 UTC, RDS confirme le run Elo global #2099 publié à 17:16:04.503585 UTC, 82 593 rencontres et 165 186 côtés Elo stockés sur ce run, deux par rencontre. Les 70 côtés des 35 rencontres Open Matchday supprimées en sont absents. À 18:00:16 UTC, les 35 IDs, clés et paires/date ne produisent aucun candidat, et le run #2097 correspond exactement au relevé scellé une fois son statut passé à `superseded`. [Matrice des états de rencontre](rencontres-par-competition-saison-source-et-etat.csv) · [Reçu RDS du run et des états](outcomes/receipt.json) · [Ancien run et clés](matchday-current/observations.json)

```sh
python3 -B verify.py
(cd matchday-current && python3 -B verify.py)
```

Les commandes hors ligne utilisent les relevés précédents dans le dossier `actualisation-main-1633`. Les sondes en ligne sont des transactions `REPEATABLE READ READ ONLY`, avec une définition de tâche éphémère désactivée après le relevé. [SQL de publication](probe.py) · [SQL des clés et des collisions](matchday-current/probe.py)
