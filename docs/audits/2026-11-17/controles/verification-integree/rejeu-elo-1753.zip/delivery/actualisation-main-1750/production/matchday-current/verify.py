from archive_compat import zip
"""Verify signed incident keys and the superseded Elo run against the current observation."""
from hashlib import sha256
import json
from pathlib import Path
import zlib

HERE = Path(__file__).resolve().parent
ARTIFACT_ROOT = HERE.parents[3]
ZIP_SHA256 = 'e850dd9ebc33dfad5c71b93090fb2d4b3c9c4dfea73296e2278fa13f29f3d71d'


def main():
    package = ARTIFACT_ROOT/'delivery/preuve-matchday/apres.zlib'
    assert sha256(package.read_bytes()).hexdigest()==ZIP_SHA256
    previous = json.loads(zlib.decompress(package.read_bytes()))
    raw = (HERE/'exact/inputs.json.zlib').read_bytes()
    rec = json.loads((HERE/'exact/receipt.json').read_bytes())
    current = json.loads(zlib.decompress(raw))
    assert sha256(raw).hexdigest()==rec['sha256']
    assert current['readonly']=='on' and rec['exit_code']==0 and rec['definition_end_state']=='INACTIVE'
    run_table = current['result']['run_rows']['rows']
    [previous_now], [latest] = run_table
    previous_elo, = map(json.loads,previous['reads']['elo_runs']['rows_json'])
    assert previous_now == {**previous_elo, 'status':'superseded'}
    assert latest['id']==2099 and latest['kind']=='elo' and latest['season_id'] is None and latest['status']=='published'
    candidates = current['result']['matchday_candidates']['rows']
    assert [x[0] for x in candidates] == [p[0] for p in previous['witnesses']]
    assert [x[1] for x in candidates] == previous['provider_keys']
    assert len(candidates)==35 and all(x[2:]==[None,None] for x in candidates)
    saudi = current['result']['saudi_fixture']
    raw_fixture, = saudi['rows']
    fixture = dict(zip(saudi['columns'],raw_fixture,strict=True))
    received = json.loads((HERE/'observations.json').read_bytes())
    expected = {'at':current['at'],'old_run_exact_after_supersession':True,'fields_differing':{},'latest':latest,
                'physical_pair_or_key_collisions':0,'scoped_matchday_candidates':35,'saudi_fixture':fixture}
    assert received==expected
    print(f"Relevé {current['at']} · 35 / 35 sans collision · run 2097 vérifié · match {fixture['public_id']}")


if __name__=='__main__':
    main()
