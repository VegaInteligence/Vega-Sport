"""Read Elo publication activity and exact fixture state counts from production."""
def collect(db):
    queries = {
        "run": """SELECT id,kind,status,started_at,finished_at,matches,method_version
                  FROM agg.power_runs WHERE kind='elo' ORDER BY id DESC LIMIT 6""",
        "elo_by_run_kind": """SELECT e.run_id,t.is_national IS TRUE AS national,count(*) AS stored_sides,
                    count(DISTINCT e.match_id) AS distinct_matches,
                    count(*) FILTER(WHERE e.match_id IN (SELECT x FROM generate_series(8049,8060) x
                       UNION ALL SELECT x FROM generate_series(8290,8301) x UNION ALL SELECT x FROM generate_series(8534,8544) x)) AS incident_sides
                  FROM agg.team_elo e JOIN core.teams t ON t.id=e.team_id GROUP BY 1,2 ORDER BY 1,2""",
        "published_rows": """SELECT run_id,count(*) AS all_sides, count(DISTINCT match_id) AS matches,
                    count(*) FILTER (WHERE n<>2) AS sides_off_pair
                  FROM (SELECT run_id,match_id,count(*) OVER(PARTITION BY match_id) AS n FROM agg.team_elo) r GROUP BY 1 ORDER BY 1""",
        "states_by_competition_season": """SELECT c.id AS competition_id, c.name AS competition,s.id AS season_id, s.label AS season,
                 m.source::text,m.status::text,count(*) AS fixtures,
                 count(*) FILTER (WHERE m.home_score IS NOT NULL AND m.away_score IS NOT NULL) AS scored
                 FROM core.matches m JOIN core.competition_seasons cs ON (cs.id,cs.season_id)=(m.competition_season_id,m.season_id)
                 JOIN core.competitions c ON c.id=cs.competition_id JOIN core.seasons s ON s.id=m.season_id
                 GROUP BY 1,2,3,4,5,6 ORDER BY 1,3,5,6""",
    }
    with db.transaction():
        db.execute("SET TRANSACTION ISOLATION LEVEL REPEATABLE READ READ ONLY")
        db.execute("SET LOCAL TIME ZONE 'UTC'")
        db.execute("SET LOCAL statement_timeout='25s'")
        at,snap,readonly=db.execute("SELECT transaction_timestamp(),pg_current_snapshot()::text,current_setting('transaction_read_only')").fetchone()
        assert readonly == "on"
        result={}
        for name,query in queries.items():
            cur=db.execute(query)
            rows=cur.fetchall()
            assert len(rows)<10000,name
            result[name]={"columns":[x.name for x in cur.description],"rows":rows}
        return {"at":at,"snapshot":snap,"readonly":readonly,"result":result}
