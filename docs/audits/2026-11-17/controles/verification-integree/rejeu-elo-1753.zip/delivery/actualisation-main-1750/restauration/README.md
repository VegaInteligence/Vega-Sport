# Restauration opérateur sur copie, schéma 150

Le commit applicatif exact `39e6272bd0deb948ec944384fdecea07c5f41280` a été archivé depuis Git et exécuté hors du worktree, sur PostgreSQL 18.6 local au port 55459. Les deux chemins partent d’un schéma 133 ou de main avec `134_archive_scores_due.sql` déjà exécuté. Le vrai migrateur aboutit à `150_sportscore_standings_quarantine.sql` avec 151 fichiers SQL et les deux 134. Les deux captures source reproduisent les 133 empreintes historiques. Les huit refus de version ou d’empreinte passent sur chaque chemin. [Reçu exact](real150b/receipt.json) · [Commande et journal](real150b.log)

Sur chaque copie du témoin antérieur, les 35 matchs et leurs 35 clés correspondent exactement à la préimage, avec les 70 anciens Elo #2097 et leurs cinq flottants conservés bit pour bit. La simulation n’écrit rien. L’application invalide les trois lectures d’édition. La répétition écrit zéro ligne et les trois ETags rendent 304. Les finales Italie 1982 et France 1998 se lisent à 3–1 et 0–3 et comme « Vainqueur ». La deuxième collecte des éditions et la répétition des migrations sont stables. Le premier lancement a été interrompu avant le semis par une pièce de préparation absente du dossier. La pièce a été recopiée du harnais approuvé et le rejeu complet part d’une nouvelle copie. [Premier journal](real150.log) · [Ledger depuis 133](real150b/a/verified-ledger.json) · [Ledger depuis main 134](real150b/b/verified-ledger.json)

## Après la publication #2099

La production est au schéma 134. La lecture RDS du run confirme que le #2097 signé correspond encore exactement, hormis le statut `superseded`. Le #2099 global est complet sur 82 593 rencontres et 165 186 côtés, tous rattachés au même run. Les 35 IDs et clés restent absents et la lecture ciblée ne trouve aucune collision sur les dates et paires signées. Aucun des 70 côtés Elo antérieurs ne reste stocké. Cette preuve porte sur la condition Elo et les collisions inspectées. La procédure d’écriture opérateur requiert à son lancement le schéma revu, les captures exactes, les références, les dépendances, la séquence et l’inventaire relus par ses gardes. [Preuve de la publication actuelle](../production/observation.json) · [Preuve ciblée des clés et de #2097](../production/matchday-current/observations.json)

Le cas d’un run récent a été répété sur une copie locale issue du schéma 150 exact. Le témoin utilise le numéro, les horodatages et la version de méthode de #2099 sur une population représentative d’une paire d’Elo étrangère aux 35. Le CLI refuse une population mélangée et un run incomplet. Dans le cas complet, il annonce 35 restaurations et 70 côtés à recalculer, restaure les 35 clés sans toucher à l’Elo et rejoue avec zéro écriture. Aucun recalcul Elo ni aucune restauration n’a été exécuté en production. [Reçu de la simulation #2099](newer2099/receipt.json)

```sh
PYTHONDONTWRITEBYTECODE=1 python3 -B exercise.py --repo "$VEGA_REPO" \
  --revision 39e6272bd0deb948ec944384fdecea07c5f41280 --evidence "$PREUVES" \
  --tag real150b --port 55459 --expected-last 150_sportscore_standings_quarantine.sql
RUNTIME=$(mktemp -d)
git -C "$VEGA_REPO" archive 39e6272bd0deb948ec944384fdecea07c5f41280 -- backend/vega backend/sql | tar -x -C "$RUNTIME"
OPEN_MATCHDAY_REPLAY_PORT=55459 PYTHONDONTWRITEBYTECODE=1 python3 -B newer-publication.py "$RUNTIME" newer2099 --template abareal150b
```

Le premier chemin du harnais laisse une base jouet que le second script clone. Utiliser des tags nouveaux pour un nouveau passage et reporter le tag du premier script à la fin du nom de template `aba<TAG>`. Les sources sportives et les entrées sont celles du ZIP scellé `delivery/preuve-matchday/35-matchs-identites-et-elo.zip` et des deux éditions OpenFootball sous `sources/upstream`. Le scénario de publication réutilise les mêmes captures décompressées dans `delivery/rds-preimage/avant-v3/inputs.json.zlib` et `delivery/rds-preimage/apres-v2/inputs.json.zlib`.
