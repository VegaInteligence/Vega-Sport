from archive_compat import zip
"""Reconcile the 19 repaired editions and the signed 35-match incident on one RDS snapshot."""
from collections import Counter, defaultdict
import csv
from hashlib import sha256
import json
from pathlib import Path
import zlib

from comparer import capture_validation, sql_index, write_csv

HERE = Path(__file__).resolve().parent
E = HERE.parents[2]
PRIOR = HERE.parents[1] / 'actualisation-main-1633/notes-apres-deploiement'
NOW = HERE / 'releve'
BASE = HERE / 'releve-1705'
MID = PRIOR / 'suivi-rds'
SEALED_MATCHDAY = E / 'delivery/preuve-matchday/apres.zlib'
MATCHDAY_SHA = 'e850dd9ebc33dfad5c71b93090fb2d4b3c9c4dfea73296e2278fa13f29f3d71d'
METRICS = ('structurally_admissible','refused_self','refused_folder','matched_copy','expected_sides','stored_valid','missing','invalid',
           'stored_on_excluded_side','wrong_result','invalid_strength_or_probability')


def output(name, value):
    (HERE / name).write_text(json.dumps(value, indent=2, ensure_ascii=False) + '\n')


def pulse(base, name):
    return sql_index(base / 'db/pulse' / f'pulse-{name}.json')


def by_edition(base):
    return {item['edition_id']:item for item in sql_index(base / 'db/team_exact/team-exact.json') if item['entity_type'] == 'national team'}


def main():
    current, before, pre_recompute = map(capture_validation, (NOW, BASE, MID))
    assert before['image_digest'] == pre_recompute['image_digest'] == current['image_digest']
    assert before['inputs'] == pre_recompute['inputs'] == current['inputs']
    assert before['common_snapshot']['at'] < pre_recompute['common_snapshot']['at'] < current['common_snapshot']['at']
    with (PRIOR / 'comparaison/ressources-editions.csv').open() as stream:
        focus = {int(r['edition_id']):r for r in csv.DictReader(stream)}
    assert len(focus) == 19
    marks, old_marks = (pulse(folder, 'marquages') for folder in (NOW, MID))
    ingest, old_ingest = ({r['edition_id']:r for r in pulse(folder,'ingestion')} for folder in (NOW,MID))
    assert focus.keys() == ingest.keys() == old_ingest.keys()
    old, now = map(by_edition, (MID,NOW))
    affected = []
    for i in sorted(focus):
        old_counts = {k:old.get(i,{}).get(k,0) for k in METRICS}
        new_counts = {k:now.get(i,{}).get(k,0) for k in METRICS}
        affected.append({**focus[i], **{f'elo_{k}_before':old_counts[k] for k in METRICS},
                         **{f'elo_{k}_after':new_counts[k] for k in METRICS},
                         **{f'elo_{k}_delta':new_counts[k]-old_counts[k] for k in METRICS},
                         'dirty_scopes_before':sum(r['scopes'] for r in old_marks if r['competition_season_id']==i),
                         'dirty_scopes_after':sum(r['scopes'] for r in marks if r['competition_season_id']==i),
                         'source':ingest[i]['source'],'last_success_before':old_ingest[i]['last_success_at'],
                         'last_success_after':ingest[i]['last_success_at'],'last_attempt_after':ingest[i]['last_attempt_at'],
                         'source_run_status':ingest[i]['status'],'source_rows_written':ingest[i]['rows_written'],
                         'last_cup_updated':ingest[i]['cup_updated_at']})
    write_csv(HERE/'19-editions.csv',affected,tuple(affected[0]))
    sealed = SEALED_MATCHDAY.read_bytes()
    assert sha256(sealed).hexdigest() == MATCHDAY_SHA
    after_incident=json.loads(zlib.decompress(sealed))
    sports={item[0]:item for item in after_incident['witnesses']}
    old_keys={item[0]:key for item,key in zip(after_incident['witnesses'],after_incident['provider_keys'],strict=True)}
    old_elo={(mid,team):fields for mid,team,fields in after_incident['reads']['elo_float_bits']['rows']}
    incident=pulse(NOW,'matchday')
    assert set(sports)=={r['id'] for r in incident} and len(old_keys)==35 and len(old_elo)==70
    outcome=Counter()
    interesting=[]
    for item in incident:
        i=item['id']
        matches,keys,elo=(item[field] or [] for field in ('matches','provider_ids','elo'))
        outcome['physical_matches']+=len(matches)
        outcome['physical_keys']+=len(keys)
        outcome['elo_sides']+=len(elo)
        for row in matches:
            fact=[row[k] for k in ('id','home_id','away_id','date','home_score','away_score','edition')]
            outcome['matches_exact']+=int(fact==sports[i] and row['status']=='finished' and row['source']=='open_matchday')
        outcome['physical_keys_exact']+=sum(key['key']==old_keys[i] and key['current'] for key in keys)
        for row in elo:
            observed={k:row[k] for k in ('elo_before','elo_after','expected','result','stakes')}
            outcome['original_float_bits_equal']+=int(observed==old_elo.get((i,row['team_id'])))
            outcome[f'elo_run_{row["run_id"]}']+=1
        interesting.append({'id':i,'expected_key':old_keys[i],'expected_signed_sporting_fields':sports[i],
                            'matches':matches,'provider_ids':keys,'elo':elo})
    outcome=dict(outcome)
    scope_counts={k:sum(row[f'elo_{k}_{variant}'] for row in affected) for k in METRICS for variant in ('before','after','delta')}
    latest_now=pulse(NOW,'publication')
    latest_pre=pulse(MID,'publication')
    operations={'before':pre_recompute['common_snapshot'],'after':current['common_snapshot'],'elo_runs_before':latest_pre,'elo_runs_after':latest_now,
                'dirty_before':old_marks,'dirty_after':marks,'source_ingestion_before':list(old_ingest.values()),'source_ingestion_after':list(ingest.values()),
                'recent_activity':pulse(NOW,'activite'),'current_migrations':pulse(NOW,'migrations'),'affected_edition_counts':scope_counts,
                'other_national_missing_after':[{k:r[k] for k in ('edition_id','expected_sides','stored_valid','missing','invalid')} for i,r in now.items() if i not in focus and r['missing']],
                'scope_count':len(affected),'incident':{'counts':outcome,'details':interesting,'signed_postimage_sha256':sha256(sealed).hexdigest()}}
    output('elo-and-matchday.json',operations)
    print(json.dumps({'at':current['common_snapshot']['at'],'data_run':latest_now[0],'affected':scope_counts,'dirty':marks,'incident':outcome},ensure_ascii=False))


if __name__=='__main__':
    main()
