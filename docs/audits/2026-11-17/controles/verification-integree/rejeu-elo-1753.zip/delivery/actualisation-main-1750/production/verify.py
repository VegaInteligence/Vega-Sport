from archive_compat import zip
"""Reconcile the three public readers, release authority, and the full Elo publication."""
from collections import Counter
import csv
from hashlib import sha256
import json
from pathlib import Path
import zlib

HERE = Path(__file__).resolve().parent
PREVIOUS = HERE.parents[1] / 'actualisation-main-1633'


def read(path):
    return json.loads(path.read_bytes())


def seal(directory):
    meta = read(directory / 'receipt.json')
    blob = (directory / 'inputs.json.zlib').read_bytes()
    assert meta['exit_code'] == 0 and meta['definition_end_state'] == 'INACTIVE'
    assert meta['sha256'] == sha256(blob).hexdigest()
    source = json.loads(zlib.decompress(blob))
    assert source['readonly'] == 'on'
    return meta, source


def rows(source, key):
    table = source['result'][key]
    return [dict(zip(table['columns'], values, strict=True)) for values in table['rows']]


def main():
    gh = read(HERE / 'github-main.json')
    vercel = read(HERE / 'vercel-deployment.json')
    old_api = read(PREVIOUS / 'production-worker-b2e6/http-receipt.json')['lambda']
    aws_deploy = read(HERE / 'github-actions-aws.json')
    worker, = read(HERE / 'worker-running.json')
    worker_container, = worker['containers']
    main_sha = gh['sha']
    worker_sha = worker_container['image'].rsplit(':', 1)[1]
    lam = read(HERE / 'lambda.json')
    assert vercel['metadata']['sha'] == main_sha and vercel['metadata']['ref'] == 'main' and 'vegasport.vercel.app' in vercel['alias']
    assert vercel['target'] == 'production' and vercel['readyState'] == 'READY'
    latest_gh = read(HERE/'github-main-recheck.json')
    latest_vercel = read(HERE/'vercel-recheck.json')
    release_diff = read(HERE/'github-vercel-diff.json')
    assert latest_gh['sha'] == latest_vercel['sha'] and latest_vercel['readyState']=='READY'
    assert release_diff['status']=='ahead' and release_diff['commits'][-1]['sha']==latest_gh['sha']
    assert all(p=='WORKLOG.md' or p.startswith(('dashboard/frontend/','tests/')) for p in release_diff['files'])
    assert worker['status'] == worker_container['status'] == 'RUNNING'
    assert aws_deploy['conclusion'] == 'success' and aws_deploy['headSha'] == worker_sha
    assert lam['sha'] == old_api['sha'] and lam['revision'] == old_api['revision']
    meta, raw = seal(HERE / 'outcomes')
    assert meta['actual_image_digest'] == worker_container['digest'] and meta['image'] == worker_container['image']
    published, prior, *_ = rows(raw,'run')
    all_data, = rows(raw, 'published_rows')
    per_kind = rows(raw, 'elo_by_run_kind')
    assert published['status'] == 'published' and published['id'] == 2099 and prior['id'] == 2097 and prior['status'] == 'superseded'
    assert all_data['run_id'] == published['id'] and all_data['matches'] == published['matches']
    assert all_data['all_sides'] == all_data['matches']*2 and all_data['sides_off_pair'] == 0
    assert sum(r['stored_sides'] for r in per_kind)==all_data['all_sides'] and sum(r['incident_sides'] for r in per_kind)==0
    status_rows = rows(raw,'states_by_competition_season')
    with (HERE / 'rencontres-par-competition-saison-source-et-etat.csv').open('w', newline='') as out:
        writer = csv.DictWriter(out, fieldnames=tuple(status_rows[0]), lineterminator='\n')
        writer.writeheader()
        writer.writerows(status_rows)
    state_totals = Counter()
    for r in status_rows:
        state_totals[r['status']]+=r['fixtures']
    missing_finished = sum(r['fixtures']-r['scored'] for r in status_rows if r['status']=='finished')
    results = read(HERE / 'reader-observations.json')
    old_index = read(PREVIOUS / 'phases-manquantes/capture/nation-index.json')['data']
    old_france = read(PREVIOUS / 'parcours/http/nation-france.json')['data']
    old_ranks = {n['name']: {'elo':n.get('elo'),'rank':(n.get('ranking') or {}).get('rank')} for n in old_index['nations']}
    public = {}
    for r in results:
        assert r['initial']['status'] == 200 and r['same']['status'] == 304
        assert r['same']['sent_etag'] == r['initial']['headers']['etag']
        if r['surface']=='lambda':
            assert {'x-cache','age'}.isdisjoint(r['initial']['headers'])
        if r['old']:
            assert r['old']['status']==200 and r['old']['headers']['etag'] == r['initial']['headers']['etag']
            assert r['old']['sent_etag'] != r['initial']['headers']['etag']
        public.setdefault(r['witness'],{}).update({r['surface']:r['initial']['projection']})
    for sides in public.values():
        assert set(sides) == {'lambda','cloudfront','vercel'}
        assert sides['lambda'] == sides['cloudfront'] == sides['vercel']
    index = public['nation-index']['lambda']
    new_ranks = {n['name']:{'elo':n['elo'],'rank':n['ranking']['rank']} for n in index['witnesses']}
    france = public['france']['lambda']
    assert new_ranks['Netherlands']['rank']==4 and old_ranks['Netherlands']['rank']==8
    assert france['points']==97 and len(old_france['elo'])==57
    evidence = {'github_main':main_sha, 'vercel_deployment':vercel, 'lambda':lam, 'worker_sha':worker_sha,'worker':worker,
                'aws_deploy':aws_deploy, 'front_followup':{'github':latest_gh,'vercel':latest_vercel,'release_diff':release_diff}, 'readers':{'samples':len(results),'confirmed_old_etag_replacements':3,
                'old_ranks':{name:old_ranks[name] for name in new_ranks},'new_ranks':new_ranks,'old_france_points':len(old_france['elo']),
                'new_france_points':france['points'],'ranking_computed_at':public['nation-power']['lambda']['method']['computedAt']},
                'rds':{'at':raw['at'],'published_run':published,'previous_run':prior,'stored_population':all_data,
                       'stored_by_national_kind':per_kind,'full_fixture_state_rows':len(status_rows),'state_counts':dict(state_totals),
                       'finished_without_scores':missing_finished}}
    (HERE/'observation.json').write_text(json.dumps(evidence,indent=2,ensure_ascii=False)+'\n')
    print(json.dumps(evidence['rds'],ensure_ascii=False))


if __name__=='__main__':
    main()
