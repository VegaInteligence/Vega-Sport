# Couverture des notes après le recalcul Elo

La transaction RDS du 18 novembre 2026 à 17:53:27.125902 UTC reprend à empreinte identique les 44 requêtes du relevé initial. Elle inclut l’inventaire des rencontres et sept lectures opérationnelles. Les modules Elo et identité ont les mêmes empreintes qu’au relevé de 17:05. [Reçu et SQL](releve/receipt.json) · [Rejeu hors ligne](verification.log) · [Comparaison exhaustive](comparaison/comparaison.json)

| Entité | Attendus avant → après | Valides avant → après | Manquants avant → après |
| --- | ---: | ---: | ---: |
| Joueurs | 2 296 998 → 2 297 026 | 2 282 580 → 2 282 608 | 14 418 → 14 418 |
| Clubs, côtés Elo | 161 932 → 161 934 | 161 912 → 161 934 | 20 → 0 |
| Sélections, côtés Elo | 3 252 → 3 252 | 1 864 → 3 252 | 1 388 → 0 |

Les 615 participations au rôle non résolu restent hors de l’attendu joueur. Les 28 notes supplémentaires se trouvent dans l’édition 28, Saudi First Division 2026/2027. Cette édition compte un seul match terminé de plus, `m_4QHczv` / #35220, PitchAPI, 3–3, dernière écriture à 17:15:09 UTC. L’édition ajoute aussi deux côtés Elo club. Les 20 autres côtés Elo club valides supplémentaires se répartissent en +8, +4 et +8 dans les éditions 332, 333 et 334 d’Open Matchday. Ces côtés appartiennent aux rencontres déjà présentes et ne récupèrent aucune des 35 rencontres supprimées. [Diffs par édition](comparaison/ecarts-edition-publiee.csv) · [Identité du match saoudien](../production/matchday-current/observations.json)

Les **1 388 côtés des 19 éditions** sont présents et valides, dont 1 316 sur les 18 éditions OpenFootball et 72 sur le complément Ligue des nations. Les 19 éditions n’ont aucune ligne `dirty_scopes` observée. Les derniers succès d’ingestion restent à 16:54:15 UTC pour OpenFootball et à 16:57:48 UTC pour l’édition 308. Le run Elo #2099 est publié à 17:16:04 UTC. Sept copies de la Coupe du monde 2022 restent exclues par la règle d’admissibilité existante. [Census des 19 éditions](19-editions.csv) · [État RDS, publication et incident](elo-and-matchday.json)

Le périmètre physique contient 588 794 rencontres et 577 189 terminées. Le nombre de terminées sans score reste à 520. Les tables ci-dessous conservent les états physiques et les notions métier de couverture séparément lorsqu’elles se recoupent avec des copies de sources.

- [Scores par compétition, saison et entité](scores-par-competition-saison-et-entite.csv)
- [Tout le détail scores par édition](actuel/scores-par-edition.csv.gz) et [par saison](actuel/scores-par-saison.csv.gz)
- [Comparaison scores par compétition](comparaison/ecarts-competition.csv) et [grille courante](comparaison/scores-par-competition-apres.csv)
- [États réels de rencontre par compétition, saison et source](../production/rencontres-par-competition-saison-source-et-etat.csv)

```sh
python3 -B verifier.py
python3 -B evaluate.py
```

Le vérificateur recrée les grilles et les écarts dans un dossier temporaire, puis vérifie leur égalité octet par octet. Il utilise les trois références 15:55, 17:05 et 17:11 du dossier d’audit existant. La commande de capture historique est `python3 -B capture.py releve` depuis un dossier de preuves dédié, avec l’autorisation de diagnostic correspondante. [Inventaire SQL](releve/db/) · [Transport de la capture](transport.log)
