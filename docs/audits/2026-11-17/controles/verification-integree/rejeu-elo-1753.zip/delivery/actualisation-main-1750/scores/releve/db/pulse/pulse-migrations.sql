SELECT version,encode(checksum,'hex') AS sha256,applied_at
FROM ops.schema_migrations
WHERE version >= '133' ORDER BY version
