SELECT r.source::text, r.scope, r.status, r.last_attempt_at, r.last_success_at, r.rows_written, e.id AS edition_id,
       e.archive_key, e.cup_checked_at, e.cup_updated_at
FROM core.competition_seasons e
LEFT JOIN ops.source_runs r ON r.scope=e.cup_key AND r.source::text IN ('openfootball','international_results')
WHERE e.id BETWEEN 274 AND 290 OR e.id IN (292,308)
ORDER BY e.id
