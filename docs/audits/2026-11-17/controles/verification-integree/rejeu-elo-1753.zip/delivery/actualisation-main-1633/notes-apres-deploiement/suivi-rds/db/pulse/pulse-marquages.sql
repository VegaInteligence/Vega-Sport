SELECT competition_season_id, scope_kind::text, count(*) AS scopes, min(queued_at) AS first_queued,
 max(queued_at) AS last_queued, max(revision) AS revision
FROM ops.dirty_scopes
WHERE competition_season_id BETWEEN 274 AND 290 OR competition_season_id IN (292,308)
GROUP BY 1,2 ORDER BY 1,2
