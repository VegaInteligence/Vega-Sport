SELECT id, kind, status, started_at, finished_at, matches, method_version
FROM agg.power_runs
WHERE kind = 'elo'
ORDER BY started_at DESC, id DESC LIMIT 12
