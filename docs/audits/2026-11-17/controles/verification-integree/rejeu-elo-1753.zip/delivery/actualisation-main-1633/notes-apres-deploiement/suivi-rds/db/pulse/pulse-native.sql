-- Season trigger sees native editions only. Show its temporal predicates for seasons with corrected matches.
WITH last AS (
 SELECT DISTINCT ON (cohort_definition) cohort_definition, started_at FROM agg.calc_runs
 WHERE kind='levels' AND status='published' ORDER BY cohort_definition, started_at DESC
), target AS (
 SELECT DISTINCT season_id FROM core.competition_seasons
 WHERE id BETWEEN 274 AND 290 OR id IN (292,308)
)
SELECT season.season_id,l.started_at AS native_last_levels_start,
       max(m.updated_at) FILTER (WHERE m.status='finished') AS last_native_finished_change,
       bool_or(m.kickoff_at > transaction_timestamp() - interval '30 days'
               AND m.kickoff_at<=transaction_timestamp()) AS native_recent,
       count(m.id) FILTER (WHERE m.status='finished') AS native_finished
FROM target season
LEFT JOIN core.competition_seasons e ON e.season_id=season.season_id AND e.cup_key IS NULL AND e.archive_key IS NULL
LEFT JOIN core.matches m ON m.competition_season_id=e.id AND m.season_id=e.season_id
LEFT JOIN last l ON l.cohort_definition='season:' || season.season_id
GROUP BY 1,2 ORDER BY 1
