-- Only emit category and timing from query visibility for the current DB role.
SELECT application_name, state, query_start, xact_start, wait_event_type,
 CASE WHEN query LIKE '%COPY agg.team_elo%' THEN 'elo-copy'
      WHEN query LIKE '%agg.league_levels%' THEN 'levels'
      WHEN query LIKE '%agg.power_runs%' THEN 'powers'
      WHEN query LIKE '%core.matches%' AND query LIKE '%LIMIT%' THEN 'bounded-matches'
      ELSE 'other' END AS observation
FROM pg_stat_activity
WHERE datname=current_database() AND usename=current_user AND pid<>pg_backend_pid()
  AND state IN ('active','idle in transaction')
ORDER BY 1,3
