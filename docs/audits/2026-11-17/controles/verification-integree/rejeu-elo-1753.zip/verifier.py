"""Recheck sealed SQL, score coverage, rosters and one complete Elo publication offline."""
from hashlib import sha256
import csv
import json
import os
from pathlib import Path
import re
import shutil
import subprocess
import sys
from tempfile import TemporaryDirectory
import zlib

ROOT = Path(__file__).resolve().parent
CURRENT = Path('delivery/actualisation-main-1750')
PRIOR_ROSTERS = Path('delivery/actualisation-main-1633/integrite-apres-deploiement')


def json_file(path):
    return json.loads(path.read_bytes())


def hash_file(path):
    with path.open('rb') as stream:
        result = sha256()
        for block in iter(lambda: stream.read(131072), b''):
            result.update(block)
    return result.hexdigest()


def validate_files():
    index = json_file(ROOT/'INVENTAIRE.json')
    paths = [p for p in ROOT.rglob('*') if p.is_file() or p.is_symlink()]
    assert not any(p.is_symlink() for p in ROOT.rglob('*'))
    assert {p.relative_to(ROOT).as_posix() for p in paths} == set(index) | {'INVENTAIRE.json'}
    for name, entry in index.items():
        path = ROOT/name
        assert path.stat().st_size == entry['octets'] and hash_file(path) == entry['sha256'], name
    return index


def check_rosters():
    def latest(dirname):
        path = ROOT/PRIOR_ROSTERS/dirname
        b = (path/'inputs.json.zlib').read_bytes()
        receipt = json_file(path/'receipt.json')
        assert sha256(b).hexdigest() == receipt['sha256'] and receipt['exit_code'] == 0
        query = json_file(path/'queries.json')
        raw = json.loads(zlib.decompress(b))
        assert raw['read_only'] == 'on'
        for key, result in raw['queries'].items():
            assert sha256(query[key].encode()).hexdigest() == result['sql_sha256'], key
        return raw

    national = latest('national-current')
    graph = national['queries']['nations']
    teams = [dict(zip(graph['columns'],r)) for r in graph['rows']]
    active = [t for t in teams if t['merged_into'] is None]
    placeholders = [t for t in active if re.match(r'^(?:[A-F][1-4]$|Winner |Runner-up |3rd Group)',t['name'])]
    assert (len(teams),len(active),len(placeholders),len(active)-len(placeholders)) == (235,207,54,153)
    cup = latest('nations-current')
    roster = cup['queries']['rosters']
    raw = cup['queries']['fixtures']
    rosters = {edition:{r[1] for r in roster['rows'] if r[0]==edition} for edition in (305,308)}
    assert [len(rosters[ed]) for ed in (305,308)] == [16,38] and rosters[305].isdisjoint(rosters[308])
    assert [sum(r[1]==ed for r in raw['rows']) for ed in (305,308)] == [48,108]
    for edition, teams in rosters.items():
        assert teams == {t for r in raw['rows'] if r[1]==edition for t in (r[6],r[7])}
    return {'nations_at':national['at'],'named':153,'redirects':28,'draw_placeholders':54,
            'cup_at':cup['at'],'split':[{'editions':[305,308],'fixtures':[48,108],'teams':[16,38]}]}


def check_outcomes():
    scores = ROOT/CURRENT/'scores'
    prod = ROOT/CURRENT/'production'
    restore = ROOT/CURRENT/'restauration'
    deltas = json_file(scores/'comparaison/comparaison.json')['total_delta']
    assert deltas == {
        'club':{'actual_valid':22,'expected_algorithm':2,'missing_from_storage':-20},
        'national team':{'actual_valid':1388,'expected_algorithm':0,'missing_from_storage':-1388},
        'player':{'actual_valid':28,'expected_algorithm':28,'missing_from_storage':0,'role_unavailable':0}}
    edition = json_file(scores/'elo-and-matchday.json')
    publication = json_file(prod/'observation.json')['rds']
    detail = json_file(prod/'matchday-current/observations.json')
    tested = json_file(restore/'receipt.json')
    assert not edition['dirty_after'] and not edition['other_national_missing_after']
    assert edition['scope_count'] == 19 and edition['affected_edition_counts']['stored_valid'] == 1388
    assert edition['affected_edition_counts']['invalid'] == 0 and edition['affected_edition_counts']['missing'] == -1388
    assert all(edition['incident']['counts'][k]==0 for k in ('physical_matches','physical_keys','elo_sides'))
    assert publication['published_run']['id'] == detail['latest']['id'] == edition['elo_runs_after'][0]['id'] == 2099
    assert publication['stored_population'] == {'run_id':2099,'all_sides':165186,'matches':82593,'sides_off_pair':0}
    assert detail['old_run_exact_after_supersession'] and detail['scoped_matchday_candidates']==35 and not detail['physical_pair_or_key_collisions']
    previous = ROOT/'delivery/preuve-matchday/avant.zlib'
    after = ROOT/'delivery/preuve-matchday/apres.zlib'
    assert hash_file(previous)=='ed7496ec232d3ef8c93b70439e3ccaa9ae56c0708c4c11cbedb4872012a1f74c'
    assert hash_file(after)=='e850dd9ebc33dfad5c71b93090fb2d4b3c9c4dfea73296e2278fa13f29f3d71d'
    captures = [json.loads(zlib.decompress(p.read_bytes())) for p in (previous,after)]
    assert captures[0]['witnesses']==captures[1]['witnesses'] and len(captures[0]['witnesses'])==35
    assert captures[0]['provider_keys']==captures[1]['provider_keys'] and len(captures[0]['provider_keys'])==35
    original_elo = [c['reads']['elo_float_bits']['rows'] for c in captures]
    assert original_elo[0] == original_elo[1] and len(original_elo[0]) == 70
    original_cli = json_file(restore/'real150b/receipt.json')
    assert original_cli['tested_revision']==tested['revision'] and original_cli['cases']==tested['tested_paths']
    assert original_cli['prototype'] is False
    for path, result in tested['tested_paths'].items():
        ledger = json_file(restore/f'real150b/{path}/verified-ledger.json')
        assert len(ledger['source']) == result['source_exact_checksums'] == 133
        assert len(ledger['destination']) == result['destination_exact_checksums'] == 151
        assert all(ledger['destination'][k]==v for k,v in ledger['source'].items())
        assert set(result['migration_134_execution_order']) == {'134_archive_repair_boundary.sql','134_archive_scores_due.sql'}
        assert max(ledger['destination']) == result['destination_last_migration'] == '150_sportscore_standings_quarantine.sql'
        assert result['physical_matches_exact']==result['physical_keys_exact']==35 and result['elo_rows_and_float_bits_unchanged']==70
        assert result['archive_http_repeat']==[304,304,304] and result['finals_second_zero_writes']
    newer = json_file(restore/'newer2099/receipt.json')
    assert newer == tested['newer_run_local']
    local = newer['cases']
    assert local['latest-apply']['report']['restored']==35 and local['latest-repeat']['report']['restored']==0
    assert all(local[p]['report']['elo_pending_sides']==70 and local[p]['report']['preserved_elo']==0 for p in ('latest-dry','latest-apply','latest-repeat'))
    assert all(local[p]['returncode']==1 for p in ('mixed-floats','incomplete-published-run'))
    assert tested['current_production']['operator_cli_executed_in_production'] is False
    return {'rds_at':edition['after']['at'],'elo':2099,'elo_sides':165186,'editions':19,'newly_valid_national_sides':1388,
            'matchday_ids_absent':35,'old_elo_sides_absent':70,'verified_local_paths':2}


def rerun(index):
    prefix = CURRENT.as_posix()
    regenerated = (f'{prefix}/scores/19-editions.csv', f'{prefix}/scores/elo-and-matchday.json',
                   f'{prefix}/scores/scores-par-competition-saison-et-entite.csv', f'{prefix}/production/observation.json',
                   f'{prefix}/production/rencontres-par-competition-saison-source-et-etat.csv')
    commands = ('scores/verifier.py','scores/evaluate.py','production/verify.py','production/matchday-current/verify.py')
    with TemporaryDirectory(prefix='vega-capsule-elo-') as directory:
        work = Path(directory)/'input'
        shutil.copytree(ROOT,work)
        env = {'PATH':os.defpath,'LANG':'C.UTF-8','PYTHONDONTWRITEBYTECODE':'1','PYTHONPATH':str(work)}
        for command in commands:
            script = work/CURRENT/command
            subprocess.run([sys.executable,'-B',str(script)],cwd=script.parent,env=env,check=True)
        for name in regenerated:
            assert hash_file(work/name)==index[name]['sha256'], name


def main():
    index = validate_files()
    rerun(index)
    print(json.dumps({'status':'pass','covered_files':len(index),'current':check_outcomes(),'rosters':check_rosters()},ensure_ascii=False))


if __name__=='__main__':
    main()
