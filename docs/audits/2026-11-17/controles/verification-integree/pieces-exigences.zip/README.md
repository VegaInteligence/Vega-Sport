# Justificatifs des 91 exigences

Ouvrir `requirements.csv` pour consulter le verdict de production, le verdict sur branche, le constat observable, le propriétaire et ce qui reste à établir pour chaque exigence. Le répertoire `preuves` contient les pièces indiquées dans la colonne `evidence_paths` du registre des exigences et des 26 calculs supplémentaires. Le répertoire `source` contient les fichiers Git indiqués dans `source_paths` au commit déclaré dans `empreintes.json`.

Après extraction, exécuter `python3 -B verifier.py`. Cette commande vérifie l’intégrité de chacun des fichiers, les identifiants uniques et l’existence de toutes les pièces référencées dans les deux registres. Elle fonctionne hors ligne avec Python 3.10 ou ultérieur. Les liens de navigation transversale et les synthèses les plus récentes se trouvent dans le rapport principal. Les documents anciens conservent leur date et leur verdict d’origine.
