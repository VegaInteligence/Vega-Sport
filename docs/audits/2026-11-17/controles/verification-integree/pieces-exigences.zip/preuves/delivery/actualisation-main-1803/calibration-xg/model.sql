SELECT m.*, EXISTS (SELECT 1 FROM agg.shot_xg x WHERE x.model_id = m.id) AS referenced_by_scores,
       count(*) OVER ()::integer AS stored_model_count
FROM agg.xg_models m
ORDER BY fitted_at DESC, id DESC LIMIT 12
