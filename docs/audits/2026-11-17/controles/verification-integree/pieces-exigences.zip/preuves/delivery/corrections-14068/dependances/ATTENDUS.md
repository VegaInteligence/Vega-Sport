# Retrait d’une rencontre déjà enrichie

Le fournisseur de cotes attache les observations d’un bookmaker à la rencontre et à la saison. La présence d’une clé de match propre au fournisseur de cotes n’est pas une condition de cette écriture. Le retrait ultérieur du calendrier complémentaire peut donc atteindre une observation indépendante même lorsque le match n’a qu’une clé fournisseur.

Créer une base PostgreSQL 18 jetable et deux rencontres par le point d’entrée Open Matchday. Attacher une cote à la rencontre programmée sans ajouter de clé de match supplémentaire. Rejouer une observation du calendrier qui retire cette rencontre. Vérifier le statut, l’existence de la rencontre, sa clé et les trois prix accessibles dans la vue de lecture. Rejouer la correction et vérifier la stabilité. Un résultat sûr conserve le fait tiers et le parent ou réalise une réconciliation explicite traçable qui conserve les prix. Un retrait accepté qui efface simultanément les prix et le parent prouve une perte.

Les cotes utilisées dans cet essai sont construites. Une lecture de production distincte doit déterminer si les matchs programmés des quatre compléments portent aujourd’hui ce type de cote.
