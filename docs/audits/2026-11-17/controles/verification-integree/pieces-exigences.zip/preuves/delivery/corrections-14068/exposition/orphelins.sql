SELECT p.provider,p.is_current,count(*) AS keys,
 count(*) FILTER(WHERE m.id IS NULL) AS missing_parent,
 count(DISTINCT p.entity_id) FILTER(WHERE m.id IS NULL) AS missing_match_ids
 FROM core.provider_ids p LEFT JOIN core.matches m ON m.id=p.entity_id
 WHERE p.entity_type='match' GROUP BY p.provider,p.is_current ORDER BY p.provider,p.is_current