SELECT
 (SELECT count(*) FROM core.player_transfers) AS transfers,
 (SELECT count(*) FROM core.player_transfers WHERE from_team_id IS NULL OR to_team_id IS NULL) AS missing_at_least_one_team,
 (SELECT count(*) FROM core.player_transfers WHERE from_team_id IS NULL AND to_team_id IS NULL) AS missing_both_teams,
 (SELECT count(*) FROM api.player_transfers) AS readable_dated_rows,
 (SELECT count(*) FROM api.player_transfer_reads) AS players_with_recorded_success,
 (SELECT count(*) FROM api.player_transfers WHERE from_id IS NULL OR to_id IS NULL) AS readable_rows_with_unresolved_endpoint,
 (SELECT count(*) FROM api.player_transfers WHERE from_name IS NULL AND to_name IS NULL) AS readable_rows_with_no_names,
 (SELECT count(*) FROM api.player_market_values) AS readable_market_values
