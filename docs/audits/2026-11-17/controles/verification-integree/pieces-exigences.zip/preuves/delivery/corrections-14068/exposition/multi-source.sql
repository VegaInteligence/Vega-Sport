WITH targeted AS (
SELECT DISTINCT p.provider AS owner,m.id,m.status FROM core.provider_ids p
JOIN core.matches m ON m.id=p.entity_id
WHERE p.entity_type='match' AND p.provider IN ('open_matchday','openfootball','openligadb','international_results') AND p.is_current
), evidence AS (
SELECT t.owner,t.id,t.status,
  bool_or(other.entity_id IS NOT NULL) AS has_other,
  bool_or(other.is_current IS TRUE) AS current_other,
  bool_or(other.provider='pitchapi' AND other.is_current) AS pitch_other
FROM targeted t LEFT JOIN core.provider_ids other ON other.entity_type='match' AND other.entity_id=t.id AND other.provider<>t.owner
GROUP BY t.owner,t.id,t.status)
SELECT owner,status,count(*) AS scoped_matches,count(*) FILTER(WHERE has_other) AS other_provider_evidence,
count(*) FILTER(WHERE current_other) AS another_current_provider,
count(*) FILTER(WHERE pitch_other) AS pitchapi_current FROM evidence GROUP BY owner,status ORDER BY owner,status