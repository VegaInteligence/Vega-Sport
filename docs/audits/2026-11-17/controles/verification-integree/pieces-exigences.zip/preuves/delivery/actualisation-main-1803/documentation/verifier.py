"""Compare every reviewed substitution with the two immutable Git objects."""
from hashlib import sha256
import json
from pathlib import Path
import subprocess
import sys

folder = Path(__file__).resolve().parent
repo = Path(sys.argv[1])
target = '396379a61699bf642a13295b206ebdd348336947'
spec = json.loads((folder/'edits.json').read_text())
base = spec['revision']

def git(*args):
    return subprocess.check_output(['git', '-C', str(repo), *args])

changed = set(git('diff', '--name-only', base, target).decode().splitlines())
assert changed == set(spec['documents'])
total = 0
for path, expected in spec['documents'].items():
    old = git('show', base + ':' + path)
    assert sha256(old).hexdigest() == expected['before_sha256']
    value = old.decode()
    for edit in spec['edits']:
        if edit['path'] == path:
            assert value.count(edit['before']) == 1
            value = value.replace(edit['before'], edit['after'], 1)
            total += 1
    result = git('show', target + ':' + path)
    assert value.encode() == result
    assert sha256(result).hexdigest() == expected['after_sha256']
historical = 'docs/calculs/09-audit-2026-11/SOURCE_AUDIT.md'
original = sha256(git('show', target + ':' + historical)).hexdigest()
assert original == 'fdf03a62f1980fc74efe2be98d87119084802c9881a4cef93a4ae7267192baeb'
assert total == len(spec['edits']) == 35 and len(changed) == 11
print(json.dumps({'avant':base, 'apres':target, 'pages':len(changed), 'remplacements_exacts':total,
                  'document_original_sha256':original, 'fichiers_executables_modifies':0,
                  'rejeu':'python3 verifier.py <chemin-du-depot-avec-les-deux-commits>'},ensure_ascii=False,indent=2))
