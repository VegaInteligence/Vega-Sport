# A16a · Première observation hors entraînement du xG en production

**Une cohorte chronologiquement hors entraînement est observable. Sa taille limite la conclusion à un match.** Le 18 novembre 2026 à 18:35:05 UTC, une lecture de production en transaction répétable a trouvé 25 tirs éligibles dans un seul match de Saudi First Division commencé le 18 novembre à 14:30 UTC. Les 24 tirs hors penalty ont donné 5 buts pour 3,33666 xG (Brier 0,11936), soit un écart observé de 6,93 points de pourcentage au-dessus de la prévision. Un seul tir atteint 35 m. Il n’a pas donné de but et valait 0,009847 xG. Le critère A16a reste partiel. [Agrégats et données horodatées](calibration.json) · [Entrée de 25 tirs](postfit-shots.json)

## Quel modèle et quelle borne

- Le modèle `agg.xg_models.id=5`, `xg-v2`, est l’unique modèle conservé et référencé dans `agg.shot_xg` au moment du relevé. L’ajustement persisté compte 1 798 648 tirs hors penalty et 174 103 buts. Le champ pénalty est 0,778812. Les 14 coefficients sont conservés dans le résultat SQL. Ils satisfont les contraintes géométriques. [Enregistrement du modèle](model.json)
- L’image active avant et après la lecture correspond à `5956a83cd76bf0b41924795e05b5024c8e1770d6`, digest `sha256:aabd97a97c17c4a344c542f656254e25cda1eff4312da211aa4e9a3c8ad4e0f9`. Le diagnostic de lecture a lui-même tiré ce digest. Le code correspondant lit d’abord `BINS`, ajuste les coefficients et lit les pénalties, puis ouvre la transaction qui insère le modèle. PostgreSQL donne à `fitted_at` le `now()` de cette transaction. Le 17 novembre à 14:21:21.688321 UTC constitue donc une borne supérieure vérifiable sur la lecture d’entraînement. La base ne conserve ni l’instant exact de lecture des tirs ni leurs identifiants alignés sur le modèle. Aucun run dans `agg.calc_runs` ne porte la version xG observée. L’identifiant du modèle est le rattachement des 25 prévisions servies. [Code épinglé](xg.pinned.py) · [Colonnes et valeurs par défaut](fit-schema.json) · [Recherche de run](calc-run.json)
- Le sous-ensemble exige une rencontre native terminée, un coup d’envoi vérifié après la borne et un premier résultat terminé consigné après le coup d’envoi et avant la mesure. Le code de collecte planifie les tirs de la famille détail après la confirmation du résultat et le rattrapage cible les matchs terminés. Les coups d’envoi sans heure, ceux à la date non établie et les tirs plus anciens passés tardivement en terminé sont écartés. Aucun `updated_at` de tir n’établit sa première disponibilité. Les coordonnées, l’issue connue et l’exclusion des buts contre son camp reprennent le filtre du modèle. [Fenêtre et ventilation des rejets](coverage.json) · [Sélection SQL](postfit-shots.sql)
- Le rejeu de novembre sur 9 223 tirs évaluait un réajustement réalisé pour la comparaison, avec 20 935 tirs d’entraînement et une coupure au 1er août 2025. Cette mesure reste un témoin distinct. Les Brier des deux études portent sur des populations et coefficients différents. [Résumé du rejeu antérieur](previous-evaluation-summary.json)

## Résultats descriptifs

| Domaine | Tirs | Buts | xG attendu | Brier |
|---|---:|---:|---:|---:|
| Hors penalty | 24 | 5 | 3,33666 | 0,11936 |
| Moins de 12 m | 13 | 3 | 2,71169 | 0,09726 |
| 12 à moins de 24 m | 6 | 2 | 0,51195 | 0,26624 |
| 24 à moins de 35 m | 4 | 0 | 0,10317 | 0,000685 |
| 35 m et plus | 1 | 0 | 0,009847 | 0,00009696 |
| Jeu ouvert | 20 | 5 | 2,92758 | 0,14074 |
| Phases arrêtées hors penalty | 4 | 0 | 0,40908 | 0,01245 |
| Têtes hors penalty | 5 | 0 | 0,55643 | 0,01306 |
| Penalties | 1 | 1 | 0,77881 | 0,04892 |

Les groupes par distance partitionnent les tirs hors penalty. Les groupes par partie du corps et situation les recoupent. Le Brier est la moyenne de `(p−y)²` par tir, avec `y=1` pour un but. Le calcul depuis les coordonnées et les coefficients concorde avec les 25 probabilités servies, écart maximum absolu de `2,89×10⁻⁸`. Cette parité et la non-croissance à angle fixé sont des contrôles distincts de la calibration.

Un seul match ne permet pas d’estimer une incertitude entre matchs. Le script laisse l’intervalle vide. Un bon Brier sur le seul tir lointain ne permet pas de juger le domaine 35 m et plus. La source couvre ici un match et une compétition, aucun échantillon représentatif des autres ligues ni mesure d’évolution du modèle.

## Autre contrôle dans le même relevé

Les 4 682 lignes de source `open_matchday` portent toutes un `round_id`. Cela comprend 2 576 matchs terminés et 2 106 non commencés. Le champ présent ne vérifie ni sa justesse, ni sa signification pour le classement. La mesure demandée séparément retrouve 1 086 lignes officielles SportScore de 60 éditions, toutes avec victoires, nuls et défaites renseignés. Aucune somme de ces trois champs ne diffère du nombre joué. Une divergence de marqueur d’effectif subsiste entre Gent B et Gent U23 parmi 838 graphies. Ce comptage ne tranche pas leur identité. [Relevé des tours](open-matchday-rounds.json) · [Exposition séparée](exposition.json)

## Rejeu

```sh
python3 -B analyse.py
# Avec vérification des sources à partir du dépôt local
python3 -B analyse.py "/Users/lemonnierhugo/Developer/Coding Project/Vega-Sport-audit-20261117"
# Nouvelle observation de production selon les accès déjà autorisés
python3 -B capture.py
```

Les cinq requêtes de vérification du modèle, les deux lectures séparées et les résultats sont scellés par leurs SHA-256 dans `receipt.json`. Le rejeu hors ligne et le rejeu depuis Git ont produit le même JSON. Une première tentative avec `vega-v2-diagnose:266` a échoué au téléchargement d’une image ECR retirée. Le repli autorisé a repris les rôles existants, le digest actif et une transaction SQL en lecture seule, sans nouveau rôle. La définition temporaire `:217` est sortie avec code 0 et a été désenregistrée, statut vérifié `INACTIVE`. [Reçu AWS](receipt.json)
