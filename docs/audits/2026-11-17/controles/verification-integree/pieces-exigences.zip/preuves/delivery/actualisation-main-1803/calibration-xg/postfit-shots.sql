WITH model AS MATERIALIZED (SELECT id,fitted_at FROM agg.xg_models ORDER BY fitted_at DESC,id DESC LIMIT 1)
SELECT m.season_id,m.id AS match_id,c.kind::text AS competition_kind,c.name AS competition,m.kickoff_at,m.first_finished_at,
       s.shot_no,s.x::double precision,s.y::double precision,s.situation::text,s.body_part::text,s.outcome::text,
       v.xg::double precision AS served_xg,v.model_id AS served_model_id
FROM model x JOIN core.matches m ON m.kickoff_at>x.fitted_at AND m.kickoff_at<=transaction_timestamp()
JOIN core.shots s ON (s.season_id,s.match_id)=(m.season_id,m.id)
JOIN core.competition_seasons cs ON cs.id=m.competition_season_id
JOIN core.competitions c ON c.id=cs.competition_id
LEFT JOIN agg.shot_xg v ON (v.season_id,v.match_id,v.shot_no)=(s.season_id,s.match_id,s.shot_no)
WHERE m.status='finished' AND m.source='pitchapi' AND m.date_unverified IS NOT TRUE
  AND m.match_date BETWEEN (m.kickoff_at AT TIME ZONE 'UTC')::date-1 AND (m.kickoff_at AT TIME ZONE 'UTC')::date+1
  AND m.season_id BETWEEN extract(year from x.fitted_at AT TIME ZONE 'UTC')::int-1
                      AND extract(year from transaction_timestamp() AT TIME ZONE 'UTC')::int
  AND m.match_date BETWEEN greatest((x.fitted_at AT TIME ZONE 'UTC')::date-1,(transaction_timestamp() AT TIME ZONE 'UTC')::date-45)
                       AND (transaction_timestamp() AT TIME ZONE 'UTC')::date+1
  AND s.outcome IS NOT NULL AND s.is_own_goal IS NOT TRUE AND s.x BETWEEN 0 AND 105 AND s.y BETWEEN 0 AND 68
ORDER BY m.season_id,m.id,s.shot_no LIMIT 60001
