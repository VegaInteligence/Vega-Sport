WITH targets AS (
 SELECT m.* FROM core.matches m JOIN core.competition_seasons cs ON cs.id=m.competition_season_id
 WHERE cs.competition_id IN (71,209,231) AND (m.home_team_id=707 OR m.away_team_id=707)
)
SELECT m.id,api.public_id('match',m.id) public_id,m.competition_season_id edition,
 c.id competition,api.public_id('competition',c.id) public_competition,c.name competition_name,m.season_id,
 cs.native_label,cs.archive_key,cs.cup_key,m.source::text,m.status::text,m.match_date,m.kickoff_at,m.round_id,
 m.home_team_id,api.public_id('team',m.home_team_id) public_home,h.name home,m.home_team_name source_home,
 m.away_team_id,api.public_id('team',m.away_team_id) public_away,a.name away,m.away_team_name source_away,
 m.home_score,m.away_score,
 ARRAY(SELECT p.provider::text||':'||p.provider_key FROM core.provider_ids p WHERE p.entity_type='match' AND p.entity_id=m.id AND p.is_current ORDER BY 1) match_keys,
 (SELECT coalesce(jsonb_agg(jsonb_build_object('team',e.team_id,'run',r.id,'before',e.elo_before,'after',e.elo_after,'status',r.status) ORDER BY e.team_id),'[]')
 FROM agg.team_elo e JOIN agg.power_runs r ON r.id=e.run_id WHERE e.match_id=m.id AND r.kind='elo' AND r.status='published') published_elo
FROM targets m JOIN core.competition_seasons cs ON cs.id=m.competition_season_id JOIN core.competitions c ON c.id=cs.competition_id
JOIN core.teams h ON h.id=m.home_team_id JOIN core.teams a ON a.id=m.away_team_id
ORDER BY m.season_id,m.match_date,m.id LIMIT 31
