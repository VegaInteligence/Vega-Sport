"""Verify the sealed read, identify the constants and report only chronologically independent shots."""
from argparse import ArgumentParser
from collections import defaultdict
from datetime import datetime
from hashlib import sha256
from importlib.machinery import SourceFileLoader
from importlib.util import module_from_spec, spec_from_loader
import json
import math
from pathlib import Path
from random import Random
import re
import subprocess

HERE=Path(__file__).resolve().parent

def digest(body): return sha256(body).hexdigest()

def read(output, key):
    return json.loads((output / (key+'.json')).read_bytes())

def rows(table):
    assert all(len(row)==len(table['columns']) for row in table['rows'])
    return [dict(zip(table['columns'],row,strict=True)) for row in table['rows']]

def at(value):
    return datetime.fromisoformat(value) if value else None

def material(repo, receipt, output):
    before, after = (receipt[k] for k in ('worker_before','worker_after'))
    if (before['image'],before['image_digest']) != (after['image'],after['image_digest']):
        raise ValueError('worker image changed around the read')
    commit = before['image'].rsplit(':',1)[1]
    assert re.fullmatch(r'[a-f0-9]{40}',commit)
    if repo is not None:
        sources={}
        for name in ('backend/vega/xg.py','backend/vega/models.py','backend/vega/planner.py','backend/sql/080_vega_xg.sql'):
            raw = subprocess.check_output(['git','-C',str(repo),'show',f'{commit}:{name}'])
            sources[name] = digest(raw)
            if name.endswith('/xg.py'): (output/'xg.pinned.py').write_bytes(raw)
        (output/'worker-source.json').write_text(json.dumps({'commit':commit,'sources':sources},indent=2)+'\n')
    else:
        provenance=read(output,'worker-source')
        assert provenance['commit']==commit
        sources=provenance['sources']
    p=output/'xg.pinned.py'
    assert digest(p.read_bytes())==sources['backend/vega/xg.py']
    loader=SourceFileLoader('xg_prod_audit',str(p))
    module=module_from_spec(spec_from_loader(loader.name,loader))
    # Run the verified code from Git without writing Python bytecode.
    exec(compile(p.read_bytes(),str(p),'exec'), module.__dict__)
    return commit, sources, module

def classify(r, distance):
    if r['situation']=='penalty': return ('penalties_only',)
    if distance >= 35: near='35m_plus'
    elif distance >= 24: near='24_to_under_35m'
    elif distance >= 12: near='12_to_under_24m'
    else: near='under_12m'
    domains=('all_non_penalty', near, 'head' if r['body_part']=='header' else 'non_head',
             'open_play' if r['situation'] in {None,'regular_play','fast_break','individual_play'} else 'set_piece_non_penalty')
    return domains

def aggregate(values):
    if not values: return {'shots':0,'matches':0,'goals':0,'expected_goals':None,'brier':None,'observed_minus_expected_rate':None,'cluster_bootstrap_95pct':None}
    by_match=defaultdict(list)
    for match,p,y in values: by_match[match].append((p,y))
    grouped=[(len(a),sum(y-p for p,y in a),sum((p-y)**2 for p,y in a)) for a in by_match.values()]
    count=len(values)
    predicted=math.fsum(p for _,p,y in values)
    goals=sum(y for _,p,y in values)
    result={'shots':count,'matches':len(grouped),'goals':goals,'expected_goals':predicted,
            'predicted_rate':predicted/count,'observed_rate':goals/count,
            'brier':math.fsum((p-y)**2 for _,p,y in values)/count,
            'observed_minus_expected_rate':(goals-predicted)/count,'cluster_bootstrap_95pct':None}
    if len(grouped)>=20:
        rng=Random(162026)
        trials=[]
        for _ in range(2000):
            draws=rng.choices(grouped,k=len(grouped))
            n,delta,squared=map(sum,zip(*draws))
            trials.append((delta/n,squared/n))
        bounds=[]
        for series in zip(*trials):
            series=sorted(series)
            bounds.append([series[50],series[1949]])
        result['cluster_bootstrap_95pct']=dict(zip(('observed_minus_expected_rate','brier'),bounds,strict=True))
    return result

def main():
    args=ArgumentParser()
    args.add_argument('repo',type=Path,nargs='?')
    args.add_argument('--output',type=Path,default=HERE)
    args=args.parse_args()
    out=args.output
    receipt=read(out,'receipt')
    assert receipt['exit_code']==0 and receipt['snapshot']['read_only']=='on'
    for name, expected in receipt['result_sha256'].items():
        assert digest((out/f'{name}.json').read_bytes())==expected,name
    for name, expected in receipt['query_sha256'].items():
        assert digest((out/f'{name}.sql').read_text().strip().encode())==expected,name
    commit,sources,kernel=material(args.repo,receipt,out)
    all_models=rows(read(out,'model'))
    assert all_models,'no stored model'
    assert all_models[0]['stored_model_count']==len(all_models),'model list truncated'
    model=all_models[0]
    assert model['version']==kernel.MODEL_VERSION and model['referenced_by_scores']
    assert [r['id'] for r in all_models if r['referenced_by_scores']]==[model['id']]
    terms=[model[t] for t in kernel.TERMS]
    assert all(map(math.isfinite,terms)) and kernel.violations(terms)==[]
    cutoff=at(model['fitted_at'])
    observation=at(receipt['snapshot']['at'])
    assert cutoff < observation
    scope=rows(read(out,'coverage'))
    timing=defaultdict(lambda: defaultdict(int))
    scope_columns=('fixtures','fixtures_with_shots','shots','eligible','npxg_eligible','npxg_35m','scores_latest','scores_other','updated_after_fit')
    for r in scope:
        for name in scope_columns: timing[r['timing']][name]+=r[name]
    positive=[r for r in scope if (r['timing'],r['source'],r['status'])==('after_fit_verified_kickoff','pitchapi','finished')]
    candidates=rows(read(out,'postfit-shots'))
    assert len(candidates)<60001,'cap prevents exhaustive cohort'
    assert len(candidates)==sum(r['eligible'] for r in positive),'cohort join or scope disagreement'
    seen=set()
    groups=defaultdict(list)
    competition_kinds=defaultdict(list)
    domains=('all_non_penalty','35m_plus','24_to_under_35m','12_to_under_24m','under_12m','head','non_head','open_play','set_piece_non_penalty','penalties_only')
    skipped=defaultdict(int)
    parity=[]
    absent=0
    for r in candidates:
        key = (r['season_id'],r['match_id'],r['shot_no'])
        assert key not in seen,key
        seen.add(key)
        kickoff=at(r['kickoff_at'])
        assert cutoff < kickoff <= observation
        finish=at(r['first_finished_at'])
        if not finish or not kickoff < finish <= observation:
            skipped['first_finish_missing_or_incoherent']+=1
            continue
        distance=math.hypot(105-r['x'],34-r['y'])
        theta=max(0,math.atan2(7.32*max(105-r['x'],.01),distance*distance-3.66**2))
        p=(model['penalty'] if r['situation']=='penalty' else
           kernel.probability(terms,kernel.features(r['situation'] or 'regular_play',r['body_part'] or 'right_foot',distance,theta)))
        if p is None:
            skipped['unavailable_penalty_parameter']+=1
            continue
        if r['served_model_id']==model['id']:
            parity.append(abs(r['served_xg']-p))
        else:
            absent+=1
        result=((r['season_id'],r['match_id']),p,int(r['outcome']=='goal'))
        for domain in classify(r,distance): groups[domain].append(result)
        if r['situation']!='penalty':competition_kinds[r['competition_kind']].append(result)

    result={'status':'observed_post_fit_cohort' if groups['all_non_penalty'] else 'no_eligible_non_penalty_shot',
            'worker_revision':commit,'worker_image_digest':receipt['worker_before']['image_digest'],'deployed_sources_sha256':sources,
            'model':model,'training_snapshot_exact':None,
            'strict_holdout_after':model['fitted_at'],
            'strict_holdout_after_basis':'Deployed xg.refresh reads BINS, fits and reads PENALTIES before inserting model; fitted_at defaults to transaction now(). Only matches with a verified post-publication kickoff and later observed finish are evaluated.',
            'observation':receipt['snapshot'],'coverage_window_days_cap':45,'coverage_after_fit_full_within_window':(observation-cutoff).total_seconds()<44*86400,
            'sources_scope':'native pitchapi, finished, exact fixture kickoff; archive and date-only rows excluded from scores',
            'coverage_by_timing':timing,'candidates_before_finish_gate':len(candidates),'counts_excluded_after_sql':skipped,
            'domains':{d:aggregate(groups[d]) for d in domains},
            'by_competition_kind_non_penalty':{k:aggregate(v) for k,v in competition_kinds.items()},
            'stored_probability_parity':{'scored_with_same_model':len(parity),'without_same_served_model':absent,'max_abs':max(parity,default=None)},
            'unrelated_open_matchday_rounds':rows(read(out,'open-matchday-rounds'))}
    (out/'calibration.json').write_text(json.dumps(result,ensure_ascii=False,indent=2)+'\n')
    print(json.dumps({k:result[k] for k in ('status','strict_holdout_after','candidates_before_finish_gate','domains','unrelated_open_matchday_rounds')},ensure_ascii=False))
if __name__=='__main__':main()
