# L18 · Palmarès France 1998 et Italie 1982

Le relevé de production du 18 novembre à 15 h 47 UTC montre deux finales `not_started` sans score et le label `Finale`. Sur la branche `d29eac65d75ca4eb038a2fc5b24e1bb93d1ae2ab`, la collecte habituelle des deux éditions OpenFootball rétablit les deux vainqueurs sur une copie PostgreSQL 18. La séparation des canaux importe quand une rencontre est détenue deux fois.

| Équipe et identifiant HTTP | Production, finale | Après la collecte sur la branche |
| --- | --- | --- |
| France 1998 · `t_2ysHaw` | Brésil–France, 12 juillet, `not_started`, score absent. Deux des sept rencontres ont le statut `finished`. | Brésil 0–3 France, `finished`, sept rencontres `finished`, `Vainqueur`, `gold`. ID physique 1056. |
| Italie 1982 · `t_v0001032` | Italie–RFA, 11 juillet, `not_started`, score absent. Sept rencontres `not_started`. | Italie 3–1 RFA, `finished`, sept rencontres `finished`, `Vainqueur`, `gold`. ID physique 836. |

Les deux `/api/nations/{id}?season=2026%2F2027` ont renvoyé 200 avec l’ancien ETag de la copie. Les finales proviennent de `open-cups:world-cup-history:1998` et `open-cups:world-cup-history:1982`, source `openfootball`, avec les côtés canoniques conservés. Les rencontres purement archivées suivent le contrat public sans identifiant de page match. La source réécrit 64 lignes de l’édition 1998 et 52 de l’édition 1982 dans ce montage, qui part des colonnes historiques projetées. La réécriture inclut les champs de phase et de lecture reconstruits. Les 116 identifiants restent identiques. Au deuxième passage, `rows_written=0` pour les deux éditions et les deux requêtes conditionnelles renvoient 304. [Reçu intégral](caseone.json) · [Journal](01-local-replay.log)

## Copies de la même rencontre

`api.nation_matches` groupe par date effective et paire d’identifiants d’équipes, dans les deux orientations. Les lignes 37–38 de `120_nation_match_copies.sql` donnent la priorité à la ligne native dont les clés coupe et archive sont nulles, puis à la présence de `home_score`, puis au plus petit ID. Les lignes 41–46 complètent le tour et les tirs au but depuis les copies du groupe, en remettant les tirs du côté de la bonne équipe. Le statut et les deux buts restent ceux de la ligne retenue.

`nations.mjs:60–71` exige les deux scores pour attribuer une finale. Avec un score à égalité, les tirs au but permettent le verdict. Avec un score absent, le label reste `Finale` même si les tirs sont disponibles. Le bilan par saison exige en outre `finished`. La déduplication JavaScript des parcours peut choisir une copie scorée lorsqu’elle reçoit deux objets. La fonction SQL ne transmet déjà qu’un objet par paire et par jour.

Les contrôles locaux ajoutent une copie native inversée des deux rencontres avec leurs équipes et scores attestés. Avec les scores, chaque parcours conserve sept rencontres, affiche `Vainqueur` et sert l’identifiant de la copie native. Quand ces deux copies témoins passent à `not_started` sans but, les deux archives gardent leurs scores en base, les parcours comptent toujours sept et les deux labels reviennent à `Finale`. Le comportement attendu pour une rencontre dont le résultat est prouvé est de garder un seul match et de rendre cohérents le score, le statut et le palmarès. Le risque démontré est un statut natif inachevé qui cache le résultat d’archive et fausse également un éventuel bilan de saison. Ce test contrôle la déduplication sans supposer qu’un doublon existe réellement pour les deux finales en production.

[Tracé SQL en lecture seule](population-readonly.sql) · [Deux masques trouvés dans le contrôle local](population-local-control.json). Le premier relevé mesure les recouvrements nativement classés devant une archive terminée et scorée, à date et paire canoniques exactes. Il sépare les scores absents des statuts autres que `finished`. Le second relevé affiche toutes les copies des deux finales, les deux orientations et leurs canaux. Les paires d’identifiants divergents, les dates divergentes et les archives encore non scorées sont hors de son dénominateur.

## Matériel scellé et répétition

La copie reconstruit les 116 lignes des deux éditions à partir du relevé RDS `db/worldcup_editions_nov18_verified/fixtures.json` du 17 novembre à 23 h 36 UTC et de 44 équipes et 111 liaisons lues dans la copie locale Nov18 existante. Les 116 rapprochements date/équipe ont été vérifiés contre la projection de la source et chaque côté a gardé l’identifiant attesté. Les clés fournisseur des matchs et les tours sont reproduits depuis les fichiers OpenFootball archivés. La projection historique RDS est limitée à `open-cups`. Elle ne renseigne pas la présence éventuelle d’une autre copie en production. Le code intégré reste intact.

```sh
W='/Users/lemonnierhugo/Developer/Coding Project/Vega-Sport-audit-20261117'
E='/Users/lemonnierhugo/.codex/visualizations/2026/11/17/01a1e6f1-9c43-7b81-a52e-3ee15c953578/production-architecture-review'
Q="$E/delivery/navigation-vi22/nations-branche"
cd "$Q"
PYTHONDONTWRITEBYTECODE=1 python3 -B replay.py "$W" "$E/sources/upstream" replay02 55439
```

La commande crée une base jetable `vega_v2_nations_l18_replay02` sur PostgreSQL 18 local. Elle exige les dépendances Python du backend et celles de l’API Node. Elle lance le vrai pont dans `backend/sources`, le writer sous `vega_collect`, puis le gestionnaire HTTP avec `vega_read`. Les seuls remplacements sont les réponses archivées de l’entrée OpenFootball et les deux copies de contrôle ajoutées après la preuve principale. Les empreintes des entrées, des scripts et des résultats sont dans `SHA256SUMS`.

**Portée L18.** Défaut établi en production à 15 h 47 UTC. Correction de bout en bout vérifiée sur la branche pour les deux parcours avec leurs copies archivées attestées. L’effet d’une éventuelle copie native incomplète est reproductible sur contrôle. Le périmètre s’arrête à ces deux éditions et à ces deux nations.

