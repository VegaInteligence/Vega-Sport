# T4 — preuves de contre-revue indépendante

Relecteur gpt-6-astra / xhigh, SHA produit `0d2b950d0efdefd2a0b783f7fb0264eff5c8079b`. Aucun checkout modifié ou recopié. `frozen-source-check.json` compare 685 blobs pertinents du git figé à l'export déjà créé par le worker dans sol-reprise-1219/frozen-t4-source : zéro différence. Backend, migrations, fixtures, tests, shared et services frontend concernés sont inclus. Ce reçu ne certifie pas tous les documents d'audit.

Le conteneur privé `vega-astra-t4-20261118-1435`, PG18 sur 127.0.0.1:55484, a été créé pour cette revue. Aucun reset/prune de conteneur ou base préexistante. Les tests existants ne réinitialisent que les bases neuves privées suivantes : vega_v2_archive_guards_test, vega_v2_dfb_periods_test, vega_v2_artwork_test, vega_v2_snapshots_test. Leur création initiale est `CREATE DATABASE <nom>` sous l'administrateur local. Le conteneur et ses bases sont conservés.

## Commandes des parcours existants

```sh
E='/Users/lemonnierhugo/.codex/visualizations/2026/11/17/01a1e6f1-9c43-7b81-a52e-3ee15c953578/production-architecture-review'
F="$E/tracks/4-history/sol-reprise-1219/frozen-t4-source"
R="$E/tracks/4-history/reviews/astra-1435"
export PYTHONDONTWRITEBYTECODE=1 PYTHONPATH="$F/backend:$F/backend/tests"
export VEGA_V2_ARCHIVE_GUARDS_TEST_DSN='postgresql://postgres@127.0.0.1:55484/vega_v2_archive_guards_test'
export VEGA_V2_DFB_PERIODS_TEST_DSN='postgresql://postgres@127.0.0.1:55484/vega_v2_dfb_periods_test'
export VEGA_V2_ARTWORK_TEST_DSN='postgresql://postgres@127.0.0.1:55484/vega_v2_artwork_test'
export VEGA_V2_SNAPSHOTS_TEST_DSN='postgresql://postgres@127.0.0.1:55484/vega_v2_snapshots_test'
export VEGA_E2E_EVIDENCE="$R"
cd "$F"
"$E/ci-clean/bin/python" -B -m unittest -v test_archive_removal_guards
"$E/ci-clean/bin/python" -B -m unittest -v test_dfb_periods
"$E/ci-clean/bin/python" -B -m unittest -v \
 test_artwork.ArtworkTest.test_21abd_apply_links_once_with_its_provenance \
 test_artwork.ArtworkTest.test_21i_a_failed_storage_write_links_nothing \
 test_source_snapshots.OpenMatchdayGuardTest.test_22a_missing_statistic_columns_or_cells_keep_the_stored_values \
 test_source_snapshots.OpenMatchdayGuardTest.test_22b_a_stated_zero_replaces_the_stored_value_once \
 test_source_snapshots.CupPublishedPhasesTest.test_verified_award_and_source_loss \
 test_source_snapshots.CupPublishedPhasesTest.test_club_world_cup_22_halves_and_edition_notification
"$E/ci-clean/bin/python" -B -m unittest -v \
 test_artwork.ArtworkCorrectionsTest.test_22w_a_binding_moved_during_the_upload_links_nothing \
 test_artwork.ArtworkCorrectionsTest.test_22w_b_an_asset_changed_during_the_upload_is_a_conflict \
 test_artwork.ArtworkCorrectionsTest.test_22x_any_storage_exception_stops_with_a_receipt \
 test_artwork.ArtworkCorrectionsTest.test_22y_uefa_fills_the_canonical_club_of_a_merged_alias \
 test_artwork.StorageIntegrityTest
```

Attendus/résultats : 9 gardes de retrait, 3 workflows DFB, 6 contrôles stockage/coupes/statistiques et 5 contrôles de concurrence/objet stocké passent. Journaux : removal-guards.log, dfb-periods.log, artwork-and-cups.log, artwork-races.log. Le premier run combiné avait aussi nommé une classe inexistante ArtworkRacesTest : son exit=1 est conservé. Ses six vrais tests passent; les cinq contrôles de concurrence ont été exécutés ensuite sous le vrai nom. Aucune erreur produit masquée. Les tests existants utilisent leur administrateur de fixture pour certaines écritures; ne pas attribuer uniformément le rôle de production à toute cette suite. Le témoin suivant le vérifie explicitement.

## Retrait sous les vrais rôles

`removal-role-witness.py` crée sa propre nouvelle base. Attendu : apply sous vega_collect, jumeaux conservés, retrait propre, writer vega_collect bloqué puis refusé 23503, nouveau writer après commit refusé, accès agg refusé 42501. Exécuter `"$E/ci-clean/bin/python" -B "$R/removal-role-witness.py"`. JSON et log sauvegardent les résultats, rôles et DSN. Le transport/compiler du corpus est hors de ce petit témoin; plan, relecture sous verrou, application et triggers sont réels.

## Alias avant/après 149

`alias-witness.py` prépare une édition 1963 et deux matchs actifs dans la nouvelle base vega_v2_astra_alias_witness. Attendu : une clé/date canonique fausse, un ancien g: actif, un ancien ID actif ou sans tombstone sont refusés; attestation simple et alias d'un ID retiré sont valides. Sur le schéma figé 0d2b950d, les cinq mauvaises écritures passent sous vega_collect. L'ancien g: actif crée deux résultats possibles dans le prédicat du reader. Après application du SQL 149 extrait de **01130327f8453c4e80cbb0db7a9b307513ba6343**, les cinq donnent 23503 et les deux contrôles positifs passent. Toutes les sondes sont rollbackées. Le script ne modifie aucun source.

Pour reproduire, partir d'une nouvelle base vide nommée vega_v2_astra_alias_witness sur un conteneur privé au même port, puis `"$E/ci-clean/bin/python" -B "$R/alias-witness.py"`. Le conteneur de ce run contient déjà la migration 149 : ne pas réinitialiser cette preuve. Cette exécution est **schéma T4 figé + SQL 149**, pas la validation complète du W combiné. Aucun code du W mouvant n'a été importé.

## 23 Coupes du monde

`world-cup-half-pg.py` reprend le script de sol-reprise-1219, seuls port/nom de base changent et le DROP préexistant est retiré. Il consomme les 23 captures `E/sources/upstream/world-cup-history-<année>.json`, d'abord sans bras de buts, puis complètes, via vraie projection Node → run_due → PostgreSQL → API cups sous vega_read.

```sh
"$E/ci-clean/bin/python" -B "$R/world-cup-half-pg.py" "$F" "$E" "$R/world-cup"
```

Créer un nouveau nom de base dans le script avant répétition (la base actuelle est conservée), et un nouveau dossier de résultat. Résultat : 1 069 clés avant/après, 67 corrections exclusivement de mi-temps/révision, finales et autres phases identiques, deux répétitions sans mutation, 23 corps HTTP 200. Données complètes dans world-cup/replay.json; log world-cup.log. Le script est local et les fetch sont interceptés sur les captures, aucune source Internet contactée.

## Lecteur des alias historiques

Le script original `sol-reprise-1219/historical-dfb-http.mjs` s'exécute depuis `$F/backend/api` avec son texte transmis à `node --input-type=module -e`, et deux arguments : historical-http-input.json et historical-http.json. Le premier contient le nom d'une **nouvelle base clonée** sur 32768 depuis la preuve d'upgrade historique; la source n'est pas modifiée. Ce script compare cent détails canoniques, anciennes clés et IDs numériques, la recherche historique, le 304 et le 409 lors d'un commit de version interposé. Il modifie uniquement la version dans la nouvelle copie. Le statut final figure dans le rapport principal et historical-http.log.

Le rejeu du lecteur est terminé avec succès (100 alias, 304, 409). Le driver exact, conservé ensuite sans changement de logique dans historical-http-replay.py, permet de recréer une nouvelle copie : `"$E/ci-clean/bin/python" -B "$R/historical-http-replay.py"`. Archiver les sorties avant répétition.

Après vérification, le conteneur privé 55484 a été arrêté pour libérer ses ressources, sans suppression. Reprise : `docker --context colima start vega-astra-t4-20261118-1435`. Le clone HTTP sur 32768 et les bases T3/T2 sur leurs ports propres restent conservés.
