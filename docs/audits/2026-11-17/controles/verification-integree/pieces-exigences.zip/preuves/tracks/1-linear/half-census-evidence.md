# Production half-statistics loss, 17 November 2026

A read-only PostgreSQL census of the six populated season partitions and the public Vega player-halves route confirms the dropped observations. The approved, complete-case season totals work as defined; the original requirement and documented owner handoff also call for per-metric observation minutes and publishing exclusions. Historical VI-23 narrowed its own change to protect the existing consumer. Both VI-23 and VI-22 are Done.

| Production count | Result |
|---|---:|
| Stored player-match half rows, all six seasons | 2,760,411 |
| Finished, positive-minute half rows | 2,738,261 |
| Retained by migration 129 | 2,521,602 |
| Excluded because at least one public metric was unavailable | 216,659 |
| Eligible published-source minutes | 105,381,499 |
| Complete-case minutes | 95,689,936 |
| Lost passing minutes despite recorded passing | 9,691,563 |
| Player-season-period groups, across editions | 192,459 |
| Groups without any complete row | 15,364 |
| Entirely suppressed groups with positive observed passing | 15,342 |
| Additional groups losing some rows | 1,501 |

Passing was present on all eligible rows, including 47,390 observed zero passing counts. For xG, 2,278 eligible rows were unknown/nonfinite, 1,393 had an explicit finite zero and 1,796,590 had no recorded xG but observed zero shots (the existing structural-zero rule). A missing passing value is never manufactured. A player can appear in two periods and multiple seasons. These group counts cannot be interpreted as distinct people.

- Public player p_1FntG3, 2026/27, returned HTTP 404. The source had 83 completed passes over 225 first-half minutes, 82 over 270 second-half minutes. In fixture m_1dxYhp the source had 20/10 passes across two 45-minute halves, recorded zero shots and missing touches in each.
- Player p_2WXYqD, same season, returned HTTP 200. Public passing was 190 in 405 minutes and 115 in 388 minutes. Source support was 209 in 450 and 125 in 433. Fixture m_0QudQW contained the missing 19/10 passes, with missing touches in both halves. Both first and second half in this player satisfy the existing presentation threshold.

The raw result preserves metrics, counts and observed minutes by competition edition/period plus group counts and examples by season. Each season’s counts and witnesses share one SQL statement snapshot. Six snapshots span 21:59:59–22:00:10 UTC and the database was live. AWS profile statarena, RDS vega_v2, pinned worker image 8018e0836c, TLS verified, transactions read-only, all queries succeeded. Receipt contains image, query SHA256 and task ARN. JSON public receipts record raw bodies, headers and UTC.

Expected on the release: verified fixture observations can be lost in a complete-case projection, a wholly suppressed case can produce 404 and a partially supported case can still return only complete-case totals. Actual HTTP responses match both. A future branch that exposes supported data should intentionally invalidate those old HTTP assertions; use new DB→API criteria and validate the old result against the pinned release.

## Rerun

From the production-architecture-review evidence directory with Python, AWS CLI and the authorized statarena profile. A fresh batch directory keeps original results intact. The diagnostic runner requires the pinned 8018e0836c release; if the image changed, explicitly repin and date the measurement as a new release.

```sh
python3 tracks/1-linear/prepare-half-census.py
audit_batch=track1_half_repeat_$(date -u +%Y%m%dT%H%M%SZ)
mkdir "db/$audit_batch"
cp db/track1_half_coverage/*.sql "db/$audit_batch/"
python3 session_selects.py "$audit_batch"
python3 tracks/1-linear/verify-half-census.py --raw "db/${audit_batch}_verified" --output "tracks/1-linear/$audit_batch"
```

Original raw SQL, rows and task receipt: db/track1_half_coverage_verified/. Local summaries: tracks/1-linear/half-census.json and half-witnesses.json. Public witness IDs are chosen deterministically from current data, within the stated season and inclusion rules. Rechecking a later database legitimately produces different counts.
