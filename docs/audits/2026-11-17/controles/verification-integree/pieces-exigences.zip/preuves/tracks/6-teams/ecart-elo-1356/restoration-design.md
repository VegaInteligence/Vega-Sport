# Restauration sur copie — conception bornée, sans implémentation

**Proposition de revue, pas une procédure de production exécutée.** Périmètre : les 35 clés 8049–8060, 8290–8301, 8534–8544 et leurs 70 côtés Elo 2097. Les organisateurs corroborent les 35 dates/paires/scores. Il n’est proposé ni changement de modèle, ni recalcul/republication des Elo, ni modification du planificateur ou des règles VI-21. La protection de snapshots VI-27 concerne les futurs retraits ; elle ne reconstitue pas une préimage déjà supprimée.

## Peut-on conserver les clés avec le writer normal inchangé ?

**Pas en lui fournissant simplement les résultats anciens.** R et W cherchent une ligne existante via core.provider_ids + core.matches ; s’ils ne la trouvent pas, ils insèrent une nouvelle ligne avec l’identité SQL par défaut. L’Elo n’est pas une source d’identité du writer. Le rejeu R a réintroduit exactement les 35 faits sous **35 nouvelles clés**, laissant les **70 Elo orphelins**, y compris après une seconde lecture stable : [changements de clés](reinserted-key-changes.json), [résultat complet](replay-R/results.json).

Le writer W pourrait ensuite **réutiliser** les anciennes clés si une étape de réparation préalable, séparée, réhydrate exactement core.matches et leurs provider_ids. Cette préparation n’est pas le writer normal et doit être revue/testée comme telle. Le mode `found` de snapshot.write conserve id ; la protection refuse ensuite le CSV amputé. Ne jamais obtenir l’ancien id en abaissant une séquence, en alignant l’ordre d’import ou en injectant un provider_id pointant vers un parent absent.

Une réintroduction de fichier ancien seul n’est pas sûre : elle omet les dix nouveaux résultats et peut omettre d’autres faits courants. Une union complète est un témoin positif, pas une publication authentique et pas une restauration des préimages. Sur W, les statistiques absentes du CSV sont conservées pour un match existant ; plusieurs colonnes core, notamment les mi-temps, sont en revanche réécrites depuis le candidat, éventuellement NULL. Exiger une comparaison complète avant tout passage du writer après réhydratation : un demi-score actuel d’organisateur est un **enrichissement**, pas une preuve de l’ancienne valeur RDS.

## Ce qui est récupérable à ce stade

| Élément | Preuve disponible | Limite |
| --- | --- | --- |
| 35 anciennes clés, saison, édition, paires de team_id, date, kickoff utilisé par Elo, score final, neutralité et stakes du calcul | Snapshot RDS 02:16 + rapprochement fournisseur/organisateurs | Le SELECT Elo est une projection des données, pas un dump core.matches ; son kickoff peut être une date de repli du calcul. |
| 70 Elo du run 2097 | Snapshot antérieur complet ; contrepreuve actuelle vérifiant before/after/expected/result float32, saison, kickoff et run_id (stakes courant non sélectionné) | Ne pas réécrire ces lignes. Toute publication/valeur nouvelle survenue depuis la capture impose un nouveau diagnostic et l’arrêt de la réparation préparée. |
| Clé fournisseur logique | Formule déterministe `folder:2026/2027:date\|home\|away` + anciens noms CSV ; exemples dans source-rows-35.json | Les octets historiques de provider_ids, is_current et updated_at n’ont pas été capturés ; confirmer avec une préimage relationnelle. |
| Stats source | Les 35 lignes CSV ont les cellules heure, mi-temps et stats **vides** ; le réimport normal produit **zéro team_match_stats** | Ne pas annoncer 70/210 lignes de stats récupérées ; zéro ligne reconstruite ne prouve pas zéro ligne historique en RDS. |
| Ligne core intégrale, rounds et enfants | Non fournis par le snapshot Elo existant | Il faut un export antérieur complet ou une restauration PITR **sur copie** attestant ces lignes et leurs absences. Aucune disponibilité de PITR n’est présumée ici. |

Les heures du CSV sont vides ; ne pas introduire l’heure de la page officielle comme heure historiquement stockée, ni fixer artificiellement midi/minuit. Aucune date n’est déduite du numéro de journée, des voisins ou du calendrier attendu.

## Préimage et références à exiger avant réparation

1. Extraire en lecture seule d’une **copie avant incident** les 35 core.matches complets, tous leurs provider_ids (pas seulement open_matchday), les lignes parentes référencées et les enfants. Enregistrer l’horodatage effectif, snapshot, schéma, valeurs NULL, nombres et SHA-256. Le point 02:16 était avant les retraits observés ; la capture actuelle date de 14:20. Une copie PITR disponible avant la collecte 12:16 serait une source à vérifier, pas à supposer équivalente à 02:16.
2. Les références physiques comprennent season_id / competition_season_id, home/away team_id, round_id, venue/referee éventuels, et les paires (match_id, season_id) des enfants. Le catalogue W possède **26 contraintes FK des tables parentes (partitions exclues)** vers core.matches : statistiques par équipe/joueur/période, événements, lineups, tirs, couverture, réseaux, heatmaps, h2h, cotes, momentum, avertissements/opérations, shot_xg, lineup forecasts et attestations d’archives. L’inventaire exact est dans [restoration-schema-and-source-stats.json](restoration-schema-and-source-stats.json) et doit être refait sur le schéma de la copie utilisée.
3. Les références **sans FK** demandent un contrôle séparé : agg.team_elo, agg.player_match_grades et autres colonnes match_id/match_key (ou identity/latest_match_id), provider_ids polymorphe, alias/attestations éventuels. L’absence de FK explique la survie des 70 Elo ; ne pas supprimer ces témoins ni conclure que les enfants en cascade n’existaient pas. Identifier aussi les références indirectes à des shot/event/lineup ids avant de restaurer ces objets.
4. Pour chaque table enfant, préserver les vraies clés et valeurs antérieures, ou attester explicitement zéro ligne. Si une table n’est pas capturée, elle reste **non vérifiée**, jamais assimilée à zéro. Les fichiers publics actuels n’ont pas autorité pour remplir une lacune historique. Un [manifeste SQL de lectures bornées](restoration-preimage-reads.sql), non exécuté ici, prépare ces extractions sur la copie avant incident ; ses commandes de lecture des autres tables doivent être inspectées puis conservées avec leurs résultats.

## Gardes de la réparation à développer sur copie

Le manifeste doit énumérer ces **35 faits exactement**, leurs anciennes clés et empreintes ; aucun `match_date BETWEEN` ne doit servir de sélecteur d’écriture. Précondition : parent ancien absent, ou déjà restauré **strictement identique**. Si id existe pour un autre fait, si la même provider key pointe ailleurs, si une clé courante du même événement existe déjà, ou si les parents ont changé de sens, **refus total**, sans UPSERT destructeur ni fusion automatique.

Exiger une transaction avec verrou compatible avec le verrou source open_matchday/europe, et garde contre les changements concurrents. Vérifier dans la même transaction l’état de destination, les 70 Elo inchangés et les références. L’identité SQL est BY DEFAULT : une insertion explicite de l’ancien id est techniquement possible, mais elle n’est justifiée que par la préimage et les gardes. Ne jamais diminuer la séquence ; prouver qu’une insertion normale ultérieure ne collisionne pas (les anciens ids sont normalement déjà sous le front courant, à mesurer).

Une réparation réussie ne modifie que les parents/enfants manquants attestés et les versions de lecture strictement nécessaires. Les éditions doivent exposer un nouveau contenu après restauration, puis être stables au second passage. Protéger 70/70 Elo, leurs run_id et bits float32 ; ne pas les recalculer, leur changer d’id ou attribuer une publication nouvelle. Vérifier les hashes des populations étrangères au manifeste. Si une préimage est déjà présente et identique, le second passage ne doit écrire aucune ligne ni incrémenter révision/updated_at/version. Toute différence doit arrêter, pas écraser.

## RED et contrôles positifs requis, avant le code de réparation

- **RED réel déjà établi** : sur la source amputée, R supprime 35 et orpheline 70 ; le writer normal réintroduit sous 35 nouvelles clés. Sur W démarrant **après l’incident**, le garde seul n’a pas de mémoire des parents perdus : exiger ce témoin sur la copie de destination, sans présenter le test préventif existant comme un test de réparation.
- **Collisions RED** : une ancienne clé occupée par un autre fait ; une provider key détournée ; un même fait présent sous nouvelle clé ; une saison/équipe/round incompatible ; un des 70 Elo changé ; un enfant divergent. Chaque cas doit refuser toute la transaction et laisser les empreintes de destination inchangées.
- **Préimage invalide RED** : 34 ou 36 lignes, score/date/paires manquants, SHA faux, deux clés pour le même fait, enfant/stat inconnu présenté comme zéro, CSV sans heure transformé en kickoff inventé. Rejet explicite avant mutation.
- **Positif réel** : copie avec 35 parents et clés fournisseur absents, 70 Elo 2097 présents, préimage attestée. Résultat : anciennes clés rétablies, 70 jointures Elo valides inchangées, tous les enfants attestés identiques, dix nouveaux résultats conservés, absence de mutation hors périmètre.
- **Idempotence et concurrence** : second passage aucune mutation, versions/ETags stables ; course avec collecte, interruption avant commit et reprise ne créent ni demi-restauration ni doublon. Les droits d’exécution doivent être ceux du chemin opérationnel retenu, pas seulement postgres.
- **Retour au collecteur normal W** : source amputée refusée avec 35 parents conservés ; source complète bornée accepte les nouveautés légitimes sans perdre parent, stats ou demi-scores connus ; HTTP public résout les anciennes clés et deux côtés Elo ; répétition 304. Chaque essai conserve setup, commande, préimage, attentes et résultats.

Ces essais de **réparation** sont des exigences pour l’implémenteur ; seuls les replays préventifs R/W et la réinsertion normale déjà cités ont été exécutés dans cette revue. Aucun script de mutation, aucune restauration PITR, aucun backfill ou déploiement n’a été réalisé ici.

## Probe de préimage livré ensuite

Le coordinateur a identifié une sauvegarde chiffrée 04:50 et inspecte les copies locales ; cette revue n’en a pas accédé les données. [Probe V2 collect(db)](preimage/README.md) figé et validé sur les deux schémas locaux, avec V1 préservé pour les transports déjà lancés. Son exécution réussie sur une vraie copie antérieure, puis le contrôle des résultats, demeure nécessaire pour lever les limites de préimage ci-dessus.
