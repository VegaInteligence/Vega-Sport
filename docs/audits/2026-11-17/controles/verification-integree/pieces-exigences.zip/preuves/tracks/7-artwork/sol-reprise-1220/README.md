# VI-30 — preuves de la reprise locale

Le lot propage les références liées aux éditions par le writer T4 et conserve les champs d’image de famille. Les listes CAF, Cymru North et DFB transmettent les références des côtés depuis leurs propres FK. L’annuaire et la recherche partagent le catalogue des compétitions. Les écrans réutilisent les emplacements approuvés. Les absences, affiches documentaires, quatre placeholders et logo de l’organisateur belge ne deviennent pas des associations.

## Résultats

- `combined/receipt.json` et `combined/migration-sha256.json` contiennent les 184 vérifications du writer et de l’API réussies. Les migrations réelles T4 141/142 et 146 ont été appliquées avec T7 136/144 sur la base PostgreSQL 18 dédiée. Le writer a lié 47 éditions, dont les 25 associations du complément archives/natif, à 41 assets. Les 47 certificats concordent avec leur pointeur. Au deuxième passage, les 47 associations ont répondu `already_linked`. Les corps de coupe, snapshots, fixtures natives et archives bornées ont servi les références attendues. Les cas conditionnels ont vérifié les ETags et le sidecar d’archives.
- `combined/browser-checks.json` contient 40 vérifications réussies dans Chromium 1440×960 et 390×844. Les en-têtes CAN 2021/2023/2025, Asie 2023 et Mondial 2018/2022/2026 décodent les bons octets. Les témoins 1930/1958 restent vides. La réponse tardive 2023 n’affiche aucune image sur l’édition 2021 forcée en erreur. Le navigateur natif a sélectionné 2022 et 2026. Les gardes d’identité sont dans les manifestes. Pour les routes des archives/natifs dépourvues de rencontre dans la copie, le témoin de lecture est explicitement synthétique.
- `combined/caf-desktop.json` et `combined/caf-mobile.json` donnent chacun 96 emplacements corrects sur 48 résultats de groupe et 16 clubs. Les 48 résultats proviennent de la réconciliation gelée. Le chargeur a lié les 12 profils certifiés utilisés pour compléter cette copie. Quatre autres clubs gardaient le pointeur déjà publié. Leurs quatre copies immuables, lues publiquement en lecture seule, ont été vérifiées selon le SHA stocké. Les images représentent les profils des clubs. La période historique du dessin n’est pas validée.
- `acceptance-current/complete-route-acceptance.json` donne 26/26 contrôles de routes, 16/16 plus 16/16 contrôles étendus. Les quatre lectures Cymru North croisent les deux identifiants et les deux tailles d’écran, avec 58 emplacements de côté par vue pour 16 clubs. La recherche bornée rend une entrée unique, décode 512×111 et mène au bon identifiant source. Le verdict ancien exigeait des initiales pour Northern Premier League. Le nouveau verdict a été recalculé sur le même relevé de DOM, avec l’absence désormais attendue. Les données brutes et l’ancien verdict restent dans `../routes-e2e/runs/sol-reprise-1220-search/`.
- `directory-verified/receipt.json` donne 8/8 cas nommés. La CAN et la Copa América gardent leur nom et un espace vide en l’absence de logo de famille. Cymru North conserve son image réelle. La 404 forcée sur ses deux voies ne dessine aucun trophée ni fausse image.
- `full-profiles/profile-1.json` et `profile-2.json` ont essayé les 1 598 associations du manifeste scellé avec le writer corrigé. Sur cette copie historique, 635 liens sont nouveaux et 962 déjà présents. Vicenza `pitchapi:t_0oRsTk` est la seule cible absente de la copie. Le deuxième passage retrouve 1 597 liaisons existantes. Le chargement séparé du manifeste original sur une copie de lecture plus récente a vérifié les 1 598 associations et la préservation des 1 611 pointeurs. [Reçu indépendant du corpus 1 598](../../../root-checks/artwork-checked1598fresh/verification.json)
- `sportscore-artwork-candidates.json` conserve les 36 lignes d’Allsvenskan et J1 avec `team_logo` et le `competition_logo` par widget. Les URL constituent des pistes associables si les clés et les octets sont confirmés. Il n’y a pas d’association nouvelle pour ces collectes.
- Aucun push, déploiement, changement de couverture en production ou écriture RDS. Les archives sans emplacement conservent une réponse API enrichie, sans aperçu ajouté à leur sélecteur.

## Reproduction

Depuis ce dossier, avec le worktree T7 et le worktree T4 à leurs états consignés, utiliser des tags nouveaux. Les ports 18770 à 18772 doivent être libres. Le conteneur existant `vega-vi27-track7-pg18` (55470) et le template `vega_v2_vi27_track7_afterquota` sont requis.

```zsh
E='/Users/lemonnierhugo/.codex/visualizations/2026/11/17/01a1e6f1-9c43-7b81-a52e-3ee15c953578/production-architecture-review'
W='/Users/lemonnierhugo/Developer/Coding Project/Vega-Sport-audit-tracks-20261117/7-artwork'
D="$E/tracks/7-artwork/sol-reprise-1220"
cd "$D"
"$E/ci-clean/bin/python" -B run.py <nouveau-tag> --writer --caf
"$E/ci-clean/bin/python" -B repeat-inherited.py "$W" <tag-routes>
"$E/ci-clean/bin/python" -B verify-updated-absence.py <tag-routes> <tag-verdict>
zsh ci-bootstrap/run-ci.sh "$W" "$D" "$E" npm test --prefix backend/api
zsh ci-bootstrap/run-ci.sh "$W" "$D" "$E" python -m unittest discover -s backend/tests -v
(cd "$W" && node --test tests/*.test.mjs)
(cd "$W/dashboard" && NEXT_PUBLIC_API_ORIGIN=https://dngp6kh9jx2bl.cloudfront.net bun run build)
```

Le replay de profils utilise `full-profile-replay.sh` et sa base jetable dédiée. Les versions, SHA-256, commandes, réponses, sorties brutes et captures restent dans chaque dossier. Les entrées SQL copiées dans `ci-bootstrap` servent uniquement à l’exécution locale. Les migrations de départ et de mise à niveau emploient les mêmes fichiers T4 et T7 dans l’ordre de leurs numéros.

`shared-route/` contient les joints `cups.mjs` et `archives.mjs` construits en lecture seule à partir de la base de contenu commune. Vérifier les empreintes des entrées avant intégration. Les sorties ont été parsées par Node. La validation end-to-end de l’ensemble des branches appartient à l’intégration.

## Vérification de la branche remise

- Branche `codex/audit-7-artwork`, HEAD `d78a289b78`, propre. Les commits `55aff180c7`, `8a356718da` et `3f6bac5f69` portent respectivement la reprise du travail Opus, la lecture d’art d’édition et des écussons, puis la recherche.
- Les suites Node API ont donné 188/188 sans skip, puis les routes API modifiées 24/24. Les suites site donnent 716/716 sans skip. Build Next.js et package API réussis. Les logs sont `api-ci-recovered.log`, `api-targeted-final.log`, `site-ci-final-search.log`, `site-build-restored-search.log` et `api-package.log`.
- La suite Python sur T7 avec le schéma T4 copié pour l’essai compte 445 réussites sur 448. `test_source_identity.SourceIdentityTest.test_shared_site_data_as_rows` tente de lire un résultat absent après suppression de la référence statique World Cup et produit `TypeError`. `test_source_snapshots.CupLogosTest.test_L1_to_L6` attend qu’un logo World Cup installé sans certificat survive à la nouvelle garde et obtient `None != 1`. T4 a confirmé avoir modifié les deux contrats de test dans son worktree. Ces versions n’ont pas été exécutées avec les deux branches fusionnées pendant cette remise. `test_roles.RolesTest.test_migration_task_creates_logins_idempotently` compare les 139 migrations enregistrées à 136 fichiers attendus du seul checkout T7. Le runner de cette répétition inclut trois vrais fichiers T4 supplémentaires (141, 142 et 146). Le décompte sur la branche intégrée reste à confirmer. Les sorties exactes sont dans `python-ci-recovered.log`.
- Le redémarrage séquentiel des instances locales T7, T4, T2, T1 et du clone historique 32768 a préservé les conteneurs et volumes existants. La première tentative intégrée a été interrompue par l’arrêt de Colima. Le replay `combined` a abouti après reprise. Aucun verdict de revue indépendante Astra/Fable ni état du futur worktree intégré n’est attribué à T7.
