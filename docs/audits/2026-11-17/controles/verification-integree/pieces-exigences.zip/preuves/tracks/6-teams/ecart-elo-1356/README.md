# Delta Elo du 18 novembre — contrepreuve indépendante

Revue **gpt-6-astra / xhigh**, modèle explicitement sélectionné. Code déployé R **8018e0836ca0f32e8b2eb51fc2847154abff7f13** ; branche réunie W **13f7be9f35c8bf7a4d41cefd69d6d2c585e47c07** au rejeu. Le contrôle ultérieur relève **a6b4a313742283daaa305703aa49956f240b3bf1**, commit documentaire du coordinateur ; les fichiers applicatifs inspectés sont toujours ceux de 13f7be9f. Les résultats gardent leur SHA d’exécution. Aucun code produit ni production modifié. Les requêtes RDS ont été exécutées par le coordinateur avec son wrapper en lecture seule ; cette revue consomme les captures et rejoue sur deux bases locales neuves.

## Verdict

**E04g est incomplet à la mesure courante.** Les 20 côtés sans Elo sont les deux côtés de dix résultats du 17 novembre nouvellement importés, distincts des **35 matchs disparus et des 70 Elo devenus orphelins**. Leur disparition est physique dans la recherche bornée, pas seulement une exclusion du calcul. Les règles d’appartenance, de modèle et de réveil restent **VI-21**. Le garde de branche contre les futurs retraits est efficace sur ces données réelles ; il ne restaure pas des clés déjà effacées.

La concordance numérique de la publication 2097 reste vraie sur son instantané : ce résultat historique n’est pas une preuve de couverture actuelle. Aucune couverture n’est créditée par simple soustraction des orphelins ou par réintroduction de matchs sous d’autres clés.

## Rapprochement des faits

Le [tableau des 35 dispositions](dispositions-35.csv) conserve chaque ancienne clé, édition, paire, date, score, origine publique et limite. Les [dix nouveaux résultats](new-results-10.csv) sont séparés. [analyze.py](analyze.py) vérifie les empreintes des trois captures RDS et des CSV publics, les cellules exactes et les valeurs Elo binary32 ; [analysis.json](analysis.json) est son résultat.

| Édition | Résultats anciens dans le CSV | Retirés | Nouveaux | Résultats actuels dans le CSV |
| --- | ---: | ---: | ---: | ---: |
| 332, National League North | 124 | 12 du 31 août | 4 | 116 |
| 333, National League South | 122 | 12 du 5 septembre | 2 | 112 |
| 334, Northern Premier | 118 | 10 du 31 août + 1 du 1er septembre | 4 | 111 |
| Total des trois sources | 364 | 35 | 10 | 339 |

Le dénominateur des **quatre** éditions vérifiées inclut aussi Cymru North 361 : **463 − 35 + 10 = 438 matchs admis**, **856 côtés présents sur 876 attendus**, soit 20 absents. Ces nombres ne sont pas les 339 seuls résultats des trois CSV ci-dessus.

- Capture publiée à **02:16:34.234527 UTC** : run **2097**, commencé à 01:48:53.370889, publié à **01:49:24.867474**, **81 923 matchs / 163 846 côtés**.
- [rds-3](rds-3/receipt.json) à **14:08:25.179526 UTC** : capture correcte qui applique les règles globales Elo avant de filtrer les quatre éditions ; 438 matchs, 856 côtés. Ne pas réutiliser les premiers essais erronés de ce dossier.
- [Contrepreuve](contrepreuve/rds/receipt.json) à **14:20:15.680786 UTC** : zéro ancienne clé dans core.matches ; zéro paire connue dans les deux orientations à ±31 jours, toutes compétitions ; zéro provider key pour ces 35 clés. Les racines des équipes sont non fusionnées et absentes des alias courants. **70 lignes agg.team_elo persistent**, toutes rattachées au run 2097, mêmes saison, kickoff et valeurs before/after/expected/result binary32.
- La population globale admise courante est 81 898. L’égalité 81 923 − 35 + 10 = 81 898 est compatible avec le compte global ; aucun nouvel ensemble global complet de clés n’a été capturé ici pour exclure des changements compensateurs ailleurs.

La colonne `stakes` des 70 orphelins n’est pas sélectionnée dans la contrepreuve : sa valeur courante reste non vérifiée, même si elle figure dans le snapshot ancien. La conservation de ligne intégrale doit être contrôlée avant réparation.

La requête complète et les paramètres sont dans [astra-followup-probe.py](astra-followup-probe.py). La recherche ne permet pas d’exclure une paire renommée sous des identités inconnues ou une date déplacée au-delà de 31 jours. Elle exclut les remplacements usuels à paires connues, y compris dans une autre compétition.

## Publications originales et corroboration sportive

Les [fichiers publics conservés](public-source/receipt.json) sont épinglés aux commits fournisseur **496e94ec4c976cbc244fc734c86e6772778a35f1** (ancien) et **13a434955de865f66f95a71937205a3a286488c6** (actuel, commité le 18 novembre à **06:43:54 UTC**). Les 35 dates/paires/scores existent exactement dans le premier et manquent du second. Les dix nouveaux existent exactement dans le second et manquent du premier. Cela établit le retrait du fichier publié, sans confondre cette publication avec la vérité sportive universelle.

Trois témoins indépendants du dépôt fournisseur ont été archivés, HTTP 200 et SHA-256 dans [official-witnesses/receipts.json](official-witnesses/receipts.json) :

- **8059**, Spennymoor Town 1–1 Hednesford Town, 31 août : [rapport Hednesford](https://htfc.co.uk/2026/08/match-report-spennymoor-town-1-1-hednesford-town/).
- **8291**, Billericay Town 3–3 Dorking Wanderers, 5 septembre : [rapport Dorking](https://dwfc.co.uk/2026/09/match-report-billericay-town-3-3-dorking-wanderers-05-09-26/).
- **8534**, Curzon Ashton 2–0 Ashton United, 31 août : [publication Curzon](https://curzon-ashton.co.uk/adam-barton-post-ashton-united-h/).

**Corroboration complémentaire achevée : 35/35 résultats concordent avec les organisateurs.** Deux flux publics de la National League contiennent chacun les 552 rencontres de 2026/2027 : 12 résultats North le 31 août et 12 South le 5 septembre. La page NPL du 31 août au 1er septembre contient les 11 résultats Premier. Dates et scores correspondent exactement ; les noms abrégés utilisent une table de correspondance explicite, sans recherche floue. [Rapprochement des 35](organizer/matched-35.json), [script](organizer/reconcile.py), [reçu National League](organizer/national-season-receipts.json), [reçu NPL](organizer/date-discovery-receipts.json), [note](organizer/README.md). Cette concordance sportive ne décide pas à elle seule de leur admission Elo ni ne restitue les anciennes statistiques RDS. Aucune date manquante n’est reconstruite par heuristique.

[Note de conception pour une restauration sur copie](restoration-design.md) : le writer normal seul ne conserve pas les anciennes clés après suppression. Les CSV anciens ont zéro cellule statistique et zéro mi-temps renseignée pour ces 35, et produisent zéro ligne team_match_stats. Une préimage relationnelle complète antérieure à l’incident demeure nécessaire pour une restauration exacte des autres champs et enfants.

## Échéance réellement exposée par le worker

La dernière collecte open_matchday réussie démarre à **12:16:08.578408 UTC**, met à jour son reçu à **12:16:44.772623**, écrit 4 682 lignes, unmatched 0. À **14:20**, la vraie fonction déployée `worker.due_seasons` retourne **[]**. Le dernier levels de 2026 commence à 01:15:36.751135 ; le dernier finished natif modifié date de 00:37:51.842157. Ceux de 2025 ne déclenchent pas non plus une échéance.

`due_seasons` exclut les éditions qui portent `archive_key` ou `cup_key`. Les dix nouveaux résultats complémentaires ne déclenchent donc pas le test « saison modifiée, délai d’une heure ». `Worker.daily` appelle `refresh_elo` seulement si une saison est due. Le passage latéral toutes les 60 secondes, la période source de six heures et le délai de reprise d’une heure ne constituent pas une promesse d’Elo horaire.

Sans autre événement natif ou condition de modèle, le prochain seuil calendaire connu de la saison native 2026 est **le 19 novembre à 00:00 UTC**, puis un cycle latéral peut tenter le calcul. Ce n’est **pas une heure de publication garantie** : pré-traitements, verrous ou échec peuvent retarder la fin. `worker.py` et `power.py` sont identiques entre R et W. Cette revue ne modifie ni le modèle ni le planificateur VI-21.

## Rejeu par l’entrée normale

[Attentes écrites avant exécution](replay-expectations.md), [harness](replay-snapshot.py), [serveur réel](serve.mjs), [résultat R](replay-R/results.json), [résultat W](replay-W/results.json), [journal R](replay-R.log), [journal W](replay-W.log).

Deux nouvelles bases PostgreSQL 18, port 55484, conservées pour inspection. Migrations propres à chaque SHA. `sources.run_due` sous **vega_collect** ; vrai handler HTTP et lecteur sous **vega_read**. Le transport externe est remplacé par les cellules CSV capturées, réencodées par DictWriter ; le manifeste est limité aux trois ligues. Les 70 Elo publiés sont chargés comme préimage, remappés aux clés locales par date/paires/scores exacts : les clés locales ne sont pas les clés physiques RDS.

| Étape | R 8018e083 | W 13f7be9f |
| --- | --- | --- |
| Source ancienne, préimage 70 Elo | 364 résultats, 0 orphelin | 364 résultats, 0 orphelin |
| Source actuelle, 35 absents + 10 nouveaux | 339 résultats, 70 orphelins ; HTTP 200 | 3 refus SNAPSHOT_DROPS_RESULT ; 364 conservés, 0 orphelin ; HTTP conditionnel 304 |
| Contrôle positif construit, union complète | 374 résultats, **70 orphelins toujours** | 374 résultats, 0 orphelin ; HTTP 200 |
| Répétition de cette union | 374, 70 orphelins, HTTP 304 | 374, 0 orphelin, mêmes lignes et révisions, HTTP 304 |

L’union complète est un **contrôle construit**, pas une nouvelle publication fournisseur. La protection W conserve les matchs et leurs Elo mais refuse aussi les dix nouveaux tant que la source reste amputée : c’est le compromis observé. Le retour des résultats sous R crée de nouvelles clés, sans rattacher automatiquement les anciens Elo. Le test ne recalcule pas le modèle global, ne restaure pas la production et ne démontre pas l’état historique de statistiques qui n’ont pas été capturées en RDS.

Depuis E : `PYTHONDONTWRITEBYTECODE=1 ./ci-clean/bin/python -B tracks/6-teams/ecart-elo-1356/analyze.py`. Pour rejouer, préserver les dossiers `replay-R` / `replay-W` existants dans ce même dossier de preuve, puis exécuter `PYTHONDONTWRITEBYTECODE=1 ./ci-clean/bin/python -B tracks/6-teams/ecart-elo-1356/replay-snapshot.py R` et la même commande avec `W`. Le harness refuse d’écraser une preuve existante et crée un nom de base unique ; W doit être au SHA indiqué. Aucune CI intégrale relancée. [Reçu code et runtimes](code-and-runtime-receipt.json) : versions réelles, noms des bases conservées, empreintes des fichiers et HEAD observé après les travaux du coordinateur.
