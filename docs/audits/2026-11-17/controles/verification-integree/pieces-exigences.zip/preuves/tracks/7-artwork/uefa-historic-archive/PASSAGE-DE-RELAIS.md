# Relais autonome des visuels Vega

Hugo confie au chat partenaire la suite des visuels, des acquisitions, des contrôles et des publications éventuelles. La révision produit communiquée pour ce relais est **`a6b4a313742283daaa305703aa49956f240b3bf1`**. Les preuves PostgreSQL du lot UEFA ont exécuté le chargeur du candidat figé **`01130327f8453c4e80cbb0db7a9b307513ba6343`**. Le partenaire peut comparer les deux révisions avant une qualification ou une publication future.

**Décision au départ du relais : aucune publication.** Le registre de l’audit pointe toujours sur 1 605. Le ZIP 1 932 est un candidat inspectable. Le chantier source s’arrête après remise de ce dossier.

## Paquet et résultats

| Fichier ou population | Valeur |
| --- | --- |
| Candidat cumulatif | `candidate-1932.zip` |
| SHA-256 ZIP | `0547bdfae5c34c924e1c47a27ad3c68f2ef3a4b9915265974378f209b4422476` |
| SHA-256 manifeste cumulatif | `8f50533de53eec90b4e510e45a4608ccdc610cbf77dbe53551aadcb69f5c2feb` |
| Rattachements cumulés | 1 932, dont 1 828 clubs et 104 compétitions |
| Nouveaux rattachements UEFA | 81 profils non numérotés et 246 occurrences |
| Identités UEFA distinctes | 143, dont 121 rattachées avec preuve à une autre racine déjà illustrée |
| Couverture | 64 saisons C1 et 4 127 des 6 480 rencontres avec correspondance des deux côtés |

Le paquet 1 605 de référence conserve les 1 611 pointeurs initialement relevés dans ses essais seul sur le schéma de production. Au passage sur le candidat intégré, le retrait attesté des deux faux logos génériques du Mondial 2026 ramène cette base à 1 609 pointeurs à préserver. Les seuils de conservation des preuves 1 932 partent de cet état intégré. [Candidat](candidate-1932.zip) · [Métadonnées du paquet](candidate-expanded-1932/release.json) · [Contrôle des octets du ZIP](verify-1932-zip.json)

| Capture RDS locale | Import direct de 1 605 avec le candidat intégré | Mise à niveau de 1 605 | Compléments 81 puis 246 | Rejeu cumulatif de 1 932 |
| --- | --- | --- | --- | --- |
| 17 novembre | 1 604 liaisons, Vicenza absent | 7 ajouts CAF après l’étape 1 598; 1 604 liaisons cumulées | 81 et 246 liés au premier passage, déjà liés au deuxième | 1 931 déjà liés, Vicenza absent |
| 18 novembre | 1 605 liaisons | 7 ajouts CAF après l’étape 1 598; 1 605 liaisons cumulées | 81 et 246 liés au premier passage, déjà liés au deuxième | 1 932 déjà liés |

Les deux compléments ont également été importés directement depuis leurs propres manifestes sur chaque copie qui avait reçu le lot 1 605. Un import direct du manifeste **cumulatif 1 932** sur une capture vierge du lot 1 605 et des deux compléments reste à exécuter si le partenaire souhaite qualifier ce mode de première installation. Le rejeu cumulé sur les copies déjà enrichies est attesté. Les contrôleurs stricts initiaux du lot 1 605 ont refusé les hypothèses brutes qui combinaient les 1 611 pointeurs pré-migration et la présence de Vicenza au 17 novembre. Les reçus du lot 1 605 conservent ces refus et les chemins vérifiés avec les hypothèses corrigées. [Relectures 1 605](../all-roots-1605/README.md) · [Preuves 1 932 et empreintes](delivery-verification.json) · [Commandes locales](REPLAY.md)

## Exceptions et périmètre résiduel

- **Vicenza** #13539, clé `pitchapi=t_0oRsTk`, manque dans la capture du 17. La capture du 18 le résout dans les révisions 1 605 et 1 932. Il appartient au lot de départ.
- **Huit racines** produisent une contradiction sur l’identifiant de club dès qu’on compare date, score, côté et adversaire. Le registre isole deux racines Stade Dudelange, deux Pyunik et quatre Levadia. Ces cas partent à VI-21.
- **Dix-huit occurrences** trouvent un témoin pour tous leurs usages mais une correspondance officielle n’est pas réciproque de façon unique. Leurs rattachements visuels restent retenus.
- **3 139 des 3 466 fiches** initiales `archive:europe:` restent ouvertes. Parmi elles, 813 n’ont pas de rencontre dans les deux séries C1 historiques. Sur les **2 326** ouvertes dans ces séries, 1 704 n’atteignent pas le seuil de preuve d’identité, 575 ont au moins un usage sans correspondance complète ou réciproque, 39 sont retenues lors de l’examen des visuels ou de la continuité et 8 ont une contradiction explicite. Les dix-huit non réciproques font partie des 575. L’ensemble des fiches de club et assimilées sans image passe de 8 027 à 7 700 dans le recensement projeté sur copie.

[Inventaire par fiche](all-3466-archive-roots-dispositions.csv.gz) · [Registre des alias et contradictions](vi21-alias-evidence.json.gz) · [Motifs visuels et continuité](visual-decisions.json) · [Calcul de couverture](comparative-census.json)

## Dossiers à transmettre au partenaire

La racine de preuve est `/Users/lemonnierhugo/.codex/visualizations/2026/11/17/01a1e6f1-9c43-7b81-a52e-3ee15c953578/production-architecture-review`. Les chemins suivants sont relatifs à cette racine.

| Dossier ou fichier | Usage |
| --- | --- |
| `tracks/7-artwork/uefa-historic-archive/` | Ce relais, les 41 réponses inédites de calendrier, les 19 reçus d’images, les planches, les deux suppléments, le candidat 1 932, les reçus de PostgreSQL et le registre VI-21 |
| `tracks/7-artwork/all-roots-1605/` | État de référence, captures et relectures, effets distincts de la migration 146, code 01130327 figé et recensement avant le complément |
| `artwork-expanded-1605/`, `logos-verifies-1605.zip`, `current-artwork.json` | Paquet, empreintes et registre de référence de l’audit |
| `root-checks/artwork-caf1605prod18/` et `root-checks/artwork-caf1605legacy18/` | Essais du paquet seul et conservation des 1 611 pointeurs |
| `remaining-club-art/source/`, `remaining-club-art/checks/`, `remaining-club-art/assets/` | Calendriers UEFA et écussons déjà conservés, repris lorsque l’ID et l’empreinte correspondent |
| `tracks/3-identities/club-fixture-fingerprints/rds-frozen/` et `db/archive_witnesses_verified/` | Captures gelées des racines, des clés, des dates, des résultats et des noms bruts |
| `tracks/7-artwork/refresh-media-nov18/` et `db/media_state_verified/`, `db/media_context_verified/` | Captures RDS du 17/18 novembre et extraction locale pour répéter les imports |
| `build_verified_artwork.py`, `combine_complete_artwork.py`, `verify_artwork_pack.py` | Composition et validation du ZIP à partir des manifests contrôlés |

**[VI-21](https://linear.app/vegainteligence/issue/VI-21)** reste propriétaire de la correction des clés, des alias, de l’identité, des fusions éventuelles et de la convergence des matchs. Les éléments UEFA sont des pièces datées que VI-21 peut examiner.

**[VI-30](https://linear.app/vegainteligence/issue/VI-30)** et le partenaire reprennent la qualification des visuels, les sources et droits, les contrôles de lecture, les essais de premier import et la préparation d’une éventuelle publication. Pour une nouvelle qualification, vérifier le code à la révision a6b4a313, éprouver le mode direct du cumul si souhaité et conserver la distinction entre clubs UEFA dédupliqués et racines qui reçoivent un visuel. La décision de publication appartient au partenaire dans son mandat et est séparée de ces résultats locaux.
