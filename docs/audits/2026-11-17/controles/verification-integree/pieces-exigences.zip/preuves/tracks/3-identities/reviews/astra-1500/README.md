# Vérification indépendante de la correction T3

gpt-6-astra / xhigh. SHA `33266597f766a019f8c75f1c99a4a21692381e06`. Même worktree T3, aucun fichier produit modifié. Diff relu contre `dc33b4fe59f7d01e4e963b7b5d055dd9ca7e9964`.

Attendus : expiration omise/invalide ne remplace ni le staging contractuel ni le fait publié; transfert complet reste admis; recherche partielle rend le profil dû; null explicite ne devient pas une date; fin datée corrigée peut rendre un contrat expiré.

Le témoin initial est repris dans witness_contract_completeness.py, avec `SET ROLE vega_collect` sur les lectures du Reader et maintien des préparations sous administrateur. Le vrai serveur de profil s'exécute sous vega_read. Une base neuve est créée sur 55471 à chaque lancement; son DSN et le SHA sont dans le JSON. Résultat : transfert Club 11 → Club 22 valide; les deux observations omise/invalide gardent intégralement Club 11 par HTTP, avec CONTRACT_MISSING / CONTRACT_INVALID dans la file. Reader.read renvoie toujours ok au niveau du lot; le refus individuel est celui de la file, pas une erreur HTTP fournisseur.

```sh
E='/Users/lemonnierhugo/.codex/visualizations/2026/11/17/01a1e6f1-9c43-7b81-a52e-3ee15c953578/production-architecture-review'
PYTHONDONTWRITEBYTECODE=1 "$E/ci-clean/bin/python" -B "$E/tracks/3-identities/reviews/astra-1500/witness_contract_completeness.py"
```

Le premier ajout du rôle avait placé le calcul de l'ID public sous vega_collect; PostgreSQL l'a correctement refusé (harness-role-public-id.log). Le calcul a été remis dans la préparation administrateur, sans élargir les droits.

Complément exécuté, deux parcours existants **2/2 verts**, avec un schéma neuf dans la base privée vega_v2_sources_test sur le conteneur de cette revue port 55484 :

```sh
W='/Users/lemonnierhugo/Developer/Coding Project/Vega-Sport-audit-tracks-20261117/3-identities'
PYTHONDONTWRITEBYTECODE=1 PYTHONPATH="$W/backend:$W/backend/tests" \
 VEGA_V2_SOURCES_TEST_DSN='postgresql://postgres@127.0.0.1:55484/vega_v2_sources_test' \
 VEGA_TM_HISTORY_REPORT="$E/tracks/3-identities/reviews/astra-1500/search-and-expiry.json" \
 "$E/ci-clean/bin/python" -B -m unittest -v \
 test_transfermarkt_history.ContractTest.test_20aj_missing_invalid_and_undated_club_changes_keep_dated_contracts \
 test_transfermarkt_history.ContractTest.test_20ak_a_dated_end_correction_is_still_an_observed_expiration
```

Ces deux parcours utilisent la connexion de test administrateur pour préparation et assertions, contrairement au témoin indépendant explicitement sous vega_collect. Ils couvrent profil et recherche, date tronquée, null explicite, préservation de la provenance un jour plus tard, HTTP, et correction d'une fin datée. Le rapport et le journal sont conservés. Aucun nouvel appel Transfermarkt, aucune CI intégrale, aucune validation de couverture production.

Le conteneur privé utilisé pour les deux tests complémentaires sur 55484 est arrêté après revue, sans suppression. Redémarrage : `docker --context colima start vega-astra-t4-20261118-1435`. Le témoin indépendant sur 55471 reste conservé séparément.
