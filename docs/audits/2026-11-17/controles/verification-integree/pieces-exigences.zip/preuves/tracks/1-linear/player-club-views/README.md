# VI-17 · Fiches publiques aux largeurs intermédiaires

Le 18 novembre entre 01 h 11 min 01 s et 01 h 11 min 18 s UTC, Chromium a parcouru les fiches de Lamine Yamal et du Paris Saint-Germain effectivement servies par la production. Les quatre largeurs testées étaient 641, 768, 1 024 et 1 280 pixels, à hauteur 950. Le test a changé la palette par le bouton de thème du site. Sur les 16 états, la largeur du document correspondait à celle de la fenêtre, le lien « Rapport » portait le bon identifiant et la même barre contenait « Enregistrer ». [Mesures des 16 états](verified/matrix.json) · [Reçu et empreintes](verified/receipt.json)

Sur les huit états joueur, une seule barre de filtres ouvre le dialogue « Du / Au » puis le referme. Une fois sa carte amenée dans la fenêtre, Yamal affiche le radar, quatre barres de rôle, six barres de compétence et le raccourci vers les statistiques avancées. Le palmarès et les neuf onglets sont présents. La demande ultérieure sur les barres dans le profil est suivie dans VI-21. Sur les huit états du PSG, les quatre chiffres de « Résultats et attendus » ont la même ordonnée. Les vues scannées ne couvrent pas toutes les largeurs possibles. [Carte du club, thème clair à 768 px](verified/club-section-768-light.png) · [Profil joueur, thème sombre à 1 280 px](verified/profile-section-1280-dark.png)

L’essai a ensuite actionné les deux choix de comparaison, l’onglet « Stats avancées », les liens de clubs de Yamal et Mbappé, et les liens de rapport de Yamal et du PSG. Dans les deux fiches joueurs, le contexte d’équipe suit « Valeur des actions ». Les cartes chargées de Barcelona et du Real Madrid comparent les équipes aux 20 clubs de LaLiga et présentent les valeurs de possession, de territoire et de PPDA. Le chargement s’effectue lorsque la carte devient visible. [Interactions et valeurs](verified/interactions.json) · [Carte du Real Madrid](verified/p_217YMB-context.png)

La première passe avait vérifié 16 états et la navigation, mais certaines captures précédaient les statistiques individuelles chargées à l’approche de la fenêtre. La passe retenue attend explicitement les compétences calculées et capture également les sections. Aucun changement de configuration utilisateur ou de donnée sportive. Les deux thèmes sont modifiés uniquement dans le profil temporaire du navigateur.

Depuis ce dossier de preuves, le contrôle hors ligne valide les JSON, les identifiants, les dimensions, les clics et les empreintes des 34 images. La seconde commande crée un nouveau profil de navigateur pour une nouvelle observation publique. Elle utilise le lanceur Playwright du Mac et le Chromium désigné dans le fichier de configuration de l’étude des cinq ligues. L’exécution sur une autre machine demande d’y indiquer son binaire Chromium installé. Le site et son contenu peuvent évoluer.

```sh
python3 verify.py
python3 run.py nouvelle-observation --session=vega-vi17-nouvelle
```
