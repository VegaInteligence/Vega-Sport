# Première division féminine saoudienne · les 292 côtés historiques

Une transaction RDS du **18 novembre 2026 à 11:28:21 UTC** ventile les 4 118 notes des éditions 1000 et 1001 sur leurs 292 côtés. Le rapprochement avec les feuilles SAFF déjà gelées confirme **23 participations de plus que de notes sur 23 côtés, et 16 notes de plus que de participations sur 13 côtés**. Les 256 autres côtés ont des comptes égaux. Aucun des 146 matchs ne compense un déficit de son équipe à domicile par un excédent de son adversaire, ni l’inverse. [Registre par équipe et par match](cotes-292.csv)

| Saison | Côtés | Titulaires SAFF | Entrées SAFF | Participations SAFF | Participations selon les indices RDS | Notes RDS | Déficits / excédents de notes |
|---|---:|---:|---:|---:|---:|---:|---:|
| 2024/25 | 180 | 1 980 | 561 | 2 541 | 2 552 | 2 547 | 5 / 11 |
| 2025/26 | 112 | 1 232 | 352 | 1 584 | 1 589 | 1 571 | 18 / 5 |
| Ensemble | 292 | 3 212 | 913 | 4 125 | 4 141 | 4 118 | 23 / 16 |

Les 146 totaux de match sont identiques à ceux de la capsule antérieure. Le nouveau relevé compte une seule fois la personne au sein du match. Les 4 118 clés de note coïncident exactement avec les 4 118 clés de statistique individuelle à minutes strictement positives, jusqu’à l’ID d’équipe. **Aucune note n’est dépourvue d’indice de jeu dans RDS**. Les indices de titularisation, remplacement, but ou tir ajoutent 23 acteurs-matchs sans note. Les compositions RDS comprennent 3 211 titulaires, 930 non-titulaires avec indice de jeu et 1 462 inscriptions au banc sans indice de jeu. Une attribution de côté fondée sur la composition et contredite par le seul événement disponible est détaillée plus bas. [Vérification SQL indépendante](verification-initiale.json) · [Comptes des 146 rencontres](matchs-146.csv)

## Personnes, maillots et banc

| Ce que la rencontre permet de vérifier | 2024/25 | 2025/26 | Ensemble |
|---|---:|---:|---:|
| Note rattachée par côté, maillot et nom exact unique à une participante SAFF | 210 | 168 | **378** |
| Note rattachée de la même manière à une joueuse SAFF restée au banc | 0 | 0 | **0** |
| Maillot d’une participante SAFF, identité en attente | 2 324 | 1 397 | 3 721 |
| Maillot d’une joueuse SAFF sans entrée, identité en attente | 13 | 6 | **19** |
| Note sans emplacement sous le même côté et maillot officiels | 0 | 0 | 0 |

Le contrôle strict exige que le nom multicomposant normalisé soit exact et unique dans chacune des deux sources, sur **l’ensemble des deux équipes du match**, et que le côté et le numéro concordent. Les noms originaux restent dans leurs systèmes respectifs. Le rejeu compare leurs empreintes après normalisation de la casse, des espaces et de la ponctuation. Les diacritiques sont conservés. Le nom doit identifier une seule personne de la rencontre parmi les alias officiels. Les 378 notes documentent des apparitions de 19 personnes fédérales et 19 racines Vega, sans correspondance croisée dans cet échantillon. La même règle associe 27 inscriptions au banc sans note. L’identité est ouverte pour 3 740 notes. La preuve disponible situe les **19 maillots de banc** et ne permet pas de conclure quelles personnes portent ces notes. [Synthèse des associations](synthese.json) · [Contrôles de faux positifs](tests-negatifs.json)

À l’échelle du maillot, **26 places fédérales de participantes n’ont aucune note Vega** et **19 places de banc en ont une**. Trois côtés compensent une divergence de maillot dans chaque sens. Le 31 janvier 2025, Al Taraji a le bon total contre Al Ahli alors que la n°16 a participé sans note sur son maillot et que le n°15, inscrit au banc sans entrée, porte une note. Les deux autres compensations concernent Al Ula à domicile le 14 mars 2025 (87606) et Al Ahli à domicile le 13 février 2026 (69346). Ces 26 et 19 sont des comptes d’emplacements. Ils ne constituent pas une liste de notes individuelles à créer ou à retirer. [Feuille du match Al Taraji–Al Ahli](https://wpl.saff.com.sa/match/14675?season=2024/2025) · [Registre des compensations](matchs-146.csv)

## Deux contradictions de côté à transférer à VI-21

- **Al Ahli–Al Ula, 8 novembre 2025, match 69327.** Vega inscrit la racine 2258 sur le banc à domicile sous le n°20. Son seul indice de jeu est le remplacement de l’équipe visiteuse associé au n°7. La SAFF garde la n°20 d’Al Ahli au banc et fait entrer la n°99 d’Al Ula à la place de sa n°7 à la 46e minute. La partie RDS compte l’acteur une fois et l’attribue conventionnellement au côté de sa composition. Le côté de l’apparition demeure indéterminé. [Feuille de la ligue](https://wpl.saff.com.sa/match/32040?season=2025/2026)
- **Al Ula–Al Ahli, 27 mars 2026, match 69353.** La même racine Vega est titulaire n°99 à domicile et porte un événement de but pour Al Ula. Elle apparaît également dans le remplacement visiteur associé au n°11. À la 71e, la SAFF fait entrer la n°20 d’Al Ahli pour sa n°11. La n°99 d’Al Ula est bien titulaire. Les deux numéros renvoient aux mêmes deux identifiants fédéraux distincts dans les deux manches. [Feuille de la ligue](https://wpl.saff.com.sa/match/32068?season=2025/2026)

La racine Vega 2258 n’a ni ligne de statistiques individuelles ni note dans ces deux rencontres. Parmi les 4 141 acteurs-matchs RDS, 4 139 ont des indices cohérents quant au côté, un a des indices de jeu pour le domicile en plus du remplacement adverse et un a pour seul indice le remplacement adverse. Toutes les notes disposent d’une équipe connue et d’un indice de jeu pour cette même équipe. L’événement d’origine qui a produit ces rattachements demeure inconnu. [Preuve croisée des deux manches](deux-cotes-contradictoires.json) · [Indices contradictoires](exceptions.json)

## Rejeu

Depuis une extraction neuve, Python 3.10 ou ultérieur et un outil SHA-256 suffisent.

```sh
shasum -a 256 -c SHA256SUMS
python3 -B verifier.py
```

Les SELECT, le probe et le reçu d’image figurent dans la capsule. Une seule transaction en lecture seule et à isolation reproductible a servi les huit sélections. La définition de diagnostic a été désactivée après succès. Le reçu donne l’empreinte des octets RDS. La sélection est bornée à la famille 197, aux deux couples saison/édition et aux 146 identifiants déjà gelés. Les seules pièces sportives externes utilisées sont les feuilles et journaux déjà scellés sur ces deux saisons. Les données transportées gardent les clés sportives, les numéros et les empreintes nécessaires au rejeu, sans biographies, photos ni coordonnées. [Reçu RDS](recu-rds.json)
