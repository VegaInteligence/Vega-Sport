# Dictionnaire des dispositions et vérification

Ce répertoire dérive le [registre T1 original](../requirements.csv) sans le modifier. Son CSV garde exactement : `id`, `requirement_fr`, `production_state`, `branch_state`, `measured_witness`, `source_paths`, `evidence_paths`, `owner`, `blocker_or_update_gate`.

## Signification des deux états

- `implemented_production` : contrat borné déjà mesuré en R. Dans la colonne branche, comportement hérité de R ; aucun nouveau déploiement n’est impliqué.
- `implemented_branch` : preuve bornée de branche ou livrable d’audit documentaire. Ici E01a, E02a et E06a sont des livrables, E04n une correction de parseur. La ligne explicite le périmètre, le SHA de code réellement exécuté et les limites.
- `incomplete` : défaut confirmé, couverture ou validation insuffisante, décision de méthode, de design ou revue finale en attente. Une correction de sous-périmètre peut être vérifiée tout en laissant ce statut.
- `missing` : absence établie du mécanisme demandé (A04, A11b), distincte d’un champ inconnu.
- `not_applicable` : action de coordination/audit hors exécution du produit ou distinction de contrat E04h. Ce statut ne signifie pas que toute obligation procédurale est accomplie.

Le SHA de branche est **13f7be9f35c8bf7a4d41cefd69d6d2c585e47c07**. La CI commune achevée porte **01130327f8453c4e80cbb0db7a9b307513ba6343** ; elle n’est pas renommée en preuve de la dernière branche. La preuve locale par lot conserve le SHA de ce lot. Les états de production restent ceux de R **8018e0836ca0f32e8b2eb51fc2847154abff7f13**, applicativement identique au déploiement Vercel **17ca0f76175301e77ae43fe137467222f594b40a** observé à 11:26 UTC le 18. Chaque population mesurée conserve sa propre date dans son reçu.

| Famille | Lignes | Production : implémenté / incomplet / manquant / sans objet | Branche : hérité / implémenté local / incomplet / manquant / sans objet |
| --- | ---: | --- | --- |
| A — 18 sections initiales | 38 | 12 / 24 / 2 / 0 | 12 / 0 / 24 / 2 / 0 |
| E — demandes du 17 | 36 | 2 / 24 / 0 / 10 | 2 / 4 / 27 / 0 / 3 |
| L — huit tickets clos | 8 | 6 / 2 / 0 / 0 | 6 / 0 / 2 / 0 / 0 |
| N — constats complémentaires | 9 | 8 / 1 / 0 / 0 | 8 / 0 / 1 / 0 / 0 |
| Total | 91 | 28 / 51 / 2 / 10 | 28 / 4 / 54 / 2 / 3 |

Une seule ligne change de statut global depuis le registre original : **E04g, implemented_production → incomplete dans les deux colonnes**. Les 20 côtés récents sans Elo et les 70 anciens Elo orphelins constatés à 14:20 UTC empêchent de reconduire la couverture historique comme couverture actuelle. [Contrepreuve](../../6-teams/ecart-elo-1356/README.md). Tous les autres statuts conservent l’acceptation bornée déjà établie ; aucune promotion. Les différences de faits et de blocages sont dans `measured_witness` et `blocker_or_update_gate`. Les dates et contre-exemples remplacés restent lisibles dans les preuves d’origine.

## Les 26 changements de calcul sont un autre registre

Le [dictionnaire original des calculs](../new-calculations.csv) garde ses 26 entrées et 13 colonnes. Il recense des changements depuis **36049afb498b177cc6d92ebd1b7b2346a81b7639**, référence du document du 16 novembre, jusqu’à la production R. Ses 23 commits de livraison distincts sont tous ancêtres de R. Il ne décrit pas 26 nouveautés introduites par les sept lots actuels, ne compte pas 26 critères supplémentaires à clôturer et ne s’ajoute pas aux 91 pour former 117 ou 121 exigences.

L’ancien checkpoint **7239f67f9c** diverge de R au repère **a912ed319e** (cinq commits propres contre 45). Une comparaison de marqueurs avec ce checkpoint n’est donc pas une preuve chronologique linéaire de chaque méthode. Résultat vérifié par `git show` : **10 repères présents, 9 repères absents et 7 fichiers absents** à ce checkpoint ; **26 repères présents en R et 26 en W**. La présence d’un nom de fonction ne prouve ni une sémantique inchangée ni une validation scientifique.

Les 14 catégories du registre se répartissent ainsi : six corrections de calcul ; quatre nouvelles simulations ; deux agrégats de lecture ; deux populations de calcul ; deux projections de calcul existant ; deux corrections de modèle ; un rapprochement de données ; une règle de classement affichée ; une extension de population/modèle ; un nouveau calcul de similarité ; un changement de modèle ; une extension de couverture ; une règle de repli ; un calcul opérationnel. Total 26.

Pour C18–C21, les migrations historiques 124/125/126/127 sont les équivalents d’intention des 128/129/130/131 de R ; leurs fichiers historiques existent. L’équivalence ne prétend pas que les octets sont identiques. La 137 de T1 prolonge C19 sans changer le total du dictionnaire.

| ID | Calcul ou lecteur compté | Repère 7239 | Repère R/W | Disposition actuelle et limite |
| --- | --- | --- | --- | --- |
| C01 | Synthèse des joueurs, tireurs, cartons et leaders d’un match dans l’interface. | présent | présent / présent | Les familles manquantes et les caméos VI-21 restent ; T1 ajoute gradeExact au transport sans preuve de nouvelles cellules. |
| C02 | Bilan saisonnier, évolution Elo et parcours des sélections par tournoi. | présent | présent / présent | Les pages de palmarès post-publication restent non vérifiées ; T4 répare des faits sans valider tous les parcours. |
| C03 | Enrichissement du tour et des tirs au but d’une rencontre de sélection depuis ses copies. | présent | présent / présent | Contre-exemple de paire assemblée (4,2)/(3,5)→(4,5) maintenu ; aucune paire assemblée observée sur la capture R. |
| C04 | Attribution historique des places européennes d’un championnat à partir du devenir observé des clubs. | présent | présent / présent | L’allocation réglementaire et le devenir observé diffèrent parfois; aucune vérification officielle de chaque saison ancienne. |
| C05 | Sélections réconciliées entre sources et participations internationales dans la chronologie Elo. | présent | présent / présent | Couverture internationale et identité demeurent incomplètes ; le dénominateur des côtés admis n’est pas celui de toutes les rencontres officielles. |
| C06 | Projection UEFA de phase de ligue, top 8, barrages et chaque tour d’élimination. | présent | présent / présent | La masse ne valide pas les appariements, la loi du score, les deux manches ni les tours absents. |
| C07 | Niveau initial et pondération des clubs des ligues complémentaires et coupes dans un Elo commun. | présent | présent / présent | Les groupes sans estimation propre gardent une convention d’initialisation; le recentrage bouge l’espérance de 555 rencontres de plus de 0,01. |
| C08 | Déduplication des fixtures Elo natives/complémentaires et remappage des côtés avant le calcul. | repère absent | présent / présent | T4 corrige des doublons bornés ; le replay officiel Italie–Espagne 1934 reste omis par le filtre Elo. |
| C09 | Centiles de style et sélection de voisins interligues avec pénalité de différence de niveau. | fichier absent | présent / présent | La similitude est descriptive. Ni le potentiel d’un transfert ni le calibrage de cette distance n’ont été démontrés. |
| C10 | Projection des coupes nationales tour par tour et identification du prochain adversaire. | repère absent | présent / présent | Les tirages incomplets, premières phases, rencontres rejouées et décisions administratives demandent validation par format. |
| C11 | Ligue des nations par groupe et accès de la Ligue A au Final Four. | repère absent | présent / présent | Les masses de places ne vérifient pas chaque départage ni le tirage effectif. Vérifier les formats et les phases du cycle concerné. |
| C12 | Moyennes de confédération avec rétrécissement et prior conjoint pour niveaux de ligues. | repère absent | présent / présent | Moyenne déployée ; gradient/covariance MAP et référence masculine du score des clubs féminins restent ouverts. |
| C13 | Généralisation des probabilités de prochain match aux éditions complémentaires. | repère absent | présent / présent | Le test de calibration des cinq ligues porte sur un refit de base. Les publications passées des autres compétitions ne sont pas disponibles. |
| C14 | Saison transitoire Ligue des nations, promotion, relégation, barrages et parcours entre ligues. | repère absent | présent / présent | Aucune reconstitution exhaustive de tous les tirages, probabilités émises et transitions par cycle. |
| C15 | Rattachement de la prévision au bon identifiant de match dans les listes de rencontres de coupe. | fichier absent | présent / présent | Une fixture sans prévision ou sous deux identités peut encore échapper au contrat. |
| C16 | Classements, résultats et projection rendus pour 19 championnats complémentaires. | repère absent | présent / présent | Réutilise des sorties du moteur; ne crée pas un nouveau modèle prédictif. Vérification statistique par championnat incomplète. |
| C17 | Prêt temporaire de la force d’un club à son alias en attendant la fusion d’identité. | repère absent | présent / présent | Aucun décompte isolé du gain imputable à ce repli ni validation indépendante de tous les aliases. |
| C18 | Finition joueur sur buts/xG appariés et distribution des pairs limitée aux matchs terminés. | fichier absent | présent / présent | Des données manquantes peuvent réduire les groupes. Voir A09a, A13c et A15b. |
| C19 | Somme des mi-temps complètes avec exclusion de minutes, matchs et xG non fini. | fichier absent | présent / présent | 129 reste le changement historique compté. 137 est un prolongement T1 : précision et supports vérifiés sur 2813e7c1, intégré 4fb7a71a ; affichage mi-temps non approuvé, aucune 27e entrée ajoutée. |
| C20 | Loi rétrospective des points attendus adaptative et symétrique. | fichier absent | présent / présent | Domaine borné à 100 xG par côté. Une loi cohérente ne démontre pas la calibration prédictive. |
| C21 | Indicateurs de club sur supports appariés et comparaisons avec la cohorte appropriée. | fichier absent | présent / présent | La version uniforme ne vérifie pas individuellement chaque statistique saisie. |
| C22 | Classification unique par match des buts contre son camp et tentatives de penalty. | fichier absent | présent / présent | Les 208 bénéficiaires Bundesliga et les alias ont des corrections T4 attestées ; les cas non attestés et réexécutions globales restent distincts. |
| C23 | Estimation xG sous contraintes et publication atomique des fits admissibles. | présent | présent / présent | Le refit d’évaluation diffère de l’instance en production; il n’établit pas un gain prédictif. |
| C24 | Filtrage des entrées de l’embedding et versionnement des profils éligibles. | présent | présent / présent | La proximité géométrique n’est pas une mesure validée du succès sportif. |
| C25 | Reconstruction des retours et courbes de reprise sur les apparitions en club. | présent | présent / présent | Une composition absente peut encore simuler un match manqué. |
| C26 | Ordonnancement des cohortes sur le premier marquage afin de borner le délai d’éligibilité. | repère absent | présent / présent | La borne d’éligibilité de cohorte n’assure pas la complétude des inputs, le réveil de chaque année ou la fin du calcul ; les contre-exemples T5 demeurent. |

## Chemins et reproduction du contrôle documentaire

`source_paths` est relatif à la racine Git de Vega-Sport et résolu **au SHA de W**, car il comprend maintenant des migrations non déployées. `evidence_paths` est relatif à la racine E, séparé par des points-virgules. Les fichiers historiques ne sont pas effacés lorsqu’un contre-exemple est corrigé. Les chemins dans les colonnes sont portables sans chemin absolu ni authentification. Un futur colis doit conserver ces mêmes noms relatifs ; le présent contrôle constate les fichiers locaux, pas un ZIP final encore en construction.

Le script suivant est celui du contrôle d’intégrité documentaire, à lancer depuis ce répertoire en indiquant le checkout qui contient les objets Git. Il n’accède pas au réseau, ne modifie ni produit ni registre et n’exécute aucun test applicatif.

```sh
export VEGA_REVIEW_REPO='/chemin/vers/Vega-Sport-audit-20261117'
python3 - <<'PYVERIFY'
import collections, csv, hashlib, os, pathlib, re, subprocess
here = pathlib.Path.cwd()
evidence = here.parents[2]
repo = os.environ['VEGA_REVIEW_REPO']
branch = '13f7be9f35c8bf7a4d41cefd69d6d2c585e47c07'
release = '8018e0836ca0f32e8b2eb51fc2847154abff7f13'
old = '7239f67f9c'
def records(path):
    with path.open(encoding='utf-8', newline='') as stream:
        reader = csv.DictReader(stream)
        return list(reader), reader.fieldnames
def git(*args):
    return subprocess.run(['git', '-C', repo, *args], capture_output=True)
rows, columns = records(here/'requirements.csv')
original, original_columns = records(here.parent/'requirements.csv')
calculations, calculation_columns = records(here.parent/'new-calculations.csv')
assert columns == original_columns and len(columns) == 9
assert len(rows) == len({r['id'] for r in rows}) == 91
assert [(r['id'], r['requirement_fr']) for r in rows] == [(r['id'], r['requirement_fr']) for r in original]
assert collections.Counter(r['id'][0] for r in rows) == {'A':38, 'E':36, 'L':8, 'N':9}
assert {int(re.match(r'A(\d+)', r['id'])[1]) for r in rows if r['id'].startswith('A')} == set(range(1,19))
states = {'implemented_production','implemented_branch','incomplete','missing','not_applicable'}
assert all(r[k] in states for r in rows for k in ('production_state','branch_state'))
assert all(r[k] == ('incomplete' if r['id'] == 'E04g' else before[k]) for r, before in zip(rows, original) for k in ('production_state','branch_state'))
source_paths = {p for r in rows for p in r['source_paths'].split(';')}
assert all(git('cat-file', '-e', branch+':'+p).returncode == 0 for p in source_paths)
proof_paths = {p for r in rows+calculations for p in r['evidence_paths'].split(';')}
assert all(not pathlib.Path(p).is_absolute() and (evidence/p).exists() for p in proof_paths)
assert len(calculations) == len({r['id'] for r in calculations}) == 26
assert len(calculation_columns) == 13
counts = collections.Counter()
commits = {s for r in calculations for s in r['release_commits'].split(';')}
assert len(commits) == 23
assert all(git('merge-base', '--is-ancestor', s, release).returncode == 0 for s in commits)
for r in calculations:
    for rev, key in [(old,'marker_at_historic_checkpoint'),(release,'marker_at_production'),(branch,None)]:
        result = git('show', rev+':'+r['callsite_path'])
        actual = 'file_absent' if result.returncode else ('present' if r['code_marker'].encode() in result.stdout else 'marker_absent')
        assert actual == (r[key] if key else 'present'), (r['id'], rev, actual)
        if rev == old:
            counts[actual] += 1
    assert r['marker_at_production'] == 'present'
    if r['historic_migration_equivalent']:
        assert git('cat-file','-e',old+':'+r['historic_migration_equivalent']).returncode == 0
assert counts == {'present':10,'marker_absent':9,'file_absent':7}
expected_hashes = {
    here.parent/'requirements.csv': '058bc72743a829faa6774839f0d5e7419468226cd50925de8af6d91aa27d2ff2',
    here.parent/'new-calculations.csv': 'de5e7ef95a4b90d074b2fb1946a98d49187fc20ec33f784663ef273b450f5abf',
    pathlib.Path(repo)/'docs/calculs/09-audit-2026-11/SOURCE_AUDIT.md': 'fdf03a62f1980fc74efe2be98d87119084802c9881a4cef93a4ae7267192baeb',
}
for path, expected in expected_hashes.items():
    assert hashlib.sha256(path.read_bytes()).hexdigest() == expected, path
for key in ('production_state','branch_state'):
    print(key, dict(collections.Counter(r[key] for r in rows)))
print('Exigences', len(rows), 'colonnes', len(columns), 'calculs', len(calculations), 'commits', len(commits))
print('Chemins source', len(source_paths), 'chemins de preuve', len(proof_paths), 'repères historiques', dict(counts))
PYVERIFY
```

Le contrôle effectivement exécuté ne relance aucune extraction de production et ne change aucun verdict de modèle scientifique. Les preuves complémentaires T5/T6 postérieures à leurs revues doivent encore être incluses dans la double revue finale intégrée. Les questions visuelles et la publication sont des portes de validation indépendantes du succès de ce contrôle documentaire.
