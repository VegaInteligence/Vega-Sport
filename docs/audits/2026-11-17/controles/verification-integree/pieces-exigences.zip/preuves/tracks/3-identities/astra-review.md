# T3 / VI-31 — contre-revue Astra

**Décision actualisée : correction P1 vérifiée, T3 acceptable pour intégration sur `33266597f766a019f8c75f1c99a4a21692381e06`.** Le constat initial ci-dessous reste conservé pour traçabilité. Revue de correction par le même Astra explicitement sélectionné; la future revue de branche combinée reste indépendante.

Le parseur distingue maintenant une déclaration contractuelle datée valide, une affectation sans date, et une échéance absente/invalide. Seule la déclaration datée peut superséder le fait antérieur. Le tuple contractuel de staging et son jour d'observation restent ensemble; la recherche partielle rend le profil dû et les refus individuels portent CONTRACT_MISSING / CONTRACT_INVALID. La lecture du diff n'a pas révélé de régression supplémentaire.

Vérification indépendante : témoin original rejoué sous **vega_collect → Reader → PostgreSQL → HTTP vega_read**, contrôle transfert valide et deux observations négatives. Les deux contrats anciens restent visibles et non supersédés; le transfert valide publie Club 22. Deux parcours supplémentaires existants passent : recherche/profil, null explicite, date avec suffixe invalide, provenance au lendemain, première affectation sans date, correction d'une fin datée qui expire légitimement le contrat. [Commandes et limites](reviews/astra-1500/README.md), [témoin indépendant](reviews/astra-1500/witness_contract_completeness.json), [parcours complémentaires](reviews/astra-1500/search-and-expiry.json).

La sémantique d'une suppression contractuelle fondée uniquement sur null n'est pas inventée : null conserve le dernier contrat daté. Le contrôle positif d'expiration est une nouvelle date explicite. Les limites de couverture et d'intégration ci-dessous restent valables.

---

## Constat initial sur dc33b4fe

**Décision : corrections requises avant intégration.** Revue indépendante de Fable, gpt-6-astra / xhigh explicitement sélectionné par le coordinateur, 18 novembre 2026. HEAD contrôlé : dc33b4fe59f7d01e4e963b7b5d055dd9ca7e9964 ; base de scope : 1b28961a88e968d5602f9fb278fc3c471ebb7467. Worktree exact de scope.json ; seul WORKLOG.md était modifié localement, préservé. Aucun accès production, aucune édition de code ou de test produit, aucun autre lot touché.

## P1 — Une échéance absente ou invalide retire encore un contrat publié

`backend/vega/transfermarkt.py:235` définit complete par la présence d'un objet attributes et d'une liste clubAssignments. `:242` réduit une date invalide et une clé absente au même None. `provider_player:955-959` efface alors l'observation acceptée ; `contract:1028` accepte None et `:1053-1057` supersède l'ancien contrat dès que le nouveau joined_on est plus récent. Cette combinaison contredit le plan accepté : une réponse partielle ou des dates invalides n'autorisent pas la supersession.

Reproduction sur base neuve, toutes migrations, vrai Reader.read, transport HTTP contrôlé puis vrai handler `/api/players` : contrat Club 11 valide jusqu'au 2028-04-01 ; profil Club 22 avec début 2026-11-17 et soit contractUntil absent, soit « definitely-not-a-date ». Les deux lectures retournent ok. Club 11 reçoit superseded_on=2026-11-17, aucun contrat Club 22 n'est écrit ; les quatre champs de contrat disparaissent de la réponse HTTP. Le contrôle valide du même transfert fonctionne et conserve les deux faits. Voir [témoin, commande et résultats](reviews/astra-1306/README.md) et [JSON intégral](reviews/astra-1306/witness_contract_completeness.json).

Correction attendue : distinguer présence, absence explicitement attestée et invalidité au parsing, et n'accorder l'autorité de transition/publication qu'à une observation réellement complète et valide. Conserver staging et publication sur fragment/refus ; demander le profil normal lorsque la recherche est partielle. Préserver le contrôle positif et une absence d'expiration explicitement légitime si le contrat fournisseur l'établit. Éprouver profil et recherche : ils partagent observe et sont tous deux exposés.

## Ce que la revue confirme

Le diff protège réellement les transferts : validation de la liste avant mutation, mise à jour par clé, préservation des IDs et des champs omis, isolation des autres sources, changement de clé club sans réutiliser l'ancien club canonique, conservation des mouvements absents et refus d'un retour terminé→annoncé. La migration bloque les clés répétées avant création de l'index et protège le rollback contre l'ancien writer destructif. Le backoff est borné avant exponentiation. Les vues excluent la quarantaine aussi par clé fournisseur courante. Ces conclusions viennent de la lecture du code et des scénarios, pas d'une nouvelle exécution exhaustive.

Les preuves candidate-evidence.md/vi31 décrivent 32 scénarios, 210 assertions, les 55 mouvements et les deux régressions, contention, rollback et migrations avec données résiduelles. J'ai inspecté les assertions de contrats, concurrence, santé du Reader, migration et HTTP ; le manque révélé ci-dessus n'est pas couvert par 20x (qui teste bloc absent et échéance antérieure au début, pas champ omis/date invalide dans un bloc présent). Le nouveau témoin a appliqué l'ensemble des migrations avec succès et vérifié un transfert de contrat positif par HTTP. Pas de CI intégrale relancée.

## Limites et risque d'intégration

L'incidence historique en production, la couverture globale des identités, la sémantique fournisseur d'un retour à une ancienne clé avec échéance future et l'absence d'expiration explicitement confirmée restent non vérifiées ici. La contention au-delà du lock_timeout reste une erreur de processus déclarée dans le reçu. Les vues 139 doivent être contrôlées sur la branche intégrée ; l'interaction des gardes DELETE avec d'éventuelles futures fusions/réparations n'a pas été exécutée. Les autres listes remplacées sont hors VI-31.

UX : la conservation est utile, mais le cas négatif retire encore une information valable. DX/AX : vrai statut HTTP, motifs HISTORY et index rendent les refus inspectables ; le booléen complete est trop grossier pour l'autorité qu'il confère. Aucun déploiement ni verdict de couverture production n'est donné.
