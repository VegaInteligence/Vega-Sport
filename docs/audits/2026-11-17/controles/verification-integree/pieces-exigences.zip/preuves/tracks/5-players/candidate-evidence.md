## Révision du 18 novembre après la première revue contradictoire

# Réponse aux neuf demandes de la première revue

| Demande | Correction et contrôle |
| --- | --- |
| 1. Année de notation sans réveil | 14 427 lignes dans l’année 2020 dont 14 418 avec poste et neuf sans poste. Après 2020, 606 sans poste et zéro avec poste parmi les lignes sans indice. La publication 1886 compte zéro joueur et match. Quatre tables vides sont relevées pour la partition ou l’année concernée. Le chemin PG18 quotidien laisse 50 des 100 témoins sans note. Le chemin d’une version obsolète les calcule puis étalonne sur ces 50 participations. |
| 2. Support statistique | Le SQL RDS compte les neuf colonnes utilisées par rôle. 104 792 notes à support partiel, dont 104 716 gardiens sans le bloc des arrêts. Les 52 665 gardiens à un seul bloc sont tous notés sur la distribution. Aucun témoin sans ligne ou sans touches. Deuxième requête sur 301 éditions et comparaison des trois primitives. |
| 3. Premier Soccer League | 1 110 sans poste le 17 à 22 h 07, 14 dès le 18 à 02 h 02 et toujours 14 à 07 h 12. Deux séries de 132 cibles et erreurs de parsing. Pas de préimage nominative de l’agrégat d’origine. Le déclencheur humain ou automatique et l’effet propre sur la référence de Daniels sont inconnus. |
| 4. Dénominateur | La mesure de couverture publiée part désormais des 2 297 613 entrées admises pour parvenir à 2 282 580 notes. La concordance des indices disponibles et des notes est une mesure de persistance. |
| 5. Référentiel | Le chemin journalier calcule N puis réécrit N−1 sous condition. Les runs 2095 et 2096 sont datés. Les cinq empreintes et les 37 témoins sont stables sur les contrôles de 02 h 59, 05 h 54 et 07 h 14. La convergence attend une nouvelle publication de 2026 à références inchangées. |
| 6. Troisième équipe | Le chemin annuel déployé sur PG18 transforme une seule statistique d’une équipe tierce en deux côtés et échoue deux fois en 23505 au COPY. Les données de l’ancienne publication restent intactes, puis la correction de l’équipe permet une nouvelle publication. Aucun cas sur les 5 537 de la PSL. |
| 7. Signal et participation réelle | Les documents de travail et le dictionnaire de la grille diffusée décrivent des clés joueur–match avec signaux. Le libellé `known_participations_minimum` subsiste uniquement dans les reçus historiques gelés et leur dictionnaire explicatif. Erreurs et absences interdisent une borne physique. |
| 8. Journal | Le WORKLOG du checkout de piste précise le périmètre, VI-27, les propriétaires et le contrôle suivant. |
| 9. Deux indices de Moutoussamy | L’ancien indice 0,35036 est daté. La performance à 02 h 00 donne 0,3523640633, la note de la famille match vaut 55,05361169 et la performance masque cette note. |

Les neuf réponses décrivent la justesse ou les limites du rapport révisé. Les décisions et les changements de production restent attribués aux propriétaires. [Données, requêtes et reproduction](README.md) · [Traces PSL, transactions et conflit de troisième équipe](psl-lineage/README.md)

## Éléments du paquet précédent, datés au 18 novembre à 05 h 26 UTC

# Track 5 candidate for independent challenge

The review uses historical production RDS measurements, verified ordinary public readers, offline local sensitivity and actual lower-level writer/reader E2Es. The user kept global model, scheduler and canonical identity changes with VI-19/21. The worktree for this evidence-only batch is 1b28961a88e968d5602f9fb278fc3c471ebb7467; the measured application and worker are 8018e0836ca0f32e8b2eb51fc2847154abff7f13. No branch test or off-production recalculation is itself a live backfill.

- At the 21 h UTC interval, 2,149 editions (208 competitions, 157 seasons) give 6,447 edition/entity cells. 2,249,579 admitted positive-minute player appearances included 2,229,830 with the intermediate value and a valid internally mapped grade and 19,749 without the intermediate. Counts with event evidence but no full stats, minutes absent and intentionally hidden brief grades are separate. Identify which facts actually prove numeric eligibility, which establish playing only, and which reflect provider error or a policy. The degree of exposure changed between the seven partitioned observations. Every numerator has a snapshot marker.
- On 23 exact real missing keys, a full 2021/22 fit from award-year inputs in one RDS snapshot yields 21 numeric grades (17.39–78.45) and two genuine unknown roles. The frozen 23 reproduce exactly in the branch and the portable bundle. Four local scheduler corrections fail to wake the correct year through the deployed normal path; the 6-hour cooldown and a growing, active ingestion job alone do not establish real historical loss. Small-minute public display threshold does not erase 329,476 persistent grades. Dated cohorts, current as-of-publication references and both years of a July boundary are separate.
- A second RDS snapshot for 2022/23 across 265,707 inputs reproduces both published top-100 rosters and positions before any modification. Under fixed match reference populations, suppressing the invalid duel denominator changes 16,221 outfield contributions among 8,028 players. Annual aggregation is recomputed normally. Each top-100 retains 99 members and 39 positions. Twelve independent outfield probes change and two controls are unchanged. A frozen-parameter sensitivity does not make this alternative the adopted formula.
- In the two native World Cup final tournaments, all 5,283 real grades occupy FIFA playing slots. Initial name links cover 5,214; a 50-source reviewed registration/identity complement corroborates 41 more and a typed personal FIFA ID on Serge Gnabry's linked Wikidata item corroborates a further three despite the incorrect displayed date. 25 personal assignments remain open, including 16 spelling variants and cases with conflicting dates. 3,272 unused native benches have null minutes/grade and 17 absent native bench slots have no playing evidence. Conversely ten real Saudi women incorrectly graded against men's fixtures are present in raw provider match stats and absent from the official men's sheets. Do not merely relabel measured minutes as proof of playing.
- Official international qualifiers for 2022 and 2026 yield 54,062 distinct starters/entrants in 1,764 usable official match sheets (8 missing/empty), on fixtures not present at the tested dates anywhere in Vega. Rosters do not guarantee minutes/statistics for an internal grade. Distinguish fixture presence, scored lineup, identity, historical covariate availability and policy refusal.
- On canonical identity/age, the 29 native profiles for the remaining finals candidates reply 200 and have no birth date. There are 17,377 absent canonical dates despite an unquarantined staged Transfermarkt date. Using every inferred club-season-name linkage as truth would add 163 unvalidated U23 player-seasons. Public lists currently contain 13 player-seasons failing their existing prior-regular gate; all corresponding historic regular rows (18) were published after the three lists. Fallbacks need both source precedence and identity validation. The private age E2E reproduces six wrong citations after a conflicting secondary date. No such disagreement was observed in explicitly cited live observations.

The normal historical publication actually happened. RDS at 2026-11-18 01:57:24 UTC found 21 intermediates and 21 persisted numeric grades for the 23 fixed inputs versus zero at 00:03. Version power-ranking-v8, run 2098, started 01:49:24 and published 01:51:42 UTC. It agrees on 21 roles and all 21 minutes with the old, frozen refit. The new production grades are 17.7252–78.2257; maximum absolute difference from the older refit is 0.43988. Two controls are still unscored. At 02:00 the deployed Lambda reported success for invocations of the two ordinary routes for all 23 subjects. At 02:22 each of 46 independently signed production-origin HTTPS reads returned the byte-identical body recorded for that path/query. The appearance reader exposed 20 numeric grades, match-player rows 21. The 7-minute cameo of match 250822 and player 1011 has 53.7018086536606 in the match API and null in the appearance grade. The previously published 1-minute Moutoussamy control showed a second such disagreement (55.053611690361 versus null). This establishes actual publication and one reader-policy discrepancy without a forced rerun or app-level policy change. The issue for shared model and visibility policy remains VI-21.


## Atomic candidate evidence

# Couverture des notes au 2026-11-18 02:02:22 UTC

Les 6 447 lignes couvrent 2 149 éditions, 208 compétitions et 157 saisons. La grille des statistiques et des notes provient d’une seule transaction RDS en lecture seule. Le contrôle inverse et les lectures de l’API ont chacun leur propre horodatage. Les tables détaillées comptent chaque type d’entité pour chaque édition et chaque saison. [Par édition](coverage-by-edition-and-entity.csv.gz) · [Par saison](coverage-by-season-and-entity.csv.gz) · [Horaires et requêtes](score-query-snapshots.csv.gz) · [Instantané PostgreSQL](snapshot.json)

| Entité et population mesurée | Attendu selon la règle déployée | Valeurs valides persistées | Évolution des valeurs valides depuis le relevé du 17 au soir |
| --- | ---: | ---: | ---: |
| Joueurs avec indice interne calculé | 2 282 580 | 2 282 580 | 52 750 |
| Clubs admis au calcul Elo | 161 982 | 161 982 | 0 |
| Sélections admises au calcul Elo | 1 864 | 1 864 | 4 |

La base enregistre 2 297 613 couples match–identifiant joueur avec des minutes positives admis au calcul. Pour 15 033 d’entre eux, l’intermédiaire manque à la date du relevé. Le seuil de la fiche performance masque 336 979 notes déjà enregistrées.

## Ce que compte une apparition enregistrée

| Couples match–identifiant joueur de matchs terminés | Durée positive, titularisation ou remplacement | Candidats supplémentaires détectés par but ou tir, gardien compris | Total enregistré |
| --- | ---: | ---: | ---: |
| Avec un indice de participation | 2 307 397 | 938 | 2 308 335 |
| Sans ligne de statistiques | 7 878 | 930 | 8 808 |
| Avec ligne de statistiques mais sans durée positive mesurée | 1 906 | 8 | 1 914 |

Les identifiants sont dédupliqués au sein de chaque match. Une même personne ou un même fait de jeu peut toutefois être rattaché à plusieurs identifiants. Une durée positive peut aussi figurer sur la ligne de la mauvaise personne. Le nombre de personnes ayant véritablement joué et le nombre de notes qui leur étaient dues restent inconnus. Le chiffre 2 308 335 ne fournit aucune borne physique. Les 938 identifiants supplémentaires sont des candidats à vérifier. [Décompositions pour les 2 149 éditions](participation-cues-by-edition.csv) · [Totaux](participation-cues-summary.json)

Sur Laval–Saint-Étienne, Vega attribue le but de la 51ᵉ minute à Miguel Belem, absent de ses familles composition et joueurs. Le tir victorieux de la même minute est rattaché à Ben Old, que le club désigne comme buteur. Sur PSV–Copenhague, Vega attribue le tir à 90+5 à Oscar Højlund. La feuille UEFA et le compte rendu de Copenhague désignent Emil Højlund, que Vega enregistre entrant à la 86ᵉ. Ces deux erreurs sont constatées sur des relevés nominatifs distincts du recensement agrégé. Leur incidence exacte sur son total reste inconnue. [Témoins de l’origine AWS](origin-https/actor-ranking.json) · [Reçus officiels bornés](origin-https/official-actor-receipts.json) · [Feuille ASSE](https://www.asse.fr/fr/lives/laval-asse-l8856/) · [Composition UEFA](https://match.uefa.com/v5/matches/2033414/lineups?language=EN) · [Compte rendu de Copenhague](https://fck.dk/nyhed/kampreferat-en-af-vores-mest-forrygende-kampe-nogensinde)

La grille brute archivée nommait ce champ `known_participations_minimum`. La grille de lecture diffusée et le CSV de décomposition utilisent `recorded_match_player_id_pairs_with_participation_cues` pour les joueurs. Les équipes ont une colonne propre, `recorded_finished_team_sides`. Les SQL et leurs sorties conservent les noms originaux avec leurs empreintes. [Archive et rejeu initiaux](archive/initial-delivery.zip) · [SQL des signaux de base](db/participants_verified/) · [SQL des actions supplémentaires](db/events_verified/)

Sur les 23 mêmes couples joueur–match de 2021/22, 21 possèdent maintenant l’intermédiaire et 21 une note persistée, dont 20 satisfont la règle d’affichage. Le calcul local antérieur avait produit 21 valeurs et deux rôles indéterminés. [23 clés et nouvelles valeurs](sample-keys.json) · [Publications du worker](run-times.json) · [Écarts mesurés](comparaison.json)

## Éditions avec le plus de participations en attente d’un indice joueur

| Édition | Saison | Participations admises | Notes persistées | Sans indice |
| --- | --- | ---: | ---: | ---: |
| MLS (883) | 2021/2022 | 14 063 | 7 899 | 6 164 |
| Eliteserien (780) | 2021/2022 | 7 070 | 3 891 | 3 179 |
| Allsvenskan (729) | 2021/2022 | 7 037 | 4 171 | 2 866 |
| 2. Bundesliga (714) | 2021/2022 | 9 380 | 8 921 | 459 |
| First Division A (798) | 2021/2022 | 9 633 | 9 228 | 405 |
| Superligaen (980) | 2021/2022 | 5 941 | 5 539 | 402 |
| Liga MX (853) | 2021/2022 | 5 212 | 4 839 | 373 |
| Bundesliga (744) | 2021/2022 | 5 861 | 5 593 | 268 |
| Super League (963) | 2021/2022 | 5 522 | 5 308 | 214 |
| Saudi Pro League (938) | 2023/2024 | 9 080 | 8 948 | 132 |
| Premiership (913) | 2021/2022 | 6 436 | 6 325 | 111 |
| K League 1 (822) | 2023/2024 | 6 978 | 6 940 | 38 |

Ce tableau compte les entrées admises par l’algorithme avant attribution du poste. La grille détaille les statistiques absentes et les notes déjà calculées mais masquées. Le CSV joueurs ci-dessous explique comment les postes se répartissent parmi les lignes en attente.

## Causes mesurées pour les joueurs

Le [CSV joueurs](player-reasons-by-edition.csv) contient une ligne par édition. La table s’appuie sur les six partitions source de 2021 à 2026 et le recensement global des partitions. Les 90 groupes en attente contiennent des années de récompense de 2020 à 2026. Le fichier de synthèse conserve l’heure du relevé, le SHA déployé, la méthode observée et les identifiants des publications par année concernée. [Synthèse et années](player-reasons-summary.json) · [Catalogue](db/catalog_verified/editions.json) · [Partitions](db/catalog_verified/season-universe.json)

| Compteur SQL demandé | Population contrôlée | Total |
| --- | --- | ---: |
| `unknown_or_wrong_team` | Minutes positives avec équipe absente ou étrangère aux deux adversaires | 0 |
| `positive_minutes_outside_award_window` | Minutes positives en domaine natif, sans date ou hors fenêtre de récompense | 0 |
| `no_published_award` | Entrées admises sans intermédiaire, sans publication joueurs dans leur année | 0 |
| `insufficient_contribution` | Entrées admises avec intermédiaire, contribution absente | 0 |
| `insufficient_role_reference` | Entrées admises avec contribution dans un intermédiaire, indice absent | 0 |

Dans les 2 810 237 lignes de statistiques de matchs terminés, 512 624 ont une durée inconnue et 2 297 613 une durée positive. La valeur zéro ou négative apparaît 0 fois. Les 2 297 613 entrées admises se répartissent entre 2 282 580 indices valides persistés et 15 033 entrées sans intermédiaire. Dans les notes valides, 1 945 601 franchissent le seuil de la fiche joueur et 336 979 restent masquées sur cette fiche.

Parmi les entrées sans intermédiaire, 14 411 ont un poste assignable immédiatement, 7 retrouvent un poste détaillé dans une autre apparition de la même année et 615 restent sans poste. Les statistiques de 14 427 entrées en attente portent une écriture postérieure au démarrage de la dernière publication. Le contrôle des postes assignables dont l’écriture précède ou coïncide avec ce démarrage donne 0. Ces horodatages décrivent l’état observé et ne démontrent pas la visibilité transactionnelle d’une ligne au démarrage du worker. [Six sorties annuelles et six sources SQL](db/longitudinal/) · [Statistiques et indices](db/grades_verified/) · [Entrées en attente](db/pending_verified/) · [Contrôle inverse des notes par partition](db/grade_integrity_verified/)

Sur 304 éditions natives, 301 ont des statistiques joueurs sur matchs terminés. Les 99 éditions de coupe complémentaires et 1 746 éditions d’archives ont respectivement 0 et 0 éditions avec de telles statistiques. Une absence de source laisse la population sportive réelle inconnue. Les compteurs portent sur les lignes conservées en base. Les champs d’équipe, d’année, de chronologie et de provenance peuvent se recouper au sein d’une population. Les six requêtes annuelles établissent la disponibilité du poste parmi les cas en attente. Elles ne permettent pas d’attribuer à chaque joueur noté la voie de résolution de son poste, de séparer dans le compteur de fenêtre les dates absentes, ou d’énumérer les clés individuelles à partir des groupes. Les matchs non terminés et les rencontres sans statistiques restent comptés dans le catalogue des éditions. Le contrôle inverse des intermédiaires et des paires multi-annuelles utilise une transaction indépendante.

Le second relevé, à 2026-11-18 02:11:08 UTC, a parcouru 2 282 580 intermédiaires, soit 2 282 580 paires match/joueur distinctes. Il retrouve 2 282 580 sources admises. Les effectifs sans source, à source inéligible, à année incorrecte, sur plusieurs années ou en excédent sont respectivement 0, 0, 0, 0 et 0. Cette transaction a son propre reçu et sa propre heure. [Résultat indépendant](reverse-intermediate/reverse-intermediate.json) · [Reçu indépendant](reverse-intermediate/receipt.json) · [Requête](reverse-intermediate/reverse-intermediate.sql) · [Cas témoins sur PostgreSQL 18.3](reverse-intermediate/local/local-verification.json)

## Lecteurs et valeur transmise au tableau

À 02 h 00 UTC, le collecteur a transmis des événements GET construits localement avec `aws lambda invoke`. Les 46 invocations distinctes de `vega-v2-api` ont produit des enveloppes contenant `statusCode=200`. Le collecteur a conservé les valeurs extraites et les SHA-256 des corps. À 02 h 22 UTC, le relecteur a adressé les mêmes chemins et requêtes à l’URL de fonction AWS par HTTPS, avec signature SigV4 et authentification IAM. Les 46 corps reçus ont chacun le même SHA-256 que celui consigné à 02 h 00. Le paquet contient ces corps pour rejouer la vérification hors réseau. [Collecteur Lambda](reader-0200/reader.py) · [Empreintes des enveloppes](reader-0200/response-digests.json) · [Reçus HTTPS et clés](origin-https/origin-observations.json) · [Corps indexés par SHA-256](origin-https/origin-bodies/)

Pour les 27 clés relues, les deux lecteurs retrouvent le même identifiant. Pour 23 clés, les notes numériques concordent. Pour deux autres, les deux valeurs sont nulles. Dix GET HTTPS signés supplémentaires à 02 h 24 UTC couvrent les événements, tirs, joueurs et compositions des deux matchs à attribution contestée et le classement de deux matchs avec caméo. Tous ont répondu HTTP 200. Pour ces deux caméos, la fiche performance et le classement rendent une note nulle alors que la famille joueurs contient une note numérique. Sur les corps HTTPS, la fonction frontend de production `boardRows` restitue 53,7018086536606 pour Alexandru Mățan (7 minutes) et 55,053611690361 pour Samuel Moutoussamy (1 minute). Le contrôle porte sur les données des lignes de tableau exécutées sous Node.js. Le chemin CDN/Vercel et le rendu dans un navigateur restent non observés. [Dix reçus supplémentaires](origin-https/actor-ranking.json) · [Sorties du tableau](origin-https/board.jsonl) · [Module figé](origin-https/match-tabs.mjs) · [Protocole de rejeu](rejeu.md)


editions 2149 entity cells 6447 team policy replay True season universe True player score partitions [2021, 2022, 2023, 2024, 2025, 2026] event enrichment partitions [2021, 2022, 2023, 2024, 2025, 2026]
6447 [('club', 161982, 161982), ('national team', 1864, 1864), ('player', 2282580, 2282580)]
Publication vérifiée 2149 éditions, 90 groupes en attente, 44 SELECT, cinq compteurs [0, 0, 0, 0, 0]
Initial delivery replayed. Source groups 2307397 938 transport {'lambda_envelopes': 46, 'signed_https_identical_to_envelope_body': 46, 'additional_signed_https': 10, 'offline_extractions': 27, 'board_rows': 2}

## Coordinator evidence for fresh review

The signed 02:02 report and deploy-path receipt establish 15,033 unprocessed admitted inputs. The public match-board screenshots show 54 and 55 for Mățan (7 minutes) and Moutoussamy (1), and both players have null performance and match ranking grades. New independently captured normal HTTPS public readers agree with RDS for Raymond Daniels and Louie Watson. Please explicitly challenge the new all-row reference reconstruction and external Copa América evidence supplied separately, including each denominator and the documented uncertainty. Grade calculations run solely through Vega functions. Request a separate verdict on (1) the 2,282,580-to-2,282,580 contribution-stage replay, including 1,083 numerical rounding differences, the mutable reference-version limitation and why these are not raw-input refits, (2) 1,010 official Copa América appearances with no persisted player grading inputs, and (3) seven absent domestic fixtures with 219 appearances and the six erroneous or missing Ligue 1 linkages. Reader-specific displays and missing data must be mapped separately.

## Independent witnesses added on 18 November

The repeated read-only RDS transaction at 04:22 UTC observed the same 6,447 edition–entity rows as at 02:02 UTC. 2,297,613 admitted positive-minute participations and 2,282,580 persisted internal grades. 15,033 await an intermediate index. Review inclusion of externally visible eligible appearances outside those installed tables. Three completed AFCON finals tournaments have 156 matches, 312 team Elo sides, 4,786 observed player appearances and zero corresponding player grades. Copa América 2024 supplies 1,010 appearances with no stored grades. These are external participation counts; confirm the available feature inputs by year before representing the appearances as immediately scoreable. In the public Orenburg case, normalize 46 player entries, 29 ranked response rows, 23 officially visible grades, 6 masked. The table's decision to expose the numerical family fallback (VI-21) is independent of double rounding 97,029 of 1,945,601 already visible grades (VI-32). Validate stored contribution replay versus historical/raw refit. Public UI reproduction and source provenance are attached in the evidence. Challenge each denominator and distinguish correctness of the report from resolution by the owner.
