# T2 — décision actualisée sur c61e87af

**P1 de première publication corrigé et vérifié indépendamment. Le candidat `c61e87afdae4439bf3cdcf7a3a58f58b45240286` peut poursuivre l’intégration dans son périmètre de qualification des classements. J1, le roster sportif réel et les phases/identités natives restent ouverts dans VI-21.**

Astra gpt-6-astra / xhigh explicitement sélectionné, lecture du diff et rejeu ciblé sur le SHA exact. Témoin original : refus `INCOMPLETE_TABLE`, zéro ligne, HTTP 404, puis contrôle complet accepté avec trois lignes et HTTP 200. Sept cas phase/roster (dix étapes) repassent : refus conservateurs et contrôles positifs, versions et ETags vérifiés. Collecteur sous vega_collect, GET sous vega_read ; HTTPS fournisseur simulé localement. Aucune CI intégrale concurrente et aucune connexion production.

[Reproduction, preuves et limites](reviews/astra-1630/README.md). Le rapport initial ci-dessous reste historique ; ses vérifications de 138/147 et du calendrier gardent leur SHA f396b4ec. Le verdict ne transforme ni la qualification conditionnelle Allsvenskan ni la mise à l’écart ciblée J1 en correction globale du calendrier.

---

# T2 — contre-revue indépendante Astra

**Décision : corrections requises (P1).** La migration J1 ciblée et la protection des observations acceptées ne règlent pas la complétude de la première table. Cette exigence du brief reste violée par un chemin normal du collecteur et du lecteur.

Relecteur : gpt-6-astra / xhigh, sélection explicite confirmée par le coordinateur. SHA relu et exécuté : `f396b4ec429158445afae90c708127e0678eed00`, base `1b28961a88e968d5602f9fb278fc3c471ebb7467`. Revue indépendante des verdicts Fable. Lecture des exigences originales, des AGENTS applicables, de accepted-plan.md, pinned-astra-addendum.md, des compléments groupes/calendrier et du code effectif. Aucun changement produit, aucune connexion production, aucune CI intégrale relancée.

## P1 — première table tronquée publiée comme officielle

`backend/vega/sources/sportscore.py:448–452` ne cherche les clubs absents que parmi ceux ayant déjà un résultat compté. `compare` protège les clubs de la table précédente mais ne prouve rien lorsque cette table n'existe pas. La validation des rangs admet naturellement 1..N sur un préfixe incomplet. `run:608–625` accepte alors ces lignes et les publie.

Témoin indépendant sous **vega_collect → PostgreSQL → HTTP vega_read** : trois membres connus de l'édition; Aster et Birch ont terminé leur rencontre, Cedar a une rencontre programmée mais n'a pas joué. La première réponse contient seulement Aster et Birch. Résultat observé : `run_due=ok`, deux lignes officielles, **HTTP 200 source SportScore avec deux clubs**. Contrôle positif : la réponse complète suivante fournit trois lignes, acceptées et publiées normalement. [Reproduction et reçus](reviews/astra-1420/README.md), [script](reviews/astra-1420/initial-completeness.py), [résultats complets](reviews/astra-1420/initial-completeness.json).

Le pinned addendum exige précisément une preuve positive adaptée à l'édition/phase pour la première observation et un groupe entièrement omis. La limite ajoutée dans FAILURE_MODES_SPORTSCORE.md ne vaut pas dérogation à ce critère. Correction attendue : qualifier cette première complétude sans exiger universellement tous les membres dans chaque groupe; si elle n'est pas établie, conserver l'observation précédente ou servir le repli/indisponibilité approprié. Ne pas la fabriquer à partir de rangs continus.

## Ce que le code et les exécutions établissent

- Migration 138 : la base sportive de chaque ligne suit les six comptes de résultats, avec contrôle `first_finished_at` pour les observations héritées sans base. Le repli ne dépend plus seulement d'un coup d'envoi postérieur. Le remplacement est effectué après parsing, résolution et contrôles; une erreur conserve le stockage et l'observation temporelle acceptés.
- Les clubs et tables déjà acceptés sont protégés, y compris contre la disparition d'un classement transversal sous couvert de renommer les groupes. Le découpage d'une table unique reste possible lorsqu'il conserve exhaustivement clubs et historique sportif. La diminution de points reste distincte d'une diminution non justifiée des rencontres.
- Le rejeu indépendant `calendar/results.json` passe **7/7** scénarios du vrai collecteur et lecteur : répétition Allsvenskan, résultat suivant, correction de points; refus de saison antérieure à clubs identiques, preuve organisateur indisponible ou de mauvaise année, et rattachement J1 incorrect. Le widget et l'organisateur sont des captures injectées au transport; ce n'est pas une collecte Internet nouvelle.
- Migration 147 : l'exclusion est bornée à une édition J1 2027/2028/native 2027, vingt lignes SportScore sans groupe/stage, une observation antérieure au premier match et une empreinte exacte des faits/public IDs. Elle conserve core.standings_official, exclut aussi le repli de cette édition incorrecte et modifie le choix HTTP pour rendre l'indisponibilité explicite. La réparation du calendrier canonique 2026/27 reste VI-21; 147 n'en tient pas lieu.

Le rejeu indépendant complet **60 éditions de 147 est terminé sans échec** : [reçu](reviews/astra-1420/j1/results.json). 1 086 lignes stockées inchangées; les deux vues ne changent que l'édition 22 (20 → 0 lignes), version 41 → 42. Les **59 autres éditions répondent 304 avec le même ETag**. L'ancien J1 est indisponible par sélection courante et étiquette explicite; une édition historique de contrôle reste accessible explicitement sans repli silencieux sur elle. Le rattachement corrigé de contrôle est lisible, et une observation future différente reste admise. La comparaison HTTP avant migration réutilise le reçu RED figé dont l'empreinte de capture est vérifiée; SQL avant/après et HTTP après migration ont été réexécutés ici. Aucune réparation canonique de production n'est présumée.

## Limites et risques

Pas de revue navigateur ni de CI intégrale concurrente. Pas de nouveau corpus live. Une saison à mêmes clubs avec une faible activité sportive peut demeurer indiscernable dans les ligues sans preuve d'édition supplémentaire; le contrôle organisateur ajouté est spécifique à Allsvenskan. Le refus d'un premier classement incomplet réduit l'apparente disponibilité mais protège l'UX contre un tableau faux; pour DX/AX, le motif doit rester visible et la récupération complète doit suivre le même chemin normal. Aucun verdict d'aptitude production.
