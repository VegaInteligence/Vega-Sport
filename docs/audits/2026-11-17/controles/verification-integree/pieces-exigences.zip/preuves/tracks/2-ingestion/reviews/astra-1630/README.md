# Reprise indépendante T2 — c61e87af

Modèle explicitement sélectionné : gpt-6-astra / xhigh. SHA testé : `c61e87afdae4439bf3cdcf7a3a58f58b45240286`. Le code du checkout exact est lu et exécuté sans modification. Deux bases PG18 locales neuves sur 55469 sont conservées dans les reçus. Aucun accès production, aucune CI globale. Le setup et les observations SQL du harnais utilisent l’administrateur ; toutes les collectes sont sous `vega_collect`, tous les GET publics sous `vega_read`.

## Attentes et résultats

1. Témoin indépendant initial : trois membres connus, dont Cedar à zéro match avec une rencontre programmée. L’ancien candidat f396b4ec acceptait les deux seuls clubs ayant joué. Le candidat c61 refuse `INCOMPLETE_TABLE`, conserve zéro ligne et HTTP 404 ; le contrôle complet suivant accepte trois lignes et HTTP 200. Voir [JSON](initial-completeness.json) et [log](initial-completeness.log).
2. Contre-exemples S48–S54 : **7 cas, 10 étapes, zéro écart**. Renommer et redistribuer les groupes ne retire pas implicitement le tableau transversal : refus et 304 inchangé ; le renommage complet avec ce tableau est accepté. Le roster complet à zéro sans calendrier passe. Les groupes natifs vérifiés peuvent exclure un club cantonné aux qualifications. Une coupe sans phase vérifiée est refusée `UNVERIFIED_TABLE`. Permuter les deux groupes connus est refusé, et HTTP conserve le classement Vega existant. Voir [résumé](phase-roster.log) et le sous-dossier runs.

Le second harnais est une copie documentaire du runner E2E existant, adaptée uniquement pour sélectionner S48–S54 et appliquer explicitement le rôle de collecte. Transport : HTTPS local → vrai json_getter → sources.run_due → PostgreSQL → handler HTTP public. Les réponses fournisseur sont simulées ; le chemin d’écriture et de lecture est celui du SHA cité. Chaque étape garde l’entrée, le statut attendu et observé, les lignes et versions SQL, les corps/ETags HTTP et les rôles. Les cas restent définis dans le checkout figé, leurs empreintes figurent dans code-digests.json.

## Commandes exactes

Depuis la racine E :

```sh
PYTHONDONTWRITEBYTECODE=1 ./ci-clean/bin/python -B tracks/2-ingestion/reviews/astra-1630/initial-completeness.py
PYTHONDONTWRITEBYTECODE=1 ./ci-clean/bin/python -B tracks/2-ingestion/reviews/astra-1630/phase-roster.py --tree '/Users/lemonnierhugo/Developer/Coding Project/Vega-Sport-audit-tracks-20261117/2-ingestion' --label astra-c61-roles --pg postgresql://postgres@127.0.0.1:55469
```

## Portée et limites

Le P1 de première publication est levé pour une population native connue. Le collecteur ne prouve pas l’existence d’un club absent de toutes ses observations natives, ne reconstitue pas les calendriers japonais et ne répare pas les phases/identités canoniques. La migration 147, ses 60 éditions et le renouvellement suédois/japonais avaient déjà été rejoués indépendamment à f396b4ec (astra-1420) ; ils n’ont pas été relancés ici. La preuve du worker à c61 sur ces scénarios est séparée. La CI complète, l’intégration finale et tout déploiement restent au coordinateur.
