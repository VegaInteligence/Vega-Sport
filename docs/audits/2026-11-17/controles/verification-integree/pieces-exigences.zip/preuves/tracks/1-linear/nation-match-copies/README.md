# C03 · Tirs au but des sélections

**Les 46 paires de tirs au but rendues par le lecteur proviennent chacune d’une observation complète et correctement orientée.** Les 132 rencontres présentes en double ne présentent aucune contradiction sur un but ou un tir au but renseigné. Le contrôle couvre les 153 sélections servies, dans un instantané RDS du 18 novembre 2026 à 01:04:27 UTC. [Résultat SQL](db/frozen/census.json) · [Reçu d’exécution](db/frozen/receipt.json)

| Unité vérifiée | Nombre |
| --- | ---: |
| Lignes rendues par `api.nation_matches`, deux sélections par rencontre | 3 256 |
| Clés distinctes (jour, deux identifiants d’équipe non ordonnés) | 1 628 |
| Observations sources | 1 760 |
| Clés avec une fiche collectée et un complément | 132, soit 264 observations |
| Paires complètes / partielles / entièrement absentes | 46 / 0 / 1 582 |
| Paires remplies depuis la copie | 8 |
| Paires publiées absentes de toutes les observations, valeurs nulles comprises | 0 |
| Clés avec scores de match contradictoires / tirs au but contradictoires | 0 / 0 |

La requête reprend les identifiants de `api.nation_list` servis par la route après exclusion des équipes provisoires. Elle appelle la fonction réelle pour chaque sélection et compare sa sortie aux observations de `core.matches` rattachées aux mêmes identifiants et à la même date. Une date inconnue conserve l’identifiant du match comme clé. Les comparaisons remettent les deux composantes dans l’ordre des identifiants d’équipe et conservent les valeurs nulles. Les 1 628 clés attendues correspondent exactement aux sorties des deux côtés. Le score de match conservé et les valeurs de remplacement concordent avec le SQL du worker `8018e083`. Le corps de la fonction en RDS a la même empreinte que celui de la migration 120. [SQL du recensement](census.sql) · [Migration archivée](migration-120.sql) · [Lecteur HTTP, lignes 156–191](https://github.com/VegaInteligence/Vega-Sport/blob/8018e0836ca0f32e8b2eb51fc2847154abff7f13/backend/api/src/routes/nations.mjs#L156-L191)

**Témoin réel.** Pour Argentine–France, le match collecté `230450` et l’archive `1440` donnent 3–3. Seule l’archive renseigne les tirs au but, 4–2. Les captures HTTP 200 des deux pages de sélection du 17 novembre à 22:47 UTC rendent 3–3 et 4–2 pour `m_3Zw3cP`. Le contrôle de l’ensemble des clés porte sur le lecteur RDS. Les deux captures contrôlent en plus le passage du lecteur à l’API publique. [Extraits et empreintes HTTP](http-controls.json)

**Limite démontrée.** Aucune des 132 copies réelles n’inverse domicile et extérieur. Un PostgreSQL 18.6 isolé a exécuté la migration originale sur trois cas joués des deux côtés. Avec une fiche retenue vide et deux archives donnant 4–2 et 3–5 après orientation, le lecteur renvoie **4–5**, absent des observations. Avec deux demi-paires (4, inconnu) et (inconnu, 3), il renvoie **4–3**. Le contrôle à une seule copie inversée restitue exactement **4–2**. Ces résultats démontrent dans quelles conditions le lecteur peut assembler une paire. Le recensement n’en a trouvé aucune à l’instant observé. L’exhaustivité des rencontres absentes du produit et la véracité sportive des 46 scores dépassent ce contrôle de provenance. [Trois résultats PostgreSQL](synthetic-results.json)

**Rejeu.** Depuis ce dossier, `python3 verify.py` contrôle le reçu RDS, les dénominateurs, les preuves HTTP et les résultats synthétiques hors réseau. Pour relire aussi les deux corps HTTP d’origine, utiliser `python3 verify.py --http-dir ../../2-ingestion/official-calendar-extended/raw`. Pour réexécuter la migration dans un cluster temporaire, utiliser `uv run --no-project --python 3.12 --with 'psycopg[binary]==3.3.2' python synthetic.py /chemin/postgresql-18/bin /tmp/c03-resultat.json`. Pour une lecture RDS ultérieure et autorisée depuis la racine d’audit munie de son `query_batch.py`, lancer dans ce dossier `python3 run.py nouveau-releve`. Le libellé doit être neuf afin de préserver l’instantané.

VI-18, livraison du lecteur, est terminée. VI-21 et VI-27 sont en cours. Cette preuve documentaire complète C03 dans l’audit partagé et laisse la décision d’évolution au propriétaire. [Statuts Linear consultés](linear.json)
