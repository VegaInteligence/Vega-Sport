import assert from 'node:assert/strict';
import fs from 'node:fs';
import {createRequire} from 'node:module';
import {createServer} from 'node:http';
import {once} from 'node:events';
import {execFileSync} from 'node:child_process';
const W='/Users/lemonnierhugo/Developer/Coding Project/Vega-Sport-audit-tracks-20261117/1-linear';
const req=createRequire(W+'/backend/api/package.json');
const {Client}=req('pg');
const {createReader}=await import(W+'/backend/api/src/db.mjs');
const {createHandler}=await import(W+'/backend/api/src/handler.mjs');
const {writeHalves}=await import(W+'/backend/api/test/half-fixture.mjs');
const {GET:report}=await import(W+'/dashboard/frontend/app/api/rapport/route.js');
const dsn=fs.readFileSync(new URL('./dsn.txt',import.meta.url),'utf8').trim();
const owner=new Client({connectionString:dsn});await owner.connect();
await writeHalves(owner);
const reader=createReader(dsn,{role:'vega_read'});
const handler=createHandler({read:reader.read,mediaBase:'https://media.test/',clock:()=>Date.parse('2025-09-06T12:00:00Z')});
let origin;
const server=createServer(async(q,s)=>{
  try{const r=await (q.url.startsWith('/api/rapport')?report:handler)(new Request(origin+q.url,{headers:q.headers}));
  s.writeHead(r.status,Object.fromEntries(r.headers));s.end(Buffer.from(await r.arrayBuffer()));}catch(e){s.writeHead(500).end(String(e));}
});server.listen(0,'127.0.0.1');await once(server,'listening');origin='http://127.0.0.1:'+server.address().port;
process.env.ORION_API_ORIGIN=origin;
const out={head:execFileSync('git',['-C',W,'rev-parse','HEAD'],{encoding:'utf8'}).trim(),dsn,checks:[],responses:{}};
async function read(path,headers){const r=await fetch(origin+path,{headers});return {status:r.status,etag:r.headers.get('etag'),body:r.status===304?null:await r.json()};}
function equal(label,actual,expected){out.checks.push({label,actual,expected,pass:JSON.stringify(actual)===JSON.stringify(expected)});assert.deepEqual(actual,expected,label);}
try{
  const pass=await read('/api/players/p_aaab32/halves?season=2025/2026');out.responses.passing_only=pass;
  equal('partially measured player is available',pass.status,200);
  equal('legacy complete half stays null',pass.body.data.first,null);
  equal('measured passing has its own support',pass.body.data.coverage.first.stats.passes,{sum:14,count:1,minutes:45});
  equal('unknown goals stay unknown',pass.body.data.coverage.first.stats.goals,{sum:null,count:0,minutes:0});
  const unknown=await read('/api/players/p_aaab34/halves?season=2025/2026');out.responses.unknown=unknown;
  equal('wholly unmeasured stays distinguishable',unknown.body.data.coverage.first.stats.xg,{sum:null,count:0,minutes:0});
  const zero=await read('/api/players/p_aaab36/halves?season=2025/2026');out.responses.zero=zero;
  equal('structural zero has support',zero.body.data.coverage.first.stats.xg,{sum:0,count:1,minutes:45});
  const precision=await read('/api/players/p_aaab37/halves?season=2025/2026');out.responses.precision=precision;
  equal('numeric sum before final JSON conversion',precision.body.data.coverage.first.stats.xg.sum,1.35802459);
  equal('no eligible observations 404',(await read('/api/players/p_aaab35/halves?season=2025/2026')).status,404);
  const ix=x=>4*Math.log10(x/(100-x));
  async function set(player,grade){await owner.query("UPDATE agg.player_match_grades SET z=$1::real WHERE season_id=2025 AND match_id=api.internal_id('match','m_aaaaa1') AND player_id=api.internal_id('player',$2)",[ix(grade),player]);}
  await set('p_aaaab1',48.49);await set('p_aaaab4',48.52);
  const old=await read('/api/rankings/match?match=m_aaaaa1');out.responses.old=old;
  await set('p_aaaab1',48.51);
  const revised=await read('/api/rankings/match?match=m_aaaaa1',{'If-None-Match':old.etag});out.responses.revised=revised;
  const row=b=>b.grades.find(x=>x.playerId==='p_aaaab1');
  equal('same-tenth revision invalidates ETag',revised.status,200);
  equal('legacy grade stable',[row(old.body).grade,row(revised.body).grade],[48.5,48.5]);
  equal('true integers change',[Math.round(row(old.body).gradeExact),Math.round(row(revised.body).gradeExact)],[48,49]);
  equal('official rank remains exact-ordered',[row(old.body).rank,row(revised.body).rank],[2,2]);
  const rep=await read('/api/rapport?id=m_aaaaa1');out.responses.report=rep;
  equal('real report route status',rep.status,200);
  equal('report transports same precision',rep.body.grades.find(x=>x.id==='p_aaaab1').gradeExact,row(revised.body).gradeExact);
}finally{
  fs.writeFileSync(new URL('./witness.json',import.meta.url),JSON.stringify(out,null,2)+'\n');
  await new Promise(resolve=>server.close(resolve));await reader.end();await owner.end();
}
console.log(JSON.stringify(out.checks,null,2));
