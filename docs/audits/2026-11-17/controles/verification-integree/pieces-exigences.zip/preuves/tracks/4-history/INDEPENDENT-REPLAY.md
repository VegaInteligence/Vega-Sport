# Independent historical replay · 17 November 2026

Version `repair-2251-v2` is an immutable copy of the current correction on branch base `1b28961a88`. The deployed parser used for the comparison was `8018e0836c`. No production import was executed. All reads of production rows in this verification use the previously collected, dated production SQL receipts. Only the independent loopback PostgreSQL clones were modified.

## Outcome on this version

| Control | Observed |
| --- | --- |
| Source inventory | All 52 files matched both the production object ETag (MD5) and captured SHA-256. 11,851,103 bytes. |
| Complete archive build | All 154 seasons. 507,698 baseline matches and 507,458 corrected candidates before authority selection. Exactly 240 omitted keys, all known ru.2 copies with exact retained ru.1 twins. No other key disappeared or appeared. |
| Private database plan | Migration 134 on a private clone with 494,713 baseline matches. The actual import plan as `vega_collect` completed for 154 seasons. It proposes 1,479 changed matches, 9,636 position-only changes, 92 goal-only changes, 892 held rows, 240 removals and one removed edition. No total-season refusal. |
| Malformed origins | All 1,783 production IDs and 5,666 source goals reconciled to baseline records, immutable bytes, actual CSV record number and physical line range. 918 in-place repairs, 865 held; all original match IDs retained by design. The parseable subset references 1,781 distinct malformed club rows. The abandoned Paris FC–Lyon record adds one further distinct malformed club ID. |
| Phase disagreements | 47 separately inspected, plus one abandonment. 17 retain sporting totals and add a shootout marker, 30 held. All five administrative awards and the sixth on-field discrepancy are held. Known numeric kicks omitted on seven UEFA-documented shootouts. Each winner, home/away orientation, date and native tally is joined against the actual UEFA handbook table in the seven-match file. Paris FC–Lyon and Bradford–Luton held. In all 507,458 common keys no final score or edition changed. Notes changed on 520 cancellations, 55 extra-time and 27 penalties entries. |
| Goal beneficiaries | All 461,696 emitted event facts preserved on their existing match keys. Zero established named sides cleared or swapped on previously readable fixtures. Across the seven cited derbies, eight affected goals receive a corroborated club ID; the other eight stay with their old actor under a whole-match hold. The prior full archive had 655 null sides; this parser emits 313. Of those, 14 across five unheld matches have exact names once the governing-association suffix in the source is interpreted. |
| CONCACAF | All 33 source-plus-season IDs in incorrect edition 3333 are explicitly held in the DB plan. The local fixture date is one day earlier on each independent corroboration. The live historical edition and its current publication remain unresolved. |
| Appearance ordinals | All 13,108 raw sides across 2,639 club-edition groups verified. 10,540 sides are consumed before 2010. A further 2,568 in 2010–15 fall outside the established Footballcsv selection in favor of OpenFootball. All 210 previously proposed absorptions whose destinations used split identities are held. The 455 split groups / 2,560 effective identities require separate ownership and binding evidence before any merge. |
| Canceled and awarded | All 520 native cancellations are proposed as canceled, with null scores. All four authentic Russian first-division award rows retain their source scores and become awarded. |
| Positive and rejected stored plans | Private positive run over 1971/72 and 1972/73 applied 56 changes, retained one explicit hold, then replanned with no mutable changes. Replay retained archive versions and timestamps; revision drift on another clone was refused. |

## Two reproduced data losses block approval

- **New goal after plan review.** An existing 2019/20 ru.2 record received one ordinary, newly recorded goal after its deletion had been approved. The function returned an empty dependency list. The normal stored plan applied with a partial season receipt and deleted the new goal through the foreign-key cascade. The clean private baseline itself had zero events on all 240 ru.2 copies.
- **Empty primary edition.** Registering an empty 2024/25 PitchAPI Polish competition-season in a baseline clone qualified the complete archive edition as covered. The real plan and stored apply removed all 119 historical fixtures, all 339 goals and their edition. The primary edition contained zero matches. The session recorded a complete receipt. This is a controlled coverage transition, not an observation that the live Polish archive disappeared.

## Reproduction and evidence

From this evidence tree's `full-archive-verification` directory, with `PY` the audit worktree's `.venv/bin/python`, `v` an unused snapshot name and `T=../tracks/4-history`:

```sh
python3 "$T/snapshot.py" "$v"
"$PY" archive_build.py "$v"
python3 census.py "$v"
python3 archive_actor_census.py "$v"
"$PY" "$T/private_plan.py" "$v"
python3 "$T/corpus_check.py" "$v"
python3 "$T/plan_check.py" "$v"
python3 "$T/locators.py" "$v"
python3 "$T/known_phases.py" "$v"
"$PY" "$T/rehearsal.py" "$v" positive
"$PY" "$T/rehearsal.py" "$v" drift
"$PY" "$T/rehearsal.py" "$v" ru2-goal
"$PY" "$T/primary_coverage.py" "$v"
python3 "$T/snapshot.py" "$v" check
```

The `private_plan.py` command clones the preserved local database, then migrates only the clone. The four rehearsal commands each create their own clone of that pre-apply state. The expected controls and observed results are in individually named JSON receipts. On v2, the last two controlled scenarios failed the preservation requirement. The test script assertions for phase and derby actions reflect the v2 snapshot; later corrections require explicit re-evaluation against their independently verified target facts. Filenames below use this snapshot version as their suffix.

- `repair-2251-v2-files.json`, `s3-source-checksums.json`, `census-repair-2251-v2.json`, `season-counts-repair-2251-v2.json`.
- `1783-dispositions`, `1783-csv-locators`, `malformed-team-ids`, `score-phase-dispositions`, `verified-seven-shootouts`, `16-derby-private-team-ids`, `continental-edition`, `ordinal-provenance`, `cancellations`, `ru1-awarded`, `ru2-authority`.
- `all-phase-edition-diffs`, `event-losses-or-named-swaps`, `archive-actor-census`, `full-private-plan`, `private-plan-summary`, `stored-positive`, `stored-drift`, `stored-ru2-goal`, `empty-primary`.

The prior authority citations, their captured raw bytes, and each production SQL/receipt path are indexed in `full-archive-verification/CORRECTION-ACCEPTANCE.md`.
