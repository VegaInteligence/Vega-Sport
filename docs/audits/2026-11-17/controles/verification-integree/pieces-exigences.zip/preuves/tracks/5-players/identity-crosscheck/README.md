# Identités des Mondiaux, dates de naissance et classements publiés

Sur les 168 matchs natifs des phases finales 2022 et 2026, les **5 283 notes** sont sur des places effectivement jouées. L’identité personnelle est désormais corroborée pour **5 258 notes** et **8 514 lignes joueur–match sur 8 555**. L’attribution de 25 notes reste ouverte. La date de naissance est un fait distinct du rapprochement d’identité. La base et les notes de production ont été lues sans modification. [Résultats reproductibles](source-checks.json) · [Registre individuel](official/candidates.csv)

| Éléments qui permettent le rapprochement | Lignes natives | Dont notes Vega |
| --- | ---: | ---: |
| Premier rapprochement nominatif entre Vega et les listes FIFA | 8 453 | 5 214 |
| Graphie native attestée et contexte sportif distinct du maillot des finales | 58 | 41 |
| Identifiant personnel FIFA dans le Wikidata lié au joueur natif, malgré une date de naissance erronée | 3 | 3 |
| Identité restant réservée | 41 | 25 |

Les 102 lignes d’origine à vérifier concernent 29 personnes. Pour chacune, le profil sportif natif a répondu HTTP 200 avec l’identifiant demandé. Aucun de ces 29 profils ne contenait de date de naissance. Les 50 sources citées par le contrôle nominatif comprennent les registres FIFA, les fédérations et les ligues. Pour Serge Gnabry, le lien Wikidata de Vega mène à Q59490, dont la propriété P1469 porte exactement l’identifiant FIFA 395475. Trois notes de Gnabry sont donc attribuables personnellement malgré son année de naissance erronée dans la fiche Vega. Sur les 25 notes encore ouvertes, 16 correspondent à des variantes de nom, six à deux désaccords de dates Vega/FIFA et trois à un conflit entre clubs pour Mohammad Mohebi. [Contrôle officiel, méthodes et sources](official/README.md) · [Réponses du fournisseur natif](pitch-observed.json) · [Relevé Wikidata](wikidata/comparison.json)

## Effet des dates sur les résultats

À 00 h 48 UTC le 18 novembre, les six fiches témoins ont répondu HTTP 200. Les dates de trois joueurs étaient présentes. Celles de Mohamed Abdelmonem, Mohammad Mohebi et Abdullah Al-Hamdan étaient absentes, bien que le staging contienne une date pour chacun. Pour les deux derniers, le désaccord respectif entre clubs et entre registre FIFA et staging demande une décision sur les preuves avant publication. [Six fiches du lecteur](public-profiles.json) · [Liens sportifs et observations](db/person_facts_29/mapping.json)

| Joueur | Date Vega et contrôle indépendant | Occurrences dont l’âge révolu au match change |
| --- | --- | ---: |
| Serge Gnabry | 14 juillet 1990 dans Vega, 14 juillet 1995 dans les registres DFB et FIFA et dans le Wikidata actuel | 181 matchs, 9 554 minutes |
| Nathan Saliba | 29 août 2004 dans Vega et une déclaration Wikidata sans référence, 7 février 2004 selon la FIFA, la Concacaf et Anderlecht | 74 matchs, 4 830 minutes |
| Malick Diouf | 28 décembre 2004 selon Vega, West Ham et la Premier League, 29 décembre selon le registre FIFA | 0 sur 93 matchs vérifiés |

L’historique public de Gnabry montre le passage de 1995 à 1990 le 21 octobre à 02 h 02 UTC, puis le rétablissement de 1995 le 15 novembre à 00 h 57 UTC. Le dernier contrôle du club dans Vega date du 12 novembre. L’ancienne réponse lue par le worker ne figure pas dans ces reçus. La mesure d’âge utilise les minutes positives des matchs terminés. [Révisions datées](wikidata/history-comparison.json) · [Impact SQL par saison](db/age_impacts/age-impact.json)

RDS comptait 64 972 joueurs à 00 h 36 UTC, dont 6 116 avec une naissance canonique et 17 377 sans naissance canonique malgré un profil Transfermarkt lié, daté et hors quarantaine. Aucun désaccord avec une observation explicitement citée dans le champ de provenance au moment du relevé. Sur une copie PostgreSQL 18, six profils effectivement cités sont passés par l’adaptateur Wikidata du worker et le lecteur SQL de profil. Une réponse concordante a préservé les six citations. Une réponse contrôlée décalée d’un jour a modifié les six dates en conservant la citation antérieure, résultat identique à la répétition. L’opération démontre une perte de traçabilité reproductible. [Mesure RDS](db/fact_provenance/fact-provenance.json) · [Critères et entrées de l’essai](birth-criteria.md) · [Résultat avant correction](birth-replay-original.json)

## Révélations U23

Sur les six saisons 2021 à 2026 et avec les entrées RDS à 00 h 38 UTC, 855 couples joueur–saison satisfont les conditions sportives. La règle déployée, qui exige une date canonique, retient 113 couples. Les 113 sont publiés. Réutiliser à titre de sensibilité la date de repli admise pour l’âge d’équipe porterait le nombre à 276, soit 163 couples supplémentaires concernant 152 personnes. Les 163 passent tous par une correspondance Transfermarkt inférée sur le nom, le club et la saison. Une validation d’identité individuelle conditionne leur éventuelle admission. [Populations et méthode SQL](breakout-cohorts.sql) · [Résultats détaillés](db/breakout_analysis/breakout-cohorts.json)

Les listes publiées comportaient 126 couples. Les 13 cas supplémentaires avaient déjà une saison antérieure éligible dans le classement désormais en base. Ce motif explique chacun des 13 écarts sur les entrées contemporaines. L’API publique a confirmé les 13 identifiants, leurs rangs et leurs minutes dans les trois listes, cinq pour 2022, deux pour 2023 et six pour 2024. Pour ces 13 joueurs–saisons, les 18 lignes de régularité historique reliées par identifiant de passe ont toutes été republiées **après** la liste « Révélations » de la saison concernée. Les relevés ne contiennent pas les anciennes versions des 18 lignes. Ils établissent que la liste servie diverge de la règle appliquée aux données actuelles. La relecture des dépendances entre saisons relève du propriétaire de VI-21. [Lecteur public par saison](public-breakouts.json) · [Passes comparées](db/prior_published/breakout-prior.json) · [Prédicats un par un](db/published_flags/breakout-published-drift.json)

## Reproduction

Depuis ce répertoire, ces deux commandes relisent les entrées gelées, les empreintes SQL, les 29 profils, les six fiches, les 20 révisions et les correspondances de classement. Les 11 fichiers du sous-dossier officiel constituent son périmètre transportable. La relecture des corps originaux des clubs exige le cache privé ou une nouvelle acquisition documentée.

```sh
python3 official/verify.py --compact-only
python3 verify.py
```

Avec PostgreSQL 18 disponible dans Docker (contexte colima) et l’environnement Python du backend, cet essai crée puis arrête un conteneur isolé. Le dernier argument est une nouvelle destination JSON. Les entrées, les résultats attendus et les conditions simulées sont dans les critères ci-dessus.

```sh
python exercise-birth.py "$VEGA_AUDIT_WORKTREE" "$VEGA_EVIDENCE_OUTPUT/birth-replay.json"
```

Pour une nouvelle mesure en lecture seule dans RDS, les commandes `python3 run.py person_facts_29`, puis `run.py` avec chacun de `fact_provenance`, `cited_facts`, `age_impacts`, `breakout_analysis`, `published_flags` et `prior_published` s’exécutent dans une nouvelle copie de travail du dossier de preuves. Le lanceur fixe l’image ECS à celle de la production vérifiée et clôt sa définition de tâche après chaque lot. Chaque dossier sous `db/` contient les SELECT exacts, les heures et les résultats.
