# T1 / VI-28 et VI-32 — contre-revue Astra

**Décision : acceptable pour intégration du périmètre backend/transport gelé ; aucun défaut bloquant supplémentaire trouvé. Les corrections d'affichage restent ouvertes.** gpt-6-astra / xhigh explicitement sélectionné, revue indépendante sans verdict Fable, 18 novembre 2026. HEAD vérifié 2813e7c1d606b231c4dc81a255a8124f85eecb3d, base de scope 1b28961a88e968d5602f9fb278fc3c471ebb7467, arbre propre. Instructions root/frontend, exigences originales, accepted-plan, pinned-astra-addendum et candidate-evidence examinés.

## Mi-temps

Migration 137 comparée à 129 : mêmes observations admissibles (match terminé, minutes positives), même population de cas complets ; les sommes et supports nouveaux sont propres à chaque mesure. La conversion xG élimine NaN/±Infinity avant comptage, réserve le zéro structurel aux tirs explicitement nuls, additionne en numeric les décimales courtes des real et fixe extra_float_digits dans la fonction. L'API filtre les deux vues par joueur/saison avant jointure dans une seule requête, conserve les deux blocs historiques et ajoute la couverture même sans cas complet. Pas de faux zéro ni de 404 pour le joueur partiellement mesuré dans le rejeu.

## gradeExact, rang et rapport

La précision vient du même SELECT que le dixième ; aucune autre publication n'est utilisée pour la fabriquer. L'admission et l'ordre/rang historiques restent identiques. Une note cachée garde gradeExact null. Le rapport valide type, finitude, plage et compatibilité avec le dixième ; l'absence du nouveau champ conserve la forme ancienne. Les listes best et playerOfMatch gardent leur tri historique ; le tri stable conserve l'ordre exact déjà établi par le classement lorsque les dixièmes sont égaux.

Le nouveau témoin indépendant applique les migrations sur une base neuve, lit les routes via le rôle vega_read et un vrai serveur HTTP, puis le vrai /api/rapport : **14/14 contrôles PASS**. Passe seule 14/45 minutes disponible avec goals inconnu ; mesure entièrement inconnue distincte de zéro ; xG 1.35802459 préservé ; cas sans participation admissible 404. Révision 48.4900000244873→48.5100000149922 : grade reste 48.5, entier précis 48→49, rang 2 conservé dans ce scénario, ETag différent et réponse 200, même précision dans le rapport. [Commande et preuve](reviews/astra-1306/README.md), [corps/ETags/résultats](reviews/astra-1306/witness.json).

## Limites de l'acceptation

Le tableau/composition et les surfaces de présentation utilisent encore grade : la variation Tataev 48→49 et les rangs locaux 14→13 des corps publics rejoués ne sont donc pas corrigés par ce lot. Ce n'est pas un défaut dissimulé de ce commit : l'activation frontend est explicitement en attente de validation de maquette. Un même dixième provenant d'une ancienne famille ne suffit toujours pas à attester une publication commune. Le lot ne prétend pas corriger ce mélange ; aucun repli inter-publications risqué n'a été ajouté.

Les preuves auteur/coordinateur (40 API mi-temps, 4 tests précision, CI locale avec incident Colima puis reprise API) ont été examinées comme preuves datées ; elles ne sont pas de nouvelles exécutions de cette revue. Ni CI exhaustive ni navigateur desktop/mobile n'ont été relancés. Pas de vérification production, de déploiement, de couverture scientifique ou de clôture globale VI-28/VI-32. La future branche intégrée doit faire ses vérifications propres.

UX : données partielles disponibles sans effacer le sens de l'inconnu, activation visuelle encore nécessaire. DX/AX : ajout compatible et preuve HTTP/ETag explicite ; contrepartie assumée, deux représentations de la couverture coexistent tant que l'ancien client reste en service. Aucun fichier produit modifié pendant la revue.
