"use client";
import React, {
  lazy,
  useCallback,
  Suspense,
  useEffect,
  useMemo,
  useRef,
  useState,
} from "react";
import Link from "next/link";
import { useSearchParams } from "next/navigation";
import { useFootball } from "../hooks/FootballContext.jsx";
import useActorRead from "../hooks/useActorRead.js";
import useVisibleIntent from "../hooks/useVisibleIntent.js";
import { actorReadParams } from "../services/actor-reads.js";
import { compactGeneration, readCompact } from "../services/compact-reads.js";
import { useResearch } from "../hooks/ResearchContext.jsx";
import {
  aggregateSeason,
  aggregateSeasonPlayers,
  MIN_SEASON_MINUTES,
  seasonMetric,
} from "../services/season-player.js";
import {
  buildCohorts,
  rankMetric,
  roleAssessments,
  SCOUT_METRICS,
} from "../services/scouting.js";
import { number } from "../services/format.js";
import { Segments, Skeleton } from "./UI.jsx";
import {
  BookmarkButton,
  ComparePlayerButton,
  MetricInfo,
  ResearchTabs,
} from "./ResearchUI.jsx";
import Icon from "./Icon.jsx";
import { usePlayerHonours } from "./PlayerHonours.jsx";
import PlayerOverviewRadar from "./PlayerOverviewRadar.jsx";
import PlayerProfileFilters, { FilterGroup } from "./PlayerProfileFilters.jsx";
import PlayerScoutRail, { PlayerScoutStrip } from "./PlayerScoutRail.jsx";
import PlayerAdvancedStats from "./PlayerAdvancedStats.jsx";
import PlayerScoutOverview, {
  PlayerGames,
  PlayerScoutCompare,
  PlayerScoutStats,
} from "./PlayerScoutOverview.jsx";
import PlayerScoutCareer from "./PlayerScoutCareer.jsx";
import PlayerPhysical from "./PlayerPhysical.jsx";
import PlayerPresenceCard from "./PlayerPresenceCard.jsx";
import PlayerPassPartners from "./PlayerPassPartners.jsx";
import PlayerNeighbours from "./PlayerNeighbours.jsx";
import PlayerHalves from "./PlayerHalves.jsx";
import PlayerReturn from "./PlayerReturn.jsx";
import PlayerActionValues from "./PlayerActionValues.jsx";
import { TeamContextCard } from "./PlayerStyleCards.jsx";
import PlayerFaced from "./PlayerFaced.jsx";
import { chartTokens } from "./PlayerScoutCharts.jsx";
import scout from "./PlayerScout.module.css";
import { nationalFlagCode } from "../services/national-flags.js";
import MessiGoats from "./MessiGoats.jsx";
import { levelPeerClubs, useEuropeLevels } from "../services/club-scout.js";
import { RankingProvider, RankingTrigger } from "./RankingDialog.jsx";
import {
  PlayerLevelGroup,
  PlayerLevelStatus,
  PlayerRankingDialog,
} from "./PlayerRanking.jsx";
import { MESSI_ID } from "../services/player-honours.js";
import { breakoutSignal, usePlayerPower, vegaParts } from "../services/ballon-dor.js";
import {
  cachedResource,
  primeResource,
  useResource,
} from "../services/resources.js";
import {
  MESSI_PORTRAIT,
  loadSummaryIdentity,
  resolvePlayerIdentity,
} from "../services/player-identity.js";
import { Term } from "./Hint.jsx";

const Similarity = lazy(() => import("./PlayerSimilarity.jsx"));
const Projection = lazy(() => import("./PlayerProjection.jsx"));
const SeasonShots = lazy(() => import("./SeasonShots.jsx"));
const loadSeasonStats = () => import("./PlayerSeasonStats.jsx");
const loadCareerStats = () => import("./PlayerCareerStats.jsx");
const SeasonStats = lazy(loadSeasonStats);
const CareerStats = lazy(loadCareerStats);
/** The code of what the overview shows at once, for the page to ask for early. */
export const preloadProfileParts = () =>
  Promise.all([loadSeasonStats(), loadCareerStats()]);
const PerformanceStats = lazy(() =>
  import("./PlayerSeasonStats.jsx").then(({ PlayerPerformanceStats }) => ({
    default: PlayerPerformanceStats,
  })),
);
// Same tabs, order and names as mock-up C.
const TABS = [
  ["overview", "Vue d’ensemble"],
  ["stats", "Statistiques"],
  ["advanced", "Stats avancées"],
  ["physical", "Physique"],
  ["compare", "Comparaison"],
  ["similar", "Profils similaires"],
  ["evolution", "Carrière et marché"],
  ["projection", "Projection"],
  ["games", "Matchs"],
];
// Tabs whose content ignores the competition and date filters.
const UNFILTERED_VIEWS = new Set([
  "stats",
  "evolution",
  "physical",
  "projection",
]);
const HISTORY_TABS = TABS.slice(0, 2);
// Why a player's rank in Vega's ranking is provisional (the API's provisionalReason).
const PROVISIONAL = {
  minutes: "Rang provisoire : il a moins de minutes que le seuil de la saison ; son indice part du bas de son poste et rejoint le sien à mesure qu’il joue.",
  league: "Rang provisoire : le niveau de son championnat n’est encore mesuré qu’à peu près.",
  no_league: "Rang provisoire : son club ne joue dans aucun championnat suivi par Vega ; son niveau ne vient que de ses matchs de coupe d’Europe.",
  national: "Rang provisoire : il n’est connu que par ses matchs en sélection, sans club suivi par Vega.",
};
const STAT_MODES = [
  ["total", "Totaux"],
  ["per90", "Par 90 min"],
  ["perMatch", "Par match"],
];

function profileTeam(rows, teams, season, includeSelection = false) {
  const minutes = new Map();
  for (const row of rows)
    if (row.teamId)
      minutes.set(
        row.teamId,
        (minutes.get(row.teamId) || 0) + (row.minutes || 0),
      );
  const known = new Map((teams || []).map((item) => [item.id, item]));
  let selection = null;
  for (const [teamId] of [...minutes].sort((a, b) => b[1] - a[1])) {
    const info = known.get(teamId);
    const name = info?.name || rows.find((row) => row.teamId === teamId)?.team;
    if (!name) continue;
    const team = { id: teamId, name, imageUrl: info?.imageUrl };
    if (!nationalFlagCode(name, season)) return team;
    if (includeSelection) selection ||= team;
  }
  return selection;
}

export function PlayerMetricTable({ profile, keys, mode, cohorts }) {
  return (
    <div className="table-scroll">
      <table className="data-table research-player-metrics">
        <caption className="sr-only">
          Statistiques de saison, couverture et centiles au poste
        </caption>
        <thead>
          <tr>
            <th><Term>Indicateur</Term></th>
            <th>
              {mode === "total"
                ? "Total"
                : mode === "per90"
                  ? "Par 90 ou %"
                  : "Par match ou %"}
            </th>
            <th><Term>Matchs renseignés</Term></th>
            <th><Term>Médiane / 90 ou %</Term></th>
            <th>
              <Term>Centile au poste</Term>
            </th>
            <th><Term>Pairs</Term></th>
          </tr>
        </thead>
        <tbody>
          {keys.map((key) => {
            const value = seasonMetric(profile, key, mode),
              rank = rankMetric(profile, key, cohorts);
            return (
              <tr key={key} data-metric={key}>
                <th scope="row">
                  <RankingTrigger target={{ type: "metric", key }}>
                    {SCOUT_METRICS[key].label}
                  </RankingTrigger>
                  <MetricInfo
                    metric={key}
                    observed={value.count}
                    total={profile.matches}
                  />
                </th>
                <td>
                  {number(
                    value.value,
                    mode === "total" && !SCOUT_METRICS[key].ratio
                      ? SCOUT_METRICS[key].decimals || 0
                      : 2,
                  )}
                  {SCOUT_METRICS[key].unit ? ` ${SCOUT_METRICS[key].unit}` : ""}
                </td>
                <td>
                  {value.count} / {profile.matches}
                </td>
                <td>{number(rank.median, 2)}</td>
                <td>{number(rank.percentile)}</td>
                <td>{rank.peers || "—"}</td>
              </tr>
            );
          })}
        </tbody>
      </table>
    </div>
  );
}
/** Identity rail beside the tabbed analysis, plus its compact scrolling strip. */
function ProfileLayout({
  id,
  identity,
  profile,
  record,
  season,
  team,
  playingTime,
  vega,
  honours,
  actions,
  stripActions,
  onTab,
  children,
}) {
  const railRef = useRef(null);
  const fallbackUrl = id === MESSI_ID ? MESSI_PORTRAIT : undefined;
  const showIdentity = Boolean(identity.name);
  return (
    <>
      {showIdentity && (
        <PlayerScoutStrip
          railRef={railRef}
          identity={identity}
          profile={profile}
          team={team}
          actions={stripActions}
        />
      )}
      <div className={scout.layout}>
        <div ref={railRef}>
          <PlayerScoutRail
            id={id}
            identity={identity}
            fallbackUrl={fallbackUrl}
            showIdentity={showIdentity}
            profile={profile}
            record={record}
            season={season}
            team={team}
            playingTime={playingTime}
            vega={vega}
            honours={honours}
            actions={actions}
            onTab={onTab}
          />
        </div>
        <div className={scout.main}>{children}</div>
      </div>
    </>
  );
}

export default function PlayerSeasonProfile({
  id,
  rows,
  summaryProfile,
  scopeRows,
  profiles: allProfiles,
  comparisonsReady = true,
  onNeedComparisons,
  radarComparison,
}) {
  const f = useFootball(),
    params = useSearchParams();
  // Every played observation, whatever the match's status: the match log (VI-23 stage 6, §15).
  const logProfile = useMemo(() => aggregateSeason(rows, id), [rows, id]);
  // The season's figures: the caller's finished-only summary (PlayersPage), else these rows.
  const profile = summaryProfile ?? logProfile;
  const knownIdentity = useMemo(
    () => resolvePlayerIdentity(id, profile, f.data?.appearances),
    [id, profile, f.data?.appearances],
  );
  const identityKey = `player-identity:${id}`;
  useEffect(() => {
    // Changing competitions can remount the profile with a different dataset.
    if (knownIdentity.name)
      void primeResource(identityKey, () => knownIdentity);
  }, [identityKey, knownIdentity]);
  const publishedProfile = useResource(
    `player-record:${id}`,
    async () => {
      try {
        return (await f.client.request(`players/${encodeURIComponent(id)}`))
          .data;
      } catch (error) {
        if (error.status === 404) return null;
        throw error;
      }
    },
    Boolean(f.client && /^p_[A-Za-z0-9]{6}$/.test(id)),
  );
  const record = publishedProfile.value;
  const storedIdentity = cachedResource(identityKey);
  const generation = compactGeneration(f.manifest);
  const seasons = [
    f.season,
    ...(f.manifest?.seasons || []).map((s) => s.id),
  ].filter((season, index, all) => season && all.indexOf(season) === index);
  const relationalIdentity = useResource(
    `player-summary-identity:${id}:${seasons.join(",")}:${generation}`,
    ({ signal }) =>
      loadSummaryIdentity(id, seasons, generation, readCompact, signal),
    Boolean(
      !knownIdentity.name &&
      !record?.name &&
      !storedIdentity?.name &&
      seasons.length &&
      /^p_[A-Za-z0-9]{6}$/.test(id || ""),
    ),
  );
  const summaryIdentity = relationalIdentity.value;
  useEffect(() => {
    if (summaryIdentity?.name)
      void primeResource(identityKey, () => summaryIdentity);
  }, [identityKey, summaryIdentity]);
  const identity = useMemo(
    () =>
      resolvePlayerIdentity(id, profile, f.data?.appearances, {
        name: record?.name || storedIdentity?.name || summaryIdentity?.name,
        image_url:
          record?.image_url ||
          record?.imageUrl ||
          storedIdentity?.imageUrl ||
          summaryIdentity?.imageUrl,
      }),
    [id, profile, f.data?.appearances, record, storedIdentity, summaryIdentity],
  );
  const honours = usePlayerHonours(id, identity.name);
  // The club of the finished matches; without one, of the observed ones.
  const team = useMemo(
    () =>
      profileTeam(
        profile.rows.length ? profile.rows : logProfile.rows,
        f.data?.teams,
        f.season,
      ),
    [profile.rows, logProfile.rows, f.data?.teams, f.season],
  );
  const role = profile.role?.label;
  const profiles = useMemo(
    () => allProfiles || aggregateSeasonPlayers(scopeRows),
    [allProfiles, scopeRows],
  );
  const [mode, setMode] = useState("total"),
    [minMinutes, setMinMinutes] = useState(450);
  const requestedView = params?.get("playerView");
  const view = TABS.some(([key]) => key === requestedView)
    ? requestedView
    : "overview";
  const [overviewScope, setOverviewScope] = useState(null);
  const scopeKey = `${id}:${f.season}`;
  const competition =
    view === "overview" &&
    overviewScope?.key === scopeKey &&
    profile.rows.some((row) => row.league === overviewScope.competition)
      ? overviewScope.competition
      : "all";
  // The competitions he played this season, most matches first: the bar's pills.
  const competitions = useMemo(() => {
    const names = new Map();
    for (const row of profile.rows)
      if (row.league) names.set(row.league, (names.get(row.league) || 0) + 1);
    return [...names].sort((a, b) => b[1] - a[1]).map(([name]) => name);
  }, [profile.rows]);
  const timeRows = useMemo(
    () =>
      competition === "all"
        ? rows
        : rows.filter((row) => row.league === competition),
    [rows, competition],
  );
  const timeTeam = useMemo(() => {
    if (competition === "all" && team) return team;
    return (
      profileTeam(timeRows, f.data?.teams, f.season, true) ||
      profileTeam(
        (f.data?.appearances || []).filter((row) => row.playerId === id),
        f.data?.teams,
        f.season,
        true,
      )
    );
  }, [
    competition,
    team,
    timeRows,
    f.data?.teams,
    f.data?.appearances,
    f.season,
    id,
  ]);
  const playingTime = { rows: timeRows, team: timeTeam, competition };
  const comparisonMinutes =
    view === "overview" ? MIN_SEASON_MINUTES : minMinutes;
  // Peers restricted to the clubs closest to the player's club in level.
  const [level, setLevel] = useState(true);
  const europe = useEuropeLevels(level);
  const levelPeers = useMemo(
    () =>
      level && europe.status === "ready" && team
        ? levelPeerClubs(europe.value, team.id)
        : null,
    [level, europe, team],
  );
  const scopedProfiles = useMemo(
    () =>
      levelPeers
        ? profiles.filter(
            (peer) =>
              peer.id === profile.id ||
              (peer.teamIds || []).some((teamId) => levelPeers.ids.has(teamId)),
          )
        : profiles,
    [profiles, levelPeers, profile.id],
  );
  const cohorts = useMemo(
    () => buildCohorts(scopedProfiles, comparisonMinutes),
    [scopedProfiles, comparisonMinutes],
  );
  const [rankingKey, setRankingKey] = useState(null);
  const openRanking = useCallback(
    (target) => target?.type === "metric" && setRankingKey(target.key),
    [],
  );
  const change = (next) => {
    const url = new URL(window.location.href);
    url.searchParams.set("playerView", next);
    if (next !== "overview") setOverviewScope(null);
    if (next === "stats") {
      url.searchParams.delete("performanceCompetition");
      url.searchParams.delete("performanceSeason");
    }
    window.history.replaceState(null, "", url.pathname + url.search);
  };
  const cohort = cohorts.groups.get(profile.role?.group);
  // Rail « Indice Vega »: the player's score in Vega's power ranking of the season and
  // his rank among the ranked players of his position; for a season or a player without
  // one, his best role index and its rank among the cohort.
  const power = usePlayerPower(f.season, id);
  const vega = useMemo(() => {
    if (power === undefined) return null;
    if (power?.score != null)
      return {
        value: Math.round(power.score),
        label: power.position,
        rank: power.roleRank ?? null,
        of: power.roleRank ? power.roleCount : null,
        parts: vegaParts(power),
        women: power.universe === "women",
        // A provisional rank, and why (the API's provisionalReason).
        provisional: PROVISIONAL[power.provisionalReason] ?? null,
        signal: breakoutSignal(power.breakout),
      };
    // Below the ranking's minutes: no score of his own, but he may be flagged as a breakout.
    const signal = breakoutSignal(power?.breakout);
    if (!comparisonsReady || !profile.matches) return signal ? { signal } : null;
    const best = roleAssessments(profile, cohorts).find(
      (role) => role.value != null,
    );
    if (!best) return signal ? { signal } : null;
    const scores = (cohorts.groups.get(profile.role?.group)?.profiles || [])
      .filter((peer) => peer.id !== profile.id)
      .map(
        (peer) =>
          roleAssessments(peer, cohorts).find((role) => role.id === best.id)
            ?.value,
      )
      .filter((value) => value != null);
    return {
      value: Math.round(best.value),
      label: best.label,
      rank: scores.filter((value) => value > best.value).length + 1,
      of: scores.length + 1,
      signal,
    };
  }, [power, comparisonsReady, profile, cohorts]);
  const performanceSeason = params?.get("performanceSeason");
  const showCurrentShots =
    view === "stats" &&
    (performanceSeason == null || performanceSeason === f.season);
  const [comparisonRef, comparisonVisible] = useVisibleIntent(
    `${id}:${f.season}:${view}`,
    ["overview", "stats"].includes(view),
  );
  useEffect(() => {
    if (comparisonVisible) onNeedComparisons?.();
  }, [comparisonVisible, onNeedComparisons]);
  const [shotsRef, shotsVisible] = useVisibleIntent(
    `${id}:${f.season}:shots`,
    showCurrentShots,
  );
  const deferredShots = f.manifest?.capabilities?.actorSummary === true;
  const shotDetails = useActorRead(
    f.manifest,
    "player",
    actorReadParams(f.manifest, "player", {
      id,
      season: f.season,
      leagues: f.actorScope || "all",
      include: "shots",
    }),
    {
      enabled: deferredShots && showCurrentShots && shotsVisible,
      refreshManifest: f.refreshManifest,
    },
  );
  const shotMatches = deferredShots
    ? shotDetails.value?.matches || []
    : f.data.matches;
  const matchIds = useMemo(
    () => new Set(profile.rows.map((row) => row.matchId)),
    [profile.rows],
  );
  const shots = useMemo(
    () =>
      showCurrentShots
        ? shotMatches
            .filter((m) => matchIds.has(m.id))
            .flatMap((m) =>
              (m.shots || [])
                .filter((s) => s.playerId === id)
                .map((s) => ({
                  ...s,
                  matchId: m.id,
                  date: m.date,
                  leagueId: m.leagueId,
                  season: m.season,
                })),
            )
        : [],
    [showCurrentShots, shotMatches, matchIds, id],
  );
  const historyLoading = (
    <Skeleton data-page-loading="" label="Chargement des saisons…" />
  );
  const historyOverview = (
    <div className="player-overview">
      <Suspense fallback={historyLoading}>
        <SeasonStats id={id} season={f.season} />
      </Suspense>
      <div className="player-overview-comparison">
        <div ref={comparisonRef}>
          <PlayerOverviewRadar
            profile={profile}
            cohorts={cohorts}
            comparison={
              radarComparison || (!comparisonsReady ? { loading: true } : null)
            }
          />
        </div>
        <Suspense fallback={historyLoading}>
          <CareerStats id={id} season={f.season} overview />
        </Suspense>
      </div>
    </div>
  );
  const overview = (
    <PlayerScoutOverview
      profile={profile}
      cohorts={cohorts}
      ready={comparisonsReady}
      season={f.season}
      matches={f.data?.matches}
      comparisonRef={comparisonRef}
      onTab={change}
      competition={competition}
    />
  );
  // A player observed this season keeps the tabs and his match log, even without a finished match.
  if (!logProfile.matches) {
    const historyView = view === "stats" ? "stats" : "overview";
    return (
      <article
        className={`research-player-profile player-profile-flat ${chartTokens}`}
      >
        <MessiGoats id={id} />
        <ProfileLayout
          id={id}
          identity={identity}
          profile={profile}
          record={record}
          season={f.season}
          team={team}
          playingTime={playingTime}
          honours={honours}
          onTab={change}
        >
          <ResearchTabs
            animated
            label="Analyse du joueur"
            value={historyView}
            items={HISTORY_TABS}
            onChange={change}
            panelId="player-profile-panel"
          />
          <div
            id="player-profile-panel"
            role="tabpanel"
            aria-label={
              historyView === "stats" ? "Statistiques" : "Vue d’ensemble"
            }
          >
            {historyView === "overview" && <PlayerProfileFilters />}
            {historyView === "stats" ? (
              <>
                <Suspense fallback={historyLoading}>
                  <PerformanceStats id={id} />
                </Suspense>
                {rows.length > 0 && <PlayerPresenceCard id={id} rows={rows} />}
              </>
            ) : (
              historyOverview
            )}
          </div>
        </ProfileLayout>
      </article>
    );
  }
  const cohortControls = (
    <div className="research-context">
      <span>
        {number(cohort?.profiles.length || 0)} joueurs au même poste · au moins{" "}
        {minMinutes} min
      </span>
      <label>
        Minutes minimum
        <input
          type="number"
          aria-label="Minutes minimum de la cohorte"
          min="0"
          max="9000"
          step="90"
          value={minMinutes}
          onChange={(e) =>
            setMinMinutes(
              Math.max(0, Math.min(9000, Number(e.target.value) || 0)),
            )
          }
        />
      </label>
    </div>
  );
  // The actions name the resolved identity: a summary without a finished match is « Joueur ».
  const actionProfile = {
    ...profile,
    name: identity.name || profile.name,
    imageUrl: identity.imageUrl || profile.imageUrl,
  };
  // The Matchs tab: the season's competitions finished-only, its log every observation.
  const games = (
    <PlayerGames
      profile={profile}
      logRows={logProfile.rows}
      matches={f.data?.matches}
    />
  );
  const playerActions = (
    <div className="research-toolbar">
      <BookmarkButton
        kind="players"
        id={id}
        name={actionProfile.name}
        imageUrl={actionProfile.imageUrl}
        season={f.season}
      />
      <ComparePlayerButton profile={actionProfile} season={f.season} />
      <Link className="button button-secondary" href={f.href("/rapport/", { id })}>
        <Icon name="eye" />
        Rapport
      </Link>
    </div>
  );
  return (
    <RankingProvider value={comparisonsReady ? openRanking : null}>
    <article
      className={`research-player-profile player-profile-flat ${chartTokens}`}
    >
      <MessiGoats id={id} />
      <ProfileLayout
        id={id}
        identity={identity}
        profile={profile}
        record={record}
        season={f.season}
        team={team}
        playingTime={playingTime}
        vega={vega}
        honours={honours}
        onTab={change}
        actions={playerActions}
        stripActions={
          <div className="research-toolbar">
            <ComparePlayerButton profile={actionProfile} season={f.season} />
          </div>
        }
      >
        <ResearchTabs
          animated
          label="Analyse du joueur"
          value={view}
          items={TABS}
          onChange={change}
          panelId="player-profile-panel"
        />
        <div
          id="player-profile-panel"
          role="tabpanel"
          aria-label={TABS.find(([key]) => key === view)[1]}
        >
          <PlayerProfileFilters
            period={!UNFILTERED_VIEWS.has(view)}
            after={
              (view === "overview" && competitions.length > 1) ||
              COHORT_VIEWS.has(view) ? (
                <>
                  {view === "overview" && competitions.length > 1 && (
                    <FilterGroup>
                      <Segments
                        label="Compétition"
                        value={competition}
                        onChange={(value) =>
                          setOverviewScope({ key: scopeKey, competition: value })
                        }
                        items={[
                          ["all", "Toutes"],
                          ...competitions
                            .slice(0, 4)
                            .map((name) => [name, name]),
                        ]}
                      />
                    </FilterGroup>
                  )}
                  {COHORT_VIEWS.has(view) && (
                    <PlayerLevelGroup level={level} onLevel={setLevel} />
                  )}
                </>
              ) : null
            }
            status={
              COHORT_VIEWS.has(view) && (
                <PlayerLevelStatus
                  level={level}
                  state={level ? europe : { status: "ready" }}
                  peers={levelPeers}
                  team={team}
                />
              )
            }
          />
          {view === "similar" && cohortControls}
          <Suspense
            fallback={
              <Skeleton data-page-loading="" label="Chargement de l’analyse…" />
            }
          >
            {view === "overview" && overview}
            {view === "advanced" && (
              <>
                <PlayerAdvancedStats
                  profile={profile}
                  cohorts={cohorts}
                  minMinutes={minMinutes}
                  onMinMinutes={setMinMinutes}
                  ready={comparisonsReady}
                />
                <PlayerActionValues id={id} />
                <TeamContextCard id={id} season={f.season} team={team} />
              </>
            )}
            {view === "stats" && (
              <>
                <div className={scout.overview} ref={comparisonRef}>
                  <div className={scout.sectionHead}>
                    <div>
                      <h2>Statistiques détaillées</h2>
                      <p>
                        Valeur, médiane, centile et rang face aux{" "}
                        {profile.role?.peers || "joueurs du même poste"} ·
                        saison {f.season}
                      </p>
                    </div>
                    <div className="research-toolbar">
                      <Segments
                        label="Calcul des statistiques du joueur"
                        value={mode}
                        onChange={setMode}
                        items={STAT_MODES}
                      />
                    </div>
                  </div>
                </div>
                {cohortControls}
                <PlayerScoutStats
                  profile={profile}
                  cohorts={cohorts}
                  mode={mode}
                  ready={comparisonsReady}
                />
                <div className={`${scout.block} ${scout.grid2}`}>
                  <section className={scout.card} ref={shotsRef}>
                    {deferredShots && !shotDetails.value ? (
                      shotDetails.error ? (
                        <p role="alert">
                          {shotDetails.error}{" "}
                          <button onClick={shotDetails.retry}>Réessayer</button>
                        </p>
                      ) : (
                        <Skeleton data-page-loading="" label="Chargement des tirs de la saison…" lines={2} />
                      )
                    ) : (
                      <Suspense fallback={historyLoading}>
                        <SeasonShots
                          key={id}
                          title="Carte des tirs"
                          shots={shots}
                          legacyPitchApi={
                            f.manifest?.storage === "aws-relational"
                          }
                        />
                      </Suspense>
                    )}
                  </section>
                  <PlayerPresenceCard id={id} rows={rows} />
                </div>
                <div className={scout.block}>
                  <PlayerReturn id={id} />
                </div>
                <div className={scout.block}>
                  <PlayerFaced id={id} enabled={profile.role?.group === "G"} />
                </div>
                <div className={scout.block}>
                  <PlayerPassPartners id={id} />
                </div>
                <div className={scout.block}>
                  <PlayerHalves id={id} />
                </div>
              </>
            )}
            {view === "similar" && (
              <div className={scout.block}>
                <PlayerNeighbours id={id} />
              </div>
            )}
            {view === "similar" &&
              (comparisonsReady ? (
                <Similarity profile={profile} cohorts={cohorts} />
              ) : (
                <Skeleton label="Chargement des joueurs du même poste…" lines={2} />
              ))}
            {view === "evolution" && (
              <PlayerScoutCareer
                key={id}
                id={id}
                record={record}
                team={team}
                season={f.season}
              />
            )}
            {view === "physical" && <PlayerPhysical id={id} season={f.season} rows={profile.rows} />}
            {view === "projection" && (
              <Projection
                profile={profile}
                profiles={profiles}
                team={team}
                ready={comparisonsReady}
              />
            )}
            {view === "games" && games}
            {view === "compare" && (
              <PlayerScoutCompare
                profile={profile}
                cohorts={cohorts}
                ready={comparisonsReady}
              />
            )}
          </Suspense>
        </div>
      </ProfileLayout>
      {rankingKey && (
        <PlayerRankingDialog
          profile={profile}
          cohorts={cohorts}
          metricKey={rankingKey}
          onClose={() => setRankingKey(null)}
        />
      )}
    </article>
    </RankingProvider>
  );
}
const COHORT_VIEWS = new Set([
  "overview",
  "advanced",
  "stats",
  "similar",
  "compare",
]);
