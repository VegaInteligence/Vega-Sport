# Calculs de Vega — comment chaque chiffre est obtenu

Ce dossier explique, formule par formule, comment le site calcule ce qu'il affiche : xG, xA, xGOT, points attendus (xPts), probabilités de victoire, centiles, indices Vega, similarités, classements, sélections éditoriales de l'accueil.

Il décrit le code tel qu'il est au 9 novembre 2026, et les corrections de l'audit des calculs du 16 novembre 2026 faites le 17 novembre (section 9). Chaque page renvoie aux fichiers et aux fonctions concernés ; si le code change, le code fait foi.

## Ce que Vega calcule, et ce qu'il ne calcule pas

| Valeur | Origine |
| --- | --- |
| xG, xG hors penalty, xG en jeu / sur CPA, xGOT, xA, buts évités | **Fournies par PitchAPI**. Vega lit, additionne et compare ces valeurs ; son propre xG ([Le xG de Vega](02-metriques-attendues/05-xg-vega.md)) les double sans les remplacer à l'affichage. |
| Points attendus (xPts), probabilités victoire / nul / défaite | **Calculés par Vega** à partir des xG d'équipe (loi de Poisson). |
| Écarts « réel − attendu » (finition, gardien, qualité de frappe, points) | **Calculés par Vega**. |
| Totaux, moyennes par match, valeurs par 90 minutes, taux | **Calculés par Vega** à partir des observations par match. |
| Centiles, rangs, indice Vega club et joueur, similarités, tags de style | **Calculés par Vega**, toujours relativement à un groupe de comparaison. |
| Classements dérivés des résultats, zones européennes | **Calculés par Vega** quand aucun classement officiel n'est utilisé. |
| Classements FIFA, coefficients UEFA | **Collectés** par le worker (`backend/vega/sources/fifa.py`, `uefa.py`), jamais recalculés. |
| Classement Ballon d'Or Vega, niveaux des championnats, forces des clubs, note de chaque match | **Calculés par Vega** chaque jour (`backend/vega/power.py`), selon [METHODE_CLASSEMENT_BALLON_D_OR.md](../METHODE_CLASSEMENT_BALLON_D_OR.md). Toutes les formules et leurs raisons : [les notes Vega](08-notes-vega/01-formules-et-raisons.md) ; les essais et validations : [l'audit](05-joueurs/08-audit-classement-puissance.md). |

## Sections

### 1. Sources et conventions
- [Provenance des données](01-sources-et-conventions/01-provenance-des-donnees.md) — champs PitchAPI lus, correspondance des noms, voie Pro expérimentale.
- [Valeurs absentes et fiabilité](01-sources-et-conventions/02-valeurs-absentes-et-fiabilite.md) — absent ≠ zéro, zéros suspects, couverture.
- [Postes et groupes de comparaison](01-sources-et-conventions/03-postes-et-groupes.md) — du `positionId` au groupe G / D / M / O / F.

### 2. Métriques « attendues »
- [xG, xG hors penalty, xGOT](02-metriques-attendues/01-xg-npxg-xgot.md)
- [xA — passes décisives attendues](02-metriques-attendues/02-xa.md)
- [Buts évités (gardien)](02-metriques-attendues/03-buts-evites.md)
- [Note du match](02-metriques-attendues/04-note-du-match.md) — la note Vega de chaque match, sur 100, et la note de saison qui en découle.
- [Le xG de Vega](02-metriques-attendues/05-xg-vega.md)

### 3. Résultats et points attendus
- [Points attendus (xPts) et victoires attendues](03-resultats-et-points-attendus/01-points-attendus-xpts.md)
- [Classements calculés](03-resultats-et-points-attendus/02-classements.md)
- [Zones européennes, montée et relégation](03-resultats-et-points-attendus/03-zones-europeennes-et-relegation.md)

### 4. Clubs
- [Indicateurs d'équipe](04-clubs/01-indicateurs-club.md) — les 46 indicateurs du profil club et leur formule.
- [Centiles, rangs et indice Vega club](04-clubs/02-centiles-rangs-et-indice-vega.md)
- [Référentiels et niveau européen](04-clubs/03-referentiels-et-niveau-europeen.md)
- [Style, tags et clubs similaires](04-clubs/04-style-et-similarite.md)
- [États de match, tirs et effectif](04-clubs/05-etats-de-match-tirs-et-effectif.md)

### 5. Joueurs
- [Agrégation d'une saison](05-joueurs/01-agregation-saison.md) — totaux, par match, par 90, taux.
- [Centiles et cohortes](05-joueurs/02-centiles-et-cohortes.md) — par match et par saison.
- [Indices Vega et profils de rôle](05-joueurs/03-indices-vega-et-roles.md)
- [Similarité, radar, pizza et traits](05-joueurs/04-similarite-radar-et-traits.md)
- [Classements joueurs](05-joueurs/05-classements-joueurs.md) — meilleures notes, buteurs, efficaces, maladroits.
- [Compatibilité par niveau](05-joueurs/06-compatibilite-par-niveau.md) — onglet Projection : le joueur face aux titulaires de chaque club.
- [Carte « Lecture du scout »](05-joueurs/07-lecture-du-scout.md) — les quatre phrases de synthèse de la vue d'ensemble et d'où vient chaque chiffre.
- [Audit du classement de puissance et version 2](05-joueurs/08-audit-classement-puissance.md) — ce que donnait la première version, l'échelle commune des championnats, le rôle par formation, le poids du niveau du club.
- [Retour d'absence et forme](05-joueurs/09-retour-d-absence.md)
- [Révélations](05-joueurs/10-revelations.md) — les joueurs sous le seuil de minutes du classement qui jouent déjà comme ses titulaires, et ce qu'ils deviennent un an après.
- [Valeur des actions](05-joueurs/11-valeur-des-actions.md) — les VAEP, PV et xT du fournisseur, lues par 90 minutes du championnat du joueur et situées parmi son poste ; pourquoi le classement ne s'appuie pas dessus.
- [Et si un joueur en remplaçait un autre ?](05-joueurs/12-et-si-un-joueur-en-remplacait-un-autre.md) — ce que les compositions de départ changent aux résultats au-delà de l'Elo, et l'estimation en points d'un remplacement.

### 6. Accueil et fiches de match
- [Accueil](06-accueil-et-matchs/01-accueil.md) — semaine affichée, match de la semaine, joueur de la semaine, séries.
- [Fiche de match](06-accueil-et-matchs/02-fiche-match.md) — courbe des xG, carte des tirs, contexte avant match, discipline.
- [Pronostics et projections](06-accueil-et-matchs/03-pronostics-et-projections.md) — probabilités d’un match à venir, championnat, coupe européenne ou nationale et Ligue des nations rejoués jusqu’à leur terme, vérifications ; clubs sans Elo.
- [Recommandation de l'accueil](06-accueil-et-matchs/04-recommandation-accueil.md) — proposition, rien n'est construit : la rangée « Pour vous », quatre ordres choisis par un bandit, la loi Bêta et le nombre de visites qu'il faut pour trancher.
- [Journées, équipe de la journée et joueur de la saison](06-accueil-et-matchs/05-journees.md) — quand une journée se ferme (reports compris), ce qui l'attend, l'équipe type choisie par affectation exacte, la course au joueur de la saison.

### 7. Limites
- [Non calculé ou fictif](07-limites/01-non-calcule-fictif-demo.md)
- [Points d'attention relevés dans le code](07-limites/02-points-d-attention.md)

### 8. Notes Vega des championnats, des clubs et des joueurs
- [Toutes les formules et leurs raisons](08-notes-vega/01-formules-et-raisons.md) — l'enjeu d'un match, l'Elo des clubs, le niveau de chaque championnat (matchs entre championnats, joueurs qui en changent, a priori de division et de confédération), la note d'un joueur sur l'année et sa note de chaque match ; pour chaque réglage, s'il est mesuré sur la base ou choisi.

### 9. Audit des calculs du 16 novembre 2026
- [Modes de défaillance et contrats](09-audit-2026-11/FAILURE_MODES.md) — écrits avant les tests, puis avant le code (en anglais).
- [Traçabilité de l'audit](09-audit-2026-11/TRACEABILITY.md) — chaque point de l'audit, son statut (corrigé et vérifié, transmis à son propriétaire, choix de modèle, validation réelle indisponible), ses preuves ; la migration et le recalcul de toutes les éditions.

## Quatre règles qui reviennent partout

1. **Une valeur absente n'est jamais un zéro.** Une moyenne ou un total ne prend que les matchs où la valeur est observée, et le « par 90 » divise par les minutes de ces matchs seulement.
2. **Un centile n'existe que si la comparaison est sérieuse** : assez de minutes pour le joueur, assez de pairs (30 pour les joueurs, 5 pour les clubs), et pour la saison une mesure renseignée sur tous les matchs joués.
3. **Un taux est un rapport de sommes, pas une moyenne de taux** : précision des passes = 100 × Σ passes réussies / Σ passes tentées sur les mêmes matchs. De même, un **écart** (buts − xG, points − xPts, xG pour − xG contre) se lit sur les matchs où ses deux termes sont connus (audit du 16 novembre 2026).
4. **Seuls les matchs terminés comptent** dans une saison, et un match se lit avec ce qu'il a vraiment mesuré : un nombre absent, `NaN` ou infini n'est jamais une observation.

## Fichiers de code principaux

| Domaine | Fichier |
| --- | --- |
| Profil club, xPts, indicateurs, centiles, indice Vega, niveau européen | [club-scout.js](../../dashboard/frontend/src/services/club-scout.js) |
| Résumé club (fiche match, effectif) | [club-analysis.js](../../dashboard/frontend/src/services/club-analysis.js) |
| Agrégation saison joueur | [season-player.js](../../dashboard/frontend/src/services/season-player.js) |
| Cohortes, indices, similarité joueur | [scouting.js](../../dashboard/frontend/src/services/scouting.js) |
| Compatibilité par niveau (onglet Projection) | [player-projection.js](../../dashboard/frontend/src/services/player-projection.js) |
| Profil d'une performance, postes, centile | [shared/player-profile.js](../../dashboard/shared/player-profile.js) |
| Accueil (semaine, sélections, meneurs) | [home-insights.js](../../dashboard/frontend/src/services/home-insights.js), [home.mjs](../../backend/api/src/routes/home.mjs) |
| Classements dérivés et zones | [competition-standings.js](../../dashboard/frontend/src/services/competition-standings.js), [standings-zones.js](../../dashboard/frontend/src/services/standings-zones.js), [nations-standings.js](../../dashboard/frontend/src/services/nations-standings.js) |
| Lecture des données fournisseur | build_dashboard_data.py (ancien backend, supprimé le 10 novembre 2026) |
| Agrégats saison côté base | 025_player_season_rollups.sql (ancien backend, supprimé le 10 novembre 2026), [performance.mjs](../../backend/api/src/routes/performance.mjs), [calculator.py](../../backend/vega/calculator.py), migrations 128–131 |
| Indicateurs club du serveur (version 2) | [club_indicators.py](../../backend/vega/club_indicators.py) |
| Évaluation datée du xG de Vega | [evaluate_xg.py](../../backend/tools/evaluate_xg.py) |

## Audit du 16 novembre 2026

[Vérification de production du 18 novembre](../audits/2026-11-17/SITUATION.md) · [Couverture des notes par compétition, saison et entité](../audits/2026-11-17/controles/verification-integree/scores-actuels-par-edition.csv.gz) · [Formules et évolutions recensées](../audits/2026-11-17/registres/requirements-README.md)

[Revue et corrections](09-audit-2026-11/REVIEW.md) · [Suivi de chaque constat](09-audit-2026-11/TRACEABILITY.md) · [Audit original inchangé](09-audit-2026-11/SOURCE_AUDIT.md).
