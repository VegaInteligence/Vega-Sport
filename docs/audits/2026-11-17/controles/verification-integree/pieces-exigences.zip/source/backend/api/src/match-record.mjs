/**
 * A whole match in the legacy match record of assembleMatches() (relational-core.js
 * on main): sides, team statistics, shots, coverage and the appearance ids. Shared by
 * the reads that embed a match (performance).
 */
import { teamStats } from "./team-stats.mjs";

const SHOT_FIELDS = `'id',x.id,'playerId',api.public_id('player',x.player_id),'playerName',x.player_name,
 'teamId',api.public_id('team',x.team_id),'type',x.type,'shotType',x.shot_type,'situation',x.situation,
 'keeperId',api.public_id('player',x.keeper_id),'keeperName',x.keeper_name,'period',x.period,'x',x.x,'y',x.y,'xg',x.xg,
 'xgot',x.xgot,'minute',x.minute,'goalCrossedY',x.goal_crossed_y,'goalCrossedZ',x.goal_crossed_z,'blockedX',x.blocked_x,
 'blockedY',x.blocked_y,'minuteAdded',x.minute_added,'isGoal',x.is_goal,'isOwnGoal',x.is_own_goal,'isOnTarget',x.is_on_target,
 'isBlocked',x.is_blocked,'insideBox',x.inside_box`;

/** SQL columns of a match record for the match row `f` of api.fixtures. */
// `players` and `teamStats` false: a card that shows neither (the home's result rows)
// skips the player aggregate and the team statistics.
// `season`: the SQL of the season's id when the read knows it (a bound parameter). The
// details are season-partitioned: a constant prunes the other seasons when the query is
// planned, the match row's own season only when it runs, after planning them all.
// `scoring`: each side's own goals for and penalty attempts (132, api.match_scoring), for the reads
// a club profile ranks clubs with (actors.mjs); a record read without it carries neither field.
export const matchRecordColumns = ({ shots = true, players = true, teamStats = true, scoring = false, season = "f.season_id" } = {}) => `row_to_json(f) AS fixture,
 ${scoring ? `${scoringColumn(season, "f.match_id")},` : ""}
 (SELECT json_agg(s ORDER BY s.side DESC) FROM api.match_sides s WHERE s.season_id=${season} AND s.match_id=f.match_id) sides,
 ${teamStats ? `(SELECT to_json(t) FROM api.match_team_sides t WHERE t.season_id=${season} AND t.match_id=f.match_id AND t.team_id=f.home_internal_id AND t.period='all')` : "NULL::json"} home_stats,
 ${teamStats ? `(SELECT to_json(t) FROM api.match_team_sides t WHERE t.season_id=${season} AND t.match_id=f.match_id AND t.team_id=f.away_internal_id AND t.period='all')` : "NULL::json"} away_stats,
 ${shots ? `(SELECT coalesce(json_agg(json_build_object(${SHOT_FIELDS}) ORDER BY x.shot_no),'[]'::json) FROM api.match_shots x WHERE x.season_id=${season} AND x.match_id=f.match_id)` : "'[]'::json"} shots,
 (SELECT row_to_json(d) FROM api.match_detail_state d WHERE d.season_id=${season} AND d.match_id=f.match_id) state,
 ${players ? `(SELECT json_build_object('listed',count(*),'played',count(*) FILTER(WHERE a.minutes>0),
   'graded',count(*) FILTER(WHERE a.minutes>0 AND a.grade IS NOT NULL),'xg',count(*) FILTER(WHERE a.minutes>0 AND a.xg IS NOT NULL),
   'xa',count(*) FILTER(WHERE a.minutes>0 AND a.xa IS NOT NULL),
   'ids',coalesce(json_agg(f.id||':'||api.public_id('player',a.player_id) ORDER BY api.public_id('player',a.player_id)),'[]'::json))
   FROM api.player_appearances a WHERE a.season_id=${season} AND a.match_id=f.match_id)` : "NULL::json"} players,
 f.referee AS referee,
 f.stadium AS stadium`;

/** The SQL column of a match's scoring (132, api.match_scoring): its row, or NULL (no row: the match
 * is not finished). One correlated read of the view per match. */
export const scoringColumn = (season, match) =>
  `(SELECT row_to_json(v) FROM api.match_scoring v WHERE v.season_id=${season} AND v.match_id=${match}) scoring`;

/** A side's scoring (VI-23 stage 8, FAILURE_MODES §17.2): `ownGoalsFor`, the opponent's own goals in
 * its score, and `penaltyAttempts`; null when not established, 0 when established none. */
export function sideScoring(scoring, name) {
  return { ownGoalsFor: scoring?.[`own_goals_for_${name}`] ?? null, penaltyAttempts: scoring?.[`penalties_${name}`] ?? null };
}

const strip = (row) => (row ? Object.fromEntries(Object.entries(row).filter(([k]) => k.startsWith("for_")).map(([k, v]) => [k.slice(4), v])) : null);

/** The legacy match object, or null when the match's details are not collected
 * (`allowPending`: the record of a scored match whose details are still coming). */
export function assembleMatch(r, { statKeys, allowPending = false } = {}) {
  const f = r?.fixture;
  const state = r?.state || {};
  if (!f || (!state.detail_collected && !allowPending)) return null;
  const sides = Object.fromEntries((r.sides || []).map((s) => [s.side, s]));
  const side = (name) => {
    const s = sides[name] || {};
    return {
      id: f[name + "_team_id"], name: f[name + "_name"], imageUrl: f[name + "_image_url"], formation: s.formation ?? null,
      coach: s.coach ?? null, score: f["score_" + name], xg: s.xg ?? null, shots: s.shots ?? null,
      shotsOnTarget: s.shots_on_target ?? null, possession: s.possession ?? null, lineupConfirmed: s.lineup_confirmed ?? null,
      ...("scoring" in r ? sideScoring(r.scoring, name) : {}),
    };
  };
  const n = r.players || {};
  return {
    id: f.id, season: f.season, leagueId: f.league_id, league: f.league_name, country: f.country, date: f.day,
    timeUtc: f.time_utc, status: f.status, roundName: f.round_name, hasPlayoff: f.has_playoff,
    referee: r.referee ?? null, stadium: r.stadium ?? null, home: side("home"), away: side("away"),
    shots: r.shots || [],
    stats: teamStats(strip(r.home_stats), strip(r.away_stats), statKeys),
    coverage: {
      players: Boolean(state.player_stats_ok) && n.listed > 0, playerStats: n.played > 0, grades: n.graded > 0,
      xg: n.xg > 0, xa: n.xa > 0, shots: Boolean(state.shots_ok), teamStatsReliable: Boolean(state.team_stats_ok),
      listedPlayers: n.listed ?? 0, playedPlayers: n.played ?? 0, gradedPlayers: n.graded ?? 0, xgPlayers: n.xg ?? 0, xaPlayers: n.xa ?? 0,
    },
    warnings: [],
    warningCodes: [],
    detailCollected: Boolean(state.detail_collected),
    players: n.ids || [],
  };
}
