"""Check every evidence and code pointer for 91 requirements and 26 additional calculations."""
import csv
import hashlib
import json
from pathlib import Path

root=Path(__file__).resolve().parent
manifest=json.loads((root/'empreintes.json').read_bytes())
def rows(name):
    with (root/name).open(newline='',encoding='utf-8') as stream:
        return list(csv.DictReader(stream))
def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()

for pointer,expected in manifest['sha256'].items():
    path=(root/pointer).resolve()
    if not path.is_relative_to(root) or sha(path)!=expected:
        raise ValueError(pointer)
requirements=rows('requirements.csv')
calculations=rows('new-calculations.csv')
assert len(requirements)==len({r['id'] for r in requirements})==91
assert len(calculations)==26
sources={p for r in requirements for p in r['source_paths'].split(';') if p}
evidence={p for r in requirements+calculations for p in r['evidence_paths'].split(';') if p}
for group,paths in [('preuves',evidence),('source',sources)]:
    for p in paths:
        if group+'/'+p not in manifest['sha256']:
            raise ValueError(group+'/'+p)
print(json.dumps({'commit_source':manifest['commit_source'],'exigences':len(requirements),'calculs_additionnels':len(calculations),'pieces':len(evidence),'sources':len(sources),'empreintes_verifiees':len(manifest['sha256'])},ensure_ascii=False))
