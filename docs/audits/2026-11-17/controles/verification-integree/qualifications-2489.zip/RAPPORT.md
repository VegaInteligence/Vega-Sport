# Qualifications UEFA et participations des joueurs

**76 589 apparitions prouvées** sur les qualifications des trois coupes de 2021/22 à 2026/27. Le minimum comprend 54 758 titularisations et 21 831 entrées en jeu, pour 13 101 identifiants UEFA distincts dont 10 537 au moins une fois titulaires. **Collecte terminée** au 2026-11-18 à 15:02 UTC, avec 2 489/2 489 réponses enregistrées et 0 matchs encore sans reçu. [Décompte](results/summary.json) · [Apparitions et identifiants](results/proven-player-matches.csv)

Les 2489 journaux reçus comprennent 2446 journaux cohérents et 43 partiels ou contradictoires. Les autres journaux sont inconnus. Parmi les inscriptions au banc, 21831 entrées et 30847 non-usages sont prouvés selon le journal. 525 inscriptions restent indéterminées. Le rapprochement RDS ne retrouve aucun match Vega pour ces qualifications. La disponibilité de statistiques suffisantes pour la note reste à établir.

| Saison | Ligue | Matchs | Feuilles 200 | Titulaires | Banc | Entrés | Non utilisés | Banc inconnu |
|---|---|---:|---:|---:|---:|---:|---:|---:|
| 2021/22 | Champions | 93 | 93 | 2 046 | 1 982 | 745 | 1 214 | 23 |
| 2021/22 | Europa | 36 | 36 | 792 | 726 | 307 | 409 | 10 |
| 2021/22 | Conférence | 282 | 282 | 6 204 | 5 662 | 2 284 | 3 378 | 0 |
| 2022/23 | Champions | 89 | 89 | 1 958 | 1 943 | 754 | 1 177 | 12 |
| 2022/23 | Europa | 34 | 34 | 748 | 723 | 310 | 399 | 14 |
| 2022/23 | Conférence | 274 | 274 | 6 028 | 5 759 | 2 331 | 3 303 | 125 |
| 2023/24 | Champions | 89 | 89 | 1 958 | 1 972 | 796 | 1 155 | 21 |
| 2023/24 | Europa | 34 | 34 | 748 | 745 | 300 | 445 | 0 |
| 2023/24 | Conférence | 276 | 276 | 6 072 | 5 777 | 2 439 | 3 297 | 41 |
| 2024/25 | Champions | 90 | 90 | 1 980 | 2 002 | 804 | 1 104 | 94 |
| 2024/25 | Europa | 80 | 80 | 1 760 | 1 789 | 708 | 1 050 | 31 |
| 2024/25 | Conférence | 254 | 254 | 5 588 | 5 369 | 2 259 | 3 046 | 64 |
| 2025/26 | Champions | 92 | 92 | 2 024 | 2 058 | 823 | 1 235 | 0 |
| 2025/26 | Europa | 82 | 82 | 1 804 | 1 842 | 771 | 1 071 | 0 |
| 2025/26 | Conférence | 256 | 256 | 5 632 | 5 516 | 2 275 | 3 202 | 39 |
| 2026/27 | Champions | 90 | 90 | 1 980 | 1 994 | 846 | 1 122 | 26 |
| 2026/27 | Europa | 80 | 80 | 1 760 | 1 804 | 724 | 1 068 | 12 |
| 2026/27 | Conférence | 258 | 258 | 5 676 | 5 540 | 2 355 | 3 172 | 13 |

[18 éditions](results/editions.csv) · [Capacité d’établir une note](results/grade-capability.csv) · [Mode de vérification](LIRE.md)
