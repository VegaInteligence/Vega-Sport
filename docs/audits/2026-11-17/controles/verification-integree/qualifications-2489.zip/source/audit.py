"""Count confirmed UEFA player-match appearances from a fixed snapshot of the shared lineup cache."""
import argparse
from collections import Counter, defaultdict
import csv
from datetime import datetime, timezone
import gzip
import hashlib
import json
from pathlib import Path
import sys

HERE = Path(__file__).resolve().parent
TRACKS = HERE.parents[2]
LINEUPS = HERE.parent / "public"
STATUS_WITH_FINAL_LINEUP = {"TACTICAL_AVAILABLE"}
PLAYER_LINEUP_TYPES = {"PLAYER", "CAPTAIN", "GOALKEEPER", "GOALKEEPER_CAPTAIN"}
KEYS_TO_SUM = (
    "fixtures", "uncollected", "http_200", "http_errors", "identity_errors", "incomplete_sheets",
    "role_collisions", "duplicate_rows", "unknown_role_rows", "confirmed_starters", "unconfirmed_starter_slots",
    "listed_bench", "confirmed_entrants", "unused_in_complete_events", "unresolved_bench",
    "scheduled_event_feeds", "event_receipts_seen", "event_uncollected", "incomplete_event_feeds", "complete_event_feeds",
    "entrants_stoppage_time", "entrants_extra_time", "entrants_replacing_substitute", "entrants_with_verified_actor_alias",
    "entrants_clock_from_phase",
)


def read_csv(path):
    with path.open() as f:
        return list(csv.DictReader(f))


def sha(data):
    return hashlib.sha256(data).hexdigest()


def identify(value):
    return str(value) if str(value).isdigit() else None


def decode(receipt, body):
    raw = gzip.decompress(body.read_bytes())
    assert sha(raw) == receipt["sha256"], body
    return json.loads(raw)


def parse_lineup(row, path):
    result = Counter(fixtures=1)
    roles = defaultdict(set)
    metadata = {}
    flags = set()
    if path is None:
        return result + Counter(uncollected=1), roles, metadata, {"lineup_uncollected"}, "UNCOLLECTED"
    receipt = json.loads(path.read_bytes())
    key = row["id"]
    status = receipt["status"]
    assert str(receipt["id"]) == key
    if status != 200:
        return result + Counter(http_errors=1), roles, metadata, {f"http_{status}"}, f"HTTP_{status}"
    result["http_200"] += 1
    sheet = decode(receipt, path.with_name(f"{key}.json.gz"))
    if not isinstance(sheet, dict) or identify(sheet.get("matchId")) != key:
        return result + Counter(identity_errors=1), roles, metadata, {"lineup_wrong_match"}, "WRONG_MATCH"
    source_status = sheet.get("lineupStatus", "MISSING_STATUS")
    teams = {}
    for side, label in (("homeTeam", "home_uid"), ("awayTeam", "away_uid")):
        payload = sheet.get(side)
        if not isinstance(payload, dict):
            flags.update({"missing_team_side", "partial_lineup"})
            continue
        expected = row[label]
        reported = identify((payload.get("team") or {}).get("id"))
        if reported != expected:
            return result + Counter(identity_errors=1), roles, metadata, {"lineup_wrong_team"}, str(source_status)
        teams[expected] = payload
    known_status = isinstance(source_status, str) and source_status in STATUS_WITH_FINAL_LINEUP
    if not known_status:
        flags.add("lineup_status_unconfirmed")
    for team, payload in teams.items():
        for role in ("field", "bench"):
            entries = payload.get(role)
            if not isinstance(entries, list):
                flags.add(f"missing_{role}")
                continue
            if role == "field" and len(entries) != 11:
                flags.add("non_eleven_squad")
            for item in entries:
                player = item.get("player") if isinstance(item, dict) else None
                identity = identify(player.get("id")) if isinstance(player, dict) else None
                if identity is None or item.get("type") not in PLAYER_LINEUP_TYPES:
                    result["unknown_role_rows"] += 1
                    continue
                membership = team, role
                if membership in roles[identity]:
                    result["duplicate_rows"] += 1
                roles[identity].add(membership)
                metadata[identity] = {
                    "name": player.get("internationalName"),
                    "birth": player.get("birthDate"),
                    "shirt": identify(item.get("jerseyNumber")),
                }
    if result["duplicate_rows"]:
        flags.add("repeated_role_rows")
    collisions = {player for player, placements in roles.items() if len(placements) != 1}
    if collisions:
        result["role_collisions"] = len(collisions)
        flags.add("role_collisions")
    for player in collisions:
        del roles[player]
    if not known_status:
        # The rows are retained in the cache and flagged, but a status we have not qualified
        # cannot transform a provisional starting XI into confirmed appearances.
        roles = {player: placed for player, placed in roles.items() if next(iter(placed))[1] == "bench"}
    return result, roles, metadata, flags, str(source_status)


PERIODS = {
    "FIRST_HALF": (0, 1, 45),
    "SECOND_HALF": (1, 45, 90),
    "EXTRA_TIME_FIRST_HALF": (2, 90, 105),
    "EXTRA_TIME_SECOND_HALF": (3, 105, 120),
}
PHASE_MARKERS = {"START_PHASE", "END_PHASE", "CHANGE_PHASE", "FULL_TIME", "INJURY_TIME"}
REMOVALS = {"RED_CARD", "SECOND_YELLOW_CARD", "YELLOW_CARD_SECOND", "RED_YELLOW_CARD"}


def event_payload(match_id, event_pages):
    folder = HERE / "events" / match_id
    rows = []
    receipts = []
    offset = 0
    while True:
        receipt_file = folder / f"{offset}.receipt.json"
        if receipt_file not in event_pages:
            return rows, receipts, "event_page_missing" if receipts else "event_uncollected"
        info = json.loads(receipt_file.read_bytes())
        receipts.append({key: info.get(key) for key in ("url", "sha256", "status", "rows", "offset", "limit", "wire_length")})
        if info["status"] != 200:
            return rows, receipts, f"event_http_{info['status']}"
        obj = decode(info, receipt_file.with_name(f"{offset}.json.gz"))
        if not isinstance(obj, list) or len(obj) != info["rows"] or not all(isinstance(item, dict) for item in obj):
            return rows, receipts, "event_not_an_array"
        if info["offset"] != offset or not 0 <= len(obj) <= info["limit"]:
            return rows, receipts, "event_bad_pagination"
        rows.extend(obj)
        if len(obj) < info["limit"]:
            return rows, receipts, None
        offset += info["limit"]


def actor(event, key):
    data = event.get(key)
    if not isinstance(data, dict):
        return None, None
    team, person = data.get("team"), data.get("person")
    return (identify(team.get("id")) if isinstance(team, dict) else None,
            identify(person.get("id")) if isinstance(person, dict) else None)


def identity_signature(side, name, birth, shirt):
    if not (side and isinstance(name, str) and name.strip() and isinstance(birth, str) and birth and shirt):
        return None
    return side, " ".join(name.casefold().split()), birth, shirt


def event_player(event, label, roles, identities):
    side, source_id = actor(event, label)
    if source_id is None or source_id in roles:
        return side, source_id, source_id
    person = (event.get(label) or {}).get("person") or {}
    key = identity_signature(
        side, person.get("internationalName"), person.get("birthDate"), identify(person.get("clubJerseyNumber"))
    )
    candidates = identities.get(key, set())
    local_id = next(iter(candidates)) if len(candidates) == 1 else source_id
    return side, local_id, source_id


def match_clock(event):
    period = PERIODS.get(event.get("phase"))
    clock = event.get("time")
    if period is None or not isinstance(clock, dict):
        return None
    phase_order, lower, upper = period
    minute, second, injury = clock.get("minute"), clock.get("second", 0), clock.get("injuryMinute", 0)
    if not all(type(value) is int for value in (minute, second, injury)):
        return None
    if not lower <= minute <= upper or not 0 <= second < 60 or injury < 0 or (injury and minute != upper):
        return None
    return phase_order, minute, injury, second


def utc_timestamp(value):
    if not isinstance(value, str) or not value:
        return None
    try:
        stamp = datetime.fromisoformat(value)
    except ValueError:
        return None
    return stamp if stamp.utcoffset() is not None else None


def recover_clock_from_phase(event, markers, actor_transitions, roles, identities):
    period = PERIODS.get(event.get("phase"))
    if period is None or event.get("time") is not None:
        return None
    start, end = markers.get(event.get("phase"), (set(), set()))
    moment = utc_timestamp(event.get("timestamp"))
    if len(start) != 1 or len(end) != 1 or moment is None or not min(start) <= moment <= min(end):
        return None
    _, leaving, _ = event_player(event, "primaryActor", roles, identities)
    _, entering, _ = event_player(event, "secondaryActor", roles, identities)
    if not leaving or not entering or actor_transitions[leaving] != 1 or actor_transitions[entering] != 1:
        return None
    # With no other transition involving either player, a stable place in this phase is enough
    # for the lineup replay. Do not report this internal ordering key as an observed match minute.
    return period[0], period[2], 0, 59


def qualified_event_rows(events, match_id, evidence):
    by_id = {}
    for event in events:
        key = event.get("id")
        kind = event.get("type")
        if not isinstance(key, str) or not key or not isinstance(kind, str) or identify(event.get("matchId")) != match_id:
            evidence["flags"].append("event_wrong_identity")
            continue
        if key in by_id:
            evidence["duplicate_event_ids"] += 1
            if event != by_id[key]:
                evidence["flags"].append(f"event_conflicting_id:{key}")
                by_id[key] = None
            else:
                evidence["flags"].append("event_repeated_page_or_row")
            continue
        by_id[key] = event
    return [event for event in by_id.values() if event is not None]


def projection_key(event):
    kind, phase = event["type"], event.get("phase")
    clock = event.get("time")
    if kind not in {"GOAL", "SUBSTITUTION"} or phase not in PERIODS or not isinstance(clock, dict):
        return None
    first = actor(event, "primaryActor")
    second = actor(event, "secondaryActor") if kind == "SUBSTITUTION" else ()
    if not all(first) or not all(second) or type(clock.get("minute")) is not int:
        return None
    return kind, phase, clock["minute"], clock.get("injuryMinute", 0), event.get("subType"), first, second


def discard_projected_duplicates(events, evidence):
    detailed = Counter(
        key for event in events if event.get("timestamp") and (key := projection_key(event)) is not None
        and "second" in event["time"]
    )
    retained = []
    for event in events:
        key = projection_key(event)
        if key is not None and detailed[key] == 1 and not event.get("timestamp") and "second" not in event["time"]:
            evidence["shape_notes"][f"deduplicated_minute_projection_{event['type'].lower()}"] += 1
        else:
            retained.append(event)
    return retained


def extra_periods_observed(fixture, events):
    extra = {"EXTRA_TIME_FIRST_HALF", "EXTRA_TIME_SECOND_HALF"}
    if fixture["pen"] or (fixture["regular"] and fixture["total"] and fixture["regular"] != fixture["total"]):
        return extra
    phases = {e.get("phase") for e in events if e["type"] in {"START_PHASE", "END_PHASE"}}
    return extra & phases


def check_event_boundaries(fixture, events, evidence):
    starts = {e.get("phase") for e in events if e["type"] == "START_PHASE"}
    ends = {e.get("phase") for e in events if e["type"] == "END_PHASE"}
    full_times = [e for e in events if e["type"] == "FULL_TIME"]
    dated_by_phase = defaultdict(list)
    for end in full_times:
        if end.get("timestamp"):
            dated_by_phase[end.get("phase")].append(end["id"])
    duplicates = [
        e for e in full_times if not e.get("timestamp") and len(dated_by_phase[e.get("phase")]) == 1
        and dated_by_phase[e.get("phase")][0].startswith(e["id"])
    ]
    evidence["duplicate_full_time_markers"] = len(duplicates)
    canonical_ends = [e.get("phase") for e in full_times if e not in duplicates]
    required = {"FIRST_HALF", "SECOND_HALF"}
    extra_phases = {"EXTRA_TIME_FIRST_HALF", "EXTRA_TIME_SECOND_HALF"}
    after_regular = fixture["regular"] and fixture["total"] and fixture["regular"] != fixture["total"]
    shootout = bool(fixture["pen"])
    has_extra = bool(after_regular or extra_phases & starts or shootout)
    if has_extra:
        required |= extra_phases
    ordinary_end = "EXTRA_TIME_SECOND_HALF" if has_extra else "SECOND_HALF"
    allowed_ends = {ordinary_end}
    terminal_end = ordinary_end
    if shootout:
        required.add("PENALTY")
        allowed_ends.add("PENALTY")
        terminal_end = "PENALTY"
    if (len(canonical_ends) != len(set(canonical_ends)) or terminal_end not in canonical_ends
        or not set(canonical_ends) <= allowed_ends or not required <= starts or not starts <= ends):
        evidence["flags"].append("event_boundaries_unconfirmed")
    if shootout:
        made = Counter(
            actor(e, "primaryActor")[0] for e in events if e.get("phase") == "PENALTY"
            and e["type"] == "PENALTY" and e.get("subType") == "SCORED"
        )
        target = [fixture[key].split(":")[-1] for key in ("home", "away")]
        if [made[uid] for uid in target] != json.loads(fixture["pen"]) or set(made) - set(target):
            evidence["flags"].append("event_shootout_score_unconfirmed")
    if not any(e["type"] not in PHASE_MARKERS and e.get("phase") in PERIODS for e in events):
        evidence["flags"].append("event_no_football_actions")
    teams = tuple(fixture[key].split(":")[-1] for key in ("home", "away"))
    goals = Counter()
    for event in events:
        if event["type"] != "GOAL" or event.get("phase") not in PERIODS:
            continue
        side, _ = actor(event, "primaryActor")
        if event.get("subType") == "OWN" and side in teams:
            side = teams[1 - teams.index(side)]
        goals[side] += 1
    recorded = [goals[team] for team in teams]
    expected = json.loads(fixture["total"]) if fixture["total"] else None
    evidence["event_score"] = {"official": expected, "recorded": recorded, "unknown_goal_side": sum(goals.values()) - sum(recorded)}
    if recorded != expected or evidence["event_score"]["unknown_goal_side"]:
        evidence["flags"].append("event_score_unconfirmed")


def corroborate(fixture, roles, starters, metadata, event_pages):
    match_id = fixture["id"]
    events, receipts, error = event_payload(match_id, event_pages)
    evidence = {"pages": receipts, "flags": [], "entrants": [], "event_types": Counter(),
                "duplicate_event_ids": 0, "duplicate_substitutions": 0, "duplicate_full_time_markers": 0,
                "shape_notes": Counter()}
    if error:
        evidence["flags"].append(error)
    if not receipts:
        return evidence
    events = qualified_event_rows(events, match_id, evidence)
    events = discard_projected_duplicates(events, evidence)
    evidence["event_types"].update(e["type"] for e in events)
    check_event_boundaries(fixture, events, evidence)
    if len(starters) != 22:
        evidence["flags"].append("starters_unconfirmed_for_event_replay")

    current = set(starters)
    bench = {p for p, place in roles.items() if next(iter(place))[1] == "bench"}
    identities = defaultdict(set)
    for player, place in roles.items():
        side, _ = next(iter(place))
        data = metadata[player]
        key = identity_signature(side, data["name"], data["birth"], data["shirt"])
        if key is not None:
            identities[key].add(player)
    transitions = []
    extra_support = extra_periods_observed(fixture, events)
    kickoff_times = [
        e["timestamp"] for e in events
        if e["type"] == "START_PHASE" and e.get("phase") == "FIRST_HALF" and e.get("timestamp")
    ]
    kickoff = min(kickoff_times, default="")
    phase_markers = defaultdict(lambda: (set(), set()))
    for event in events:
        if event["type"] in {"START_PHASE", "END_PHASE"}:
            stamp = utc_timestamp(event.get("timestamp"))
            if stamp is not None:
                phase_markers[event.get("phase")][event["type"] == "END_PHASE"].add(stamp)
    movement = [event for event in events if event["type"] in REMOVALS | {"SUBSTITUTION"}]
    actor_transitions = Counter()
    for event in movement:
        _, left, _ = event_player(event, "primaryActor", roles, identities)
        actor_transitions[left] += 1
        if event["type"] == "SUBSTITUTION":
            _, entered, _ = event_player(event, "secondaryActor", roles, identities)
            actor_transitions[entered] += 1
    for event in movement:
        clock = match_clock(event)
        recovered_clock = False
        if clock is None and event["type"] == "SUBSTITUTION":
            clock = recover_clock_from_phase(event, phase_markers, actor_transitions, roles, identities)
            recovered_clock = clock is not None
        timestamp = event.get("timestamp") or ""
        absolute_before_kickoff = bool(kickoff and timestamp and timestamp < kickoff)
        if (clock is None or (absolute_before_kickoff and clock[0] == 0)
            or (clock[0] > 1 and event.get("phase") not in extra_support)):
            if event["type"] == "SUBSTITUTION":
                evidence["flags"].append(f"substitution_time_unverified:{event['id']}")
            continue
        if absolute_before_kickoff:
            # The phase and match clock order in-play events. Keep the anomalous absolute time
            # in the receipt instead of treating a timestamp offset as a pre-match change.
            evidence["shape_notes"]["absolute_timestamp_inconsistent"] += 1
        transitions.append((clock, timestamp, event["id"], recovered_clock, event))

    entrants = []
    handled = set()
    for clock, _, event_id, recovered_clock, event in sorted(transitions):
        side_out, left, raw_left = event_player(event, "primaryActor", roles, identities)
        if event["type"] in REMOVALS:
            if left in current and any(team == side_out for team, _ in roles[left]):
                current.remove(left)
            continue
        side_in, entered, raw_entered = event_player(event, "secondaryActor", roles, identities)
        # UEFA's primary actor leaves and the secondary actor replaces them. Check the actual
        # lineup and the replayed state so a second event with a false entrant cannot add a row.
        transition = (clock, side_in, left, entered)
        if transition in handled:
            evidence["duplicate_substitutions"] += 1
            continue
        if (side_in is None or side_in != side_out or left not in current or entered not in bench
            or not any(team == side_out for team, _ in roles[left]) or (side_in, "bench") not in roles[entered]):
            evidence["flags"].append(f"substitution_disagrees:{event_id}")
            continue
        handled.add(transition)
        current.remove(left)
        current.add(entered)
        bench.remove(entered)
        entrants.append({"team": side_in, "entered": entered, "entered_name": metadata[entered]["name"],
                         "left": left, "left_name": metadata[left]["name"], "minute": event.get("time"),
                         "clock_method": "phase_timestamp" if recovered_clock else "match_clock",
                         "entered_event_source_id": raw_entered, "left_event_source_id": raw_left,
                         "identity_alias": entered != raw_entered or left != raw_left,
                         "phase": event["phase"], "event_id": event_id,
                         "stoppage_time": clock[2] > 0, "extra_time": clock[0] > 1,
                         "replaces_substitute": (side_out, "bench") in roles[left]})
    evidence["entrants"] = entrants
    if not evidence["flags"]:
        evidence["unused"] = sorted(bench)
    return evidence


def calc(row, path, event_fixture, event_pages):
    totals, roles, names, flags, status = parse_lineup(row, path)
    starters = {p for p, positions in roles.items() if next(iter(positions))[1] == "field"}
    bench = set(roles) - starters
    for team in (row["home_uid"], row["away_uid"]):
        side = {p for p in starters if (team, "field") in roles[p]}
        if len(side) > 11:
            # No reliable way to identify the published starting XI in an oversized squad.
            starters -= side
            flags.add("oversized_starting_lineup")
    totals.update(confirmed_starters=len(starters), unconfirmed_starter_slots=22-len(starters), listed_bench=len(bench))
    partial = {"missing_team_side", "missing_field", "missing_bench", "non_eleven_squad"} & flags
    if totals["http_200"] and (len(starters) != 22 or partial or totals["unknown_role_rows"]):
        totals["incomplete_sheets"] += 1
        flags.add("incomplete_sheet")
    event = corroborate(event_fixture, roles, starters, names, event_pages) if event_fixture is not None else None
    entrants = {change["entered"] for change in event["entrants"]} if event else set()
    unused = set(event.get("unused", [])) if event else set()
    totals.update(confirmed_entrants=len(entrants), unused_in_complete_events=len(unused),
                  unresolved_bench=len(bench - entrants - unused))
    if event is not None:
        attempted = bool(event["pages"])
        totals.update(
            scheduled_event_feeds=1, event_receipts_seen=int(attempted), event_uncollected=int(not attempted),
            incomplete_event_feeds=int(attempted and bool(event["flags"])),
            complete_event_feeds=int(attempted and not event["flags"]),
            entrants_stoppage_time=sum(change["stoppage_time"] for change in event["entrants"]),
            entrants_extra_time=sum(change["extra_time"] for change in event["entrants"]),
            entrants_replacing_substitute=sum(change["replaces_substitute"] for change in event["entrants"]),
            entrants_with_verified_actor_alias=sum(change["identity_alias"] for change in event["entrants"]),
            entrants_clock_from_phase=sum(change["clock_method"] == "phase_timestamp" for change in event["entrants"]),
        )
    assert starters.isdisjoint(entrants) and entrants.isdisjoint(unused)
    assert totals["confirmed_entrants"] + totals["unused_in_complete_events"] + totals["unresolved_bench"] == len(bench)
    return dict(row, **totals, status=status, flags=sorted(flags)), starters, bench, event


def output_csv(path, rows):
    rows = list(rows)
    if not rows:
        return
    fields = list(dict.fromkeys(key for row in rows for key in row))
    with path.open("w", newline="") as f:
        w = csv.DictWriter(f, fields, restval=0, lineterminator="\n")
        w.writeheader()
        w.writerows(rows)


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--out", type=Path, required=True)
    parser.add_argument("--lineup-manifest", type=Path, help="Reuse a fixed list of lineup cache receipts and hashes")
    parser.add_argument("--event-scope", choices=["witnesses", "all"], default="witnesses")
    parser.add_argument("--event-manifest", type=Path, help="Reuse a fixed list of event cache receipts and hashes")
    args = parser.parse_args()
    args.out.mkdir(parents=True, exist_ok=False)
    inventory = HERE / "rds-replay" / "global-search.csv"
    calendar = TRACKS / "2-ingestion" / "continental-calendar" / "official-fixtures.csv"
    scope = HERE / "event-scope.csv" if args.event_scope == "witnesses" else calendar
    rows = [r for r in read_csv(inventory) if r["phase"] == "QUALIFYING"]
    official = {r["id"]: r for r in read_csv(calendar) if r["status"] == "FINISHED" and r["phase"] == "QUALIFYING"}
    assert len(rows) == len({r["id"] for r in rows}) == len(official) == 2489
    for row in rows:
        match = official[row["id"]]
        assert (row["competition"], row["season"], row["home_uid"], row["away_uid"]) == (
            match["comp"], match["year"], match["home"].split(":")[-1], match["away"].split(":")[-1])
        assert not any(int(row[k]) for k in ("exact_global_candidates", "near_global_candidates", "numeric_match_id_entities"))
    event_fixtures = {r["id"]: r for r in read_csv(scope) if r["phase"] == "QUALIFYING" and r["status"] == "FINISHED"}
    assert len(event_fixtures) == (15 if args.event_scope == "witnesses" else len(rows))
    if args.lineup_manifest is None:
        manifest = {
            "snapshot_at": datetime.now(timezone.utc).isoformat(),
            "receipts": {str(p.relative_to(HERE.parent)): sha(p.read_bytes()) for p in sorted(LINEUPS.glob("*/*/*.receipt.json"))},
        }
    else:
        manifest = json.loads(args.lineup_manifest.read_bytes())
    collected = {HERE.parent / name for name in manifest["receipts"]}
    for name, expected in manifest["receipts"].items():
        assert sha((HERE.parent / name).read_bytes()) == expected, name
    manifest_path = args.out / "lineup-manifest.json"
    manifest_path.write_text(json.dumps(manifest, indent=2) + "\n")
    if args.event_manifest is None:
        event_manifest = {
            "snapshot_at": datetime.now(timezone.utc).isoformat(),
            "receipts": {str(p.relative_to(HERE)): sha(p.read_bytes())
                         for p in sorted((HERE / "events").glob("*/*.receipt.json")) if p.parent.name in event_fixtures},
        }
    else:
        event_manifest = json.loads(args.event_manifest.read_bytes())
    event_pages = {HERE / name for name in event_manifest["receipts"]}
    for name, expected in event_manifest["receipts"].items():
        assert sha((HERE / name).read_bytes()) == expected, name
    event_manifest_path = args.out / "event-manifest.json"
    event_manifest_path.write_text(json.dumps(event_manifest, indent=2) + "\n")
    overall = Counter()
    groups = defaultdict(Counter)
    starter_players_by_edition = defaultdict(set)
    bench_players_by_edition = defaultdict(set)
    entrant_players_by_edition = defaultdict(set)
    status_counts = Counter()
    flag_counts = Counter()
    event_flag_counts = Counter()
    event_shape_notes = Counter()
    fixtures = []
    events = []
    participation_keys = set()
    known_star = []
    for row in rows:
        path = LINEUPS / row["competition"] / row["season"] / f"{row['id']}.receipt.json"
        result, starters, bench, event = calc(row, path if path in collected else None, event_fixtures.get(row["id"]), event_pages)
        values = {key: result.get(key, 0) for key in KEYS_TO_SUM}
        overall.update(values)
        edition = (row["competition"], row["season"])
        groups[edition].update(values)
        groups[edition]["status_" + result["status"]] += 1
        starter_players_by_edition[edition].update(starters)
        bench_players_by_edition[edition].update(bench)
        status_counts[result["status"]] += 1
        flag_counts.update(result["flags"])
        if path in collected:
            info = json.loads(path.read_bytes())
            result["lineup_receipt"] = str(path.relative_to(HERE.parent))
            result["lineup_sha256"] = info.get("sha256")
        fixtures.append({**result, **values, "flags": "|".join(result["flags"])})
        for player in starters:
            key = (row["id"], player)
            assert key not in participation_keys
            participation_keys.add(key)
            known_star.append({"uefa_match_id": row["id"], "uefa_player_id": player, "evidence": "confirmed_starter"})
        if event:
            event_flag_counts.update(flag.split(":", 1)[0] for flag in set(event["flags"]))
            event_shape_notes.update(event["shape_notes"])
            events.append({"match": row, "lineup_status": result["status"], "starters": sorted(starters),
                           "listed_bench": sorted(bench), **event})
            for change in event["entrants"]:
                entrant_players_by_edition[edition].add(change["entered"])
                key = (row["id"], change["entered"])
                assert key not in participation_keys
                participation_keys.add(key)
                known_star.append({"uefa_match_id": key[0], "uefa_player_id": key[1], "evidence": "confirmed_entry"})
    assert overall["confirmed_starters"] + overall["confirmed_entrants"] == len(participation_keys)
    assert overall["confirmed_starters"] + overall["unconfirmed_starter_slots"] == 22 * len(rows)
    assert len(groups) == 18
    assert overall["scheduled_event_feeds"] == overall["event_receipts_seen"] + overall["event_uncollected"]
    assert overall["event_receipts_seen"] == overall["complete_event_feeds"] + overall["incomplete_event_feeds"]
    output_csv(args.out / "editions.csv",
               ({"competition": comp, "season": season, **counts,
                 "distinct_uefa_starters": len(starter_players_by_edition[comp, season]),
                 "distinct_uefa_bench": len(bench_players_by_edition[comp, season]),
                 "distinct_uefa_entrants": len(entrant_players_by_edition[comp, season])}
                for (comp, season), counts in sorted(groups.items())))
    output_csv(args.out / "fixtures.csv", fixtures)
    output_csv(args.out / "proven-player-matches.csv", sorted(known_star, key=lambda r: (r["uefa_match_id"], r["uefa_player_id"])))
    (args.out / "events.json").write_text(json.dumps(events, ensure_ascii=False, indent=2) + "\n")
    receipt = {
        "snapshot_at": manifest["snapshot_at"], "completed_collection": not overall["uncollected"],
        "counts": overall, "lineup_statuses": status_counts, "flags": flag_counts,
        "event_flags": event_flag_counts, "event_shape_notes": event_shape_notes,
        "event_snapshot_at": event_manifest["snapshot_at"],
        "proven_player_matches": len(participation_keys),
        "distinct_uefa_players": len({player for _, player in participation_keys}),
        "distinct_uefa_starters": len(set().union(*starter_players_by_edition.values())),
        "distinct_uefa_bench": len(set().union(*bench_players_by_edition.values())),
        "distinct_uefa_entrants": len(set().union(*entrant_players_by_edition.values())),
        "source_sha256": {str(p): sha(p.read_bytes()) for p in (inventory, calendar, scope, Path(__file__))},
        "cache_receipts_observed": len(collected), "events_scope": len(event_fixtures),
        "rerun": [sys.executable, str(Path(__file__).resolve()), "--out", str(args.out) + "-again",
                  "--lineup-manifest", str(manifest_path), "--event-scope", args.event_scope,
                  "--event-manifest", str(event_manifest_path)],
    }
    (args.out / "summary.json").write_text(json.dumps(receipt, ensure_ascii=False, indent=2) + "\n")
    print(json.dumps(receipt, ensure_ascii=False))


if __name__ == "__main__":
    main()
