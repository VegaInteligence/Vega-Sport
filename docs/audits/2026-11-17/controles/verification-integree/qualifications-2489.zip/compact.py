"""Losslessly project the source fields used by the UEFA participation audit."""
import gzip
import json
from pathlib import Path


def pick(obj, keys):
    if not isinstance(obj, dict):
        return obj
    return {key: obj[key] for key in keys if key in obj}


def lineup_entry(obj):
    row = pick(obj, ("type", "jerseyNumber", "player"))
    if isinstance(row, dict) and "player" in row:
        row["player"] = pick(row["player"], ("id", "internationalName", "birthDate"))
    return row


def lineup_body(obj):
    doc = pick(obj, ("lineupStatus", "matchId", "homeTeam", "awayTeam"))
    if not isinstance(doc, dict):
        return doc
    for side in ("homeTeam", "awayTeam"):
        if side not in doc:
            continue
        team = pick(doc[side], ("team", "field", "bench"))
        if isinstance(team, dict):
            if "team" in team:
                team["team"] = pick(team["team"], ("id",))
            for role in ("field", "bench"):
                if isinstance(team.get(role), list):
                    team[role] = [lineup_entry(row) for row in team[role]]
        doc[side] = team
    return doc


def compact_actor(obj):
    data = pick(obj, ("person", "team"))
    if isinstance(data, dict):
        if "person" in data:
            data["person"] = pick(data["person"], ("id", "internationalName", "birthDate", "clubJerseyNumber"))
        if "team" in data:
            data["team"] = pick(data["team"], ("id",))
    return data


def event_body(obj):
    if not isinstance(obj, list):
        return obj
    processed = []
    for item in obj:
        event = pick(item, ("id", "matchId", "type", "phase"))
        if not isinstance(event, dict):
            processed.append(event)
            continue
        event_type = event.get("type")
        if event_type in {"START_PHASE", "END_PHASE", "FULL_TIME", "SUBSTITUTION", "GOAL",
                          "RED_CARD", "SECOND_YELLOW_CARD", "YELLOW_CARD_SECOND", "RED_YELLOW_CARD"}:
            event.update(pick(item, ("timestamp", "time", "subType")))
        if event_type in {"GOAL", "SUBSTITUTION", "PENALTY", "RED_CARD", "SECOND_YELLOW_CARD",
                          "YELLOW_CARD_SECOND", "RED_YELLOW_CARD"}:
            event.update(pick(item, ("subType",)))
            for actor in ("primaryActor", "secondaryActor"):
                if actor in item:
                    event[actor] = compact_actor(item[actor])
        processed.append(event)
    return processed


def compact(raw, projector):
    try:
        return projector(json.loads(raw))
    except (ValueError, UnicodeError):
        return None


def read_dictionary_stream(path):
    with gzip.open(path, "rt", encoding="utf-8") as document:
        for line in document:
            yield json.loads(line)


def write_dictionary_stream(path, items):
    with path.open("wb") as file:
        with gzip.GzipFile(fileobj=file, mode="wb", filename="", mtime=0, compresslevel=6) as output:
            for item in items:
                record = json.dumps(item, separators=(",", ":"), ensure_ascii=False).encode()
                output.write(record + b"\n")
