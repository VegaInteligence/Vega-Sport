"""Replay a portable UEFA qualification audit offline using only this package."""
import csv
import gzip
import hashlib
import json
from pathlib import Path
import shutil
import subprocess
import sys
import tempfile

sys.dont_write_bytecode = True
from compact import compact, event_body, lineup_body, read_dictionary_stream

ROOT = Path(__file__).resolve().parent


def sha(raw):
    return hashlib.sha256(raw).hexdigest()


def json_file(path):
    return json.loads(path.read_bytes())


def csv_rows(path):
    with path.open() as f:
        return list(csv.DictReader(f))


def check_files():
    for line in (ROOT / "SHA256SUMS").read_text().splitlines():
        expected, name = line.split("  ", 1)
        assert sha((ROOT / name).read_bytes()) == expected, name


def materialize(kind, directory, received_at):
    facts = ROOT / "facts" / f"{kind}.jsonl.gz"
    manifest = {}
    witness_count = 0
    projector = lineup_body if kind == "lineups" else event_body
    for entry in read_dictionary_stream(facts):
        name = entry["path"]
        relative = Path(name)
        assert not relative.is_absolute() and ".." not in relative.parts
        assert relative.parts[0] == ("public" if kind == "lineups" else "events")
        assert name.endswith(".receipt.json") and name not in manifest
        info = entry["receipt"]
        source_sha = info.get("sha256")
        body = entry["compact_body"]
        initial = ROOT / "primary-witnesses" / name
        if initial.is_file():
            assert json_file(initial) == info, name
            original = initial.with_name(initial.name.replace(".receipt.json", ".json.gz"))
            if original.is_file():
                raw = gzip.decompress(original.read_bytes())
                assert sha(raw) == source_sha, name
                native = compact(raw, projector)
                if kind == "events" and isinstance(body, list):
                    without_hash = [
                        {k: v for k, v in event.items() if k != "original_comparison_group"} if isinstance(event, dict) else event
                        for event in body
                    ]
                else:
                    without_hash = body
                assert native == without_hash, name
                witness_count += 1
        raw = json.dumps(body, ensure_ascii=False, separators=(",", ":")).encode()
        local = {**info, "original_source_sha256": source_sha, "sha256": sha(raw), "length": len(raw)}
        receipt = directory / name
        receipt.parent.mkdir(parents=True, exist_ok=True)
        received = (json.dumps(local, ensure_ascii=False, sort_keys=True) + "\n").encode()
        receipt.write_bytes(received)
        receipt.with_name(receipt.name.replace(".receipt.json", ".json.gz")).write_bytes(gzip.compress(raw, mtime=0))
        manifest[name] = sha(received)
    target = directory.parent / (kind + "-manifest.json")
    if target.exists():
        target = directory / (kind + "-manifest.json")
    target.write_text(json.dumps({"snapshot_at": received_at, "receipts": manifest}) + "\n")
    return target, witness_count, len(manifest)


def grade_and_match_coverage(edition_data):
    rows = csv_rows(ROOT / "source" / "rds" / "global-search.csv")
    qualify = [r for r in rows if r["phase"] == "QUALIFYING"]
    tournament = [r for r in rows if r["phase"] == "TOURNAMENT"]
    assert len(qualify) == 2489 and len(tournament) == 2478
    assert not any(int(row[field]) for field in ("exact_global_candidates", "near_global_candidates", "numeric_match_id_entities")
                   for row in qualify)
    assert sum(int(row["near_global_candidates"]) > 0 for row in tournament) == 2475
    rds_receipt = json_file(ROOT / "source" / "rds" / "receipt.json")
    assert sha((ROOT / "source" / "rds" / "global-search.csv").read_bytes()) == rds_receipt["outputs_equal_sha256"]["global-search.csv"]
    editions = {(e["competition"], e["season"]): e for e in edition_data}
    grades = csv_rows(ROOT / "results" / "grade-capability.csv")
    assert len(grades) == len(editions) == 18
    for g in grades:
        e = editions[g["competition"], g["season"]]
        proved = int(e["confirmed_starters"]) + int(e["confirmed_entrants"])
        assert int(g["verified_player_matches"]) == proved
        assert int(g["bench_appearances_unresolved"]) == int(e["unresolved_bench"])
        assert int(g["sufficient_player_match_grade_inputs_demonstrated"]) == int(g["matching_vega_fixtures"]) == 0
        assert int(g["verified_player_matches_with_input_sufficiency_unassessed"]) == proved


def main():
    check_files()
    expected = json_file(ROOT / "results" / "summary.json")
    receipt = json_file(ROOT / "RECEIPT.json")["expected_replay"]
    thresholds = {
        "fixtures": "fixtures", "journal_receipts": "event_receipts_seen",
        "confirmed_starts": "confirmed_starters", "confirmed_entries": "confirmed_entrants",
    }
    assert all(receipt[key] == expected["counts"][field] for key, field in thresholds.items())
    assert receipt["proven_player_matches"] == expected["proven_player_matches"]
    with tempfile.TemporaryDirectory(prefix="uefa-offline-", dir=ROOT.parent) as scratch:
        scratch = Path(scratch)
        tracks = scratch / "tracks"
        replay = tracks / "5-players" / "qualifications-uefa-participations" / "analysis"
        replay.mkdir(parents=True)
        rds = replay / "rds-replay"
        rds.mkdir()
        calendar = tracks / "2-ingestion" / "continental-calendar"
        calendar.mkdir(parents=True)
        shutil.copyfile(ROOT / "source" / "audit.py", replay / "audit.py")
        shutil.copyfile(ROOT / "source" / "event-scope.csv", replay / "event-scope.csv")
        shutil.copyfile(ROOT / "source" / "official-fixtures.csv", calendar / "official-fixtures.csv")
        shutil.copyfile(ROOT / "source" / "rds" / "global-search.csv", rds / "global-search.csv")
        lineups, raw_lineups, lineup_pages = materialize("lineups", replay.parent, expected["snapshot_at"])
        events, raw_events, event_pages = materialize("events", replay, expected["event_snapshot_at"])
        mode = "all" if expected["events_scope"] == 2489 else "witnesses"
        output = scratch / "replay"
        command = [sys.executable, "-B", str(replay / "audit.py"), "--event-scope", mode, "--out", str(output),
                   "--lineup-manifest", str(lineups), "--event-manifest", str(events)]
        subprocess.run(command, stdout=subprocess.DEVNULL, check=True)
        actual = json_file(output / "summary.json")
        for field in ("counts", "lineup_statuses", "event_flags", "event_shape_notes", "proven_player_matches",
                      "distinct_uefa_players", "distinct_uefa_starters", "distinct_uefa_bench", "distinct_uefa_entrants"):
            assert actual[field] == expected[field], (field, actual[field], expected[field])
        for name in ("editions.csv", "proven-player-matches.csv"):
            assert (output / name).read_bytes() == (ROOT / "results" / name).read_bytes(), name
        grade_and_match_coverage(csv_rows(output / "editions.csv"))
        print(json.dumps({
            "result": "PASS", "editions": 18, "fixtures": 2489, "lineup_receipts": lineup_pages, "event_pages": event_pages,
            "raw_lineups_checked": raw_lineups, "raw_event_pages_checked": raw_events,
            "proven_player_matches": actual["proven_player_matches"], "matching_vega_qualifications": 0,
        }, indent=2))


if __name__ == "__main__":
    main()
