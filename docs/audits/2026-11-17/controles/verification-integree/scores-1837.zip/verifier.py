"""Repeat the 44-query proof and re-create the current score grids without AWS or SQL execution."""
from collections import Counter, defaultdict
import csv
import gzip
import json
from pathlib import Path
import shutil
import subprocess
import sys
from tempfile import TemporaryDirectory

from comparer import capture_validation

ROOT = Path(__file__).resolve().parent


def run(*args):
    subprocess.run([sys.executable, '-B', *(str(x) for x in args)], check=True)


def compare_generated(out, sealed, names):
    for name in names:
        assert (out/name).read_bytes() == (sealed/name).read_bytes(), name


def group_edition_grid():
    with gzip.open(ROOT/'grilles/scores-par-edition.csv.gz','rt',encoding='utf-8') as stream:
        grid = list(csv.DictReader(stream))
    keys = ('competition_id','competition','season_id','season','entity_type')
    metrics = ('recorded_matches','finished','expected_algorithm','actual_valid','missing_from_storage','role_unavailable')
    summary = defaultdict(Counter)
    for row in grid:
        group = summary[tuple(row[k] for k in keys)]
        group['editions'] += 1
        for metric in metrics:
            group[metric] += int(row[metric] or 0)
    with (ROOT/'scores-par-competition-saison-et-entite.csv').open('w', newline='') as destination:
        writer = csv.DictWriter(destination, fieldnames=(*keys,'editions',*metrics), lineterminator='\n')
        writer.writeheader()
        for key,counters in sorted(summary.items()):
            metrics_row = dict(counters)
            if key[-1] != 'player':
                metrics_row['role_unavailable'] = ''
            writer.writerow({**dict(zip(keys,key,strict=True)), **metrics_row})
    return len(summary)


def main():
    import hashlib
    old = capture_validation(ROOT/'precedent')
    current = capture_validation(ROOT/'releve')
    assert len(old['query_sha256']) == 52
    assert all(current['query_sha256'][k] == v for k,v in old['query_sha256'].items())
    assert set(current['query_sha256']) - set(old['query_sha256']) == {'pulse-transferts'}
    assert current['inputs'] == old['inputs']
    with TemporaryDirectory(prefix='vega-1837-') as tmp:
        root=Path(tmp)
        raw=root/'releve'
        shutil.copytree(ROOT/'releve',raw)
        run(raw/'scores/build-score-grid.py')
        run(raw/'verify_grid.py')
        compare_generated(raw/'scores',ROOT/'releve/scores',('coverage-by-edition-and-entity.csv','coverage-by-season-and-entity.csv','grid-validation.json'))
        run(ROOT/'calculer.py',raw,root/'grilles')
        compare_generated(root/'grilles',ROOT/'grilles',('scores-par-edition.csv.gz','scores-par-saison.csv.gz','resultats.json'))
        for fn in ('scores-par-edition.csv.gz','scores-par-saison.csv.gz'):
            assert gzip.decompress((root/'grilles'/fn).read_bytes())==gzip.decompress((ROOT/'grilles-1753'/fn).read_bytes())
    table=ROOT/'scores-par-competition-saison-et-entite.csv'
    existed=table.read_bytes() if table.exists() else None
    rows=group_edition_grid()
    assert existed is None or table.read_bytes()==existed
    print(json.dumps({'statut':'verified','release':current['release'],'transaction':current['common_snapshot'],'reference':old['common_snapshot'],'requêtes_précédentes_identiques':52,'requêtes_actuelles':53,'comparaison':'toutes les cellules des grilles des 2 149 éditions et des 471 lignes saison/entité identiques entre les deux transactions','lignes_agregees_competition_saison_type':rows,'sha256_grille_agregee':hashlib.sha256(table.read_bytes()).hexdigest()},ensure_ascii=False))
if __name__=='__main__':
    main()
