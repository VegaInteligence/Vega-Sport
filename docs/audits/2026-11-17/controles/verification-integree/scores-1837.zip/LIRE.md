# Scores et transferts après la migration 135

Le 18 novembre 2026 à 18 h 37 min 54 s UTC, le worker déployé `5956a83cd76b` a servi d’environnement à une mesure RDS en lecture seule. Les 53 requêtes et le rejeu de l’algorithme Elo lisent le même instantané PostgreSQL. La migration `135_player_transfers.sql` y est présente avec l’empreinte Git attendue depuis 18 h 22 min 31 s UTC. Les 52 requêtes communes ont les mêmes empreintes qu’à 17 h 53. Chaque cellule des grilles publiées par édition et par saison concorde avec ce relevé antérieur. [Transaction et empreintes](releve/receipt.json) · [Rejeu hors ligne](verification.log)

| Entité | Admissibles | Persistés valides | Manquants |
|---|---:|---:|---:|
| Joueurs | 2 297 026 | 2 282 608 | 14 418 |
| Clubs, côtés Elo | 161 934 | 161 934 | 0 |
| Sélections, côtés Elo | 3 252 | 3 252 | 0 |

Les 615 participations individuelles sans rôle sont comptées à part. Les 35 rencontres anglaises supprimées et les calendriers absents limitent aussi la couverture sportive. Le run Elo 2099 couvre les 82 593 matchs admis à cet instant. [Grille compétition, saison et entité](scores-par-competition-saison-et-entite.csv) · [Détail par édition](grilles/scores-par-edition.csv.gz)

La population de transferts continue de grandir. Sur 136 902 lignes, 86 619 ont au moins une extrémité canonique absente et 47 157 ont les deux absentes. La nouvelle vue du site expose 134 916 lignes datées, dont 86 140 avec au moins une extrémité sans identifiant canonique. Douze lignes n’ont le nom d’aucun des deux clubs. Le lecteur peut conserver un nom fournisseur lorsqu’un club n’a pas d’identifiant. Les 16 957 lignes de lectures réussies et les 342 408 valeurs de marché lisibles ne suffisent pas à établir l’identité de tous les clubs. [SQL exact](releve/db/pulse/pulse-transferts.sql) · [Résultat](releve/db/pulse/pulse-transferts.json)

Après extraction, lancer `python3 -B verifier.py` à la racine. Le contrôle rejoue les grilles à partir des réponses originales, vérifie le SQL, les empreintes de transport, les données des deux transactions et leur concordance. Il utilise uniquement la bibliothèque standard de Python. La consultation des grilles et la vérification ne nécessitent aucun accès AWS.
