"""Relecture HTTP publique des CSV épinglés et des éditions masculines ouvertes."""
import ast,collections,csv,datetime,hashlib,io,json,sys,tempfile,types
from concurrent.futures import ThreadPoolExecutor
from pathlib import Path
import requests
D=Path(__file__).resolve().parent
code=(D/'sources/backend/vega/sources/worldcup.py').read_text()
pkg=types.ModuleType('epreuve');pkg.SourceError=ValueError;sys.modules['epreuve']=pkg
env={'__package__':'epreuve'}
exec(compile(code,'worldcup.py','exec'),env)
pins=env['FILES']; commit=env['COMMIT']
def read(url):
 with requests.get(url,timeout=45) as r:
  return r.content,{'url':url,'status':r.status_code,'at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'bytes':len(r.content),
                   'sha256':hashlib.sha256(r.content).hexdigest(),'etag':r.headers.get('etag'),'age':r.headers.get('age')}
def put(name,obj):(D/name).write_text(json.dumps(obj,ensure_ascii=False,indent=2)+'\n')
def get_file(n):
 raw,rec=read(env['RAW'].format(commit=commit,name=n));assert rec['status']==200 and rec['sha256']==pins[n];return n,raw.decode(),rec
with ThreadPoolExecutor(4) as pool: docs=list(pool.map(get_file,pins))
raws={n:s for n,s,_ in docs}; rows=env['typed'](raws);env['verify'](raws)
tournaments={t['tournament_key']:t for t in rows['tournaments']}; print(rows['matches'][0].keys(),list(tournaments.values())[0])
men={m['match_key']:m for m in rows['matches'] if not tournaments[m['tournament_key']]['women']};women=[m for m in rows['matches'] if tournaments[m['tournament_key']]['women']]
by_edition=collections.Counter(tournaments[m['tournament_key']]['year'] for m in men.values())
people=collections.Counter((r['match_key'],r['role'],r['team_key']) for r in rows['appearances'] if r['match_key'] in men)
multiple=sorted([(k[0],k[2],v) for k,v in people.items() if k[1]=='manager' and v>1])
players={k[0] for k in people if k[1]=='player'}
samples=['M-1930-18','M-1998-64','M-2022-64']+[multiple[0][0]] if multiple else ['M-1930-18','M-1998-64','M-2022-64']
put('source-calculs.json',{'commit':commit,'source_fichiers':[r for _,_,r in docs],'lignes_par_table':{k:len(v) for k,v in rows.items()},'lignes_typees':sum(map(len,rows.values())),'tournois_par_genre':dict(collections.Counter('feminin' if t['women'] else 'masculin' for t in tournaments.values())),'matchs_masculins':len(men),'matchs_feminins':len(women),'matchs_masculins_par_edition':by_edition,'matchs_masculins_avec_apparitions':len(players),'annees_apparitions_masculines':sorted({tournaments[men[k]['tournament_key']]['year'] for k in players}),'plusieurs_selectionneurs_matchs_equipes':multiple})
roots=['https://vegasport.vercel.app','https://dngp6kh9jx2bl.cloudfront.net']
paths=['/api/worldcup/matches?edition='+str(y) for y in sorted(by_edition)]+['/api/worldcup/matches?edition=2026','/api/worldcup/matches?edition=2019']
urls=[roots[0]+p for p in paths]+[h+'/api/worldcup/matches/'+k for h in roots for k in dict.fromkeys(samples)]
def get_url(url):
 raw,rec=read(url);body=json.loads(raw);payload=body.get('data',{});rec['payload_keys']=list(payload)
 if 'matches' in payload:
  matches=payload['matches'];year=payload['edition']; expected={k for k,m in men.items() if tournaments[m['tournament_key']]['year']==year}; seen={m['key'] for m in matches}
  rec.update(edition=year,count=len(matches),exact_keys=expected==seen and len(seen)==len(matches),exact_dates=all(str(men[r['key']]['match_date'])==r['date'] for r in matches))
 elif 'lineups' in payload:
  key=payload['key']; m=men[key];rec.update({k:payload[k] for k in ['key','stage','date','home','away','score','penalties','credit']})
  rec.update(lineups={s:len(p) for s,p in payload['lineups'].items()},starters={s:sum(e['starter'] for e in p) for s,p in payload['lineups'].items()},events=len(payload['events']),kicks=len(payload['kicks']),lineup_properties=sorted({n for players in payload['lineups'].values() for p in players for n in p}),source_home_score=m['home_score'],source_away_score=m['away_score'])
  if key in [x[0] for x in multiple]:rec['source_managers']=[{n:r[n] for n in ('team_key','person_key')} for r in rows['appearances'] if r['match_key']==key and r['role']=='manager']
 else:rec['error']=body.get('error')
 return rec
with ThreadPoolExecutor(3) as pool:receipts=list(pool.map(get_url,urls))
put('http/lectures-mondial.json',receipts); indexes=[r for r in receipts if 'exact_keys' in r];print('indexes',len(indexes),sum(r['count'] for r in indexes),all(r['exact_keys'] and r['exact_dates'] for r in indexes));print('samples',samples,'managers',len(multiple))
