"""Compare l’archive calendrier/score Vega et les scores Fjelstul au commit épinglé."""
import ast,collections,csv,datetime,hashlib,io,json
from pathlib import Path
from concurrent.futures import ThreadPoolExecutor
import requests
D=Path(__file__).resolve().parent
def get(url):
 r=requests.get(url,timeout=35);return r, dict(url=url,at=datetime.datetime.now(datetime.timezone.utc).isoformat(),status=r.status_code,sha256=hashlib.sha256(r.content).hexdigest())
s=json.loads((D/'source-calculs.json').read_bytes())
file=next(f for f in s['source_fichiers'] if f['url'].endswith('/matches.csv'))
r,e=get(file['url']);assert e['sha256']==file['sha256'];rows=list(csv.DictReader(io.StringIO(r.text if r.encoding=='utf-8' else r.content.decode())))
table=ast.parse((D/'sources/backend/vega/sources/worldcup.py').read_text());pairs=next(ast.literal_eval(a.value) for a in table.body if isinstance(a,ast.Assign) and a.targets[0].id=='SPELLINGS')
normalize={alias:pair[0] for pair in pairs for alias in pair}
def name(x):return normalize.get(x,x)
def check(year):
 urls='https://vegasport.vercel.app/api/cups/edition?competition=l_v0000064&season='+str(year)
 r,e=get(urls);ms=r.json().get('matches',[])
 wanted={ (v['match_date'],frozenset((name(v['home_team_name']),name(v['away_team_name'])))):v for v in rows if v['tournament_id']=='WC-'+str(year) }
 n=score=reg=pen=samepen=0; absent=[]; errors=[]
 for row in ms:
  f=wanted.get((row['date'],frozenset((name(row['team1']),name(row['team2'])))))
  if not f:absent.append([row['date'],row['team1'],row['team2'],row.get('score')]);continue
  n+=1;swap=name(row['team1'])!=name(f['home_team_name'])
  expected=[int(f['home_team_score']),int(f['away_team_score'])][::-1 if swap else 1]; actual=row.get('score') or {}
  if isinstance(actual,list):actual={'ft':actual}
  if actual.get('ft')==expected: reg+=1
  if (actual.get('et') or actual.get('ft'))==expected: score+=1
  else:errors.append([f['match_id'],expected,actual])
  if f['penalty_shootout']=='1':
   pen+=1; wanted_p=[int(f['home_team_score_penalties']),int(f['away_team_score_penalties'])][::-1 if swap else 1]
   if actual.get('p')==wanted_p:samepen+=1
   else:errors.append([f['match_id'],'shootout',wanted_p,actual])
 return {**e,'year':year,'source':len(wanted),'vega':len(ms),'paired':n,'equal_final':score,'equal_ft_only':reg,'shootouts':pen,'equal_shootouts':samepen,'unpaired_vega':absent,'divergent':errors}
with ThreadPoolExecutor(3) as pool:report=list(pool.map(check, sorted(s['matchs_masculins_par_edition'])))
(D/'http/scores-fjelstul-archive.json').write_text(json.dumps(report,ensure_ascii=False,indent=2)+'\n')
for k in ['source','vega','paired','equal_final','equal_ft_only','shootouts','equal_shootouts']:print(k,sum(r[k] for r in report))
print([(r['year'],r['unpaired_vega'],r['divergent'][:1]) for r in report if r['unpaired_vega'] or r['divergent']][:25])
