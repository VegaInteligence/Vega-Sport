"""Compare les lignes de compétitions et lectures de texte de deux classeurs de couverture."""
import collections,hashlib,json,sys,zipfile,xml.etree.ElementTree as X
from pathlib import Path
N={'x':'http://schemas.openxmlformats.org/spreadsheetml/2006/main'}
def read(path):
 with zipfile.ZipFile(path) as z:
  ss=[''.join(x.itertext()) for x in X.fromstring(z.read('xl/sharedStrings.xml'))]
  sheets=[x.get('name') for x in X.fromstring(z.read('xl/workbook.xml')).findall('.//x:sheet',N)]
  data={}
  for i,s in enumerate(sheets,1):
   rows=[]
   for row in X.fromstring(z.read(f'xl/worksheets/sheet{i}.xml')).findall('.//x:row',N):
    cells=[]
    for c in row:
     v=c.findtext('x:v',namespaces=N)
     cells.append(ss[int(v)] if c.get('t')=='s' else ''.join(c.itertext()))
    rows.append(cells)
   data[s]=rows
 return data
p,q=map(Path,sys.argv[1:]);a,b=read(p),read(q)
d=dict(baseline_sha256=hashlib.sha256(p.read_bytes()).hexdigest(),new_sha256=hashlib.sha256(q.read_bytes()).hexdigest())
def rows(s):return {tuple(x[:2]) for x in s['Competitions'][7:]}
before,after=rows(a),rows(b);d.update(baseline_competitions=len(before),new_competitions=len(after),removed=sorted(before-after),added=sorted(after-before),worksheets={s:[len(a[s]),len(b[s])] for s in a},fjelstul_cells=[[s,i+1,j+1] for s,rr in b.items() for i,r in enumerate(rr) for j,v in enumerate(r) if 'fjelstul' in str(v).lower()])
Path(__file__).with_name('classeur.json').write_text(json.dumps(d,ensure_ascii=False,indent=2)+'\n')
print(len(before),len(after),d['removed'],d['fjelstul_cells'])
