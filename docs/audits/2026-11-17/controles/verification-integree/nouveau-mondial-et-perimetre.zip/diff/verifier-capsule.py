"""Rejeu autonome des données publiques originales, sans réseau ni dépendance tierce."""
import collections,csv,hashlib,io,json,runpy,shutil,sys,tempfile,types
from pathlib import Path
here=Path(__file__).resolve().parent
root=here.parent
def digest(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def require(v,msg):
    if not v:raise ValueError(msg)
manifest=json.loads((root/'manifest-sha256.json').read_bytes())
for f,h in manifest.items(): require((root/f).is_file() and digest(root/f)==h,'entrée manquante ou altérée : '+f)
all_files={f.relative_to(root).as_posix() for f in root.rglob('*') if f.is_file()}
require(all_files==set(manifest)|{'manifest-sha256.json'},'inventaire divergent')
index=json.loads((here/'rejeu/index.json').read_bytes())
class Response:
    def __init__(self,u):
        x=index[u];file=here/'rejeu'/x['file'];require(digest(file)==x['sha256'],'corps HTTP altéré')
        self.content=file.read_bytes();self.status_code=x['status'];self.headers={};self.encoding='utf-8';self.text=self.content.decode()
    def json(self):return json.loads(self.content)
    def __enter__(self):return self
    def __exit__(self,*args):return False
def get(u,**kwargs):return Response(u)
fake=types.ModuleType('requests');fake.get=get;sys.modules['requests']=fake
def stable(v):
    if isinstance(v,dict):return {k:stable(x) for k,x in v.items() if k not in ('at','etag','age')}
    if isinstance(v,list):return [stable(x) for x in v]
    return v
with tempfile.TemporaryDirectory() as temp:
    t=Path(temp);(t/'http').mkdir();(t/'sources/backend/vega/sources').mkdir(parents=True)
    for f in ['verifier-mondial.py','verifier-scores.py','sources/backend/vega/sources/worldcup.py']:
        shutil.copyfile(here/f,t/f)
    for script in ('verifier-mondial.py','verifier-scores.py'):
        runpy.run_path(str(t/script),run_name='__main__')
    for f in ['source-calculs.json','http/lectures-mondial.json','http/scores-fjelstul-archive.json']:
        require(stable(json.loads((t/f).read_bytes()))==stable(json.loads((here/f).read_bytes())),f)
    results=json.loads((t/'http/scores-fjelstul-archive.json').read_bytes())
    require(sum(x['equal_final'] for x in results)==964 and sum(x['equal_shootouts'] for x in results)==35,'scores')
    s=json.loads((t/'source-calculs.json').read_bytes())
    def tab(n):
        u=next(u for u in index if u.endswith('/'+n+'.csv'))
        return list(csv.DictReader(io.StringIO(get(u).text)))
    ma=tab('manager_appearances'); target=list(csv.DictReader((here/'co-selectionneurs-42.csv').open()))
    require(len(target)==42 and len({r['match_key'] for r in target})==41,'42 côtés')
    for row in target:
        src=[r for r in ma if r['match_id']==row['match_key'] and r['team_id']==row['team_key']]
        api=get('https://vegasport.vercel.app/api/worldcup/matches/'+row['match_key']).json()['data']
        matches=[api[side]['manager'] for side in ('home','away') if api[side]['name']==row['equipe_affichee']]
        require(len(src)==int(row['selectionneurs_source']) and ' | '.join(r['manager_id'] for r in src)==row['ids_source'] and ' | '.join((r['given_name']+' '+r['family_name']).strip() for r in src)==row['noms_source'] and matches==[row['selectionneur_API']],row['match_key'])
    for f in ('verifier-classeur.py','ancien.xlsx','sources/docs/vega-sport-data-coverage.xlsx'):
        (t/f).parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(here/f,t/f)
    sys.argv=[str(t/'verifier-classeur.py'),str(t/'ancien.xlsx'),str(t/'sources/docs/vega-sport-data-coverage.xlsx')];runpy.run_path(str(t/'verifier-classeur.py'),run_name='__main__')
    require(json.loads((t/'classeur.json').read_bytes())==json.loads((here/'classeur.json').read_bytes()),'classeur')
    print('PASS: 17 CSV, 75 669 lignes typées, 964 scores, 35 séances, 42 côtés à plusieurs sélectionneurs sur 41 matchs, classeur 130 → 99.')
