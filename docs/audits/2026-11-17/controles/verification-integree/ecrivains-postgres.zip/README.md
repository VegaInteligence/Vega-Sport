# Correctifs d’écriture Vega-Sport

La capsule réunit les cinq défauts vérifiés dans les écritures quotidiennes. Elle fonctionne hors réseau externe. Tous ses chemins sont relatifs à ce dossier. Le source est celui du candidat intégré `070f7c82cf99cf240d77278eca152dcdc20803ab`.

| Correctif | Résultat vérifiable |
| --- | --- |
| Journée facultative Open Matchday | La vue conserve la journée 1 et la révision quand le CSV laisse la cellule vide. La suite ciblée couvre aussi l’en-tête absent, la correction explicite, une nouvelle fixture et le changement d’édition. |
| Concurrence de deux imports Open Matchday | L’import A reprend après la publication 2–1 par B. La rencontre, sa journée, sa révision et sa clé sont encore présentes. La suite couvre la suppression, la rétrogradation et une mise à jour concurrente. |
| Clés historiques Open Matchday | Une ancienne clé ne pilote plus le retrait. Un rejeu inchangé conserve les deux clés et le match. Le retrait réellement admissible emporte les clés du match. Le rejeu d’une clé retirée donne un refus observable. |
| Bilan SportScore impossible | Les bilans complets et partiels incohérents sont refusés. Le tableau valide, les cellules inconnues légitimes et les déductions restent admis. |
| Alias SportScore première équipe, réserve et jeunes | Le lien doit respecter l’identité canonique, y compris pour un alias déjà appris. Les graphies attestées restent attachées à leur clé PitchAPI. |

[Scénarios définis avant l’implémentation](SCENARIOS.md) · [Manifestes SHA-256 et révisions](manifest.json)

## Vérifier les preuves enregistrées

Python 3.14 et sa bibliothèque standard suffisent. Le contrôle recalcule les empreintes, puis vérifie les observations des cinq correctifs, les red/green des suites, les 11 cas HTTP et les 872 contrôles des 838 graphies SportScore. Les lignes sont issues de réponses contrôlées ou de captures existantes. Aucune nouvelle mesure de production n’est effectuée.

```sh
python3 -B tools/verify.py
python3 -B tools/verify.py --negative
```

La seconde commande doit échouer avec « la rencontre, sa révision ou sa clé a changé ». Elle simule la perte d’une clé en mémoire après le contrôle des empreintes. Les témoins d’origine et corrigés sont dans [proof](proof/).

## Rejouer avec PostgreSQL 18

Prérequis disponibles localement avant le rejeu

- Python 3.14.6 et `psycopg[binary]==3.3.9`. Préparer ces distributions à partir d’un cache ou de roues adaptées à la plateforme. Le vérificateur sans base ne dépend pas de psycopg.
- PostgreSQL 18 jetable, joignable sur l’interface de boucle locale. Utiliser l’utilisateur de test `postgres` avec la permission de créer des bases. Lancer le serveur de test avant de couper le réseau extérieur. Les harnais créent des bases à nom aléatoire, appliquent les migrations emballées, puis les suppriment.
- Pour le lecteur HTTP, Node 26.4.0 et les dépendances de [backend/api/package-lock.json](backend/api/package-lock.json), dont `pg` 8.23.1. Le cache npm doit déjà contenir les dépendances pour `npm ci --offline --prefix backend/api`. Les autres rejeux n’utilisent pas Node.

Exécuter depuis ce dossier. Remplacer le port par celui de l’instance de test. Les deux rejeux qualifiés « before » importent les écrivains archivés correspondant au scénario négatif. Les scripts utilisent le même schéma local inclus dans la capsule.

```sh
observed="$(mktemp -d)"
python3 -B tools/writers.py original --port 5432 > "$observed"/writers-before.json
python3 -B tools/writers.py corrected --port 5432 > "$observed"/writers-after.json
python3 -B tools/match_keys.py historical --port 5432 > "$observed"/keys-before.json
python3 -B tools/match_keys.py corrected --port 5432 > "$observed"/keys-after.json
python3 -B tools/standings_http.py --port 5432 > "$observed"/http-replayed.json
python3 -B tools/aliases.py --port 5432 > "$observed"/aliases-replayed.json
python3 -B tools/verify.py --replay-dir "$observed"
```

Les scripts appellent le writer via `sources.run_due`; deux vraies transactions traversent la course Open Matchday. Le lecteur HTTP lance le code de l’API et ses requêtes sous le rôle de lecture. Le serveur de test renvoie six réponses 304 pour les refus. Les entrées des alias reproduisent 852 appariements dans les éditions capturées et 20 dans un roster synthétique pour les clubs sans ligne de classement officielle capturée. La preuve T2 est une synthèse de l’ancien rejeu sur le candidat intégré.

Les tables complètes ou les métadonnées d’un environnement d’hébergement ne sont pas requises. Les cas d’homonymie au-delà des éditions SportScore restent hors du lot. Aucun correctif n’est appliqué à une installation par l’extraction de cette capsule.
