"""Check the 838 captured club names using SportScore's real local roster loader."""
from argparse import ArgumentParser
from hashlib import sha256
import json

from local import ROOT, code, database

parser = ArgumentParser()
parser.add_argument("--port", type=int, default=5432)
args = parser.parse_args()
code()

from vega import sources
from vega.sources import sportscore
from vega.store import Store, migrate

capture = ROOT / "inputs"
paths = [capture / f"{source}.json" for source in ("aliases", "editions", "exact")]
aliases, editions, peers = [json.loads(path.read_bytes())["rows"] for path in paths]

def pitch_key(keys):
    key, = (p.split(":", 1)[1] for p in keys if p.startswith("pitchapi:"))
    return key

active = {team: shifts for team, _, _, _, _, _, _, shifts, _ in aliases}
checks, failures, matches = 0, [], {}
with database(args.port) as (db, dsn):
    server = db.execute("SHOW server_version").fetchone()[0]
    migrate(db)
    with db.transaction():
        for edition, competition, name, year, _, native_label in editions:
            Store(db).season(f"{year}/{year+1}")
            db.execute("INSERT INTO core.competitions(id,name) VALUES(%s,%s) ON CONFLICT DO NOTHING", (competition, name))
            db.execute("""INSERT INTO core.competition_seasons(id,competition_id,season_id,native_label) VALUES(%s,%s,%s,%s)""",
                       (edition, competition, year, native_label))
        # Synthetic edition for the 20 retained aliases whose clubs lack a current official row.
        db.execute("INSERT INTO core.competitions(id,name) VALUES(80000,'Retained aliases')")
        db.execute("INSERT INTO core.competition_seasons(id,competition_id,season_id) VALUES(80000,80000,2026)")
        for team, alias, kind, canonical, short, country, merged, shifts, keys in aliases:
            db.execute("INSERT INTO core.teams(id,name,short_name) VALUES(%s,%s,%s)", (team, canonical, short))
            db.execute("""INSERT INTO core.provider_ids(entity_type,provider,provider_key,entity_id)
                          VALUES('team','pitchapi',%s,%s)""", (pitch_key(keys), team))
            db.execute("""INSERT INTO core.entity_names(entity_type,entity_id,name,normalized,kind,source)
                          VALUES('team',%s,%s,%s,%s,'sportscore')""", (team, alias, sources.normalize(alias), kind))
            for edition in shifts or [80000]:
                db.execute("INSERT INTO core.team_seasons(team_id,competition_season_id) VALUES(%s,%s)", (team, edition))
        # Include exact-name peers when the captured official edition places them with a witness.
        for team, _, peer, canonical, merged, _, _, _, _, shared, official in peers:
            editions_in_common = set(shared or ()) & set(active[team])
            if peer in active or merged or not editions_in_common:
                continue
            db.execute("INSERT INTO core.teams(id,name) VALUES(%s,%s) ON CONFLICT DO NOTHING", (peer, canonical))
            for edition in editions_in_common:
                db.execute("INSERT INTO core.team_seasons(team_id,competition_season_id) VALUES(%s,%s) ON CONFLICT DO NOTHING",
                           (peer, edition))
    for edition in [row[0] for row in editions] + [80000]:
        names, _, _, _ = sportscore._edition_teams(db, edition)
        matches[edition] = names
    for team, alias, _, canonical, _, _, _, shifts, keys in aliases:
        for edition in shifts or [80000]:
            checks += 1
            found = sportscore._exact([alias], matches[edition]).get(alias)
            if found != team:
                failures.append({"edition": edition, "team": team, "canonical": canonical, "name": alias, "got": found})

summary = {
    "server": server,
    "source": {path.name: sha256(path.read_bytes()).hexdigest() for path in paths},
    "aliases": len(aliases),
    "official_editions": len(editions),
    "aliases_without_official_edition": sum(not row[-2] for row in aliases),
    "checks": checks,
    "failures": failures,
}
print(json.dumps(summary, indent=2, ensure_ascii=False))
raise SystemExit(bool(failures))
