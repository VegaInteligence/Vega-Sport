"""Run the packaged SportScore inputs through the worker and real local HTTP API."""
from argparse import ArgumentParser
from datetime import timedelta
import json
import subprocess
from urllib.error import HTTPError
from urllib.request import build_opener, ProxyHandler, Request
from local import ROOT, code, database

parser = ArgumentParser()
parser.add_argument("--port", type=int, default=5432)
parser.add_argument("--node", default="node")
args = parser.parse_args()
code()

from vega import sources
from vega.sources import sportscore
from vega.store import Store, migrate
import sportscore_replay as replay
from sportscore_cases import CASES, T0

opener = build_opener(ProxyHandler({}))


def served(port, key, tag=None):
    request = Request(f"http://127.0.0.1:{port}/api/standings?competition={key}",
                      headers={"If-None-Match": tag} if tag else {})
    try:
        response = opener.open(request, timeout=15)
    except HTTPError as error:
        response = error
    with response:
        body = response.read()
        return response.status, response.headers.get("etag"), json.loads(body) if body else None


def aliases(db):
    return db.execute("""SELECT entity_id, name
        FROM core.entity_names WHERE entity_type='team' AND entity_id BETWEEN 101 AND 103 ORDER BY 1,2""").fetchall()


def replay_cases(db, port, trials):
    case = CASES[0]
    records = []
    for trial in trials:
        label = trial["label"]
        if label == "prelearned-reserve-spelling":
            db.execute("""INSERT INTO core.entity_names(entity_type,entity_id,name,normalized,kind,source)
                      VALUES ('team',101,'Aster City II','astercityii','source_spelling','sportscore')""")
        if label == "reviewed-gent-b-alias":
            db.execute("UPDATE core.teams SET name='Gent U23' WHERE id=101")
            db.execute("""UPDATE core.provider_ids SET provider_key='t_1ekXAt'
                            WHERE entity_type='team' AND provider='pitchapi' AND entity_id=101""")
        _, original_tag, _ = served(port, case["key"])
        names_before = aliases(db)
        body = trial["widget"]
        when = T0 + timedelta(hours=trial["request_hour"])
        db.execute("SET ROLE vega_collect")
        try:
            observed = replay.play(sources, sportscore, db, case, {"at": when}, lambda _: body) or "ok"
        finally:
            db.execute("RESET ROLE")
        status, tag, table = served(port, case["key"])
        conditional, _, _ = served(port, case["key"], original_tag)
        assert observed == trial["expected"], (label, trial["expected"], observed)
        assert status == 200 and table["source"] == "SportScore", (label, status, table)
        unchanged_aliases = aliases(db) == names_before
        if observed != "ok":
            assert conditional == 304 and tag == original_tag and unchanged_aliases, label
        if label == "coherent-correction":
            assert conditional == 200 and tag != original_tag, label
        version, = db.execute("""SELECT version FROM ops.resource_versions
                                  WHERE resource_kind='competition_season' AND resource_id=%s""",
                              (trial["edition"],)).fetchone()
        assert [version] == trial["version"], (label, version, trial["version"])
        records.append({"label": label, "outcome": observed, "status": status, "conditional": conditional,
                        "etag_stable": tag == original_tag, "aliases_stable": unchanged_aliases, "version": version})
    return records


trials = json.loads((ROOT / "proof/http.json").read_text())
with database(args.port) as (db, dsn):
    migrate(db)
    with db.transaction():
        replay.build(db, Store(db))
    server = subprocess.Popen([args.node, str(ROOT / "tools/serve.mjs"), dsn], stdout=subprocess.PIPE, text=True)
    try:
        if not (port_text := server.stdout.readline().strip()):
            raise RuntimeError("Node read API did not start")
        print(json.dumps(replay_cases(db, int(port_text), trials), indent=2))
    finally:
        server.terminate()
        server.wait(timeout=15)
