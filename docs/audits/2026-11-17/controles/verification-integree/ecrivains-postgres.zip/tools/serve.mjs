import { createServer } from "node:http";
import { createReader } from "../backend/api/src/db.mjs";
import { createHandler } from "../backend/api/src/handler.mjs";

const url = new URL(process.argv[2]);
if (url.hostname !== "127.0.0.1" || !url.pathname.startsWith("/vega_v2_writers_")) {
  throw new Error("Expected the disposable replay database");
}
const reader = createReader(url.href, { role: "vega_read" });
const serve = createHandler({ read: reader.read });
const server = createServer(async (req, res) => {
  try {
    const answer = await serve(new Request("http://127.0.0.1" + req.url, { headers: req.headers }));
    res.writeHead(answer.status, Object.fromEntries(answer.headers));
    res.end(Buffer.from(await answer.arrayBuffer()));
  } catch (error) {
    res.writeHead(500);
    res.end(String(error));
  }
});
server.listen(0, "127.0.0.1", () => console.log(server.address().port));
process.on("SIGTERM", () => server.close(async () => { await reader.end(); process.exit(0); }));
