"""Frozen local PostgreSQL probe. No provider or production connection."""
import copy
import csv
import io
import json
import sys
import uuid
from pathlib import Path
from datetime import datetime, timedelta, timezone
import psycopg
from psycopg import sql
from argparse import ArgumentParser
from local import ROOT as root, code

parser = ArgumentParser()
parser.add_argument("mode", choices=('historical', 'corrected'))
parser.add_argument("--port", type=int, default=5432)
args = parser.parse_args()
code(None if args.mode == "corrected" else args.mode)
from vega import sources
from vega.sources import open_matchday as omd, snapshot, sportscore
from vega.store import Store, migrate, connect_local
import sportscore_cases as cases
import sportscore_replay as sr

admin = f"postgresql://postgres@127.0.0.1:{args.port}/"
db = "vega_v2_astrareview_" + uuid.uuid4().hex
fx = root / "backend/tests/fixtures/open_matchday"
folder = "AUT_CUP_ofb-cup"
a = datetime(2027,2,11,15,tzinfo=timezone.utc)
def fetcher(mode):
    def get(url, as_text=False):
        if url.endswith('build_summary.json'):
            summary = json.loads((fx / 'build_summary.json').read_text())
            league = next(x for x in summary['leagues'] if x['folder'].endswith(folder))
            if mode in ('omit','finish'): league['fixtures'] -= 1
            if mode == 'finish': league['results'] += 1
            summary['leagues'] = [league]
            return summary
        relative = url.removeprefix(omd.RAW + 'data/')
        assert relative.startswith(folder + '/')
        raw = (fx / relative.replace('/','.')).read_text()
        reader = csv.DictReader(io.StringIO(raw))
        fields = reader.fieldnames
        items = list(reader)
        if mode == 'blank_round' and 'results_' in url:
            assert items[0]['home'] == 'Atus Velden'
            items[0]['gw'] = ''
        if mode in ('omit','finish') and 'fixtures_' in url:
            assert items[0]['home'] == 'Hartberg'
            items = items[1:]
        if mode == 'finish' and 'results_' in url:
            items.append(dict(gw='4', date='2027-02-10',home='Hartberg',away='A. Lustenau',ft_home='2',ft_away='1'))
        result = io.StringIO()
        writer = csv.DictWriter(result,fieldnames=fields)
        writer.writeheader(); writer.writerows(items)
        return result.getvalue()
    return get

def read(db,home):
    return db.execute("""SELECT m.id, m.revision, m.status::text, r.gw, r.home_score, r.away_score
        FROM api.cup_table_rows r JOIN core.matches m ON m.id=r.match_id WHERE r.home=%s""",(home,)).fetchone()

def run(db, get, now):
    return sources.run_due(db, get, now, names={'open_matchday'}).get(('open_matchday','europe'))

with psycopg.connect(admin+'postgres',autocommit=True) as ctl:
    if ctl.info.server_version // 10000 != 18:
        raise RuntimeError("PostgreSQL 18 on the loopback interface is required")
    ctl.execute(sql.SQL("CREATE DATABASE {}").format(sql.Identifier(db)))
    try:
        with connect_local(admin+db) as db1, connect_local(admin+db) as db2:
            migrate(db1)
            o = dict(server=db1.execute("SHOW server_version").fetchone()[0], source='AUT_CUP_ofb-cup:2026/2027')
            o['initial'] = [run(db1,fetcher('baseline'),a),read(db1,'Atus Velden'),read(db1,'Hartberg')]
            match=read(db1,'Hartberg')[0]
            with db1.transaction():
                db1.execute("INSERT INTO core.provider_ids(entity_type,entity_id,provider,provider_key,is_current) VALUES ('match',%s,'open_matchday','legacy:Hartberg-prev',false)",(match,))
            def keys():
                return db1.execute("SELECT provider_key,is_current FROM core.provider_ids WHERE provider='open_matchday' AND entity_type='match' AND entity_id=%s ORDER BY 1",(match,)).fetchall()
            o['before']=[read(db1,'Hartberg'),keys()]
            outcome=run(db1,fetcher('baseline'),a+timedelta(days=1))
            o['after']=[outcome,read(db1,'Hartberg'),keys()]
            print(json.dumps(o,indent=2))
    finally:
        ctl.execute(sql.SQL("DROP DATABASE {}").format(sql.Identifier(db)))
