"""Initialize a portable PostgreSQL replay, optionally importing the exact earlier writers."""
from contextlib import contextmanager
import importlib.abc
import importlib.util
from pathlib import Path
import sys
from uuid import uuid4

import psycopg
from psycopg import sql

ROOT = Path(__file__).resolve().parents[1]


class EarlierWriters(importlib.abc.MetaPathFinder):
    def __init__(self, baseline):
        self.baseline = baseline

    def find_spec(self, fullname, path=None, target=None):
        package = "vega.sources."
        if fullname.startswith(package):
            saved = ROOT / "baselines" / self.baseline / f"{fullname.removeprefix(package)}.py"
            if saved.is_file():
                return importlib.util.spec_from_file_location(fullname, saved)
        return None


def code(baseline=None):
    sys.path[:0] = [str(ROOT / "backend"), str(ROOT / "backend/tests")]
    if baseline:
        sys.meta_path.insert(0, EarlierWriters(baseline))


@contextmanager
def database(port):
    from vega.store import connect_local
    admin = f"postgresql://postgres@127.0.0.1:{port}/"
    name = "vega_v2_writers_" + uuid4().hex
    with psycopg.connect(admin + "postgres", autocommit=True) as ctl:
        if ctl.info.server_version // 10000 != 18:
            raise RuntimeError("PostgreSQL 18 on the loopback interface is required")
        ctl.execute(sql.SQL("CREATE DATABASE {}").format(sql.Identifier(name)))
        try:
            with connect_local(admin + name) as db:
                yield db, admin + name
        finally:
            ctl.execute(sql.SQL("DROP DATABASE {} WITH (FORCE)").format(sql.Identifier(name)))
