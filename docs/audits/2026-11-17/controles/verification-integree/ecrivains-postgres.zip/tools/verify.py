"""Verify receipt assertions and integrity using only the Python standard library."""
from argparse import ArgumentParser
from hashlib import sha256
import json
from pathlib import Path
import re

ROOT = Path(__file__).resolve().parents[1]


def require(condition, message):
    if not condition:
        raise SystemExit("REFUSÉ · " + message)


def load(name, directory=ROOT / "proof"):
    return json.loads((directory / name).read_text(encoding="utf-8"))


def integrity():
    manifest = load("manifest.json", ROOT)
    files = {p.relative_to(ROOT).as_posix() for p in ROOT.rglob("*") if p.is_file()
             and "node_modules" not in p.parts and "__pycache__" not in p.parts}
    require(files == set(manifest["files"]) | {"manifest.json"}, "l’inventaire des fichiers diffère")
    for name, spec in manifest["files"].items():
        data = (ROOT / name).read_bytes()
        require(len(data) == spec["bytes"] and sha256(data).hexdigest() == spec["sha256"], f"fichier altéré · {name}")
    return len(files)


def writers(before, after):
    require(before["blank_round"][1][3] is None, "le témoin initial doit perdre sa journée")
    require(after["initial"][1] == after["blank_round"][1] == after["repeat"][1], "la journée ou la révision a changé")
    require(before["A_resumed"][1] is None and before["final_key_count"] == 0, "le témoin initial doit perdre sa rencontre")
    finished = after["B_committed"][1]
    require(finished[2:] == ["finished", "4", 2, 1], "le résultat du producteur B diffère")
    require(after["A_resumed"][1] == finished and after["final_key_count"] == 1, "la rencontre, sa révision ou sa clé a changé")
    require(before["sportscore_impossible"][0] is None and before["sportscore_impossible"][1][2] == 17,
            "le témoin initial doit publier le nombre de victoires impossible")
    require(before["sportscore_reserve_alias"] == [["Aster City", "Aster City II", "sportscore"]],
            "le témoin initial doit créer l’alias erroné")
    table = ["Aster City", 4, 3, 1, 0, "sportscore"]
    require(after["sportscore_before"] == [None, table], "le classement valide diffère")
    require(after["sportscore_impossible"] == ["INVALID_ROW", table], "le classement a cédé à un bilan impossible")
    require(after["sportscore_reserve"] == ["UNMATCHED_TEAMS", table] and after["sportscore_reserve_alias"] == [],
            "le classement ou les alias ont changé après un nom de réserve")


def keys(before, after):
    require(before["after"] == ["ok", None, []], "le témoin initial doit perdre le match et ses deux clés")
    prior_match, prior_keys = after["before"]
    require(len(prior_keys) == 2 and {flag for _, flag in prior_keys} == {True, False}, "la paire de clés initiale diffère")
    require(after["after"] == ["ok", prior_match, prior_keys], "une clé de match a disparu au rejeu corrigé")


def http(proof, replayed):
    require(len(proof) == len(replayed) == 11, "nombre d’observations HTTP différent")
    refusals = 0
    versions = {}
    for trial, run in zip(proof, replayed):
        require(not trial["errors"] and run["label"] == trial["label"], "observation HTTP invalide")
        require(run["outcome"] == trial["actual"] == trial["expected"] and run["status"] == trial["status"] == 200,
                f"issue ou lecture HTTP différente · {trial['label']}")
        require([run["version"]] == trial["version"], f"version HTTP différente · {trial['label']}")
        versions[run["label"]] = run["version"]
        if run["outcome"] != "ok":
            refusals += 1
            require(trial["aliases_identical"] and trial["old_etag"] == trial["etag"] and trial["conditional"] == 304
                    and run["conditional"] == 304 and run["etag_stable"] and run["aliases_stable"],
                    f"ETag ou alias modifié par un refus · {trial['label']}")
        if trial["label"] == "coherent-correction":
            require(run["conditional"] == 200 and not run["etag_stable"], "l’ETag n’a pas suivi la correction admise")
    require(refusals == 6 and versions["coherent-correction"] == versions["coherent-correction-repeated"],
            "nombre de refus ou répétition de la version différent")


def aliases(replayed):
    before = load("aliases.json")
    for result in (before, replayed):
        require((result["aliases"], result["official_editions"], result["aliases_without_official_edition"],
                 result["checks"], result["failures"]) == (838, 60, 20, 872, []), "les graphies capturées ou leur appariement diffèrent")
    for name, digest in replayed["source"].items():
        require(sha256((ROOT / "inputs" / name).read_bytes()).hexdigest() == digest, f"entrée d’alias différente · {name}")


def evidence(directory, negative):
    before, after = (load(f"writers-{mode}.json", directory) for mode in ("before", "after"))
    if negative:
        after["final_key_count"] = 0
    writers(before, after)
    keys(*(load(f"keys-{mode}.json", directory) for mode in ("before", "after")))
    http(load("http.json"), load("http-replayed.json", directory))
    aliases(load("aliases-replayed.json", directory))
    t2 = load("t2.json")
    require(len(t2) == 28 and all(not item["errors"] and item["expected"] == item["actual"] for item in t2),
            "la suite T2 ne conserve pas ses 28 observations")
    for path in ("green-final-open-matchday.log", "green-final-sportscore.log"):
        log = (ROOT / "proof" / path).read_text()
        require("Ran 36 tests" in log and log.rstrip().endswith("OK"), f"suite ciblée incomplète · {path}")
    for path in ("red-final-open-matchday.log", "red-final-sportscore.log", "red-old-match-keys.log", "red-reviewed-variants.log"):
        require(re.search(r"^FAILED \(failures=[1-9]", (ROOT / "proof" / path).read_text(), re.M), f"témoin rouge manquant · {path}")


parser = ArgumentParser()
parser.add_argument("--replay-dir", type=Path, default=ROOT / "proof")
parser.add_argument("--negative", action="store_true")
options = parser.parse_args()
verified = integrity()
evidence(options.replay_dir, options.negative)
print(f"VÉRIFIÉ · {verified} fichiers, cinq correctifs, 72 tests ciblés, 11 observations HTTP, 28 T2, 838 alias")
