"""Inspection statique des objets Git et arithmétique indépendante des témoins, sans lancer l'application."""
import collections,csv,hashlib,io,json,os,re,subprocess,sys,zipfile
import xml.etree.ElementTree as ET
from pathlib import Path
w=Path(os.environ['VEGA_REPO']) if 'VEGA_REPO' in os.environ else None
out=Path(__file__).resolve().parent
s='08fa22e7875dd971e4e2ea415d6d5be13eb72347'
ref='599b80497ca7b49d65714f3d54e709c97c0cbe7f'
def blob(sha,path):
 if w is None:
  loc=out/'objets'/sha/path
  data=loc.read_bytes()
  manifest=json.loads((out/'objets.json').read_text())
  assert hashlib.sha256(data).hexdigest()==manifest[sha+':'+path]['sha256'],path
  return data
 return subprocess.check_output(['git','-C',str(w),'show',sha+':'+path])
def pair(r):
 x=r.get('score')
 if isinstance(x,list):return x
 if isinstance(x,dict):return x.get('et') or x.get('ft')
def ranks(rows,pts):
 d={}
 for r in rows:
  p=pair(r)
  if not p:continue
  a,b=r['team1'],r['team2']
  for n,gs,ga in [(a,p[0],p[1]),(b,p[1],p[0])]:
   t=d.setdefault(n,[0,0,0,0]);t[0]+=1;t[1]+=pts if gs>ga else int(gs==ga);t[2]+=gs-ga;t[3]+=gs
 return sorted([[k,*v] for k,v in d.items()],key=lambda t:(-t[2],-t[3],-t[4],t[0]))
path='backend/tests/fixtures/openfootball/editions.json'
raw=blob(ref,path);ed=json.loads(raw)['editions']
wc50=[r for r in ed['world-cup-history:1950']['matches'] if r['round']=='Final Round']
euro20=[r for r in ed['euro:2020']['matches'] if r.get('group')=='Group F']
wc54=ed['world-cup-history:1954']['matches']
euro28=ed['euro:2028']['matches']
report={'sha':s,'archive_fixture':{'commit':ref,'path':path,'sha256':hashlib.sha256(raw).hexdigest()},'row_format':['team','played','points','goal_difference','goals_for'],
'world_cup_1950':{'final_pool':wc50,'three_points':ranks(wc50,3),'two_points':ranks(wc50,2),'last_uruguay':sorted([r for r in wc50 if 'Uruguay' in [r['team1'],r['team2']]],key=lambda r:r['date'])[-1]},
'euro_2020':{'matches':euro20,'group_F_generic_order':ranks(euro20,3),'next_round':[(r['team1'],r['team2']) for r in ed['euro:2020']['matches'] if r['round']=='Round of 16' and ({r['team1'],r['team2']}&{'Germany','Portugal'})]},
'world_cup_1954':{'group_2_regular':ranks([r for r in wc54 if r.get('group')=='Group 2'],3),'playoff':[r for r in wc54 if r.get('round')=='Group 2 Play-off'],'quarterfinals':[(r['team1'],r['team2']) for r in wc54 if r.get('round')=='Quarter-finals']},
'euro_2028':dict(matches=len(euro28),groups_in_round=collections.Counter(r['round'] for r in euro28 if re.fullmatch('Group [A-F]',r['round'])),known_group_fields=sum(bool(r.get('group')) for r in euro28),final_round_fields=sum(r['round']=='Final Round' for r in euro28))}
assert len(wc50)==6 and ranks(wc50,3)[0][2]==7 and ranks(wc50,2)[0][2]==5
assert [r[0] for r in ranks(euro20,3)][1:3]==['Portugal','Germany']
assert sum(report['euro_2028']['groups_in_round'].values())==36 and not report['euro_2028']['known_group_fields']
wb='docs/vega-sport-data-coverage.xlsx';data=blob(s,wb);z=zipfile.ZipFile(io.BytesIO(data));n='{http://schemas.openxmlformats.org/spreadsheetml/2006/main}'
ss=[''.join(i.itertext()) for i in ET.fromstring(z.read('xl/sharedStrings.xml'))]
root=ET.fromstring(z.read('xl/worksheets/sheet3.xml'))
formulas=sum(len(ET.fromstring(z.read(f)).findall('.//'+n+'f')) for f in z.namelist() if re.fullmatch(r'xl/worksheets/sheet\d+.xml',f))
meta={'sha256':hashlib.sha256(data).hexdigest(),'worksheets':[x.get('name') for x in ET.fromstring(z.read('xl/workbook.xml')).findall('.//'+n+'sheet')],'formula_cells':formulas,'calculations':[]}
for r in root.findall('.//'+n+'row'):
 idx=int(r.get('r'))
 if idx<8:continue
 vals=[(ss[int(v.text)] if c.get('t')=='s' else ''.join(c.itertext())) for c in r if (v:=c.find(n+'v')) is not None]
 meta['calculations'].append({'row':idx,'name':vals[0],'grain':vals[1]})
meta['denominator_rows']={}
for sheet_index, name in [(2,'Competitions'),(4,'PitchAPI'),(6,'Open Matchday'),(7,'OpenFootball'),(22,'Evidence')]:
 root=ET.fromstring(z.read(f'xl/worksheets/sheet{sheet_index}.xml'))
 found=[]
 for row in root.findall('.//'+n+'row'):
  values={cell.get('r'): (ss[int(v.text)] if cell.get('t')=='s' else ''.join(cell.itertext())) for cell in row if (v:=cell.find(n+'v')) is not None}
  joined=' '.join(values.values()).lower()
  if (row.get('r')=='7' or '2019-20/fr.1' in joined or 'national-league-north' in joined or 'national-league-south' in joined or 'northern-premier-league' in joined or 'saudi women' in joined or ('world-cup-history:1950' in joined) or (sheet_index==22 and int(row.get('r')) in [3,8,9,10,11])):found.append(values)
 meta['denominator_rows'][name]=found
report['workbook']=meta
wc=[(k,r) for k,v in ed.items() if k.startswith('world-cup-history:') for r in v['matches']]
report['bare_scores']={'editions':sum(k.startswith('world-cup-history:') for k in ed),'matches':len(wc),'bare_pairs':sum(isinstance(r.get('score'),list) for k,r in wc),'explicitly_canceled':[(k,r) for k,r in wc if r.get('status')=='canceled']}
mapping = {8:'C23 / A16a',9:'A17a, family xG; no corresponding distinct C01–26',10:'C20 / A09b / A10',11:'C21 / A08',12:'A02 / C22',13:'C18 / C21 / A09a',14:'E03f / E04n',15:'E03f, head-to-head; no distinct C01–26',16:'C16 / A17a, new scope of archive groups',17:'C18,C19,C21 / A08,A15c',18:'A17a / C18,C19',19:'A08 / C18,C21',20:'C21 / A08',21:'C09,C18,C21,C24 / A13',22:'A03,A13b,A16c,A18d / E04f',23:'E04f,E04i / A02,A16c',24:'A03,A16c,A18d',25:'C05,C07,C08 / E04g',26:'C07,C12 / A03',27:'C09 / A13a',28:'C24 / A13d',29:'A17a; no distinct C01–26',30:'C13,C15 / A06,A11,A15a,A16b',31:'C16 / A05–07',32:'C06,C10,C11,C14',33:'A04,A11c,A12',34:'A11a,A11b,A14',35:'A15d,A17a',36:'A17a; no distinct C01–26',37:'C25 / A15g,N04',38:'C01,C21 / A14b',39:'existing demographic reader; no distinct C01–26',40:'existing discipline/status scope; no distinct C01–26',41:'A11c; no distinct C01–26'}
for r in meta['calculations']:r['old_registry_relation']=mapping[r['row']]
report['tests']={}
for f in ['tests/tournament-editions.test.mjs','tests/euro-search-flags.test.mjs','tests/competition-render.test.mjs','tests/cup-render.test.mjs','tests/cup-forecast.test.mjs','tests/complementary-leagues.test.mjs','backend/tests/test_sources.py']:
 t=blob(s,f).decode().splitlines(); report['tests'][f]=[{ 'line':i,'name':line.strip()} for i,line in enumerate(t,1) if (f.endswith('mjs') and re.match(r'^test\(',line) or 'def test_an_edition_read_before_the_bare_scores' in line or 'def test_archive_scores_written_as_a_bare_pair' in line or 'def test_open_cup' in line)]
(out/'preuves-statiques.json').write_text(json.dumps(report,ensure_ascii=False,indent=2)+'\n')
print('OK',len(ed),'éditions de preuve,',len(meta['calculations']),'rubriques Excel,',formulas,'formules Excel')
