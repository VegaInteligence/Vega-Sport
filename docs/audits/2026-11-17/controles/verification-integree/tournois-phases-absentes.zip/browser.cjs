async page => {
  const mirrors=__WITNESSES__, origin='https://vegasport.vercel.app', out=__OUT__;
  const results=[];
  page.setDefaultTimeout(12000);
  await page.setViewportSize({width:1440,height:900});
  for(const [key,witness] of Object.entries(mirrors)) {
    await page.goto(origin+'/nations/?id='+witness.nation_id+'&season=2026%2F2027',{waitUntil:'domcontentloaded'});
    await page.getByRole('complementary',{name:'Identité de la sélection'}).getByRole('heading').waitFor();
    await page.getByRole('tab',{name:'Historique',exact:true}).click();
    const panel=page.getByRole('tabpanel',{name:'Historique',exact:true});
    const link=panel.locator('a[href*="edition='+witness.curated_edition+'"][href*="'+key+'"]');
    await link.waitFor();
    const tile=await link.evaluate(node=>({
      text:node.innerText.replace(/\s+/g,' ').trim(),stageDisplay:node.querySelector('[class*="runStage"]')?.innerText.trim(),
      title:node.title,tone:node.getAttribute('data-tone'),gaugeBars:node.querySelectorAll('i').length,
      gaugeFilled:node.querySelectorAll('i[data-on]').length,
      medals:[...node.parentElement.parentElement.querySelectorAll('[aria-label*="titre"],[aria-label*="fois"]')].map(el=>el.getAttribute('aria-label')),
      href:node.getAttribute('href'),
    }));
    await link.evaluate(el=>el.scrollIntoView({block:'center',behavior:'instant'}));
    await page.screenshot({path:out+'/'+key+'-tuile.png',animations:'disabled',scale:'css'});
    await link.focus();
    await link.press('Enter');
    await page.waitForURL(url=>url.searchParams.get('edition')===String(witness.curated_edition)&&url.searchParams.get('id')==='nations-results:'+key);
    const selector=page.getByRole('combobox',{name:'Édition de la coupe',exact:true});
    await selector.waitFor();
    const matches=page.getByRole('searchbox',{name:'Rechercher une équipe dans la coupe'});
    await matches.waitFor();
    await page.locator('.cup-match').first().waitFor();
    const detail={url:page.url(),year:await selector.inputValue(),matchSearch:await matches.isVisible(),
      bracket:await page.getByRole('region',{name:'Tableau éliminatoire'}).count(),
      heading:await page.locator('.edition-head h1,.edition-head h2').innerText(),
      firstMatch:await page.locator('.cup-match').first().innerText()};
    results.push({key,nation_id:witness.nation_id,tile,detail});
  }
  return {at:new Date().toISOString(),results};
}
