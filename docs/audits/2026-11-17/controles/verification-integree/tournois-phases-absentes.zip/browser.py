"""Reproduce the UI witnesses with the installed Playwright CLI."""
from datetime import datetime, timezone
import hashlib
import json
from pathlib import Path
import subprocess
import sys
from uuid import uuid4

here = Path(__file__).resolve().parent
cli, chromium = map(Path, sys.argv[1:])
out = here / "browser"
out.mkdir()
config = out / "config.json"
config.write_text(json.dumps({"browser":{"browserName":"chromium","launchOptions":{"executablePath":str(chromium)}}}))
session = "phases-1633-" + uuid4().hex[:9]
command = [str(cli), "--session=" + session]
started = datetime.now(timezone.utc).isoformat()


def call(tag, *parts):
    result = subprocess.run([*command,*parts], cwd=out, text=True, capture_output=True, timeout=120)
    (out / (tag+".log")).write_text(result.stdout+"\n"+result.stderr)
    assert not result.returncode and "### Error" not in result.stdout, tag
    return result.stdout


call("open","open","https://vegasport.vercel.app/nations/","--config",str(config))
try:
    evidence = (here/"capture"/"result.json").read_text()
    code = (here/"browser.cjs").read_text().replace("__WITNESSES__",evidence).replace("__OUT__",json.dumps(str(out)))
    raw = call("run","run-code",code)
    observation = json.loads(raw.split("### Result\n",1)[1].split("\n###",1)[0])
    assert len(observation["results"]) == 4
    for case in observation["results"]:
        assert case["tile"]["stageDisplay"] == "1er tour"
        assert case["tile"]["tone"] is None and case["tile"]["gaugeFilled"] == 1
        assert case["detail"]["matchSearch"] and not case["detail"]["bracket"]
    (out/"result.json").write_text(json.dumps(observation,ensure_ascii=False,indent=2)+"\n")
finally:
    call("close","close")
    receipt = {"started":started,"finished":datetime.now(timezone.utc).isoformat(),
               "command":[sys.executable,str(Path(__file__).resolve()),*sys.argv[1:]], "session":session,
               "files":{str(f.relative_to(out)):hashlib.sha256(f.read_bytes()).hexdigest() for f in sorted(out.rglob("*")) if f.is_file()}}
    (out/"receipt.json").write_text(json.dumps(receipt,indent=2)+"\n")
