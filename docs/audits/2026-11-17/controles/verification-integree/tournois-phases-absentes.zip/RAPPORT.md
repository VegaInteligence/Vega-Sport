# L18 · Phases absentes dans quatre tournois

**Quatre champions apparaissent « 1er tour », avec une barre remplie et aucune médaille.** Le lecteur public identifie la bonne édition et sert la finale terminée au bon jour et au bon score. Les 166 matchs des quatre éditions examinées viennent de snapshots `results-v1` International Results. Aucun ne porte de champ `round`. La finale de chaque fiche Nations contient `round: null`. Le CSV amont porte la compétition et le score, avec aucune colonne de tour. [HTTP](capture/result.json) · [En-tête et quatre lignes amont](upstream-receipt.json) · [Rejeu écran](browser/result.json)

| Édition | Champion et ID Nations | Finale attestée et retrouvée | Matchs fiche / édition | Source officielle |
|---|---|---|---:|---|
| Copa América 2024 | Argentine `t_0WmIZB` | 14 juillet 2024, Argentine 1–0 Colombie | 6 / 32 | [CONMEBOL](https://cdn.conmebol.com/wp-content/uploads/2025/01/GET-CONMEBOL-Copa-America-USA-2024-ESP-1.pdf) |
| CAN 2023 | Côte d’Ivoire `t_4NoJRj` | 11 février 2024, Côte d’Ivoire 2–1 Nigeria | 7 / 52 | [CAF](https://www.cafonline.com/en/caf-africa-cup-of-nations/news/facts-and-figures-cote-divoire-defeat-nigeria-to-win-totalenergies-caf-afcon/) |
| Coupe d’Asie 2023 | Qatar `t_3cJCtQ` | 10 février 2024, Qatar 3–1 Jordanie | 7 / 51 | [AFC](https://www.the-afc.com/en/national/afc_asian_cup/archive/2023.html) |
| Gold Cup 2023 | Mexique `t_0IuuRb` | 16 juillet 2023, Mexique 1–0 Panama | 6 / 31 | [Concacaf](https://www.concacaf.com/competitions/gold-cup/news/gimenez-s-late-strike-earns-mexico-ninth-gold-cup-crown) |

Les quatre tuiles ouvrent la liste des matchs de la bonne édition. L’adresse porte `view=tableau` alors que la vue est Matchs et que le tableau éliminatoire est indisponible. Dans le code public, `stageKind` transforme le tour vide en `group`, le lecteur nomme cette valeur « 1er tour » et `runDepth` lui donne une seule barre. [Témoins navigateur](browser/result.json) · [Classification API](source-stageKind.txt) · [Jauge](source-renderer.txt)

## Proposition pour Opus B

Renvoyer un état « Phase non renseignée » quand le tour qui justifierait le palmarès manque. Garder l’édition, le lien et le nombre de matchs. Omettre la jauge dans cet état. Préserver « 1er tour » quand une phase de groupe est attestée et la médaille seulement pour une phase et un résultat qualifiés. Sur une page `results-v1`, adresser la liste avec `view=matchs`. Ce filet de représentation couvre les quatre cas sans déduire la phase de la seule dernière victoire ou du nombre de rencontres. Le classement définitif et le tableau dépendent du rapprochement du calendrier de chaque propriétaire avec les tours attestés des organisateurs.

## Reproduction

À partir d’un dossier neuf, exécuter `python3 -B probe.py`, `python3 -B upstream.py`, puis `python3 -B browser.py "$PLAYWRIGHT_CLI" "$CHROMIUM"`. Les commandes interrogent les routes publiques habituelles. `python3 -B verifier.py` relit les preuves conservées hors ligne. Les quatre témoins ont été mesurés le 18 novembre 2026 à partir de 16 h 53 UTC sur le lecteur courant. [Reçu navigateur](browser/receipt.json)
