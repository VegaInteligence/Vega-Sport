"""Verify that the deployed source's upstream CSV carries tournament names and scores, with no round."""
import csv
from datetime import datetime, timezone
import hashlib
import io
import json
from pathlib import Path
from urllib.request import Request, urlopen

ROOT = Path(__file__).resolve().parent
url = "https://raw.githubusercontent.com/martj42/international_results/master/results.csv"
witnesses = {
    ("2024-07-14", frozenset(("Argentina","Colombia"))),
    ("2024-02-11", frozenset(("Ivory Coast","Nigeria"))),
    ("2024-02-10", frozenset(("Qatar","Jordan"))),
    ("2023-07-16", frozenset(("Mexico","Panama"))),
}
started = datetime.now(timezone.utc).isoformat()
with urlopen(Request(url, headers={"Accept":"text/csv"}), timeout=20) as response:
    raw = response.read()
    receipt = {"at":started,"status":response.status,"url":response.url,"etag":response.headers.get("etag"),
               "sha256":hashlib.sha256(raw).hexdigest(),"bytes":len(raw)}
rows = csv.DictReader(io.StringIO(raw.decode()))
assert rows.fieldnames == ["date","home_team","away_team","home_score","away_score","tournament","city","country","neutral"]
selection = [row for row in rows if (row["date"], frozenset((row["home_team"],row["away_team"]))) in witnesses]
assert len(selection) == 4
receipt.update(header=rows.fieldnames, verified_fields=selection)
(ROOT/"upstream-receipt.json").write_text(json.dumps(receipt,ensure_ascii=False,indent=2)+"\n")
print(receipt["status"],len(selection),"matched rows with no round column")
