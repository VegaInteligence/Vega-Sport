"""Check that the recorded HTTP, source schema and Chromium observations agree."""
import hashlib
import json
from pathlib import Path
from urllib.parse import parse_qs, urlsplit

root = Path(__file__).resolve().parent
def read(relative):
    return json.loads((root/relative).read_bytes())
def sha(relative):
    return hashlib.sha256((root/relative).read_bytes()).hexdigest()

api = read("capture/result.json")
browser = {r["key"]:r for r in read("browser/result.json")["results"]}
upstream = read("upstream-receipt.json")
assert upstream["status"] == 200 and len(upstream["verified_fields"]) == 4
assert "round" not in upstream["header"] and "tournament" in upstream["header"]
assert len(browser) == len(api) == 4
assert sum(r["known_matches_cup"] for r in api.values()) == 166
for key, row in api.items():
    assert row["format"] == "results-v1" and row["phase_fields_present_cup"] == 0 and row["phases_nonempty_nation"] == []
    assert row["nation_run"]["year"] == row["curated_edition"] and row["nation_run"]["stage"] == "1er tour"
    assert "tone" not in row["nation_run"]
    for name in ("final_in_nation_run","final_in_cup_source"):
        game, = row[name]
        date = row["citations"]["official_date"]
        assert game["date"] == date and game["status"] == "finished" and game["round"] is None
        assert game["winner_oriented_score"] == row["citations"]["official_score_winner_side"]
    tile, detail = browser[key]["tile"], browser[key]["detail"]
    assert tile["stageDisplay"] == "1er tour" and tile["gaugeFilled"] == 1 and not tile["tone"] and not tile["medals"]
    assert detail["matchSearch"] and not detail["bracket"]
    assert parse_qs(urlsplit(detail["url"]).query)["view"] == ["tableau"]
for receipt in sorted((root/"capture").glob("*.receipt.json")):
    row=json.loads(receipt.read_bytes())
    assert row["status"] == 200 and sha("capture/"+receipt.name.replace(".receipt.json",".json")) == row["sha256"]
for relative, value in read("browser/receipt.json")["files"].items():
    assert sha("browser/"+relative) == value, relative
print("PASS — 4 scores officiels, 4 phases absentes, 4 tuiles fausses et 4 liens résultats")
