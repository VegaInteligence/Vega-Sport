"""Reproduce four public tournament-phase witnesses using the normal Vega reader."""
from concurrent.futures import ThreadPoolExecutor
from datetime import datetime, timezone
import hashlib
import json
from pathlib import Path
import re
import sys
import unicodedata
from urllib.parse import urlencode
from urllib.request import Request, urlopen

BASE = "https://dngp6kh9jx2bl.cloudfront.net"
OUT = Path(sys.argv[1]).resolve() if len(sys.argv) == 2 else Path(__file__).resolve().parent / "capture"
OUT.mkdir(parents=True, exist_ok=False)
CURRENT = "2026/2027"
WITNESSES = {
    "copa-america": {"name":["Argentina","Argentine"], "year":2024, "date":"2024-07-14", "other":["Colombia","Colombie"],"winner_score":[1,0],
                     "authority":"https://cdn.conmebol.com/wp-content/uploads/2025/01/GET-CONMEBOL-Copa-America-USA-2024-ESP-1.pdf"},
    "afcon": {"name":["Côte d’Ivoire","Cote d'Ivoire","Ivory Coast"], "year":2023, "date":"2024-02-11", "other":["Nigeria"],"winner_score":[2,1],
              "authority":"https://www.cafonline.com/en/caf-africa-cup-of-nations/news/facts-and-figures-cote-divoire-defeat-nigeria-to-win-totalenergies-caf-afcon/"},
    "asian-cup": {"name":["Qatar"], "year":2023, "date":"2024-02-10", "other":["Jordan","Jordanie"],"winner_score":[3,1],
                  "authority":"https://www.the-afc.com/en/national/afc_asian_cup/archive/2023.html"},
    "gold-cup": {"name":["Mexico","Mexique"], "year":2023, "date":"2023-07-16", "other":["Panama"],"winner_score":[1,0],
                  "authority":"https://www.concacaf.com/competitions/gold-cup/news/gimenez-s-late-strike-earns-mexico-ninth-gold-cup-crown"},
}


def norm(value):
    base = unicodedata.normalize("NFKD", str(value).casefold())
    return "".join(c for c in base if c.isalnum())


def fetch(name, path, **params):
    url = BASE + path + ("?" + urlencode(params) if params else "")
    request = Request(url, headers={"Accept": "application/json", "User-Agent": "Vega public tournament audit"})
    start = datetime.now(timezone.utc).isoformat()
    with urlopen(request, timeout=20) as response:
        data = response.read()
        info = {
            "at": start, "url": response.url, "status": response.status, "etag": response.headers.get("ETag"),
            "age": response.headers.get("Age"), "sha256": hashlib.sha256(data).hexdigest(), "bytes": len(data),
        }
    (OUT / (name + ".json")).write_bytes(data)
    (OUT / (name + ".receipt.json")).write_text(json.dumps(info, indent=2) + "\n")
    return json.loads(data)


def matches(teams, values):
    return set(map(norm, teams)) & set(map(norm, values))


def name(value):
    return (value or {}).get("name") if isinstance(value,dict) else value


def qualified(value):
    return bool(value and str(value).strip())


def judge_match(row, witness):
    side1 = name(row.get("home")) or row.get("team1")
    side2 = name(row.get("away")) or row.get("team2")
    home_is_champion = bool(matches((side1,), witness["name"]) and matches((side2,), witness["other"]))
    away_is_champion = bool(matches((side2,), witness["name"]) and matches((side1,), witness["other"]))
    if not (home_is_champion or away_is_champion) or row.get("date") != witness["date"]:
        return None
    score = row.get("score", [row.get("homeScore"), row.get("awayScore")])
    if isinstance(score, dict):
        score = score.get("et") or score.get("ft")
    return {"date": row["date"], "home": side1, "away": side2,
            "score": score, "winner_oriented_score": score if home_is_champion or score is None else score[::-1],
            "round": row.get("round"), "status": row.get("status"), "edition": row.get("edition")}


def main():
    with ThreadPoolExecutor(2) as pool:
        nation_index = pool.submit(fetch, "nation-index", "/api/nations", season=CURRENT)
        cup_index = pool.submit(fetch, "cup-index", "/api/cups/index")
        nations = nation_index.result()["data"]
        cups = cup_index.result()["cups"]
    if isinstance(nations, dict):
        nations = nations.get("nations") or nations.get("teams")
    snapshots = {}
    with ThreadPoolExecutor(4) as pool:
        for key, witness in WITNESSES.items():
            nation = [v for v in nations if matches((v["name"],), witness["name"])]
            catalog = [v for v in cups if v["key"] == key and str(witness["year"]) in map(str, v["seasons"])]
            assert len(nation) == 1, (key,nation)
            assert len(catalog) == 1, (key,catalog)
            ident, cup = nation[0]["id"], catalog[0]
            profile = pool.submit(fetch, key+"-nation", "/api/nations/"+ident, season=CURRENT)
            snap = pool.submit(fetch, key+"-snapshot", "/api/cup-snapshot", kind="edition", competition=cup["id"], season=witness["year"])
            snapshots[key] = (ident, cup, profile, snap)
    evidence = {}
    for key, (ident, cup, profile_call, snap_call) in snapshots.items():
        witness = WITNESSES[key]
        profile, snap = profile_call.result()["data"], snap_call.result()
        editions = [r for r in profile["tournaments"] if r["tournament"] == key and r["year"] == witness["year"]]
        assert len(editions) <= 1
        tournament = editions[0] if editions else None
        games = tournament["games"] if tournament else []
        matches_rows = snap.get("matches") or []
        check = {
            "nation": profile["name"], "nation_id": ident, "tournament":key, "curated_edition":witness["year"],
            "catalog_competition_id":cup["id"], "format":cup["format"], "source":snap.get("source"),
            "known_matches_cup":len(matches_rows), "phase_fields_present_cup":sum("round" in row for row in matches_rows),
            "phases_nonempty_cup":sorted({str(row["round"]) for row in matches_rows if qualified(row.get("round"))}),
            "nation_run": {k: v for k,v in tournament.items() if k not in {"games"}} if tournament else None,
            "phases_nonempty_nation":sorted({str(row["round"]) for row in games if qualified(row.get("round"))}),
            "citations": {"federal_final":witness["authority"],"official_date":witness["date"],"official_score_winner_side":witness["winner_score"]},
            "final_in_nation_run":[m for row in games if (m:=judge_match(row,witness)) is not None],
            "final_in_cup_source":[m for row in matches_rows if (m:=judge_match(row,witness)) is not None],
        }
        evidence[key] = check
    (OUT/"result.json").write_text(json.dumps(evidence,ensure_ascii=False,indent=2)+"\n")
    print(json.dumps(evidence,ensure_ascii=False,indent=2))


if __name__ == "__main__":
    main()
