# L18 · Parcours Nations en production

Vérifier avec deux profils Chromium isolés, en 393 × 852 et 1440 × 900. Ouvrir `/nations`, activer toutes les sélections, rechercher France et Italie et ouvrir leur résultat d’index. Contrôler les identifiants publics `t_2ysHaw` et `t_v0001032` et les rails d’identité. Parcourir Matchs, Joueurs et Historique. Le relevé API de 15 h 47 signale deux finales archivées sans score. Relever le libellé réellement visible dans l’historique et le statut présenté dans la liste des matchs lorsqu’il apparaît. Vérifier le lien de retour à l’index et un aller-retour via un match natif ou un joueur d’une sélection.

La navigation est une vérification de lecture. Le palmarès et les scores sont comparés séparément au relevé national RDS en lecture seule et au rejeu local de l’ingestion.
