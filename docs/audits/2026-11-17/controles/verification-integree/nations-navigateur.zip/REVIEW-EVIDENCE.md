# L18 · Nations en production

Le 18 novembre 2026 entre 16 h 10 min 19 s et 16 h 10 min 24 s UTC, les deux parcours publics ont abouti sur iPhone 16 simulé (393 × 852) et ordinateur (1440 × 900). Le palmarès reste incomplet à l’écran pour France 1998 et Italie 1982. [Résultat mobile](observation-393/result.json) · [Résultat ordinateur](observation-1440/result.json)

| Parcours | Observation sur les deux formats |
| --- | --- |
| Index et recherche | 153 sélections visibles avec le filtre « Toutes les sélections », dont 54 classées cette saison. La recherche ouvre France `t_2ysHaw` et Italie `t_v0001032`, avec le bon nom dans le rail d’identité. Le lien « Toutes les nations » revient à l’index pour chacune. |
| France · Matchs et Historique | Brésil–France du 12 juillet 1998 apparaît « à venir », sans score ni lien de fiche match. L’historique affiche « 1998 Finale » sans marque de victoire. [Match mobile](observation-393/finale-france.png) · [Historique mobile](observation-393/palmares-france.png) |
| Italie · Matchs et Historique | Italie–West Germany du 11 juillet 1982 apparaît « à venir », sans score ni lien de fiche match. L’historique affiche « 1982 Finale » sans marque de victoire. [Match ordinateur](observation-1440/finale-italie.png) · [Historique ordinateur](observation-1440/palmares-italie.png) |
| Joueurs | France affiche 22 joueurs pour la Coupe du monde 2026, avec le lien de Mike Maignan `p_0dlKzP` échantillonné. Italie ouvre l’onglet et affiche « Aucune statistique de joueur collectée pour cette sélection. » Le parcours Italie observé ne propose pas de lien vers une fiche match native. [Joueurs France](observation-393/joueurs-france.png) · [Joueurs Italie](observation-393/joueurs-italie.png) |
| Aller-retour international | L’ouverture de France–Angleterre `m_1HdHEO` depuis Matchs montre le lien France, qui ramène à `/nations` avec `id=t_2ysHaw`. [Lien match → France](observation-393/match-vers-france.png) |

Les réponses Nations vues par Chromium viennent du canal CloudFront et renvoient HTTP 200 pour l’index et les deux identifiants. Les douze contrôles de chaque session sont sans erreur. Le premier essai du harnais exigeait une barre finale dans les URL des liens. Le sélecteur a été corrigé pour accepter les formes servies, puis les tuiles mobiles ont été centrées pour produire les captures finales. Les captures et reçus sont ceux de cette dernière exécution.

## Concordance avec RDS et la branche

- À 15 h 47 UTC, le relevé HTTP montrait les mêmes deux finales `not_started`, sans score ni verdict. [Relevé HTTP](api-1547.json)
- La transaction RDS en lecture seule du 18 novembre à 16:02:54 UTC couvre 153 sélections, 1 628 clés de rencontre, 132 groupes de copies et zéro score terminé masqué. Les deux dates et paires canoniques des finales ne contiennent respectivement que l’archive OpenFootball 836 et l’archive 1056. Chacune est `not_started`, sans but. Pour ces témoins, l’état publié provient donc des scores archivés absents. [Projection RDS](rds-160254.json) · [Provenance](provenance.json)
- Le rejeu local de `d29eac65d75ca4eb038a2fc5b24e1bb93d1ae2ab` corrige ces deux archives et sert Italie 3–1 RFA et Brésil 0–3 France, `finished`, `Vainqueur` et sept matchs terminés pour chaque campagne. Le passage suivant effectue zéro écriture et répond deux fois HTTP 304. Cette correction reste une preuve de branche sur copie. [Résultat de branche](branche-rejeu.json)

## Reproduction

Le vérificateur hors ligne contrôle les empreintes, les dimensions des images, les parcours observés et la concordance des trois sources de preuve.

```sh
python3 -B verifier.py
```

Pour une nouvelle observation réseau, utiliser le lanceur Playwright CLI et un Chromium local déjà installés. Copier `browser-config.example.json` vers `browser-config.json` et y régler le chemin du binaire Chromium. Employer des noms de sessions et de dossiers inédits.

```sh
python3 -B run.py 393 mobile-neuf --cli "$PLAYWRIGHT_CLI" --config browser-config.json --session l18-mobile-neuf
python3 -B run.py 1440 bureau-neuf --cli "$PLAYWRIGHT_CLI" --config browser-config.json --session l18-bureau-neuf
```

La qualification navigateur porte sur les tailles, les sélections et le match international échantillonnés. Le relevé RDS décrit l’état de la transaction horodatée.

