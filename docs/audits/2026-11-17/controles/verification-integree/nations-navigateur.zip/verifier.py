"""Verify the captured L18 browser, API, RDS and replay evidence offline."""
from hashlib import file_digest
import json
from pathlib import Path
import struct
from urllib.parse import parse_qs, urlparse


ROOT = Path(__file__).resolve().parent
TARGETS = {"France": ("t_2ysHaw", "1998", "france", 1056, [0, 3]),
           "Italie": ("t_v0001032", "1982", "italie", 836, [3, 1])}


def fetch(path):
    return json.loads((ROOT / path).read_bytes())


def digest(path):
    with path.open("rb") as source:
        return file_digest(source, "sha256").hexdigest()


def check_files():
    files = fetch("manifest.json")
    for name, value in files.items():
        path = ROOT / name
        assert path.is_file() and path.stat().st_size == value["bytes"], name
        assert digest(path) == value["sha256"], name
    return len(files)


def image_size(path):
    content = path.read_bytes()
    assert content.startswith(b"\x89PNG\r\n\x1a\n") and content[12:16] == b"IHDR", path
    return struct.unpack(">II", content[16:24])


def outcome():
    count = check_files()
    rds, api, branch = map(fetch, ["rds-160254.json", "api-1547.json", "branche-rejeu.json"])
    assert rds["readonly"] == "on" and rds["at"].startswith("2026-11-18 16:02:54")
    population, *physical = rds["rows"]
    assert population[0] == "population"
    assert population[1]["eligible_nations"] == 153 and population[1]["logical"] == 1628
    assert population[1]["multiple"] == 132 and population[1]["native_masks_finished_pair"] == 0
    assert len(physical) == 2 and {r["id"] for _, r in physical} == {836,1056}
    assert all(r["status"] == "not_started" and r["home_score"] is None and r["away_score"] is None
               and not r["collected"] and r["provider"] == "openfootball" for _,r in physical)
    for nation, (public, year, _, ident, score) in TARGETS.items():
        witness, = [r for r in api if r["id"] == public]
        assert witness["stage"] == "Finale" and witness["final"]["status"] == "not_started"
        assert witness["final"]["homeScore"] is None and witness["final"]["awayScore"] is None
        fixed = branch["after"][year]
        assert fixed["id"] == public and fixed["stage"] == "Vainqueur" and fixed["tone"] == "gold"
        assert fixed["played_status"] == {"finished":7}
        final, = [m for m in branch["physical_finals_after"] if m["id"] == ident]
        assert [final["home_score"], final["away_score"]] == score and final["status"] == "finished"
        assert branch["conditional"][year]["status"] == 304
    summaries = []
    for width, height in ((393,852),(1440,900)):
        directory = ROOT / f"observation-{width}"
        state = fetch(directory.relative_to(ROOT) / "result.json")
        assert (state["width"], state["height"]) == (width,height) and not state["errors"]
        assert state["at"].startswith("2026-11-18"), state["at"]
        pictures = list(directory.glob("*.png"))
        assert all(image_size(f) == (width,height) for f in pictures)
        index, = [a for a in state["checks"] if a["step"] == "index"]
        assert (index["linkedRows"], index["allLabel"], index["rankedLabel"]) == (
            153, "Toutes les sélections · 153", "Classées cette saison · 54")
        assert len(pictures) == 10
        for nation, (public, year, suffix, _, _) in TARGETS.items():
            found = {a["step"]: a for a in state["checks"] if a.get("nation") == nation}
            for step in ("identity","matches","players","history","return-index"):
                assert step in found, (width,nation,step)
            assert found["identity"]["id"] == public and found["identity"]["heading"] == nation
            assert parse_qs(urlparse(found["identity"]["actual"]).query)["id"] == [public]
            assert found["history"]["tile"] == f"{year} Finale" and found["history"]["tone"] is None
            bounds = found["history"]["bounds"]
            assert bounds["y"] >= 54 and bounds["y"] + bounds["height"] <= height - 78
            final, = found["matches"]["finals"]
            assert final["visible"] is True and final["href"] is None and final["body"].endswith("Finale à venir")
            if nation == "France":
                assert found["players"]["count"] == 22 and found["match-return"]["match"]["id"] == "m_1HdHEO"
                assert parse_qs(urlparse(found["match-return"]["returned"]).query)["id"] == [public]
            else:
                assert found["players"]["count"] == 0 and found["matches"]["firstMatch"] is None
                assert found["players"]["text"] == "Aucune statistique de joueur collectée pour cette sélection."
            assert "id" not in parse_qs(urlparse(found["return-index"]["actual"]).query)
            for screenshot in (f"recherche-{suffix}.png", f"palmares-{suffix}.png", f"finale-{suffix}.png", f"joueurs-{suffix}.png"):
                assert (directory / screenshot).exists(), screenshot
        summaries.append({"width":width,"height":height,"checks":len(state["checks"]),"screenshots":len(pictures),
                          "international_return":any(s["step"] in ("match-return","player-return") for s in state["checks"])})
    print(json.dumps({"status":"PASS","files_checked":count,"sessions":summaries,"rds_duplicate_groups":132,
                      "currently_masked_scores":0,"visible_unscored_finals":2},ensure_ascii=False))


if __name__ == "__main__":
    outcome()
