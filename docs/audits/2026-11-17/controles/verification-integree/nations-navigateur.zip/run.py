"""Use an isolated Playwright CLI profile to follow production L18 nation links at a single width."""
import argparse
from datetime import datetime, timezone
import hashlib
import json
from pathlib import Path
import shutil
import subprocess

p=Path(__file__).resolve().parent
a=argparse.ArgumentParser()
a.add_argument('width',type=int,choices=(393,1440))
a.add_argument('folder',type=Path)
a.add_argument('--config',type=Path,required=True)
a.add_argument('--cli',type=Path,required=True)
a.add_argument('--session',required=True)
args=a.parse_args()
assert shutil.which('npx')
out=args.folder.resolve()
out.mkdir(parents=True,exist_ok=False)
cmd=[str(args.cli.resolve()),'--session='+args.session]
def call(label,*parts):
    run=subprocess.run([*cmd,*parts],cwd=out,text=True,capture_output=True,timeout=950)
    (out/(label+'.log')).write_text(run.stdout+'\n'+run.stderr)
    if run.returncode or '### Error' in run.stdout:
        raise RuntimeError(label+' failed: '+run.stdout[:450])
    return run.stdout
start=datetime.now(timezone.utc).isoformat()
call('open','open','https://vegasport.vercel.app/nations/','--config',str(args.config.resolve()))
try:
    code=(p/'parcours.cjs').read_text().replace('WIDTH',str(args.width)).replace('OUT',json.dumps(str(out)))
    msg=call('run','run-code',code)
    outcome=json.loads(msg.split('### Result\n',1)[1].split('\n###',1)[0])
    (out/'result.json').write_text(json.dumps(outcome,ensure_ascii=False,indent=2)+'\n')
    print(args.width,len(outcome['checks']),outcome['errors'])
finally:
    call('closed','close')
    files=[f for f in out.iterdir() if f.is_file()]
    summary={'started':start,'finished':datetime.now(timezone.utc).isoformat(),'width':args.width,
             'script_sha256':hashlib.sha256((p/'parcours.cjs').read_bytes()).hexdigest(),
             'files':{f.name:hashlib.sha256(f.read_bytes()).hexdigest() for f in files}}
    (out/'receipt.json').write_text(json.dumps(summary,ensure_ascii=False,indent=2)+'\n')
