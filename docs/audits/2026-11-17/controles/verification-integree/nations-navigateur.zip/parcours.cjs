async page => {
  const origin = 'https://vegasport.vercel.app';
  const targets = [
    {name:'France', id:'t_2ysHaw', year:'1998', key:'france', sides:/^(?:Brésil|Brazil) – France$/i},
    {name:'Italie', id:'t_v0001032', year:'1982', key:'italie', sides:/^Italie – (?:Allemagne(?: de l’Ouest| de l'Ouest)?|RFA|West Germany|République fédérale d’Allemagne)$/i},
  ];
  const height = WIDTH === 393 ? 852 : 900;
  const out = {width:WIDTH,height,at:new Date().toISOString(),checks:[],errors:[],observedApi:[]};
  const log = (step, more) => out.checks.push({step,...more});
  const guard = (test, error) => { if (!test) throw Error(error); };
  const brief = str => String(str).replace(/\s+/g," ").trim();
  page.setDefaultTimeout(14000);
  await page.setViewportSize({width:WIDTH,height});
  page.on('response', r => {if (/\/api\/nations(?:\/|\?)/.test(r.url())) out.observedApi.push({url:r.url(),status:r.status()});});
  async function screenshot(name) {await page.screenshot({path: OUT+'/'+name+'.png', animations:'disabled'}); }
  const search = () => page.getByRole('searchbox',{name:'Rechercher une sélection'});
  async function index() {
    await page.goto(origin+'/nations/',{waitUntil:'domcontentloaded'});
    await search().waitFor();
    await page.getByRole('button',{name:/Toutes les sélections/}).click();
    await search().fill('');
    await page.locator('tbody tr a[href^="/nations"]').first().waitFor();
  }
  function nationUrl(url, id) {return /^\/nations\/?$/.test(url.pathname) && url.searchParams.get('id') === id;}
  async function landing(target) {
    await page.waitForURL(url => nationUrl(url, target.id));
    const rail=page.getByRole('complementary',{name:'Identité de la sélection'});
    await rail.getByRole('heading',{name:target.name,exact:true}).waitFor();
    await rail.getByText('Sélection nationale',{exact:true}).waitFor();
    return rail;
  }
  async function find(target) {
    await index();
    await search().fill(target.name);
    const link=page.getByRole('link',{name:target.name,exact:true});
    await link.waitFor();
    const href=await link.getAttribute('href');
    guard(nationUrl(new URL(href,origin),target.id), 'Identifiant de recherche inattendu '+href);
    await screenshot('recherche-'+target.key);
    await link.click();
    const rail=await landing(target);
    log('identity',{nation:target.name,id:target.id,href,heading:await rail.getByRole('heading').innerText(),
                    searchText:target.name,actual:page.url()});
  }
  async function tab(name) {
    const button=page.getByRole('tab',{name,exact:true});
    await button.click();
    const panel=page.getByRole('tabpanel',{name,exact:true});
    await panel.waitFor();
    guard(await button.getAttribute('aria-selected') === 'true','Onglet non sélectionné '+name);
    return panel;
  }
  async function aside(target, kind, href, title) {
    guard(href && new URL(href,origin).searchParams.get('id'), 'Lien '+kind+' sans identifiant');
    const url=new URL(href, origin);
    return {nation:target.name,kind,title,href,id:url.searchParams.get('id')};
  }
  try {
    await index();
    log('index',{
      path:new URL(page.url()).pathname,
      rankedLabel: await page.getByRole('button',{name:/Classées cette saison/}).innerText(),
      allLabel:await page.getByRole('button',{name:/Toutes les sélections/}).innerText(),
      linkedRows:await page.locator('tbody tr a[href^="/nations"]').count(),
    });
    await screenshot('index');
  } catch(error) {out.errors.push({step:'index',error:String(error).slice(0,550)});}
  for (const target of targets) {
    try {
      await find(target);
      let panel = await tab('Matchs');
      await panel.getByRole('heading',{name:'Tous les matchs',exact:true}).waitFor();
      let finals=[];
      for(const b of await panel.getByText(target.sides).all()){
        const row=b.locator('xpath=../..');
        const body=brief(await row.innerText());
        if(/(?:Coupe du monde.*Finale|Finale.*Coupe du monde)/.test(body) && !/[-‑]finale/.test(body)) {
          finals.push({body, href:await row.getAttribute('href'), visible:await row.isVisible()});
          if(finals.length===1){await row.scrollIntoViewIfNeeded();await screenshot('finale-'+target.key);}
        }
      }
      const firstMatch=panel.locator('a[href^="/matchs"]').first();
      const targetMatch=await firstMatch.count()?await aside(target,'match',await firstMatch.getAttribute('href'),brief(await firstMatch.innerText())):null;
      log('matches',{nation:target.name,selected:'Matchs',finals,firstMatch:targetMatch});
      panel=await tab('Joueurs');
      const playerLinks=panel.locator('a[href^="/joueurs"]');
      const playerCount=await playerLinks.count();
      let player=null;
      if(playerCount) player=await aside(target,'joueur',await playerLinks.first().getAttribute('href'),brief(await playerLinks.first().innerText()));
      log('players',{nation:target.name,selected:'Joueurs',count:playerCount,firstPlayer:player,text:brief(await panel.innerText()).slice(0,280)});
      await screenshot('joueurs-'+target.key);
      panel=await tab('Historique');
      await panel.getByRole('heading',{name:'Grands tournois',exact:true}).waitFor();
      const year=panel.getByText(target.year,{exact:true});
      await year.waitFor();
      const tile=year.locator('xpath=..');
      await tile.evaluate(el=>el.scrollIntoView({block:'center',behavior:'instant'}));
      await page.waitForFunction(el=>{const r=el.getBoundingClientRect();return r.top>=54&&r.bottom<=window.innerHeight-78;},await tile.elementHandle());
      const tileText=brief(await tile.innerText());
      const tone=await tile.getAttribute('data-tone');
      const bounds=await tile.boundingBox();
      log('history',{nation:target.name,selected:'Historique',year:target.year,tile:tileText,tone,bounds});
      await screenshot('palmares-'+target.key);
      if(targetMatch && target.key==='france') {
        try {
          const m=await tab('Matchs');
          const link=m.locator('a[href*="'+targetMatch.id+'"]').first();
          await link.click();
          await page.waitForURL(url=>/^\/matchs\/?$/.test(url.pathname)&&url.searchParams.get('id')===targetMatch.id);
          const country=page.locator('a[href^="/nations"][href*="'+target.id+'"]').first();
          await country.waitFor();
          const href=await country.getAttribute('href');
          const label=brief(await country.innerText());
          await country.scrollIntoViewIfNeeded();
          await screenshot('match-vers-france');
          await country.click();
          await landing(target);
          log('match-return',{nation:target.name,match:targetMatch,link:href,label,returned:page.url()});
        } catch(error) {
          log('match-return-unavailable',{nation:target.name,match:targetMatch,error:String(error).slice(0,450),actual:page.url()});
          await find(target);
        }
      }
      const back=page.getByRole('link',{name:/Toutes les nations/});
      const href=await back.getAttribute('href');
      await back.click();
      await page.waitForURL(url=>nationUrl(url,null));
      await search().waitFor();
      log('return-index',{nation:target.name,id:target.id,href,actual:page.url()});
    } catch(error){out.errors.push({step:target.key,error:String(error).slice(0,650),actual:page.url()});}
  }
  out.finished = new Date().toISOString();
  return out;
}
