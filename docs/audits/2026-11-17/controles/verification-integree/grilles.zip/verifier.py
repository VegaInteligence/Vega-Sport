"""Rebuild the eighteen November coverage tables from the captured SQL result sets."""
import csv
import gzip
import hashlib
import json
from pathlib import Path
import shutil
import subprocess
import sys
import tempfile

base = Path(__file__).resolve().parent
def read_json(path):
    return json.loads(path.read_bytes())

def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()

checksums = read_json(base / 'empreintes.json')
for name, digest in checksums.items():
    if sha(base / name) != digest:
        raise ValueError('Empreinte différente pour ' + name)

with tempfile.TemporaryDirectory() as workspace:
    root = Path(workspace)
    snapshot = root / 'capture'
    shutil.copytree(base / 'capture', snapshot)
    subprocess.run([sys.executable, '-B', str(snapshot / 'scores/build-score-grid.py')], check=True)
    subprocess.run([sys.executable, '-B', str(snapshot / 'verify_grid.py')], check=True)
    subprocess.run([sys.executable, '-B', str(base / 'calculer.py'), str(snapshot), str(root / 'rejeu')], check=True)
    original = read_json(base / 'resultats/resultats.json')
    actual = read_json(root / 'rejeu/resultats.json')
    for table in ('scores-par-edition.csv.gz', 'scores-par-saison.csv.gz'):
        if gzip.decompress((base / 'resultats' / table).read_bytes()) != gzip.decompress((root / 'rejeu' / table).read_bytes()):
            raise ValueError('Données tabulaires différentes dans ' + table)
    original.pop('output_sha256')
    actual.pop('output_sha256')
    if actual != original or actual['rows'] != 6447 or actual['season_rows'] != 471:
        raise ValueError('Divergence des agrégats ou des dimensions')
print(json.dumps({'fichiers_verifies':len(checksums), 'editions':actual['editions'], 'competitions':actual['competitions'], 'par_entite':actual['totals'], 'lecture':actual['snapshot']},ensure_ascii=False))
