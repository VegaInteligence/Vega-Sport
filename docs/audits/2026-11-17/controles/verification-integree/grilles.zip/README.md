# Couverture des scores Vega au 18 novembre 2026 à 13 h 56 min 55 s UTC

Les deux tableaux compressés donnent les scores attendus, les valeurs persistées et la différence, pour chaque combinaison d’édition et de type d’entité, puis par saison et type. La mesure part d’une seule transaction PostgreSQL en lecture seule avec isolation repeatable read. Les 6 447 lignes couvrent 2 149 éditions, 208 compétitions et 157 libellés de saison. Les lignes de joueurs portent un minimum de participants connus. Une rencontre entièrement absente de Vega échappe à ce dénominateur.

| Entité | Attendus selon l’algorithme déployé et ses données disponibles | Persistés | Écart |
| --- | ---: | ---: | ---: |
| Joueurs | 2 296 998 | 2 282 580 | 14 418 |
| Clubs, côtés de match Elo | 161 932 | 161 912 | 20 |
| Sélections, côtés de match Elo | 1 864 | 1 864 | 0 |

Le modèle joueurs demande des minutes positives et un rôle exploitable. Les 14 418 absences calculables appartiennent au millésime de récompense 2020. Pour 615 autres participations, le rôle requis reste indéterminé même avec l’historique du joueur dans ce millésime. Un champ vide conserve son sens inconnu ou sans objet. Le score d’équipe mesuré est l’Elo interne. Les exclusions d’archives et de copies restent visibles dans les colonnes dédiées.

Après décompression de cette archive, lancer `python3 -B verifier.py` avec Python 3.10 ou ultérieur. Le programme vérifie les empreintes, reconstruit la grille depuis les réponses SQL capturées, recoupe les partitions par millésime, puis compare les deux tableaux et les totaux. La vérification fonctionne hors ligne. Les requêtes et les résultats agrégés se trouvent dans `capture/db`. Les branches d’éligibilité supplémentaires et le rapprochement par édition figurent dans `calculer.py`. Les fichiers dans `resultats` sont les résultats originaux de la mesure. Les empreintes publiées couvrent la copie source du dossier à la date indiquée.
