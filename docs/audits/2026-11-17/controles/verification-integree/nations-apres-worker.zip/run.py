"""Repeat this deployment's browser checks with fresh named Playwright CLI contexts."""
import argparse
from datetime import datetime, timezone
import hashlib
import json
from pathlib import Path
import shutil
import subprocess
import sys

HERE = Path(__file__).resolve().parent
parser = argparse.ArgumentParser(description=__doc__)
parser.add_argument("device", choices=("desktop", "iphone"))
parser.add_argument("out", type=Path)
parser.add_argument("--cli", required=True, type=Path)
parser.add_argument("--chromium", required=True, type=Path)
parser.add_argument("--session", required=True)
args = parser.parse_args()
assert shutil.which("npx") and args.cli.is_file() and args.chromium.is_file()
out = args.out.resolve()
out.mkdir()
is_phone = args.device == "iphone"
width, height = (393, 852) if is_phone else (1440, 900)
context = {"viewport": {"width": width, "height": height}, "locale": "fr-FR", "timezoneId": "Europe/Paris"}
if is_phone:
    context.update(isMobile=True, hasTouch=True, deviceScaleFactor=3, screen={"width": width, "height": height},
                   userAgent="Mozilla/5.0 (iPhone; CPU iPhone OS 18_0 like Mac OS X) AppleWebKit/605.1.15 "
                             "(KHTML, like Gecko) Version/18.0 Mobile/15E148 Safari/604.1")
config = {"browser": {"browserName": "chromium",
          "launchOptions": {"executablePath": str(args.chromium.resolve())}, "contextOptions": context}}
cfg = out / "browser-config.json"
cfg.write_text(json.dumps(config, indent=2) + "\n")
cmd = [str(args.cli.resolve()), "--session=" + args.session]
started = datetime.now(timezone.utc).isoformat()


def call(label, *parts):
    process = subprocess.run([*cmd, *parts], cwd=out, text=True, capture_output=True, timeout=440)
    (out / (label + ".log")).write_text(process.stdout + "\n" + process.stderr)
    if process.returncode or "### Error" in process.stdout:
        raise RuntimeError(f"{label}: {process.stdout[:600]} {process.stderr[:500]}")
    return process.stdout


call("open", "open", "https://vegasport.vercel.app/nations/", "--config", str(cfg))
try:
    source = (HERE / "parcours.cjs").read_text()
    code = source.replace("__OUTPUT__", json.dumps(str(out))).replace("__DEVICE__", json.dumps(args.device))
    output = call("run", "run-code", code)
    result = json.loads(output.split("### Result\n", 1)[1].split("\n###", 1)[0])
    (out / "result.json").write_text(json.dumps(result, ensure_ascii=False, indent=2) + "\n")
    print(args.device, len(result["checks"]), result["errors"])
finally:
    call("closed", "close")
    receipt = {
        "started": started, "finished": datetime.now(timezone.utc).isoformat(), "device": args.device,
        "session": args.session, "viewport": context["viewport"],
        "command": [sys.executable, str(Path(__file__).resolve()), *sys.argv[1:]],
        "script_sha256": hashlib.sha256((HERE / "parcours.cjs").read_bytes()).hexdigest(),
        "files": {str(f.relative_to(out)): hashlib.sha256(f.read_bytes()).hexdigest()
                  for f in sorted(out.rglob("*")) if f.is_file()},
    }
    (out / "receipt.json").write_text(json.dumps(receipt, ensure_ascii=False, indent=2) + "\n")
