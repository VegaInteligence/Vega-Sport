# VI-18 · Contrôle public après le déploiement AWS

Deux sessions Chromium neuves ont vérifié les liens de tournoi, vainqueurs, scores, dates, alias et rechargement à 17:08 UTC. Reçus 16:44 et 17:08 conservés séparément. Contrôle hors ligne terminé, résultats joints au rapport de coordination.
