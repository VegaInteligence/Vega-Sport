"""Check the two production browser receipts and reproduce the before/after claims offline."""
import hashlib
import json
from pathlib import Path

ROOT = Path(__file__).resolve().parent
WITNESSES = {
    "France": ("1998", "12 juil. 1998", ("Brésil", "France"), ("0","3"), "0 – 3", "t_2ysHaw"),
    "Italie": ("1982", "11 juil. 1982", ("Italie","Allemagne de l’Ouest"), ("3","1"), "3 – 1", "t_v0001032"),
}


def read(path):
    return json.loads((ROOT/path).read_bytes())


def check(result, step, nation=None):
    found = [r for r in result["checks"] if r["step"] == step and (not nation or r.get("nation") == nation)]
    assert len(found) == 1, (step, nation)
    return found[0]


baseline = read("reference-1644/cloudfront.json")
summary = {}
for device in ("desktop", "iphone"):
    source = read(f"{device}/receipt.json")
    for name,wanted in source["files"].items():
        assert hashlib.sha256((ROOT/device/name).read_bytes()).hexdigest() == wanted, (device, name)
    assert hashlib.sha256((ROOT/"parcours.cjs").read_bytes()).hexdigest() == source["script_sha256"]
    result, old = read(f"{device}/result.json"), read(f"reference-1644/{device}.json")
    assert not (result["errors"] or result["consoleErrors"])
    assert len(result["checks"]) == 26 and result["device"] == device
    records = {}
    for nation,(year, day, teams, scores, exact, nid) in WITNESSES.items():
        assert check(result,"identity",nation)["id"] == nid
        assert check(old,"edition-link",nation)["label"] == f"{year} Finale"
        link = check(result,"edition-link",nation)
        land = check(result,"edition-landing",nation)
        assert link["label"] == f"{year} Vainqueur" and link["tone"] == "gold"
        assert land["year"] == year and land["selected"] == "true"
        assert check(old,"bracket",nation)["champion"] is None
        for step in ("bracket", "bracket-after-reload"):
            rendered = check(result,step,nation)
            assert rendered["title"] == day and rendered["champion"] == nation and rendered["finalsVisible"]
            assert [tuple(t[k] for t in rendered["teams"]) for k in ("name","score")] == [teams,scores]
            assert [t["name"] for t in rendered["teams"] if t["winner"]] == [nation]
            if device=="iphone":
                assert result["render"]["hasTouch"]==1 and rendered["initialPhoneLayout"] is not None
        assert check(result,"edition-match",nation)["score"] == exact
        assert check(result,"edition-match",nation)["date"] == day
        national_matches = check(result,"national-match",nation)["finals"]
        assert len(national_matches)==1 and "à venir" not in national_matches[0]["display"]
        assert f"{scores[0]}–{scores[1]} V" in national_matches[0]["display"]
        reads = {}
        keys = (f"snapshot-{year}", "nation-france" if nation=="France" else "nation-italie")
        for key in keys:
            previous = baseline[key]
            items = [r for r in result["publicReads"] if r["url"] == previous["url"]]
            assert items and all(r["status"]==200 and r["cache"]["etag"] != previous["etag"] for r in items)
            reads[key] = {"etag_before":previous["etag"], "before_at":previous["started"],
                          "after":items}
        records[nation] = {"title":link["label"],"date":day,"score":exact,"http":reads}
    french=check(result,"localized-match-search","Italie")
    english=check(result,"english-match-search","Italie")
    assert french["query"]=="Italie" and french["empty"] and not french["finalVisible"]
    assert english["query"]=="Italy" and english["finalVisible"]
    summary[device] = {"started":result["started"],"finished":result["finished"],
                       "checks":len(result["checks"]),"witnesses":records,
                       "search":{"localized":french,"raw":english}}
print(json.dumps(summary,ensure_ascii=False,indent=2))
