# Rejouer la restauration Open Matchday

Ce paquet éprouve la restauration des 35 anciennes identités, la poursuite de la collecte et la réapparition d’enrichissements, sur PostgreSQL 18 local. La révision testée est `17306e6da6dcf116cdfc61f26749ef3d01a46e47`. Les étapes utilisent les entrées ordinaires de Vega‑Sport et la vraie lecture HTTP sur la boucle locale.

## Prérequis

- Une copie Vega‑Sport avec Git à la révision indiquée et les sources propres.
- Python 3.12+ et les dépendances de `backend/requirements.txt`, Node et les dépendances verrouillées de `backend/api` déjà installées. Le rejeu lui-même se fait hors ligne.
- Un serveur PostgreSQL 18 jetable sur `127.0.0.1`, avec le propriétaire local `postgres` et création de bases autorisée. Le port passé à la commande doit être celui de cette instance dédiée. Les bases de test sont conservées pour inspection.
- Les deux archives de preuves attachées au dossier de remise. `inputs.json` donne leurs empreintes et tous les chemins utiles.

## Lancer

Décompresser ce paquet et, depuis son dossier, exécuter la commande ci-dessous avec les chemins locaux et un suffixe de base inédit.

```sh
python3 rerun.py \
  --worktree "/chemin/vers/Vega-Sport" \
  --identities "/chemin/vers/35-matchs-identites-et-elo.zip" \
  --windows "/chemin/vers/capsule-completude-partage-20261118.zip" \
  --output "/chemin/vers/un-nouveau-dossier-de-rejeu" \
  --port 55439 --tag replay01
```

Le succès écrit `summary.json` dans la destination. Chaque étape conserve la commande, la sortie du CLI et ses observations HTTP et PostgreSQL. En cas d’échec, inspecter le dernier fichier `.log` dans `tracks/4-history/restauration-open-matchday/` sous la destination.

## Témoins hors ligne

| Origine | Entrées utilisées |
| --- | --- |
| `35-matchs-identites-et-elo.zip` | `rds/avant.zlib`, `rds/apres.zlib`, `organisateurs/35-constats.json` et `rencontres/nouveau.csv`. |
| `capsule-completude-partage-20261118.zip` | Douze CSV de résultats pour les trois ligues aux dates du 4, 10, 17 et 18 novembre. Les fichiers du commit du 10 portent le libellé `2026-11-11`. |
| `payload/` | Le résumé du 18, les six fichiers de rencontres à venir des 17 et 18, la ligne de métadonnées du blason 325834 requise par une référence physique et les cinq scripts de test. Aucune image n’est chargée. |
| Checkout | Le migrateur et les scripts SQL numérotés, avec relecture du préfixe déployé jusqu’à 133 puis application du candidat jusqu’à 149. Le writer normal, le lecteur HTTP et le CLI restent ceux du checkout. |

Le scénario du 17 au 18 restaure 35 matchs et liaisons, garde les 70 Elo publiés et accepte dix nouveaux résultats. Les scénarios suivants éprouvent le contrôle de la fenêtre glissante, une réapparition avec le HT confirmé 0–1 et des corners de contrôle, ainsi que deux états contrôlés de publication Elo ultérieure. Ils vérifient les refus et les rejeux sans écriture. La copie teste physiquement les lignes du périmètre à partir des captures, avec des valeurs auxiliaires locales pour les dix résultats entrants. Toute exécution sur un environnement distant est hors du périmètre de ce rejeu.

