"""Frozen normal collection, physical restoration, and later source reads through public HTTP."""
import argparse
import csv
from datetime import datetime, timezone, timedelta
from hashlib import sha256
import io
import json
import os
from pathlib import Path
import re
import subprocess
import sys
from urllib.error import HTTPError
from urllib.parse import urlsplit,urlencode
from urllib.request import Request,urlopen
import zlib

import psycopg
from psycopg import sql

q=Path(__file__).resolve().parent
e=q.parents[2]
diagnostic=e/"tracks/6-teams/ecart-elo-1356"
p=argparse.ArgumentParser()
p.add_argument("worktree",type=Path)
p.add_argument("tag")
p.add_argument("--template",default="realthree")
p.add_argument("--red",action="store_true")
p.add_argument("--enrichment",action="store_true")
a=p.parse_args()
w=a.worktree.resolve()
assert all(re.fullmatch(r"[a-z0-9]+",v) for v in (a.tag,a.template))
sys.path.insert(0,str(w/"backend"))
from vega import sources
from vega.sources import open_matchday
from vega.store import migrate

out=q/a.tag
out.mkdir()
pre=e/"delivery/rds-preimage/avant-v3/inputs.json.zlib"
post=e/"delivery/rds-preimage/apres-v2/inputs.json.zlib"
sealed=json.loads(zlib.decompress(pre.read_bytes()))
old_ids=[r[0] for r in sealed["witnesses"]]
provider_keys=sealed["provider_keys"]
folders=set(k.split(":")[0] for k in provider_keys)
matches=[json.loads(x) for x in sealed["reads"]["table.core.matches"]["rows_json"]]
newer=list(csv.DictReader((diagnostic/"new-results-10.csv").open()))
data={}
for name in ("old","current"):
    data[name]={folder:{part:list(csv.DictReader((diagnostic/"public-source"/name/"data"/folder/(part+"_2627.csv")).open()))
                       for part in ("fixtures","results")} for folder in folders}
def key(folder,row):
    home,away=(open_matchday.SPELLINGS.get(row[s].strip(),row[s].strip()) for s in ("home","away"))
    return f"{folder}:2026/2027:{row['date'].strip()}|{home}|{away}"

data["without_incident"]={f:{"fixtures":data["old"][f]["fixtures"],"results":[r for r in data["old"][f]["results"] if key(f,r) not in provider_keys]} for f in folders}
assert sum(len(entry["results"]) for entry in data["without_incident"].values())==329
assert sum(len(entry["results"]) for entry in data["current"].values())==339
target_folder="ENG_6_national-league-north"
data["novel"]={f:{part:list(data["current"][f][part]) for part in ("fixtures","results")} for f in folders}
next_result=dict(data["current"][target_folder]["results"][-1],date="2026-11-20")
new_key=key(target_folder,next_result)
assert all(key(target_folder,r)!=new_key for r in data["novel"][target_folder]["results"]+data["novel"][target_folder]["fixtures"])
data["novel"][target_folder]["results"].append(next_result)
data["omission"]={f:{part:list(data["novel"][f][part]) for part in ("fixtures","results")} for f in folders}
omitted=data["omission"][target_folder]["results"].pop(0)
assert key(target_folder,omitted) not in provider_keys
data["contradiction"]={f:{part:list(data["novel"][f][part]) for part in ("fixtures","results")} for f in folders}
bad=dict(next(r for r in data["old"][target_folder]["results"] if key(target_folder,r)==provider_keys[0]))
bad["ft_home"]=str(int(bad["ft_home"])+1)
data["contradiction"][target_folder]["results"].append(bad)
data["old_again"]={f:{"fixtures":data["current"][f]["fixtures"],
    "results":list({key(f,r):r for r in data["old"][f]["results"]+data["current"][f]["results"]}.values())} for f in folders}
for stage in ("enrichment","without_enrichment"):
    data[stage]={f:{"fixtures":data["novel"][f]["fixtures"],"results":data["novel"][f]["results"]+[
        {k:v for k,v in row.items() if k in ("date","home","away","ft_home","ft_away")}
        for row in data["old"][f]["results"] if key(f,row) in provider_keys]} for f in folders}
target=next(row for row in data["enrichment"][target_folder]["results"] if key(target_folder,row)==provider_keys[0])
target.update(ht_home="0",ht_away="1",home_corners="4")
summary=json.loads((diagnostic/"public-source/current/build_summary.json").read_bytes())
summary["leagues"]=[r for r in summary["leagues"] if r["folder"].split("/")[-1] in folders]
assert len(summary["leagues"])==3

def frozen_transport(name):
    def get(url,as_text=False):
        parsed=urlsplit(url)
        assert parsed.hostname=="raw.githubusercontent.com" and "/oladeeayo/open-matchday/master/" in parsed.path
        if parsed.path.endswith("/build_summary.json"):
            return dict(summary,leagues=[dict(r,**{k:len(data[name][r["folder"].split("/")[-1]][k]) for k in ("fixtures","results")})
                                         for r in summary["leagues"]])
        folder=parsed.path.split("/")[-2]
        part=parsed.path.split("/")[-1].split("_")[0]
        items=data[name][folder][part]
        result=io.StringIO()
        writer=csv.DictWriter(result,fieldnames=list(dict.fromkeys(k for item in items for k in item)))
        writer.writeheader()
        writer.writerows(items)
        return result.getvalue()
    return get

base=f"postgresql://postgres@127.0.0.1:{int(os.environ.get('OPEN_MATCHDAY_REPLAY_PORT','55439'))}/"
def database(tag,template=None):
    name="vega_v2_open_matchday_restore_"+tag
    with psycopg.connect(base+"postgres",autocommit=True) as ctl:
        extra=sql.SQL(" TEMPLATE {}").format(sql.Identifier("vega_v2_open_matchday_restore_"+template)) if template else sql.SQL("")
        ctl.execute(sql.SQL("CREATE DATABASE {}").format(sql.Identifier(name))+extra)
    return base+name

when=datetime(2026,11,18,19,tzinfo=timezone.utc)
def collect(db,name,offset):
    with db.transaction():
        db.execute("SET LOCAL ROLE vega_collect")
        ran=sources.run_due(db,frozen_transport(name),when+timedelta(days=offset),names={"open_matchday"})
    failure=db.execute("SELECT error_code FROM ops.parse_failures ORDER BY id").fetchall()
    return {"run":{str(k):v for k,v in ran.items()},"failures":[r[0] for r in failure],
            "finished":db.execute("SELECT count(*) FROM core.matches WHERE status='finished'").fetchone()[0]}

dsn=database(a.tag,a.template)
db=psycopg.connect(dsn,autocommit=True)
assert db.execute("SELECT count(*) FROM core.matches").fetchone()[0]==45
db.execute("DELETE FROM core.provider_ids WHERE entity_type='match'")
db.execute("DELETE FROM core.matches")
db.execute("SELECT setval(pg_get_serial_sequence('core.teams','id'),(SELECT max(id)+100 FROM core.teams))")
db.execute("SELECT setval(pg_get_serial_sequence('core.rounds','id'),(SELECT max(id)+100 FROM core.rounds))")
for folder in folders:
    comp=db.execute("SELECT competition_id FROM core.competition_seasons WHERE cup_key=%s",("open-matchday:"+folder+":2026/2027",)).fetchone()[0]
    db.execute("INSERT INTO core.provider_ids(entity_type,provider,provider_key,entity_id) VALUES('competition','vega',%s,%s)",("cup:open-matchday:"+folder,comp))
bindings={}
for m in matches:
    for side in ("home","away"):
        k="name:"+m[side+"_team_name"]
        ident=m[side+"_team_id"]
        assert bindings.setdefault(k,ident)==ident
seen=set()
for k,ident in bindings.items():
    db.execute("INSERT INTO core.provider_ids(entity_type,provider,provider_key,entity_id,is_current) VALUES('team','open_matchday',%s,%s,%s)",(k,ident,ident not in seen))
    seen.add(ident)
prep=collect(db,"without_incident",0)
assert prep["finished"]==329 and not prep["failures"],prep
env={**os.environ,"PYTHONDONTWRITEBYTECODE":"1","PYTHONPATH":str(w/"backend")}
cmd=[sys.executable,"-m","vega.open_matchday_restore","--dsn",dsn,
     "--preimage",str(pre),"--preimage-sha256",sha256(pre.read_bytes()).hexdigest(),
     "--postimage",str(post),"--postimage-sha256",sha256(post.read_bytes()).hexdigest(),"--apply"]
made=subprocess.run(cmd,cwd=w/"backend",env=env,capture_output=True,text=True,timeout=45)
(out/"restore.stdout").write_text(made.stdout)
(out/"restore.stderr").write_text(made.stderr)
assert made.returncode==0,made.stderr
assert json.loads(made.stdout)["restored"]==35
def stable():
    return (
      db.execute("SELECT row_to_json(m)::text FROM core.matches m WHERE id=ANY(%s) ORDER BY id",(old_ids,)).fetchall(),
      db.execute("SELECT row_to_json(p)::text FROM core.provider_ids p WHERE entity_type='match' AND entity_id=ANY(%s) ORDER BY entity_id",(old_ids,)).fetchall(),
      db.execute("SELECT row_to_json(e)::text,encode(float4send(elo_after),'hex') FROM agg.team_elo e ORDER BY match_id,team_id").fetchall(),
    )
base_state=stable()
assert tuple(map(len,base_state))==(35,35,70)
receipt={"sha":subprocess.check_output(["git","-C",str(w),"rev-parse","HEAD"],text=True).strip(),"db":dsn,"restore":cmd,
         "collector_entry":"vega.sources.run_due under vega_collect","reader_entry":"normal Node HTTP handler under vega_read","checks":{}}
report=receipt["checks"]
server=subprocess.Popen(["node",str(q/"serve.mjs"),str(w),dsn],stdout=subprocess.PIPE,stderr=(out/"http.log").open("w"),text=True)
origin="http://127.0.0.1:"+server.stdout.readline().strip()
assert not origin.endswith(":")
def http(known=None):
    responses={}
    for f in sorted(folders):
        req=Request(origin+"/api/cup-table?"+urlencode(dict(competition=f,season="2026/2027",kind="results")),
                    headers={"If-None-Match":known[f]["etag"]} if known else {})
        try:res=urlopen(req,timeout=12)
        except HTTPError as ex:res=ex
        body=res.read()
        responses[f]={"status":res.status,"etag":res.headers.get("etag"),"count":len(json.loads(body)) if body else None}
    return responses

def incoming_count(conn):
    return sum(bool(conn.execute("SELECT 1 FROM core.matches WHERE match_date=%s AND home_team_name=%s AND away_team_name=%s AND home_score=%s AND away_score=%s",
                                 (r["match_date"],r["home"],r["away"],int(r["home_score"]),int(r["away_score"]))).fetchone()) for r in newer)
try:
    initial=http()
    assert incoming_count(db)==0 and sum(x["count"] for x in initial.values())==364
    first=collect(db,"current",1)
    report["first"]={"collector":first,"http":http(initial),"ten_incoming":incoming_count(db)}
    assert stable()==base_state
    if a.red:
        assert first["finished"]==364 and first["failures"]==["SNAPSHOT_DROPS_RESULT"]*3 and not incoming_count(db)
        assert all(x["status"]==304 for x in report["first"]["http"].values())
        receipt["status"]="red"
    else:
        assert first["finished"]==374 and not first["failures"] and incoming_count(db)==10,first
        assert all(x["status"]==200 for x in report["first"]["http"].values())
        committed=http()
        before_versions=db.execute("SELECT row_to_json(v)::text FROM ops.resource_versions v ORDER BY resource_kind,resource_id").fetchall()
        repeat=collect(db,"current",2)
        report["repeat"]={"collector":repeat,"http":http(committed)}
        assert repeat["finished"]==374 and not repeat["failures"] and stable()==base_state
        assert all(x["status"]==304 for x in report["repeat"]["http"].values())
        assert before_versions==db.execute("SELECT row_to_json(v)::text FROM ops.resource_versions v ORDER BY resource_kind,resource_id").fetchall()
        next_result=collect(db,"novel",3)
        report["novel"]={"collector":next_result,"http":http(committed)}
        assert next_result["finished"]==375 and stable()==base_state and report["novel"]["http"][target_folder]["status"]==200
        latest=http()
        missing=collect(db,"omission",4)
        report["omission"]={"collector":missing,"http":http(latest)}
        assert missing["finished"]==375 and missing["failures"]==["SNAPSHOT_DROPS_RESULT"] and stable()==base_state
        contradiction=collect(db,"contradiction",5)
        report["contradiction"]={"collector":contradiction,"http":http(latest)}
        assert contradiction["finished"]==375 and contradiction["failures"][-1]=="ATTESTED_HISTORY_CONFLICT" and stable()==base_state
        assert all(x["status"]==304 for x in report["contradiction"]["http"].values())
        if a.enrichment:
            def incident(mid=old_ids[0]):
                return db.execute("""SELECT id,competition_season_id,season_id,round_id,archive_position,
                    home_team_id,away_team_id,home_score,away_score,home_score_ht,away_score_ht,revision,
                    (SELECT s.corners FROM core.team_match_stats s WHERE s.match_id=m.id AND s.season_id=m.season_id
                    AND s.team_id=m.home_team_id AND s.period='all') FROM core.matches m WHERE id=%s""",(mid,)).fetchone()
            previous=incident()
            assert previous[9:11]==(None,None) and previous[-1] is None
            enriched_result=collect(db,"enrichment",6)
            observed=incident()
            report["enrichment"]={"collector":enriched_result,"http":http(latest),"before":previous,"after":observed}
            assert enriched_result["finished"]==375 and enriched_result["failures"]==contradiction["failures"]
            assert observed[:9]==previous[:9] and stable()[1:]==base_state[1:]
            assert observed[9:]==(0,1,previous[11]+1,4),("attested match ignored enrichment",observed)
            assert report["enrichment"]["http"][target_folder]["status"]==200
            tags=http()
            missing_stat=collect(db,"without_enrichment",7)
            report["retained_enrichment"]={"collector":missing_stat,"http":http(tags),"row":incident()}
            assert incident()==observed and all(x["status"]==304 for x in report["retained_enrichment"]["http"].values())
            exact_repeat=subprocess.run(cmd,cwd=w/"backend",env=env,capture_output=True,text=True,timeout=45)
            report["enriched_original_run_repeat"]={"returncode":exact_repeat.returncode,"stdout":exact_repeat.stdout,"stderr":exact_repeat.stderr}
            with db.transaction():
                db.execute("SET LOCAL ROLE vega_calc")
                db.execute("UPDATE agg.power_runs SET status='superseded' WHERE id=2097")
                db.execute("INSERT INTO agg.power_runs(id,kind,method_version,status,started_at,finished_at,matches) VALUES (3101,'elo','control','published',now(),now(),35)")
                db.execute("UPDATE agg.team_elo SET run_id=3101,elo_after=elo_after+1 WHERE run_id=2097")
            after_calculation=stable()
            malformed=db.execute("DELETE FROM agg.team_elo e WHERE match_id=%s AND team_id=%s RETURNING to_jsonb(e)",(old_ids[0],previous[5])).fetchone()[0]
            partial=subprocess.run(cmd,cwd=w/"backend",env=env,capture_output=True,text=True,timeout=45)
            report["partial_calculation"]={"returncode":partial.returncode,"stderr":partial.stderr}
            assert partial.returncode and "Elo" in partial.stderr
            from psycopg.types.json import Jsonb
            db.execute("INSERT INTO agg.team_elo SELECT * FROM jsonb_populate_record(NULL::agg.team_elo,%s)",(Jsonb(malformed),))
            assert stable()==after_calculation
            teams=tuple(previous[5:7])
            wrong_team=db.execute("SELECT id FROM core.teams WHERE id<>ALL(%s) ORDER BY id LIMIT 1",(list(teams),)).fetchone()[0]
            db.execute("UPDATE agg.team_elo SET team_id=%s WHERE match_id=%s AND team_id=%s",(wrong_team,old_ids[0],teams[0]))
            wrong_pair=subprocess.run(cmd,cwd=w/"backend",env=env,capture_output=True,text=True,timeout=45)
            report["wrong_calculated_pair"]={"returncode":wrong_pair.returncode,"stderr":wrong_pair.stderr}
            assert wrong_pair.returncode and "Elo" in wrong_pair.stderr
            db.execute("UPDATE agg.team_elo SET team_id=%s WHERE match_id=%s AND team_id=%s",(teams[0],old_ids[0],wrong_team))
            versions=db.execute("SELECT row_to_json(v)::text FROM ops.resource_versions v ORDER BY resource_kind,resource_id").fetchall()
            newer_repeat=subprocess.run(cmd,cwd=w/"backend",env=env,capture_output=True,text=True,timeout=45)
            report["after_calculation_repeat"]={"returncode":newer_repeat.returncode,"stdout":newer_repeat.stdout,"stderr":newer_repeat.stderr}
            assert newer_repeat.returncode==0,newer_repeat.stderr
            outcome=json.loads(newer_repeat.stdout)
            assert outcome["restored"]==outcome["would_restore"]==outcome["elo_pending_sides"]==0 and outcome["elo_run"]==3101
            assert stable()==after_calculation and all(x["status"]==304 for x in http(tags).values())
            assert versions==db.execute("SELECT row_to_json(v)::text FROM ops.resource_versions v ORDER BY resource_kind,resource_id").fetchall()
            assert exact_repeat.returncode==0 and json.loads(exact_repeat.stdout)["restored"]==0,exact_repeat.stderr
        with psycopg.connect(database(a.tag+"fresh"),autocommit=True) as fresh:
            migrate(fresh)
            assert collect(fresh,"old",0)["finished"]==364
            original=fresh.execute("SELECT provider_key,entity_id FROM core.provider_ids WHERE provider='open_matchday' AND entity_type='match' AND provider_key=ANY(%s) ORDER BY provider_key",(provider_keys,)).fetchall()
            assert len(original)==35 and not ({r[1] for r in original}&set(old_ids))
            assert collect(fresh,"current",1)["finished"]==374
            assert original==fresh.execute("SELECT provider_key,entity_id FROM core.provider_ids WHERE provider='open_matchday' AND entity_type='match' AND provider_key=ANY(%s) ORDER BY provider_key",(provider_keys,)).fetchall()
            report["fresh_historical"]={"ordinary_ids":original,"continued":374}
        with psycopg.connect(database(a.tag+"missing"),autocommit=True) as fresh:
            migrate(fresh)
            assert collect(fresh,"current",0)["finished"]==339
            attempted=collect(fresh,"old_again",1)
            assert attempted["finished"]==339 and attempted["failures"]==["ATTESTED_HISTORY_RESTORE_REQUIRED"]*3
            report["existing_missing"]={"after_original_csv_return":attempted}
        receipt["status"]="passed"
finally:
    server.terminate()
    server.wait(timeout=10)
    (out/"receipt.json").write_text(json.dumps(receipt,ensure_ascii=False,indent=2)+"\n")
print(json.dumps({"status":receipt["status"],"scenarios":list(report)},ensure_ascii=False))
