"""Four frozen Open Matchday result windows through the ordinary collector and the public reader."""
import argparse
import csv
from datetime import datetime, timedelta, timezone
from hashlib import sha256
import io
import json
import os
from pathlib import Path
import re
import subprocess
import sys
from urllib.parse import urlencode, urlsplit
from urllib.request import Request,urlopen

import psycopg
from psycopg import sql

q=Path(__file__).resolve().parent
root=q.parents[2]
diag=root/"tracks/6-teams/ecart-elo-1356"
history=diag/"completude-ligues"
p=argparse.ArgumentParser()
p.add_argument("tree",type=Path)
p.add_argument("tag")
p.add_argument("--red",action="store_true")
a=p.parse_args()
sys.path.insert(0,str(a.tree/"backend"))
from vega import sources
from vega.sources.open_matchday import SPELLINGS
from vega.store import migrate

assert re.fullmatch(r"[a-z0-9]+",a.tag)
out=q/a.tag
out.mkdir()
base=f"postgresql://postgres@127.0.0.1:{int(os.environ.get('OPEN_MATCHDAY_REPLAY_PORT','55439'))}/"
dsn=base+"vega_v2_open_matchday_restore_"+a.tag
folders=("ENG_6_national-league-north","ENG_6_national-league-south","ENG_7_northern-premier-league")
paths={
    "4":{f:history/f"upstream-2026-11-04-{f}.csv" for f in folders},
    "10":{f:history/f"upstream-2026-11-11-{f}.csv" for f in folders},
    "17":{f:diag/"public-source/old/data"/f/"results_2627.csv" for f in folders},
    "18":{f:diag/"public-source/current/data"/f/"results_2627.csv" for f in folders},
}
streams={date:{f:list(csv.DictReader(path.open())) for f,path in files.items()} for date,files in paths.items()}
assert {k:[len(v[f]) for f in folders] for k,v in streams.items()}=={"4":[113,121,107],"10":[121,120,114],"17":[124,122,118],"18":[116,112,111]}
for stage in ("future","sparse","edge","inside","reopen","reversed"):
    streams[stage]={f:[dict(r) for r in streams["18"][f]] for f in folders}
first_date=min(r["date"] for r in streams["future"][folders[0]])
streams["future"][folders[0]]=[r for r in streams["future"][folders[0]] if r["date"]!=first_date]
future=dict(streams["future"][folders[0]][-1],date="2026-11-23")
streams["future"][folders[0]].append(future)
for stage in ("sparse","edge","inside","reopen","reversed"):
    streams[stage]={f:[dict(r) for r in streams["future"][f]] for f in folders}
streams["sparse"][folders[0]]=streams["sparse"][folders[0]][-4:]
edge_date=min(r["date"] for r in streams["edge"][folders[0]])
assert sum(r["date"]==edge_date for r in streams["edge"][folders[0]])>1
streams["edge"][folders[0]].remove(next(r for r in streams["edge"][folders[0]] if r["date"]==edge_date))
streams["inside"][folders[0]].pop(len(streams["inside"][folders[0]])//2)
previous_prefix=next(r for r in streams["18"][folders[0]] if r["date"]==first_date)
streams["reversed"][folders[0]].append(dict(previous_prefix,home=previous_prefix["away"],away=previous_prefix["home"]))

def key(folder,r):
    return f"{folder}:2026/2027:{r['date']}|{SPELLINGS.get(r['home'],r['home'])}|{SPELLINGS.get(r['away'],r['away'])}"

def query(stage):
    def get(url,as_text=False):
        parsed=urlsplit(url)
        assert parsed.hostname=="raw.githubusercontent.com"
        if parsed.path.endswith("build_summary.json"):
            return {"season":"2627","generated_utc":"2026-11-18T14:00:00Z",
                    "leagues":[{"folder":f,"league":f,"results":len(streams[stage][f]),
                                "fixtures":int(stage=="reopen" and f==folders[0])} for f in folders]}
        folder=parsed.path.split("/")[-2]
        part=parsed.path.split("/")[-1].split("_")[0]
        rows=streams[stage][folder] if part=="results" else [previous_prefix]
        content=io.StringIO()
        writer=csv.DictWriter(content,fieldnames=list(rows[0]))
        writer.writeheader()
        writer.writerows(rows)
        return content.getvalue()
    return get

with psycopg.connect(base+"postgres",autocommit=True) as ctl:
    ctl.execute(sql.SQL("CREATE DATABASE {}").format(sql.Identifier(urlsplit(dsn).path[1:])))
db=psycopg.connect(dsn,autocommit=True)
migrate(db)
server=subprocess.Popen(["node",str(q/"serve.mjs"),str(a.tree),dsn],stdout=subprocess.PIPE,stderr=(out/"http.log").open("w"),text=True)
origin="http://127.0.0.1:"+server.stdout.readline().strip()
assert not origin.endswith(":")
seen={}
steps=[]
start=datetime(2026,11,4,18,tzinfo=timezone.utc)

def rows():
    return dict(db.execute("""SELECT p.provider_key,row_to_json(m)::text FROM core.matches m
        JOIN core.provider_ids p ON p.entity_type='match' AND p.entity_id=m.id AND p.provider='open_matchday'
        WHERE m.status='finished'""").fetchall())
def capture(known=None):
    status={}
    for league in folders:
        url=origin+"/api/cup-table?"+urlencode(dict(competition=league,season="2026/2027",kind="results"))
        with urlopen(Request(url,headers={"If-None-Match":known[league]["etag"]} if known else {}),timeout=12) as res:
            status[league]={"etag":res.headers["ETag"],"status":res.status,"count":len(json.loads(res.read())) if res.status==200 else None}
    return status

# urllib reports 304 through HTTPError.
import urllib.error
def tags(previous=None):
    try:
        return capture(previous)
    except urllib.error.HTTPError:
        output={}
        for league in folders:
            url=origin+"/api/cup-table?"+urlencode(dict(competition=league,season="2026/2027",kind="results"))
            try:
                res=urlopen(Request(url,headers={"If-None-Match":previous[league]["etag"]} if previous else {}),timeout=12)
            except urllib.error.HTTPError as err:
                res=err
            contents=res.read()
            output[league]={"etag":res.headers["ETag"],"status":res.status,"count":len(json.loads(contents)) if contents else None}
        return output

def run(name, day):
    with db.transaction():
        db.execute("SET LOCAL ROLE vega_collect")
        sources.run_due(db,query(name),start+timedelta(days=day),names={"open_matchday"})
    current=rows()
    failures=[r[0] for r in db.execute("SELECT error_code FROM ops.parse_failures ORDER BY id")]
    steps.append({"stage":name,"completed":len(current),"parse_failures":failures,"http":tags()})
    return current,failures

try:
    prior,failures=run("4",0)
    assert not failures
    current,new_failures=run("10",6)
    if a.red:
        assert new_failures.count("SNAPSHOT_DROPS_RESULT")==2,new_failures
        status="red"
    else:
        for stage, day in (("10",6),("17",13),("18",14),("future",20)):
            if stage=="10":
                actual,failures=current,new_failures
            else:
                actual,failures=run(stage,day)
            assert not failures,(stage,failures)
            incoming={key(f,row) for f in folders for row in streams[stage][f]}
            for retained in prior.keys()-incoming:
                assert actual[retained]==prior[retained],(stage,retained)
            assert set(actual)==set(prior)|incoming
            prior=actual
        stable=tags()
        again,failures=run("future",21)
        assert again==prior and not failures
        assert all(r["status"]==304 for r in tags(stable).values())
        for stage, day in (("sparse",22),("edge",23),("inside",24),("reopen",25),("reversed",26)):
            again,failures=run(stage,day)
            assert again==prior and len(failures)==day-21,(stage,failures)
            assert all(r["status"]==304 for r in tags(stable).values())
        status="passed"
finally:
    server.terminate()
    server.wait(timeout=10)
    (out/"receipt.json").write_text(json.dumps({"status":locals().get("status","failed"),"dsn":dsn,"steps":steps,
        "source_sha256":{str(p.relative_to(root)):sha256(p.read_bytes()).hexdigest() for v in paths.values() for p in v.values()},
        "scope":"4/10 are raw captured results with a reconstructed file-count envelope and empty fixtures. Later flags are controls."},indent=2))
print(status)
