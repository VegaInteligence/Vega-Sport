"""PostgreSQL 18 and HTTP operator E2E. Capture a documented reconstructed control first."""
import argparse
import csv
from datetime import datetime, timezone
from hashlib import sha256
import importlib.util
import json
import os
from pathlib import Path
import subprocess
import sys
import tempfile
from urllib.error import HTTPError
from urllib.parse import urlencode
from urllib.request import Request, urlopen
import zlib

import psycopg
from psycopg import sql
from psycopg.types.json import Jsonb

q = Path(__file__).resolve().parent
e = q.parents[2]
diagnostic = e / "tracks/6-teams/ecart-elo-1356"
p = argparse.ArgumentParser()
p.add_argument("worktree", type=Path)
p.add_argument("tag")
p.add_argument("--real-preimage", type=Path)
p.add_argument("--red", action="store_true")
p.add_argument("--portable", action="store_true")
a = p.parse_args()
w = a.worktree
assert a.tag.isascii() and a.tag.isalnum() and a.tag.islower()
out = q / a.tag
out.mkdir()
name = "vega_v2_open_matchday_restore_" + a.tag
port = int(os.environ.get("OPEN_MATCHDAY_REPLAY_PORT", "55439"))
base = f"postgresql://postgres@127.0.0.1:{port}/"
dsn = base + name
if not a.portable:
    assert subprocess.check_output(["docker", "--context", "colima", "port", "vega-vi27-audit-ci-pg18", "5432/tcp"], text=True).strip() == f"127.0.0.1:{port}"
env = {**os.environ, "PYTHONDONTWRITEBYTECODE": "1", "PYTHONPATH": str(w / "backend")}

def read(file):
    return json.loads(zlib.decompress(file.read_bytes()))

def save(file, value):
    file.write_bytes(zlib.compress(json.dumps(value, default=str, ensure_ascii=False, separators=(",", ":")).encode()))

def rows(capture, key):
    return [json.loads(raw) for raw in capture["reads"][key]["rows_json"]]

def insert(db, table, documents):
    if documents:
        type_ = sql.Identifier(*table.split("."))
        insertable = db.execute("""SELECT attname FROM pg_attribute
            WHERE attrelid=%s::regclass AND attnum>0 AND NOT attisdropped AND attgenerated='' ORDER BY attnum""",(table,)).fetchall()
        columns = sql.SQL(", ").join(sql.Identifier(c) for (c,) in insertable)
        db.execute(sql.SQL("INSERT INTO {} ({}) SELECT {} FROM jsonb_populate_recordset(NULL::{},%s)").format(type_, columns, columns, type_), (Jsonb(documents),))

def migrate_from(root):
    subprocess.run([sys.executable, "-c", "from vega.store import connect_local,migrate; import sys; migrate(connect_local(sys.argv[1]))", dsn],
                   env={**env, "PYTHONPATH": str(root / "backend")}, check=True)

if not a.real_preimage:
    spec = importlib.util.spec_from_file_location("probe", diagnostic / "preimage/probe.py")
    probe = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(probe)
after_path = e / "delivery/rds-preimage/apres-v2/inputs.json.zlib"
after = read(after_path)
facts = after["witnesses"]
keys = after["provider_keys"]
ids = [r[0] for r in facts]
elo = rows(after, "table.agg.team_elo")
run = rows(after, "elo_runs")
organisers = {r["old_match_id"]:r for r in json.loads((diagnostic / "organizer/matched-35.json").read_bytes())}
assert {(i,r["edition"],r["date"],r["hs"],r["aws"]) for i,r in organisers.items()} == {
    (i,edition,day,hs,aws) for i,_,_,day,hs,aws,edition in facts}
parent_kinds = {
    "core.seasons": ("season_id",),
    "core.competition_seasons": ("competition_season_id_season_id",),
    "core.teams": ("away_team_id", "home_team_id"),
    "core.rounds": ("round_id",),
    "core.venues": ("venue_id",),
    "core.referees": ("referee_id",),
}
folders = sorted({key.split(":")[0] for key in keys})
cmd_receipts = []

with psycopg.connect(base + "postgres", autocommit=True) as ctl:
    ctl.execute(sql.SQL("CREATE DATABASE {}").format(sql.Identifier(name)))
if a.portable:
    assert a.real_preimage
    # Replay the exact production migration prefix from the reviewed checkout.
    # The normal store migrator still verifies and records every checksum.
    with tempfile.TemporaryDirectory(prefix="matchday-r133-") as tmp:
        path = Path(tmp)
        prefix = path / "sql"
        prefix.mkdir()
        for source in (w / "backend/sql").glob("*.sql"):
            if source.name <= "133_cohort_max_wait.sql":
                (prefix / source.name).write_bytes(source.read_bytes())
        subprocess.run([sys.executable, "-c",
                        "from vega import store; import sys; store.__file__=sys.argv[1]; store.migrate(store.connect_local(sys.argv[2]))",
                        str(path / "vega/store.py"), dsn], env=env, check=True)
else:
    migrate_from(diagnostic / "runtime-R")
db = psycopg.connect(dsn, autocommit=True)
db.execute("SET TIME ZONE 'UTC'")
with db.transaction():
    if a.real_preimage:
        prepath = a.real_preimage.resolve()
        pre = read(prepath)
        for table in ("core.seasons", "core.teams", "core.venues", "core.referees"):
            refs = {r["id"]:r for k in parent_kinds[table] for r in rows(pre, "parent.matches_" + k + "_fkey")}
            if table == "core.teams":
                db.execute("INSERT INTO core.countries(code) SELECT unnest(%s::text[]) ON CONFLICT DO NOTHING",
                           (sorted({r["country_code"] for r in refs.values() if r["country_code"]}),))
                asset_ids={r["crest_asset_id"] for r in refs.values() if r["crest_asset_id"]}
                media=json.loads((e/"db/media_state_verified/assets.json").read_bytes())
                matched=[dict(zip(media["columns"],r,strict=True)) for r in media["rows"] if r[0] in asset_ids]
                assert {r["id"] for r in matched}==asset_ids
                for asset in matched:
                    db.execute("INSERT INTO core.assets(id,kind,source_url,s3_key,sha256,content_type,width,height) VALUES (%s,%s,%s,%s,decode(%s,'hex'),%s,%s,%s)",
                               tuple(asset[c] for c in media["columns"]))
            insert(db, table, list(refs.values()))
        editions = rows(pre, "parent.matches_competition_season_id_season_id_fkey")
        for edition in editions:
            db.execute("INSERT INTO core.competitions(id,name) VALUES(%s,%s) ON CONFLICT DO NOTHING",
                       (edition["competition_id"], edition["cup_name"]))
        insert(db, "core.competition_seasons", editions)
        insert(db, "core.rounds", rows(pre, "parent.matches_round_id_fkey"))
    else:
        db.execute("INSERT INTO core.seasons(id,label) VALUES (2026,'2026/2027')")
        for eid, folder in zip((332, 333, 334), folders, strict=True):
            db.execute("INSERT INTO core.competitions(id,name) VALUES(%s,%s)", (eid, folder))
            db.execute("INSERT INTO core.competition_seasons(id,competition_id,season_id,native_label,cup_key,cup_name) VALUES(%s,%s,2026,'2026/2027',%s,%s)",
                       (eid, eid, "open-matchday:" + folder + ":2026/2027", folder))
            db.execute("INSERT INTO core.rounds(id,competition_season_id,name) VALUES(%s,%s,'Round of control')", (eid, eid))
        for fact, key in zip(facts, keys, strict=True):
            mid, home, away, day, hs, aws, eid = fact
            names = key.split(":",2)[2].split("|")[1:]
            for side, label in zip((home,away), names, strict=True):
                db.execute("INSERT INTO core.teams(id,name) VALUES(%s,%s) ON CONFLICT DO NOTHING",(side,label))
            db.execute("INSERT INTO core.matches(id,competition_season_id,season_id,match_date,source,status,home_team_id,away_team_id,home_team_name,away_team_name,home_score,away_score,round_id,archive_position) VALUES(%s,%s,2026,%s,'open_matchday','finished',%s,%s,%s,%s,%s,%s,%s,%s)",
                       (mid,eid,day,home,away,*names,hs,aws,eid,mid))
            db.execute("INSERT INTO core.provider_ids(entity_type,provider,provider_key,entity_id) VALUES('match','open_matchday',%s,%s)",(key,mid))
    insert(db, "agg.power_runs", run)
    insert(db, "agg.team_elo", elo)
    db.execute("SELECT core.ensure_season_partitions(2026)")
    db.execute("SELECT setval(pg_get_serial_sequence('core.matches','id'),20000)")
    # The reported ten post-incident facts. The capture contains a projection;
    # columns omitted by that projection have local control values only.
    with (diagnostic / "new-results-10.csv").open() as source:
        newer = list(csv.DictReader(source))
    assert len(newer) == 10
    for n,a_match in enumerate(newer):
        for team in ("home","away"):
            db.execute("INSERT INTO core.teams(id,name) VALUES (%s,%s) ON CONFLICT DO NOTHING",
                       (int(a_match[team+"_team_id"]),a_match[team]))
        db.execute("""INSERT INTO core.matches(id,competition_season_id,season_id,match_date,source,status,
                   home_team_id,away_team_id,home_team_name,away_team_name,home_score,away_score,archive_position,updated_at)
                   VALUES (%s,%s,2026,%s,'open_matchday','finished',%s,%s,%s,%s,%s,%s,%s,%s)""",
           (int(a_match["id"]),int(a_match["competition_season_id"]),a_match["match_date"],
            int(a_match["home_team_id"]),int(a_match["away_team_id"]),a_match["home"],a_match["away"],
            int(a_match["home_score"]),int(a_match["away_score"]),10000+n,a_match["updated_at"]))

if not a.real_preimage:
    pre = probe.collect(db)
    assert pre["reads"]["table.core.matches"]["count"] == 35
    prepath = out / "control-preimage.json.zlib"
    save(prepath, pre)
    db.execute("DELETE FROM core.provider_ids WHERE entity_type='match' AND entity_id=ANY(%s)", (ids,))
    db.execute("DELETE FROM core.matches WHERE id=ANY(%s)", (ids,))
    after_path = out / "control-after.json.zlib"
    actual_after = probe.collect(db)
    assert actual_after["reads"]["table.core.matches"]["count"] == 0
    save(after_path, actual_after)

migrate_from(w)
def state():
    return {label:db.execute(statement).fetchone()[0] for label, statement in {
        "matches":"SELECT coalesce(jsonb_agg(to_jsonb(m) ORDER BY id),'[]') FROM core.matches m",
        "bindings":"SELECT coalesce(jsonb_agg(to_jsonb(p) ORDER BY provider,provider_key),'[]') FROM core.provider_ids p",
        "elo":"SELECT jsonb_agg(to_jsonb(e) ORDER BY match_id,team_id) FROM agg.team_elo e",
        "resource_versions":"SELECT jsonb_agg(to_jsonb(v) ORDER BY resource_kind,resource_id) FROM ops.resource_versions v",
        "publication":"SELECT to_jsonb(p) FROM ops.publication p",
        "identity":"SELECT jsonb_build_array(last_value,is_called) FROM core.matches_id_seq",
    }.items()}

def operator(label, extra=(), apply=False, expected=0, expect_reason=None, check_no_mutation=True):
    before = state()
    command = [sys.executable, "-m", "vega.open_matchday_restore", "--dsn", dsn,
               "--preimage", str(prepath), "--preimage-sha256", sha256(prepath.read_bytes()).hexdigest(),
               "--postimage", str(after_path), "--postimage-sha256", sha256(after_path.read_bytes()).hexdigest()]
    if apply:
        command.append("--apply")
    command.extend(extra)
    result = subprocess.run(command,cwd=w/"backend",env=env,text=True,capture_output=True,timeout=50)
    (out/(label+".stdout")).write_text(result.stdout)
    (out/(label+".stderr")).write_text(result.stderr)
    cmd_receipts.append({"label":label,"command":command,"exit":result.returncode})
    assert (result.returncode==0)==(expected==0), (label, result.stderr)
    if expect_reason:
        assert expect_reason in (result.stdout + result.stderr), (label,result.stdout,result.stderr)
    if check_no_mutation:
        assert state()==before,label
    return json.loads(result.stdout) if expected==0 else None

before = state()
assert len(before["matches"])==10 and len(before["elo"])==70
if a.red:
    operator("red-operator",expected=1,expect_reason="No module named")
    (out/"receipt.json").write_text(json.dumps({"status":"red","commands":cmd_receipts},indent=2))
    sys.exit(0)

with (out/"http.log").open("w") as http_log:
    server=subprocess.Popen(["node",str(q/"serve.mjs"),str(w),dsn],stdout=subprocess.PIPE,stderr=http_log,text=True)
    origin="http://127.0.0.1:"+server.stdout.readline().strip()
    assert not origin.endswith(":")
    def get(path, etag=None):
        try:
            response=urlopen(Request(origin+path,headers={"If-None-Match":etag} if etag else {}),timeout=15)
        except HTTPError as error:
            response=error
        body=response.read()
        return {"status":response.status,"etag":response.headers.get("etag"),"body":json.loads(body) if body else None}
    def league(folder):
        return "/api/cup-table?"+urlencode(dict(competition=folder,season="2026/2027",kind="results"))
    def detail(mid):
        return f"/api/matches/m_v{mid:07d}/summary"
    fixtures="/api/fixtures?from=2026-08-31&to=2026-09-05&status=played&limit=100"
    try:
        assert all(get(detail(i))["status"]==404 for i in ids)
        initial={f:get(league(f)) for f in folders}
        old_fixture=get(fixtures)
        assert old_fixture["status"]==200
        assert operator("dry-run")["would_restore"]==35
        operator("bad-sha",("--preimage-sha256","0"*64),apply=True,expected=1,expect_reason="digest")
        with psycopg.connect(dsn,autocommit=True) as writer:
            with writer.transaction():
                writer.execute("SET LOCAL ROLE vega_collect")
                writer.execute("LOCK TABLE core.matches IN ROW EXCLUSIVE MODE")
                operator("concurrent-writer",apply=True,expected=1,expect_reason="busy")
        change=facts[0]
        cols=(change[0],change[6],change[1],change[2])
        db.execute("INSERT INTO core.matches(id,competition_season_id,season_id,source,home_team_id,away_team_id) VALUES(%s,%s,2026,'open_matchday',%s,%s)",cols)
        operator("occupied-id",apply=True,expected=1,expect_reason="collision")
        db.execute("DELETE FROM core.matches WHERE id=%s",(change[0],))
        db.execute("INSERT INTO core.provider_ids(entity_type,provider,provider_key,entity_id) VALUES('match','open_matchday',%s,%s)",(keys[0],int(newer[0]["id"])))
        operator("shunted-key",apply=True,expected=1,expect_reason="collision")
        db.execute("DELETE FROM core.provider_ids WHERE entity_type='match' AND provider='open_matchday' AND provider_key=%s",(keys[0],))
        db.execute("""INSERT INTO core.matches(id,competition_season_id,season_id,source,match_date,home_team_id,away_team_id)
                   VALUES(19500,%s,2026,'open_matchday',%s,%s,%s)""",(change[6],change[3],change[1],change[2]))
        operator("same-pair-other-id",apply=True,expected=1,expect_reason="same-day pair collision")
        db.execute("DELETE FROM core.matches WHERE id=19500")
        round_id=next(m["round_id"] for m in rows(pre,"table.core.matches"))
        round_name=db.execute("SELECT name FROM core.rounds WHERE id=%s",(round_id,)).fetchone()[0]
        db.execute("UPDATE core.rounds SET name=name||' shifted' WHERE id=%s",(round_id,))
        operator("moved-parent",apply=True,expected=1,expect_reason="parent drift")
        db.execute("UPDATE core.rounds SET name=%s WHERE id=%s",(round_name,round_id))

        db.execute("UPDATE agg.team_elo SET elo_after=elo_after+1 WHERE match_id=%s AND team_id=%s",(change[0],change[1]))
        operator("changed-elo",apply=True,expected=1,expect_reason="Elo")
        db.execute("UPDATE agg.team_elo SET elo_after=%s WHERE match_id=%s AND team_id=%s",(next(x["elo_after"] for x in elo if (x["match_id"],x["team_id"])==(change[0],change[1])),change[0],change[1]))
        assert state()==before
        applied=operator("apply",apply=True,check_no_mutation=False)
        assert applied["restored"]==35
        restored=state()
        assert restored["elo"]==before["elo"]
        assert all(m in restored["matches"] for m in before["matches"])
        assert len(restored["matches"])==45 and restored["identity"]==before["identity"]
        assert sorted((m for m in restored["matches"] if m["id"] in ids),key=lambda x:x["id"])==sorted(rows(pre,"table.core.matches"),key=lambda x:x["id"])
        assert db.execute("SELECT count(*) FROM agg.team_elo e JOIN core.matches m ON m.id=e.match_id AND e.season_id=m.season_id AND e.team_id IN (m.home_team_id,m.away_team_id)").fetchone()[0]==70
        fresh={f:get(league(f),initial[f]["etag"]) for f in folders}
        assert all(r["status"]==200 for r in fresh.values())
        conditional=get(fixtures,old_fixture["etag"])
        assert conditional["status"]==304 and conditional["etag"]==old_fixture["etag"]
        # Cup editions are excluded by design from the native detail route.
        assert all(get(detail(i))["status"]==404 for i in ids)
        with db.transaction():
            db.execute("SET LOCAL ROLE vega_read")
            read_keys=db.execute("SELECT match_id,key FROM api.cup_matches WHERE match_id=ANY(%s) ORDER BY match_id", (ids,)).fetchall()
        assert read_keys==list(zip(ids,keys,strict=True))
        assert all(any(row["date"]==m["match_date"] and row["home"]==m["home_team_name"] and row["away"]==m["away_team_name"]
                       and row["ft_home"]==str(m["home_score"]) and row["ft_away"]==str(m["away_score"])
                       for row in fresh[folders[m["competition_season_id"]-332]]["body"])
                   for m in rows(pre,"table.core.matches"))
        assert len(applied["edition_versions"])==3 and state()["publication"]==before["publication"]
        assert operator("repeat",apply=True)["restored"]==0
        assert all(get(league(f),fresh[f]["etag"])["status"]==304 for f in folders)
        assert get(fixtures,conditional["etag"])["status"]==304
        (out/"http-receipt.json").write_text(json.dumps({"before_cups":initial,"after_cups":fresh,"before_fixtures":old_fixture,"after_fixtures":conditional,"cup_match_ids_read_as_vega_read":read_keys,"all_native_detail_status":404},ensure_ascii=False,indent=2))
    finally:
        server.terminate()
        server.wait(timeout=10)
        (out/"commands.json").write_text(json.dumps(cmd_receipts,indent=2))
print(json.dumps({"status":"passed","database":name,"preimage":"real" if a.real_preimage else "reconstructed_control","commands":cmd_receipts}))
