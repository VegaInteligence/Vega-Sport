"""Replay the reviewed Open Matchday proofs from two frozen input archives and a local PostgreSQL 18."""
import argparse
from hashlib import file_digest, sha256
import json
import os
from pathlib import Path
import re
import shutil
import subprocess
import sys
from zipfile import ZipFile

import psycopg


PACKAGE = Path(__file__).resolve().parent
CHECKS = Path("tracks/4-history/restauration-open-matchday")


def digest(path):
    with path.open("rb") as body:
        return file_digest(body, "sha256").hexdigest()


def require(ok, message):
    if not ok:
        raise SystemExit(message)


def copy_inputs(output, inventory, archives):
    for relative, expected in inventory["embedded"].items():
        local = PACKAGE / "payload" / relative
        require(digest(local) == expected, f"Wrong supplemental file {relative}")
        target = output / relative
        target.parent.mkdir(parents=True, exist_ok=True)
        shutil.copyfile(local, target)

    for label, path in archives.items():
        inventory_entry = inventory["archives"][label]
        require(digest(path) == inventory_entry["sha256"], f"Incorrect archive digest for {label}")
        with ZipFile(path) as source:
            for member, descriptor in inventory_entry["members"].items():
                name = descriptor["path"]
                body = source.read(member)
                require(sha256(body).hexdigest() == descriptor["sha256"], f"Incorrect witness digest for {member}")
                dest = output / name
                dest.parent.mkdir(parents=True, exist_ok=True)
                dest.write_bytes(body)


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--worktree", required=True, type=Path)
    parser.add_argument("--identities", required=True, type=Path, help="35-matchs-identites-et-elo.zip")
    parser.add_argument("--windows", required=True, type=Path, help="capsule-completude-partage-20261118.zip")
    parser.add_argument("--output", required=True, type=Path, help="a new local directory for all evidence")
    parser.add_argument("--port", required=True, type=int, help="dedicated PostgreSQL 18 at 127.0.0.1")
    parser.add_argument("--tag", required=True, help="new 2–16 character database suffix, lower case ASCII")
    args = parser.parse_args()
    worktree = args.worktree.resolve()
    output = args.output.resolve()
    require(1 <= args.port <= 65535 and re.fullmatch(r"[a-z0-9]{2,16}", args.tag), "Invalid port or tag.")
    inventory = json.loads((PACKAGE / "inputs.json").read_text())
    head = subprocess.check_output(["git", "-C", str(worktree), "rev-parse", "HEAD"], text=True).strip()
    require(head == inventory["candidate"], f"Expected checkout at {inventory['candidate']}, found {head}.")
    versions = ["backend/vega", "backend/sql", "backend/api", "backend/tests"]
    status = subprocess.check_output(["git", "-C", str(worktree), "status", "--porcelain", "--", *versions], text=True)
    require(not status, "Use a clean candidate checkout.")
    with psycopg.connect(f"postgresql://postgres@127.0.0.1:{args.port}/postgres") as server:
        require(server.info.server_version // 10000 == 18, "PostgreSQL 18 is required.")
    output.mkdir(parents=True, exist_ok=False)
    copy_inputs(output, inventory, {"identities": args.identities, "windows": args.windows})
    checks = output / CHECKS
    env = {**os.environ, "OPEN_MATCHDAY_REPLAY_PORT": str(args.port), "PYTHONDONTWRITEBYTECODE": "1"}
    preimage = output / "delivery/rds-preimage/avant-v3/inputs.json.zlib"
    physical_tag = args.tag + "physical"
    stages = [
        ("workflow", physical_tag, "--portable", "--real-preimage", str(preimage)),
        ("continuity", args.tag + "continuity", "--template", physical_tag, "--enrichment"),
        ("rolling", args.tag + "rolling"),
        ("maintenance", args.tag + "maintenance", "--template", physical_tag),
    ]
    transcripts = {}
    for script, tag, *flags in stages:
        entry = checks / (script + ".py")
        log = checks / (script + ".log")
        command = [sys.executable, str(entry), str(worktree), tag, *flags]
        with log.open("w") as transcript:
            subprocess.run(command, cwd=checks, env=env, stdout=transcript, stderr=subprocess.STDOUT, check=True)
        transcripts[script] = {"command": command, "log": str(log.relative_to(output))}
    def report(suffix, name="receipt.json"):
        return json.loads((checks / (args.tag + suffix) / name).read_text())

    physical = report("physical", "apply.stdout")
    restored_http = report("physical", "http-receipt.json")
    continuity = report("continuity")["checks"]
    rolling = report("rolling")["steps"]
    maintenance = report("maintenance")["cases"]
    summary = {
        "status": "passed",
        "candidate": head,
        "postgres_major": 18,
        "physical_restore": physical,
        "verified_old_api_ids": len(restored_http["cup_match_ids_read_as_vega_read"]),
        "ordinary_collect_finished": [continuity[k]["collector"]["finished"] for k in ("first", "repeat", "novel")],
        "rolling_finished": {stage["stage"]: stage["completed"] for stage in rolling[:5]},
        "enriched_match": continuity["enrichment"]["after"],
        "without_enrichment_http": {f: h["status"] for f, h in continuity["retained_enrichment"]["http"].items()},
        "completed_elo_noop": json.loads(continuity["after_calculation_repeat"]["stdout"]),
        "superseded_elo_still_pending": maintenance["latest-apply"]["report"],
        "transcripts": transcripts,
    }
    (output / "summary.json").write_text(json.dumps(summary, ensure_ascii=False, indent=2) + "\n")
    print(json.dumps({"status": "passed", "candidate": head, "receipt": str(output / "summary.json")}))


if __name__ == "__main__":
    main()

