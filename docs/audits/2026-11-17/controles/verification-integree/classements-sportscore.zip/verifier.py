import hashlib,json
from pathlib import Path
p=Path(__file__).resolve().parent
for name,h in json.loads((p/'empreintes.json').read_bytes()).items():assert hashlib.sha256((p/name).read_bytes()).hexdigest()==h,name
cases={}
for label in ['rouge','vert','confirmation','integration']:
 obj=json.loads((p/'preuve'/label/'results.json').read_bytes())
 assert len(obj['records'])==28
 cases[label]=sum(not r.get('errors') for r in obj['records'])
 if label!='rouge':
  mig=p/'migrations/150_sportscore_standings_quarantine.sql'
  assert hashlib.sha256(mig.read_bytes()).hexdigest()==obj['migration150']
summary=json.loads((p/'preuve/integration/comparison.json').read_bytes())
assert cases=={'rouge':8,'vert':28,'confirmation':28,'integration':28} and summary['j1_other_unchanged_etags']==59 and summary['statuses_requests_and_representations_match_w2']
assert hashlib.sha256((p/'preuve/integration/results.json').read_bytes()).hexdigest()==summary['complete_candidate_result_sha256']
print(json.dumps({'cas_satisfaits_sur_28':cases,'sha_integre':summary['integrated_commit'],'etags_temoins':summary['j1_other_unchanged_etags']}))
