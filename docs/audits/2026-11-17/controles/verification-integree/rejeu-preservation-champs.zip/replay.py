"""Test stat preservation through the full Open Matchday writer and reader."""
import argparse
from concurrent.futures import ThreadPoolExecutor
from datetime import datetime, timedelta, timezone
from hashlib import sha256
import csv
import io
import json
from pathlib import Path
import re
import subprocess
import sys
from threading import Event
from time import monotonic, sleep
from urllib.error import HTTPError
from urllib.parse import urlencode
from urllib.request import Request, urlopen
import zlib

import psycopg
from psycopg import sql


q = Path(__file__).resolve().parent
p = argparse.ArgumentParser()
p.add_argument("tree", type=Path)
p.add_argument("tag")
p.add_argument("--red", action="store_true")
p.add_argument("--preimage", type=Path, required=True)
p.add_argument("--template", required=True)
p.add_argument("--port", type=int, required=True)
a = p.parse_args()
assert re.fullmatch(r"[a-z0-9]{2,17}", a.tag) and 1 <= a.port <= 65535
assert re.fullmatch(r"vega_v2_open_matchday_restore_[a-z0-9]+", a.template)
tree = a.tree.resolve()
sys.path.insert(0, str(tree / "backend"))
from vega import sources
from vega.store import migrate

sha = subprocess.check_output(["git","-C",str(tree),"rev-parse","HEAD"], text=True).strip()
expected = "599b80497ca7b49d65714f3d54e709c97c0cbe7f" if a.red else "0580dfd4ba645461d6c372fbd7b1d73eaaa779a0"
assert sha == expected
base = f"postgresql://postgres@127.0.0.1:{a.port}/"
name = "vega_v2_open_matchday_restore_fields"+a.tag
dsn = base + name
with psycopg.connect(base + "postgres", autocommit=True) as ctl:
    assert ctl.info.server_version // 10000 == 18
    ctl.execute(sql.SQL("CREATE DATABASE {} TEMPLATE {}").format(sql.Identifier(name), sql.Identifier(a.template)))
db = psycopg.connect(dsn, autocommit=True)
migrate(db)
x = db.execute
saved = a.preimage.resolve()
sealed = json.loads(zlib.decompress(saved.read_bytes()))
ids = [row[0] for row in sealed["witnesses"]]
old_hashed = sealed["provider_keys"]
historic = {}
restored = {r["id"]:r for r in map(json.loads, sealed["reads"]["table.core.matches"]["rows_json"])}
raw_teams = {}
for ident,key in zip(ids, old_hashed, strict=True):
    folder, year, rest = key.split(":", 2)
    day, home, away = rest.split("|")
    match = restored[ident]
    historic.setdefault(folder, []).append(dict(date=day,home=home,away=away,ft_home=str(match["home_score"]),ft_away=str(match["away_score"])))
    assert raw_teams.setdefault(home, match["home_team_id"]) == match["home_team_id"]
    assert raw_teams.setdefault(away, match["away_team_id"]) == match["away_team_id"]
used = set()
for team, ident in raw_teams.items():
    x("""INSERT INTO core.provider_ids(entity_type,provider,provider_key,entity_id,is_current)
         VALUES ('team','open_matchday',%s,%s,%s) ON CONFLICT DO NOTHING""", ("name:"+team,ident,ident not in used))
    used.add(ident)
for table in ("teams","rounds","competitions","competition_seasons"):
    x(sql.SQL("SELECT setval(pg_get_serial_sequence(%s,'id'),(SELECT max(id)+10 FROM {}))")
      .format(sql.Identifier("core", table)), ("core."+table,))

plain_folder = "SCO_3_league-one"
stamp = datetime(2026,11,18,22,tzinfo=timezone.utc)
ordinary = dict(date="2026-11-20",home="North Fields",away="South Fields",ft_home="2",ft_away="1",
                gw="12",ht_home="1",ht_away="0",home_corners="8",home_corners_1h="3",away_corners_1h="2")
poor = {k:v for k,v in ordinary.items() if k not in ("ht_home","ht_away","home_corners","home_corners_1h","away_corners_1h")}

def feed(folders):
    def get(url, as_text=False):
        assert url.startswith("https://raw.githubusercontent.com/oladeeayo/open-matchday/master/")
        if url.endswith("/build_summary.json"):
            return {"season":"2627","leagues":[{"folder":f,"league":f,"results":len(rows),"fixtures":0} for f,rows in folders.items()]}
        folder = url.split("/")[-2]
        assert url.endswith("/results_2627.csv") and as_text, url
        rows = folders[folder]
        text = io.StringIO()
        w = csv.DictWriter(text, fieldnames=list(dict.fromkeys(k for row in rows for k in row)))
        w.writeheader()
        w.writerows(rows)
        return text.getvalue()
    return get

def collect(step, folders, conn=db):
    with conn.transaction():
        conn.execute("SET LOCAL ROLE vega_collect")
        result = sources.run_due(conn, feed(folders), stamp+timedelta(days=step), names={"open_matchday"})
    return result.get(("open_matchday","europe"))

def physical(mid):
    row=x("SELECT to_jsonb(m),xmin::text FROM core.matches m WHERE id=%s",(mid,)).fetchone()
    stats=x("""SELECT team_id,period::text,to_jsonb(t),xmin::text FROM core.team_match_stats t
               WHERE match_id=%s ORDER BY team_id,period""",(mid,)).fetchall()
    return {"row":row[0],"xmin":row[1],"stats":{f"{team}/{period}":{"body":body,"xmin":version}
                                                  for team,period,body,version in stats}}

def old_scope():
    return {
        "matches":x("""SELECT id,match_date::text,kickoff_at,first_finished_at,archive_position,home_score,away_score,
                 home_team_id,away_team_id,round_id FROM core.matches WHERE id=ANY(%s) ORDER BY id""",(ids,)).fetchall(),
        "keys":x("""SELECT provider_key,entity_id FROM core.provider_ids WHERE provider='open_matchday' AND entity_type='match'
                 AND entity_id=ANY(%s) ORDER BY entity_id""",(ids,)).fetchall(),
        "elo":x("""SELECT to_jsonb(e),encode(float4send(elo_after),'hex') FROM agg.team_elo e WHERE match_id=ANY(%s) ORDER BY match_id,team_id""",(ids,)).fetchall(),
    }

assert collect(0,{plain_folder:[ordinary]})=="ok"
mid, home_id, away_id=x("SELECT id,home_team_id,away_team_id FROM core.matches WHERE home_team_name='North Fields'").fetchone()
x("""UPDATE core.matches SET kickoff_at='2026-11-20T19:00:00Z',first_finished_at='2026-11-20T21:00:00Z' WHERE id=%s""",(mid,))
x("""UPDATE core.team_match_stats SET xg=1.25,passes=455,accurate_passes=377 WHERE match_id=%s AND team_id=%s AND period='all'""",(mid,home_id))
x("""UPDATE core.team_match_stats SET possession_pct=59.0 WHERE match_id=%s AND team_id=%s AND period='first_half'""",(mid,home_id))

def outside_only():
    x("""INSERT INTO core.team_match_stats(season_id,match_id,team_id,period,blocked_shots,possession_pct)
         VALUES (2026,%s,%s,'second_half',4,55.0) ON CONFLICT DO NOTHING""",(mid,away_id))
outside_only()
old_mid = 8049
old_home = restored[old_mid]["home_team_id"]
x("""INSERT INTO core.team_match_stats(season_id,match_id,team_id,period,xg,passes,blocked_shots)
     VALUES (2026,%s,%s,'all',1.5,300,4)""",(old_mid,old_home))
control_scope=old_scope()
assert [row[0] for row in control_scope["matches"]]==ids and len(control_scope["keys"])==35 and len(control_scope["elo"])==70
before=physical(mid)
report={"candidate":sha,"database_name":name,"preimage_sha256":sha256(saved.read_bytes()).hexdigest(),"before":before,"cases":{}}
cases=report["cases"]
runner=q/"serve.mjs"
with (q/f"{a.tag}-http.log").open("w") as logs:
    server=subprocess.Popen(["node",str(runner),str(tree),dsn],stdout=subprocess.PIPE,stderr=logs,text=True)
    try:
        port=int(server.stdout.readline().strip())
        def http(folder, etag=None):
            url=f"http://127.0.0.1:{port}/api/cup-table?"+urlencode(dict(competition=folder,season="2026/2027",kind="results"))
            try:
                res=urlopen(Request(url,headers={"If-None-Match":etag} if etag else {}),timeout=15)
            except HTTPError as exc:
                res=exc
            with res:
                data=res.read()
                return {"status":res.status,"etag":res.headers.get("etag"),"body":json.loads(data) if data else None}

        baseline=http(plain_folder)
        corrected=dict(poor,home_corners="0",home_corners_1h="4")
        assert collect(1,{plain_folder:[corrected]})=="ok"
        changed=physical(mid)
        after=http(plain_folder,baseline["etag"])
        home=changed["stats"][f"{home_id}/all"]["body"]
        half=changed["stats"][f"{home_id}/first_half"]["body"]
        stable_fields=("id","season_id","match_date","kickoff_at","first_finished_at","home_team_id","away_team_id","home_score","away_score","round_id")
        assert all(changed["row"][k]==before["row"][k] for k in stable_fields)
        assert changed["row"]["revision"]==before["row"]["revision"]+1 and after["status"]==200
        assert (home["corners"],half["corners"])==(0,4)
        checks={"outside_fields":(home["xg"],home["passes"],home["accurate_passes"],half["possession_pct"])==(1.25,455,377,59.0),
                "outside_only_row":changed["stats"].get(f"{away_id}/second_half")==before["stats"][f"{away_id}/second_half"],
                "ht_db_and_http": [changed["row"]["home_score_ht"],changed["row"]["away_score_ht"]]==[1,0]
                  and [after["body"][0]["ht_home"],after["body"][0]["ht_away"]]==["1","0"]}
        cases["corrected_and_poor"]={"checks":checks,"stored":changed,"http":after}
        outside_only()
        no_change=physical(mid)
        assert collect(2,{plain_folder:[dict(poor,ht_home="1")]})=="ok"
        repeat=physical(mid)
        again=http(plain_folder,after["etag"])
        cases["only_outside_fields_and_one_ht_cell"]={"stable":no_change==repeat,"before":no_change,"after":repeat,"http":again}
        again_tag=again["etag"]
        assert collect(3,{plain_folder:[poor]})=="ok"
        cases["repeat_poor"]={"stable":physical(mid)==repeat,"http":http(plain_folder,again_tag)}
        assert collect(4,{plain_folder:[dict(poor,ht_home="0",ht_away="0")]})=="ok"
        changed_ht=physical(mid)
        assert [changed_ht["row"][k] for k in ("home_score_ht","away_score_ht")]==[0,0]
        assert changed_ht["stats"]==repeat["stats"] and changed_ht["row"]["revision"]==repeat["row"]["revision"]+1
        assert http(plain_folder,again_tag)["status"]==200
        status=old_scope()
        bindings=lambda: x("SELECT to_jsonb(i),xmin::text FROM core.provider_ids i WHERE provider='open_matchday' ORDER BY entity_type,provider_key").fetchall()
        known=bindings()
        assert collect(5,{plain_folder:[dict(poor,home="North Fields New")]})=="ok"
        assert collect(6,{plain_folder:[dict(poor,away="South Fields New")]})=="ok"
        codes=x("SELECT error_code FROM ops.parse_failures ORDER BY id").fetchall()
        assert codes[-2:]==[("SNAPSHOT_DROPS_RESULT",)]*2 and bindings()==known and physical(mid)==changed_ht
        cases["renames_refused"]={"errors":[r[0] for r in codes[-2:]],"sides":(home_id,away_id),"stable_bindings":True}
        history_folder=old_hashed[0].split(":",1)[0]
        old_read=http(history_folder)
        historic[history_folder][0].update(home_corners="4",ht_home="0",ht_away="1")
        assert collect(7,historic)=="ok"
        historic_read=http(history_folder,old_read["etag"])
        old_stat=physical(old_mid)["stats"][f"{old_home}/all"]["body"]
        assert old_scope()==control_scope==status and old_stat["corners"]==4 and historic_read["status"]==200
        cases["physically_restored_35"]={"match_ids_stable":35,"provider_keys_stable":35,"elo_sides_stable":70,
            "updated_stat":old_stat,"non_omd_values_preserved":(old_stat["xg"],old_stat["passes"],old_stat["blocked_shots"])==(1.5,300,4),
            "http_status":historic_read["status"]}
        results={"outside_fields":checks["outside_fields"],"outside_only_row":checks["outside_only_row"],
             "ht_db_and_http":checks["ht_db_and_http"],"sparse_noop":no_change==repeat and again["status"]==304,
             "restored_nonowned":cases["physically_restored_35"]["non_omd_values_preserved"]}
        def race(step, locker_sql, incoming):
            ready=Event()
            pid=[]
            def ordinary_writer():
                with psycopg.connect(dsn,autocommit=True) as worker:
                    pid.append(worker.info.backend_pid)
                    ready.set()
                    return collect(step,{plain_folder:[incoming]},worker)

            with psycopg.connect(dsn,autocommit=True) as other, ThreadPoolExecutor(max_workers=1) as thread:
                with other.transaction():
                    other.execute(locker_sql,(mid,home_id))
                    result=thread.submit(ordinary_writer)
                    assert ready.wait(3)
                    end=monotonic()+8
                    while monotonic()<end and not result.done():
                        if other.info.backend_pid in x("SELECT pg_blocking_pids(%s)",(pid[0],)).fetchone()[0]:
                            break
                        sleep(0.03)
                    else:
                        raise AssertionError("collector did not observe the independent writer's lock")
                state=result.result(timeout=20)
            return {"collector":state,"content":physical(mid)}

        update=race(8,"UPDATE core.team_match_stats SET xg=2.25 WHERE season_id=2026 AND match_id=%s AND team_id=%s AND period='all'",
                    dict(poor,home_corners="10"))
        results["concurrent_enrichment"]=(update["collector"]=="ok" and
          update["content"]["stats"][f"{home_id}/all"]["body"]["xg"]==2.25)
        insert=race(9,"INSERT INTO core.team_match_stats(season_id,match_id,team_id,period,xg,blocked_shots) VALUES (2026,%s,%s,'second_half',0.5,6)",
                    dict(poor,home_corners_2h="0"))
        new_stat=insert["content"]["stats"][f"{home_id}/second_half"]["body"]
        results["concurrent_insert"]=(insert["collector"]=="ok" and (new_stat["xg"],new_stat["blocked_shots"],new_stat["corners"])==(0.5,6,0))
        cases["concurrent_update"]=update
        cases["concurrent_insert"]=insert
        assert all(v != a.red for v in results.values()), results
        report["expected_results"]=results
        report["status"]="RED confirmed" if a.red else "passed"
    finally:
        server.terminate()
        server.wait(timeout=10)
        (q/f"{a.tag}.json").write_text(json.dumps(report,default=str,ensure_ascii=False,indent=2)+"\n")
print(json.dumps({"status":report["status"],"results":results}))
