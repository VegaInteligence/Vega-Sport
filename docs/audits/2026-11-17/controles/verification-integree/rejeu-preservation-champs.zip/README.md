# VI-27 · Conservation des données Open Matchday

Le rouge `599b80497ca7b49d65714f3d54e709c97c0cbe7f` et le vert `0580dfd4ba645461d6c372fbd7b1d73eaaa779a0` empruntent le writer Open Matchday et le lecteur HTTP réels sous PostgreSQL 18. Le rouge perd des données tierces et les deux buts d’une mi-temps encore valable. Le vert conserve ces champs, y compris quand une transaction concurrente vient de mettre à jour ou de créer la même clé de statistiques. Les 35 identités, leurs clés et les 70 côtés Elo de l’incident restent présents. Les attentes sont dans [EXPECTATIONS.md](EXPECTATIONS.md).

## Contrôle hors ligne

```sh
python3 -B verifier.py
```

Le contrôle compare empreintes et valeurs du rouge et du vert, avec les vrais états PostgreSQL et HTTP consignés. Les reçus livrés ont écarté la chaîne de connexion locale et remplacé les chemins des journaux par des libellés. Leurs empreintes d’origine figurent dans [provenance.json](provenance.json). Le contrôle hors ligne ne crée aucune base.

## Répétition PostgreSQL et HTTP

Exécuter sur un checkout propre au SHA vert, avec Python et `backend/requirements.txt`, Node et les dépendances verrouillées de `backend/api`. Préparer PostgreSQL 18 jetable sur la boucle locale. Le rôle local `postgres` doit pouvoir créer des bases. Le port de cette instance se fournit à la commande. La répétition conserve ses bases jetables et ses reçus.

```sh
python3 -B run_pg.py --worktree "$VEGA_CHECKOUT" \
  --identities "$ARCHIVE_35_MATCHS" --port 55439 --tag essai01
```

`ARCHIVE_35_MATCHS` désigne `35-matchs-identites-et-elo.zip`, SHA‑256 `db35bdf6cc5f7799cb679a8160c096a49c6bd8475130ad3895709c0fd06c0f6b`. Le lanceur extrait exactement deux membres, `rds/avant.zlib` et `rds/apres.zlib`, et vérifie les deux empreintes ci-dessous. La capsule fournit seulement la ligne de métadonnées d’actif référencée par un des parents. Elle ne dépend d’aucun autre dossier de l’audit, d’aucune image et d’aucun serveur distant.

| Membre | SHA‑256 | Rôle |
| --- | --- | --- |
| `rds/avant.zlib` | `ed7496ec232d3ef8c93b70439e3ccaa9ae56c0708c4c11cbedb4872012a1f74c` | Préimage 04 h 50, anciennes identités, parents et relations. |
| `rds/apres.zlib` | `e850dd9ebc33dfad5c71b93090fb2d4b3c9c4dfea73296e2278fa13f29f3d71d` | Le run Elo et les 70 côtés exacts, après l’incident. |

Le lanceur migre la copie, monte ses parents physiques et appelle le CLI de restauration de la branche. Le rejeu suivant passe par `sources.run_due` en `vega_collect`, puis `/api/cup-table` en `vega_read`. Les deux transactions concurrentes n’avancent qu’après observation du verrou dans `pg_blocking_pids`. Les résultats sont dans `run-essai01/restore.json`, `run-essai01/replay.log` et `essai01.json`.

Pour rejouer le rouge, utiliser le checkout propre du SHA initial, un suffixe inédit et `--mode red`. Le rouge de référence est inclus et vérifié hors ligne. Dans le relevé RDS en lecture seule, 417 paires HT étaient déjà renseignées et aucune des 834 lignes de statistiques ne portait de valeur hors des six colonnes Open Matchday. Les données tierces de ce rejeu servent de contrôles sur copie.
