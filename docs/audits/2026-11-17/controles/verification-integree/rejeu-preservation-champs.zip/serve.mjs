import {createServer} from "node:http";
import {resolve} from "node:path";
import {pathToFileURL} from "node:url";

const [tree, dsn] = process.argv.slice(2);
const url = new URL(dsn);
if (url.hostname !== "127.0.0.1" || !url.pathname.startsWith("/vega_v2_open_matchday_restore_")) {
  throw new Error("Use the dedicated restoration copy");
}
const {createReader} = await import(pathToFileURL(resolve(tree, "backend/api/src/db.mjs")));
const {createHandler} = await import(pathToFileURL(resolve(tree, "backend/api/src/handler.mjs")));
const reader = createReader(dsn, {role: "vega_read"});
const handler = createHandler({read: reader.read});
const server = createServer(async (req, res) => {
  const response = await handler(new Request("http://127.0.0.1" + req.url, {headers: req.headers}));
  res.writeHead(response.status, Object.fromEntries(response.headers));
  res.end(Buffer.from(await response.arrayBuffer()));
});
server.listen(0, "127.0.0.1", () => console.log(server.address().port));
process.on("SIGTERM", () => server.close(async () => { await reader.end(); process.exit(0); }));
