# VI-27 · Préserver les champs enrichis des résultats Open Matchday

Le témoin rouge est lancé sur `599b80497ca7b49d65714f3d54e709c97c0cbe7f`, exclusivement sur PostgreSQL 18 jetable. Les deux chemins passent par `vega.sources.run_due` et par le vrai lecteur HTTP sous `vega_read`. La copie de départ comporte les 35 anciennes clés physiques attestées et 70 Elo scellés. Les contrôles de champs complémentaires sont ajoutés sur copie et servent d'invariants.

| Cas | Attendu |
| --- | --- |
| Corners explicites à zéro, correction par côté et période | Les cellules explicites de la source changent sur la clé `season_id,match_id,team_id,period`. Les autres colonnes de la ligne et les autres lignes demeurent. |
| Ligne qui ne possède aucune des six colonnes OMD | La mise à jour d'un autre côté ou d'une autre période la conserve. Un fichier omettant toutes ses données ne déclenche aucune révision, réécriture et aucun nouvel ETag. Son `xmin`, celui du match et les versions publiques restent stables. |
| Export maigre | Si aucun ou un seul but de mi-temps est fourni, conserver ensemble les deux valeurs précédentes. Une paire complète, dont 0–0, reste une correction autorisée. |
| Changement réel et répétition | Pas de changement d'ID, de clé, de calendrier, de `first_finished_at` ou de score final ; une révision et un nouvel ETag pour une modification réelle. Un retour identique ne change ni les lignes ni l'ETag. |
| Alias non attesté de l'un des deux clubs | L'ancienne clé finie et les deux côtés sont préservés, avec refus observable. Ni nouveau club, ni nouvelle liaison, ni copie de match. |
| 35 restaurés | La rencontre 8049 accepte une statistique et l'HT attesté sans perdre ses champs tiers, en conservant les 35 anciens IDs, clés, positions et les 70 côtés Elo. Les autres rencontres et leurs horaires restent stables. |
| Concurrence | Un enrichissement tiers concurrent, réalisé avant que le writer accède à sa clé, rejoint les cellules OMD lorsque le verrou se libère. La mise à jour concurrente et la création concurrente de la même cellule ne perdent pas les champs tiers et ne font pas échouer la transaction OMD. |
