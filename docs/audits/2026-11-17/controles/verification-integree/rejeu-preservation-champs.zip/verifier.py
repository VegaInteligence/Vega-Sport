"""Check the sealed RED/GREEN observations. Standard library, no network or DB."""
from hashlib import sha256
import json
from pathlib import Path


ROOT=Path(__file__).resolve().parent
CASES={"outside_fields","outside_only_row","ht_db_and_http","sparse_noop","restored_nonowned",
       "concurrent_enrichment","concurrent_insert"}


def data(file):
    return json.loads((ROOT/file).read_bytes())


def digest(file):
    with (ROOT/file).open("rb") as handle:
        result=sha256()
        for block in iter(lambda: handle.read(65536),b""):
            result.update(block)
        return result.hexdigest()


def side_values(case, period, *fields):
    key=f"{case['row']['home_team_id']}/{period}"
    stat=case["stats"][key]["body"]
    return [stat[f] for f in fields]


def inspect(document, ok):
    assert "database" not in document
    assert set(document["expected_results"])==CASES
    assert all(v is ok for v in document["expected_results"].values())
    root=document["cases"]
    poor=root["corrected_and_poor"]
    match=poor["stored"]
    assert match["row"]["id"]==document["before"]["row"]["id"]
    assert match["row"]["revision"]==document["before"]["row"]["revision"]+1
    assert poor["http"]["status"]==200
    assert [match["row"][f] for f in ("home_score_ht","away_score_ht")]==([1,0] if ok else [None,None])
    assert side_values(match,"all","corners","xg","passes")==([0,1.25,455] if ok else [0,None,None])
    assert side_values(match,"first_half","corners","possession_pct")==([4,59.0] if ok else [4,None])
    unchanged=root["only_outside_fields_and_one_ht_cell"]
    assert unchanged["stable"] is ok and (unchanged["before"]==unchanged["after"]) is ok
    restored=root["physically_restored_35"]
    assert (restored["match_ids_stable"],restored["provider_keys_stable"],restored["elo_sides_stable"])==(35,35,70)
    assert restored["non_omd_values_preserved"] is ok and restored["http_status"]==200
    assert root["renames_refused"]["stable_bindings"] and root["renames_refused"]["errors"]==["SNAPSHOT_DROPS_RESULT"]*2
    updated=root["concurrent_update"]
    fixed=root["concurrent_insert"]
    assert updated["collector"]==fixed["collector"]=="ok"
    assert side_values(updated["content"],"all","corners","xg")==([10,2.25] if ok else [10,None])
    assert side_values(fixed["content"],"second_half","corners","xg","blocked_shots")==([0,0.5,6] if ok else [0,None,None])


def main():
    manifest=data("manifest.json")
    for file,reference in manifest.items():
        assert (ROOT/file).stat().st_size==reference["bytes"] and digest(file)==reference["sha256"], file
    baseline,current=data("receipts/red.json"),data("receipts/green.json")
    assert baseline["candidate"]=="599b80497ca7b49d65714f3d54e709c97c0cbe7f"
    assert current["candidate"]=="0580dfd4ba645461d6c372fbd7b1d73eaaa779a0"
    assert baseline["preimage_sha256"]==current["preimage_sha256"]=="ed7496ec232d3ef8c93b70439e3ccaa9ae56c0708c4c11cbedb4872012a1f74c"
    inspect(baseline,False)
    inspect(current,True)
    exposure=data("receipts/exposure.json")
    assert exposure["known_halftime"]==417 and exposure["stat_rows"]==834 and exposure["stats_with_other_fields"]==0
    assert "Ran 30 tests" in (ROOT/"receipts/source-suite.log").read_text()
    print(json.dumps({"status":"PASS","files_checked":len(manifest),"red_green_cases":len(CASES),
                      "concurrency_cases":2,"restored_ids":35,"elo_sides":70}))


if __name__=="__main__":
    main()
