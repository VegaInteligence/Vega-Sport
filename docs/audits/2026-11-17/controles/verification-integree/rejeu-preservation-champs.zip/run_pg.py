"""Prepare exact incident identities from two sealed captures and run the normal PG/HTTP witness."""
import argparse
from hashlib import sha256
import json
import os
from pathlib import Path
import re
import subprocess
import sys
from zipfile import ZipFile
import zlib

import psycopg
from psycopg import sql
from psycopg.types.json import Jsonb


ROOT = Path(__file__).resolve().parent
ARCHIVE = "db35bdf6cc5f7799cb679a8160c096a49c6bd8475130ad3895709c0fd06c0f6b"
INPUTS = {
    "rds/avant.zlib": "ed7496ec232d3ef8c93b70439e3ccaa9ae56c0708c4c11cbedb4872012a1f74c",
    "rds/apres.zlib": "e850dd9ebc33dfad5c71b93090fb2d4b3c9c4dfea73296e2278fa13f29f3d71d",
}
CANDIDATES = {
    "green": "0580dfd4ba645461d6c372fbd7b1d73eaaa779a0",
    "red": "599b80497ca7b49d65714f3d54e709c97c0cbe7f",
}


def rows(capture, key):
    return list(map(json.loads, capture["reads"][key]["rows_json"]))


def store(conn, table, records):
    if records:
        fields = sql.SQL(", ").join(sql.Identifier(r[0]) for r in conn.execute(
            """SELECT attname FROM pg_attribute WHERE attrelid=%s::regclass AND attnum>0
               AND NOT attisdropped AND attgenerated='' ORDER BY attnum""", (table,)))
        relation = sql.Identifier(*table.split("."))
        conn.execute(sql.SQL("INSERT INTO {t} ({c}) SELECT {c} FROM jsonb_populate_recordset(NULL::{t},%s)")
                     .format(t=relation,c=fields), (Jsonb(records),))


def prepare(conn, before, after):
    for source, fields in {
        "core.seasons": ("season_id",), "core.teams": ("home_team_id","away_team_id"),
        "core.venues": ("venue_id",), "core.referees": ("referee_id",),
        "core.competition_seasons": ("competition_season_id_season_id",),
        "core.rounds": ("round_id",),
    }.items():
        wanted = {r["id"]:r for field in fields for r in rows(before,"parent.matches_"+field+"_fkey")}
        if source=="core.teams":
            countries = sorted({r["country_code"] for r in wanted.values() if r["country_code"]})
            conn.execute("INSERT INTO core.countries(code) SELECT unnest(%s::text[]) ON CONFLICT DO NOTHING",(countries,))
            assets = json.loads((ROOT/"asset-parent.json").read_text())
            assert {r["crest_asset_id"] for r in wanted.values()}-{None} == {r[0] for r in assets["rows"]}
            for row in assets["rows"]:
                conn.execute("""INSERT INTO core.assets(id,kind,source_url,s3_key,sha256,content_type,width,height)
                                VALUES (%s,%s,%s,%s,decode(%s,'hex'),%s,%s,%s)""", row)
        if source=="core.competition_seasons":
            for edition in wanted.values():
                conn.execute("INSERT INTO core.competitions(id,name) VALUES(%s,%s) ON CONFLICT DO NOTHING",
                             (edition["competition_id"], edition["cup_name"]))
        store(conn,source,list(wanted.values()))
    store(conn,"agg.power_runs",rows(after,"elo_runs"))
    store(conn,"agg.team_elo",rows(after,"table.agg.team_elo"))
    conn.execute("SELECT core.ensure_season_partitions(2026)")
    conn.execute("SELECT setval(pg_get_serial_sequence('core.matches','id'),20000)")


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--worktree", required=True, type=Path)
    parser.add_argument("--identities", required=True, type=Path, help="35-matchs-identites-et-elo.zip")
    parser.add_argument("--port", required=True, type=int, help="disposable loopback PostgreSQL 18")
    parser.add_argument("--tag", required=True, help="new ASCII lowercase suffix")
    parser.add_argument("--mode", choices=CANDIDATES, default="green")
    args = parser.parse_args()
    tree=args.worktree.resolve()
    assert re.fullmatch(r"[a-z0-9]{2,11}",args.tag) and 1<=args.port<=65535
    assert subprocess.check_output(["git","-C",str(tree),"rev-parse","HEAD"],text=True).strip()==CANDIDATES[args.mode]
    assert not subprocess.check_output(["git","-C",str(tree),"status","--porcelain","--","backend"],text=True)
    with args.identities.open("rb") as file:
        digest=sha256()
        for block in iter(lambda: file.read(65536),b""):
            digest.update(block)
        assert digest.hexdigest()==ARCHIVE
    out=ROOT/("run-"+args.tag)
    out.mkdir()
    captures=[]
    with ZipFile(args.identities) as pool:
        for member,digest in INPUTS.items():
            body=pool.read(member)
            assert sha256(body).hexdigest()==digest
            path=out/Path(member).name
            path.write_bytes(body)
            captures.append(path)
    before,after=[json.loads(zlib.decompress(p.read_bytes())) for p in captures]
    sys.path.insert(0,str(tree/"backend"))
    from vega.store import migrate

    db_base=f"postgresql://postgres@127.0.0.1:{args.port}/"
    template="vega_v2_open_matchday_restore_base"+args.tag
    with psycopg.connect(db_base+"postgres",autocommit=True) as admin:
        assert admin.info.server_version//10000==18
        admin.execute(sql.SQL("CREATE DATABASE {}").format(sql.Identifier(template)))
    with psycopg.connect(db_base+template,autocommit=True) as db:
        migrate(db)
        with db.transaction():
            prepare(db,before,after)
    env={**os.environ,"PYTHONPATH":str(tree/"backend"),"PYTHONDONTWRITEBYTECODE":"1"}
    argv=[sys.executable,"-B","-m","vega.open_matchday_restore","--dsn",db_base+template,
          "--preimage",str(captures[0]),"--preimage-sha256",INPUTS["rds/avant.zlib"],
          "--postimage",str(captures[1]),"--postimage-sha256",INPUTS["rds/apres.zlib"],"--apply"]
    restored=subprocess.run(argv,cwd=tree/"backend",env=env,text=True,capture_output=True,check=True)
    certificate=json.loads(restored.stdout)
    assert certificate["restored"]==35 and certificate["preserved_elo"]==70
    (out/"restore.json").write_text(restored.stdout)
    command=[sys.executable,"-B",str(ROOT/"replay.py"),str(tree),args.tag,
             "--preimage",str(captures[0]),"--template",template,"--port",str(args.port)]
    if args.mode=="red":
        command.append("--red")
    with (out/"replay.log").open("w") as stream:
        subprocess.run(command,env=env,cwd=ROOT,stderr=subprocess.STDOUT,stdout=stream,check=True)
    print(json.dumps({"mode":args.mode,"candidate":CANDIDATES[args.mode],"evidence":args.tag+".json",
                      "restoration":certificate}))


if __name__=="__main__":
    main()
