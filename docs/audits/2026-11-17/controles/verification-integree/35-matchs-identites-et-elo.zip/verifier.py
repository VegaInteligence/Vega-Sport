"""Independently reproduce the physical restoration evidence and the two conditional Elo scenarios."""
from datetime import datetime
import hashlib
import importlib.util
import json
from pathlib import Path
import struct
import zlib

p=Path(__file__).resolve().parent
def j(name):return json.loads((p/name).read_bytes())
def z(name):return json.loads(zlib.decompress((p/name).read_bytes()))
def h(raw):return hashlib.sha256(raw).hexdigest()
for file,digest in j('empreintes.json').items():
    assert h((p/file).read_bytes())==digest,file
pre=z('rds/avant.zlib')
post=z('rds/apres.zlib')
cur=z('elo/capture-globale.zlib')
ref=j('elo/mesures.json')
pars=j('elo/parametres.json')
phys=j('elo/35-matchs.json')
audit=j('rds/comparaison.json')
for dataset in (pre,post):
    assert dataset['read_only']=='on' and len(dataset['reads'])==59
    assert all(t.get('ok') and t.get('complete',True) for t in dataset['reads'].values())
    assert all(x['reason']=='columns_intentionally_omitted' and dataset['reads']['table.'+x['table']]['count']==0 for x in dataset['not_verified'])
    for rowset in dataset['reads'].values():
        if 'rows_json' in rowset:
            assert rowset['row_sha256']==[h(v.encode()) for v in rowset['rows_json']]
for name,counts in audit['results'].items():
    for ls,dataset in [('avant',pre),('apres',post)]:
        assert (dataset['reads'][name]['count'],dataset['reads'][name]['sha256'])==(counts[ls],counts['empreinte_'+ls])
assert pre['reads']['elo_float_bits']['sha256']==post['reads']['elo_float_bits']['sha256']
assert len(phys['restored_rows'])==35
def bits(value):return struct.unpack('>I',struct.pack('>f',value))[0]
def clock(m):
    return (m[2] is None,datetime.fromisoformat(m[2]) if m[2] else datetime.max,m[8] is None,m[8] or '',m[0])
def rows(table):return [json.loads(r) for r in pre['reads'][table]['rows_json']]
parents={r['id']:r for r in rows('table.core.matches')}
keys={r['entity_id'] for r in rows('table.core.provider_ids')}
assert len(keys)==len(parents)==35
for m in phys['restored_rows']:
    r=parents[m[0]]
    assert m[0] in keys and m[1]==r['season_id'] and m[3:7]==[r['home_team_id'],r['away_team_id'],r['home_score'],r['away_score']] and m[8]==r['match_date'] and m[10]==r['competition_season_id']
spec=importlib.util.spec_from_file_location('vega_power',p/'elo/power.py')
power=importlib.util.module_from_spec(spec);spec.loader.exec_module(power)
assert h((p/'elo/power.py').read_bytes())==cur['module_hashes']['vega.power']
seeds={int(k):v for k,v in pars['seeds'].items()}
weights={int(k):v for k,v in pars['weights'].items()}
run=cur['elo_run']
def replay(matches):
    return {(r[0],r[1]):r for r in power.elo_updates(matches,initial=run[5],k=run[6],home=run[7],seeds=seeds,leagues={team:team for team in seeds},weights=weights)}
current=cur['matches']
with35=sorted([*current,*phys['restored_rows']],key=clock)
incoming=set(ref['population']['new'])
historic=replay([m for m in with35 if m[0] not in incoming])
published={(r[0],r[1]):r for r in cur['stored']}
assert historic.keys()==published.keys()
ulp=max(abs(bits(a)-bits(b)) for key,r in historic.items() for a,b in zip(r[4:8],published[key][3:7]))
assert ulp==ref['historical_control']['maximum_ulp_vs_stored']
without=replay(current);with_rows=replay(with35)
affected={k for k,r in without.items() if abs(with_rows[k][5]-r[5])>0.01}
latest={}
for m in sorted(current,key=clock):
    for team in m[3:5]:latest[team]=(m[0],team)
last_clubs=[team for team,key in latest.items() if team not in cur['national_ids'] and key in affected]
assert len(affected)==871 and len({k[0] for k in affected})==450 and len(last_clubs)==115
assert len([k for k in affected if k[0] in incoming])==20
actual={'tables_relationnelles':len(audit['results']),'matchs_physiques':len(parents),'cles_fournisseur':len(keys),'elo_anciens_intacts':len(pre['reads']['elo_float_bits']['rows']),'cotes_controle_historique':len(historic),'maximum_ulp':ulp,'cotes_avec_ecart_sup_0_01':len(affected),'matchs_avec_ecart_sup_0_01':len({k[0] for k in affected}),'clubs_avec_dernier_elo_modifie':len(last_clubs),'nouveaux_cotes_affectes':20}
print(json.dumps(actual,ensure_ascii=False))
