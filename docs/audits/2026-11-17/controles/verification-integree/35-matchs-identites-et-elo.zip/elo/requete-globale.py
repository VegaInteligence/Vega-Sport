"""All RDS reads for a reproducible numerical replay, in the unmodified worker image."""
from hashlib import sha256
from inspect import getsource


def collect(conn):
    from vega import power
    from vega.sources import identity

    with conn.transaction():
        conn.execute("SET TRANSACTION ISOLATION LEVEL REPEATABLE READ READ ONLY")
        assert conn.execute("SHOW transaction_read_only").fetchone()[0] == "on"
        stamp, snap, dbname = conn.execute(
            "SELECT transaction_timestamp(), pg_current_snapshot()::text, current_database()"
        ).fetchone()
        ids, examined = identity.pairs(conn)
        aliases = {src: dst for src, dst, *_ in ids}
        # Append metadata on the right: the deployed selection, ownership and sorting stay identical.
        needle = "cs.cup_key\nFROM core.matches m"
        assert power.ELO_MATCHES.count(needle) == 1
        query = power.ELO_MATCHES.replace(needle, "cs.cup_key,m.competition_season_id\nFROM core.matches m")
        raw = conn.execute(query + " LIMIT 250001").fetchall()
        assert len(raw) <= 250000
        merged = power.merged_rows(raw, aliases)
        matches = power.elo_matches(merged)
        leagues, tiers, countries, women = power.elo_groups(conn, matches)
        weights = power.match_stakes(conn)
        nations = {team for team, in conn.execute("SELECT id FROM core.teams WHERE is_national IS TRUE")}
        levels = conn.execute("SELECT competition_id,entry_level::float8,run_id FROM agg.league_levels ORDER BY competition_id").fetchall()
        primary_run = conn.execute("""SELECT id, method_version,started_at,finished_at,matches,elo_initial,elo_k,elo_home_advantage,
                                          seed_rounds, level_exchange,tier_gap,tier_gap_sd,top_sd,pair_sd,dispersion
                                     FROM agg.power_runs WHERE kind='elo' AND status='published'""").fetchall()
        assert len(primary_run) == 1
        mover_sets = conn.execute("SELECT id,source_run,variance,stayers,moves,persistence FROM agg.league_move_sets ORDER BY id").fetchall()
        movers = conn.execute("SELECT set_id,competition_a,competition_b,movers,mean_change::float8 FROM agg.league_moves ORDER BY set_id,competition_a,competition_b").fetchall()
        player_runs = conn.execute("SELECT id,season_id,finished_at FROM agg.power_runs WHERE kind='players' AND status='published' ORDER BY season_id").fetchall()
        stored = conn.execute("""SELECT match_id, team_id, season_id, elo_before::float8, elo_after::float8,
                                     expected::float8, result::float8, stakes::float8, run_id, kickoff_at
                                   FROM agg.team_elo ORDER BY match_id,team_id LIMIT 500001""").fetchall()
        assert len(stored) <= 500000
    print("CHECKPOINT closed read-only snapshot", str(stamp), len(matches),len(stored),flush=True)
    return {
        "at": str(stamp), "snapshot":snap,"database":dbname,
        "module_hashes":{m.__name__:sha256(getsource(m).encode()).hexdigest() for m in (power,identity)},
        "method":power.METHOD_VERSION,
        "raw_count":len(raw), "merged_count":len(merged),
        "alias_pairs":sorted(aliases.items()),"identity_examined":examined,
        "matches":[(m[0],m[1],m[2],m[3],m[4],m[5],m[6],m[7],m[8],m[9],m[13],weights.get(m[0],1.0)) for m in matches],
        "leagues":list(leagues.items()),"tiers":list(tiers.items()),"countries":list(countries.items()),"women":list(women),
        "national_ids":sorted(nations), "levels":levels, "elo_run":primary_run[0], "mover_sets":mover_sets,"movers":movers,"player_runs":player_runs,
        "stored":stored,
    }
