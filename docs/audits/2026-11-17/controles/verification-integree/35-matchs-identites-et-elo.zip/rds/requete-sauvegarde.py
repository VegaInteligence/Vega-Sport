"""Read-only preimage capture. collect(db) receives an existing psycopg3 connection.
No cloud/connection/product import, writer, scheduler or sequence mutation.
"""
import hashlib,json,re
from psycopg import sql
WITNESSES = [[8049, 2552, 2558, '2026-08-31', 0, 1, 332], [8050, 2566, 2546, '2026-08-31', 2, 1, 332], [8051, 2607, 5548, '2026-08-31', 0, 1, 332], [8052, 2557, 2559, '2026-08-31', 2, 2, 332], [8053, 2580, 2590, '2026-08-31', 2, 1, 332], [8054, 3386, 2589, '2026-08-31', 3, 1, 332], [8055, 2588, 3387, '2026-08-31', 3, 0, 332], [8056, 3388, 2593, '2026-08-31', 0, 1, 332], [8057, 2567, 2565, '2026-08-31', 1, 1, 332], [8058, 3389, 3390, '2026-08-31', 0, 1, 332], [8059, 2606, 3391, '2026-08-31', 1, 1, 332], [8060, 2551, 2596, '2026-08-31', 0, 1, 332], [8290, 3392, 2532, '2026-09-05', 4, 1, 333], [8291, 3393, 2535, '2026-09-05', 3, 3, 333], [8292, 2560, 2602, '2026-09-05', 1, 1, 333], [8293, 2579, 3394, '2026-09-05', 0, 3, 333], [8294, 2537, 2613, '2026-09-05', 0, 4, 333], [8295, 2550, 2539, '2026-09-05', 1, 1, 333], [8296, 2599, 2533, '2026-09-05', 1, 1, 333], [8297, 2543, 2548, '2026-09-05', 1, 0, 333], [8298, 3395, 2527, '2026-09-05', 1, 2, 333], [8299, 2614, 3396, '2026-09-05', 3, 2, 333], [8300, 2545, 2570, '2026-09-05', 3, 1, 333], [8301, 3397, 2573, '2026-09-05', 0, 2, 333], [8534, 3411, 3412, '2026-08-31', 2, 0, 334], [8535, 3408, 2576, '2026-08-31', 0, 4, 334], [8536, 2620, 3400, '2026-08-31', 3, 4, 334], [8537, 2541, 3413, '2026-08-31', 0, 3, 334], [8538, 3403, 2562, '2026-08-31', 2, 1, 334], [8539, 3404, 3405, '2026-08-31', 0, 2, 334], [8540, 3414, 3409, '2026-08-31', 0, 3, 334], [8541, 3401, 3407, '2026-08-31', 0, 2, 334], [8542, 3399, 3402, '2026-08-31', 3, 1, 334], [8543, 3406, 3398, '2026-08-31', 1, 4, 334], [8544, 3410, 2591, '2026-09-01', 1, 2, 334]]
PROVIDER_KEYS = ['ENG_6_national-league-north:2026/2027:2026-08-31|AFC Telford|Bedford', 'ENG_6_national-league-north:2026/2027:2026-08-31|Buxton|Merthyr Town', 'ENG_6_national-league-north:2026/2027:2026-08-31|Chester|Morecambe', 'ENG_6_national-league-north:2026/2027:2026-08-31|Chorley|Brackley Town', 'ENG_6_national-league-north:2026/2027:2026-08-31|Harborough|Marine', 'ENG_6_national-league-north:2026/2027:2026-08-31|King’s Lynn|Scarborough', 'ENG_6_national-league-north:2026/2027:2026-08-31|Macclesfield|Hebburn Town', 'ENG_6_national-league-north:2026/2027:2026-08-31|Radcliffe|Darlington', 'ENG_6_national-league-north:2026/2027:2026-08-31|South Shields|Spalding United', 'ENG_6_national-league-north:2026/2027:2026-08-31|Southport|Hereford', 'ENG_6_national-league-north:2026/2027:2026-08-31|Spennymoor|Hednesford', 'ENG_6_national-league-north:2026/2027:2026-08-31|Worksop|Oxford City', 'ENG_6_national-league-south:2026/2027:2026-09-05|AFC Totton|Hampton & Richmond', 'ENG_6_national-league-south:2026/2027:2026-09-05|Billericay|Dorking', 'ENG_6_national-league-south:2026/2027:2026-09-05|Chelmsford|Salisbury', 'ENG_6_national-league-south:2026/2027:2026-09-05|Dover|Maidenhead', 'ENG_6_national-league-south:2026/2027:2026-09-05|Farnborough|Tonbridge', 'ENG_6_national-league-south:2026/2027:2026-09-05|Hemel Hempstead|Farnham', 'ENG_6_national-league-south:2026/2027:2026-09-05|Horsham FC|Dag & Red', 'ENG_6_national-league-south:2026/2027:2026-09-05|Maidstone|Weston-super-Mare', 'ENG_6_national-league-south:2026/2027:2026-09-05|Slough|Braintree', 'ENG_6_national-league-south:2026/2027:2026-09-05|Torquay|Folkestone', 'ENG_6_national-league-south:2026/2027:2026-09-05|Truro|Chesham', 'ENG_6_national-league-south:2026/2027:2026-09-05|Walton & Hersham|Ebbsfleet', 'ENG_7_northern-premier-league:2026/2027:2026-08-31|Curzon Ashton|Ashton Utd', 'ENG_7_northern-premier-league:2026/2027:2026-08-31|Emley|Guiseley', 'ENG_7_northern-premier-league:2026/2027:2026-08-31|FC United|Avro', 'ENG_7_northern-premier-league:2026/2027:2026-08-31|Gainsborough|Cleethorpes', 'ENG_7_northern-premier-league:2026/2027:2026-08-31|Hyde|Bury', 'ENG_7_northern-premier-league:2026/2027:2026-08-31|Ilkeston|Quorn', 'ENG_7_northern-premier-league:2026/2027:2026-08-31|Lancaster|Workington', 'ENG_7_northern-premier-league:2026/2027:2026-08-31|Stockton|Redcar Athletic', 'ENG_7_northern-premier-league:2026/2027:2026-08-31|Warrington Rylands|Bamber Bridge', 'ENG_7_northern-premier-league:2026/2027:2026-08-31|Whitby|Alfreton', 'ENG_7_northern-premier-league:2026/2027:2026-09-01|Leek|Warrington']
MAX_ROWS = 10000
STATEMENT_TIMEOUT_MS = 110000
CORE = set('matches provider_ids entity_names editorial_lists seasons competition_seasons competitions teams rounds referees venues archive_match_attestations match_coverage lineups lineup_players match_events shots match_momentum match_h2h match_h2h_meetings player_match_stats player_match_half_stats team_match_stats team_match_advanced player_match_advanced pass_network_teams pass_network_nodes pass_network_edges team_heatmaps player_heatmaps player_physical_match match_odds'.split())
AGG = set('team_elo power_runs league_round_matches match_forecasts match_lineup_forecasts match_zeros player_list_editions player_match_grades player_power_matches round_teams shot_xg'.split())
OPS = set('match_watch data_warnings family_state fetch_jobs fetch_log parse_failures provider_link_conflicts provider_links reference_state resource_versions archive_removals live_discrepancies schema_migrations'.split())
OPS_COLUMNS = set('id match_id entity_type entity_id resource_kind resource_id family provider provider_key source scope status state kind source_key target_key existing_id incoming_id winner_id loser_id is_current first_seen_at last_seen_at last_success_at last_attempt_at checked_at updated_at detected_at at fetched_at target_date competition_season_id season_id error_code last_error_code http_status last_http attempts priority lane run_after next_check_at checks fingerprint version applied_at checksum revision queued_at canonical_key former_key former_id recorded_at retired_at reason_code'.split())
SPORT_COLUMNS = {'body_part','response_sha256'}
OPS_COLUMNS.update('global_key lease_until job_id duration_ms parser_version response_sha256 rows_written is_empty field live_value final_value last_status kickoff_at created_at reason noted_at rule evidence linked_at quarantined_at quarantine_reason next_due facts_revision published_at archive_key plan_sha256 removed_at'.split())
PRIVATE_COLUMN = re.compile(r'(^|_)(email|phone|password|secret|token|session|cookie|authorization|address|account|billing|payment|payload|request|response|raw|body|message|detail)(_|$)')

def collect(db):
    ids=[int(w[0]) for w in WITNESSES]
    assert len(ids)==len(set(ids))==35
    out={'probe_version':'preimage-v3-private-restore','witnesses':WITNESSES,'provider_keys':PROVIDER_KEYS,'limits':{'max_rows_per_read':MAX_ROWS,'statement_timeout_ms':STATEMENT_TIMEOUT_MS,'unknown_tables':'inventory only','ops':'sports/control columns only'},'reads':{},'not_verified':[],'inventory':{}}
    digest=lambda s:hashlib.sha256(s.encode()).hexdigest()
    with db.transaction():
        db.execute('SET TRANSACTION ISOLATION LEVEL REPEATABLE READ READ ONLY')
        db.execute(f"SET LOCAL statement_timeout = '{STATEMENT_TIMEOUT_MS}ms'")
        db.execute("SET LOCAL lock_timeout = '2000ms'")
        at,snap,ro,user,database,version=db.execute("SELECT transaction_timestamp(),pg_current_snapshot()::text,current_setting('transaction_read_only'),current_user,current_database(),version()").fetchone()
        assert ro=='on'
        out.update(at=str(at),snapshot=snap,read_only=ro,role=user,database=database,server_version=version)
        def query(label,q,args=(),raw=False):
            text=q.as_string(db) if isinstance(q,sql.Composable) else q
            item={'sql':text,'params':args,'ok':False};out['reads'][label]=item
            try:
                with db.transaction():
                    cur=db.execute(q,args or None);rows=cur.fetchall();columns=[c.name for c in cur.description]
                item.update(ok=True,columns=columns)
                if raw:
                    texts=sorted(r[0] for r in rows);truncated=len(texts)>MAX_ROWS;texts=texts[:MAX_ROWS]
                    item.update(rows_json=texts,row_sha256=[digest(s) for s in texts],sha256=digest('\n'.join(texts)),count=len(texts),complete=not truncated)
                    if truncated:out['not_verified'].append({'read':label,'reason':'row_limit','limit':MAX_ROWS})
                else:item.update(rows=rows,count=len(rows),sha256=digest(json.dumps(rows,default=str,ensure_ascii=False,separators=(',',':'))))
                return rows
            except Exception as e:
                item.update(error_type=type(e).__name__,sqlstate=getattr(e,'sqlstate',None),error=str(getattr(getattr(e,'diag',None),'message_primary',None) or type(e).__name__)[:240])
                out['not_verified'].append({'read':label,'reason':'query_failed','sqlstate':item['sqlstate']});return None
        cat=query('catalog_columns',"""SELECT c.oid::bigint,n.nspname,c.relname,c.relkind::text,c.relrowsecurity,c.relforcerowsecurity,
          has_table_privilege(c.oid,'SELECT'),has_any_column_privilege(c.oid,'SELECT'),row_security_active(c.oid),
          a.attname,t.typname,format_type(a.atttypid,a.atttypmod),a.attnum,a.attidentity::text,a.attgenerated::text
          FROM pg_class c JOIN pg_namespace n ON n.oid=c.relnamespace JOIN pg_attribute a ON a.attrelid=c.oid
          JOIN pg_type t ON t.oid=a.atttypid WHERE n.nspname IN ('core','agg','ops')
          AND c.relkind IN ('r','p') AND NOT c.relispartition AND a.attnum>0 AND NOT a.attisdropped
          ORDER BY n.nspname,c.relname,a.attnum""")
        if cat is None:out['complete']=False;return out
        tables={}
        for oid,ns,name,kind,rls,force,sel,anysel,active,col,typ,fmt,num,ident,gen in cat:
            t=tables.setdefault((ns,name),{'oid':oid,'schema':ns,'name':name,'kind':kind,'rls':rls,'rls_active':active,'select':sel,'any_column_select':anysel,'columns':{}})
            t['columns'][col]={'type':typ,'format':fmt,'position':num,'identity':ident,'generated':gen}
        fks=query('catalog_fks',"""SELECT x.oid::bigint,n.nspname,c.relname,pn.nspname,p.relname,x.conname,
          ARRAY(SELECT a.attname FROM unnest(x.conkey) WITH ORDINALITY k(attnum,ord) JOIN pg_attribute a ON a.attrelid=x.conrelid AND a.attnum=k.attnum ORDER BY k.ord),
          ARRAY(SELECT a.attname FROM unnest(x.confkey) WITH ORDINALITY k(attnum,ord) JOIN pg_attribute a ON a.attrelid=x.confrelid AND a.attnum=k.attnum ORDER BY k.ord),pg_get_constraintdef(x.oid)
          FROM pg_constraint x JOIN pg_class c ON c.oid=x.conrelid JOIN pg_namespace n ON n.oid=c.relnamespace
          JOIN pg_class p ON p.oid=x.confrelid JOIN pg_namespace pn ON pn.oid=p.relnamespace
          WHERE x.contype='f' AND n.nspname IN ('core','agg','ops') AND NOT c.relispartition ORDER BY 2,3,6""") or []
        paths={('core','matches'):[]};todo=[('core','matches')];fk_paths=[]
        while todo:
            parent=todo.pop(0)
            for f in fks:
                child=(f[1],f[2]);ref=(f[3],f[4])
                if ref!=parent:continue
                fk_paths.append({'child':'.'.join(child),'parent':'.'.join(ref),'name':f[5],'columns':f[6],'referenced_columns':f[7],'definition':f[8]})
                if child not in paths:paths[child]=[f]+paths[parent];todo.append(child)
        out['inventory']['fk_descendants']=fk_paths
        predicates={}
        def add(table,pred,args,reason):
            e=predicates.setdefault(table,{'predicates':[],'args':[],'reasons':[]});e['predicates'].append(pred);e['args'].extend(args);e['reasons'].append(reason)
        for table,t in tables.items():
            cols=t['columns']
            for name,meta in cols.items():
                if name in ('match_id','match_key') or name.endswith('_match_id') or (table==('core','archive_match_attestations') and name=='former_id'):
                    if meta['type'] in ('int2','int4','int8'):add(table,sql.SQL('t.{} = ANY(%s::bigint[])').format(sql.Identifier(name)),[ids],'numeric '+name)
                    else:out['not_verified'].append({'table':'.'.join(table),'column':name,'reason':'non_numeric_match_reference','type':meta['type']})
            for idcol,typecol,label in [('entity_id','entity_type','entity match'),('resource_id','resource_kind','resource match')]:
                if idcol in cols and typecol in cols:
                    if cols[idcol]['type'] in ('int2','int4','int8'):add(table,sql.SQL("t.{} = ANY(%s::bigint[]) AND t.{}::text = 'match'").format(sql.Identifier(idcol),sql.Identifier(typecol)),[ids],label)
                    else:out['not_verified'].append({'table':'.'.join(table),'reason':'non_numeric_polymorphic','column':idcol})
        if ('core','matches') in tables:add(('core','matches'),sql.SQL('t.id = ANY(%s::bigint[])'),[ids],'target IDs')
        if ('core','provider_ids') in tables:add(('core','provider_ids'),sql.SQL("t.entity_type::text='match' AND t.provider::text='open_matchday' AND t.provider_key=ANY(%s::text[])"),[PROVIDER_KEYS],'provider key collision')
        if ('ops','archive_removals') in tables:add(('ops','archive_removals'),sql.SQL("t.id = ANY(%s::bigint[]) AND t.kind='match'"),[ids],'archive tombstone match')
        for table,path in paths.items():
            if not path:continue
            pred=sql.SQL('{}.id = ANY(%s::bigint[])').format(sql.Identifier('p'+str(len(path))))
            for depth in range(len(path)-1,-1,-1):
                f=path[depth];ca='t' if depth==0 else 'p'+str(depth);pa='p'+str(depth+1)
                joins=sql.SQL(' AND ').join(sql.SQL('{}.{} = {}.{}').format(sql.Identifier(ca),sql.Identifier(a),sql.Identifier(pa),sql.Identifier(b)) for a,b in zip(f[6],f[7]))
                pred=sql.SQL('EXISTS (SELECT 1 FROM {}.{} {} WHERE ({}) AND ({}))').format(sql.Identifier(f[3]),sql.Identifier(f[4]),sql.Identifier(pa),joins,pred)
            # On a restored database all 35 physical parent rows exist. For a
            # validated match FK, the descendant test is implied by match_id in
            # the 35 IDs. Prune old partitions by the original parents' seasons.
            # MATCH SIMPLE also permits null components: retain those candidates.
            if len(path)==1 and path[0][3:5]==('core','matches') and path[0][6] in (['match_id'],['match_id','season_id']) and path[0][7] in (['id'],['id','season_id']) and predicates.get(table,{}).get('reasons')==['numeric match_id']:
                fk=path[0]
                valid=db.execute('SELECT convalidated AND conenforced FROM pg_constraint WHERE oid=%s',(fk[0],)).fetchone()
                if valid==(True,):
                    parents=db.execute('SELECT id,season_id FROM core.matches WHERE id=ANY(%s) ORDER BY id',(ids,)).fetchall()
                    assert len(parents)==len(set(ids))==35 and {r[0] for r in parents}==set(ids)
                    if len(fk[6])==2:
                        predicates[table]['predicates']=[sql.SQL('t.match_id = ANY(%s::int[]) AND (t.season_id = ANY(%s::smallint[]) OR t.season_id IS NULL)')]
                        predicates[table]['args']=[ids,sorted({r[1] for r in parents})]
                    predicates[table]['reasons'].append('validated FK, existing parents, null component included')
                    continue
            add(table,pred,[ids],'FK descendant')
        def read_table(table,entry,label=None):
            t=tables[table];ns,name=table;allcols=t['columns'];label=label or 'table.'+ns+'.'+name
            permitted=(ns=='core' and name in CORE) or (ns=='agg' and name in AGG) or (ns=='ops' and name in OPS)
            if not permitted:out['not_verified'].append({'table':'.'.join(table),'reason':'unreviewed_table_inventory_only'});return
            cols=[c for c in allcols if (c in SPORT_COLUMNS or not PRIVATE_COLUMN.search(c)) and (ns!='ops' or c in OPS_COLUMNS)];omitted=[c for c in allcols if c not in cols]
            if not cols:out['not_verified'].append({'table':'.'.join(table),'reason':'no_allowlisted_columns'});return
            cond=sql.SQL(' OR ').join(sql.SQL('({})').format(p) for p in entry['predicates'])
            q=sql.SQL('SELECT row_to_json(preimage_row.*)::text AS row_json FROM (SELECT {} FROM {}.{} t WHERE {} LIMIT {}) preimage_row').format(sql.SQL(',').join(sql.SQL('t.{}').format(sql.Identifier(c)) for c in cols),sql.Identifier(ns),sql.Identifier(name),cond,sql.Literal(MAX_ROWS+1))
            query(label,q,entry['args'],raw=True);out['reads'][label].update(reasons=entry['reasons'],omitted_columns=omitted,all_physical_columns=not omitted,rls_active=t['rls_active'])
            if omitted:out['not_verified'].append({'table':ns+'.'+name,'reason':'columns_intentionally_omitted','columns':omitted})
            if t['rls_active']:out['not_verified'].append({'table':ns+'.'+name,'reason':'row_level_security_active'})
        out['inventory']['candidate_tables']=[{**tables[t],'reasons':e['reasons']} for t,e in sorted(predicates.items())]
        for table,entry in sorted(predicates.items()):read_table(table,entry)
        if ('agg','team_elo') in tables:
            pairs=[]
            for c,m in tables[('agg','team_elo')]['columns'].items():
                if m['type'] in ('float4','float8'):pairs.extend([sql.Literal(c),sql.SQL("encode({}(t.{}),'hex')").format(sql.Identifier(m['type']+'send'),sql.Identifier(c))])
            q=sql.SQL('SELECT t.match_id,t.team_id,jsonb_build_object({}) AS float_bits FROM agg.team_elo t WHERE t.match_id=ANY(%s::bigint[]) ORDER BY t.match_id,t.team_id').format(sql.SQL(',').join(pairs));query('elo_float_bits',q,(ids,))
        values=sql.SQL(',').join(sql.SQL('(%s::bigint,%s::bigint,%s::bigint,%s::date,%s::int,%s::int,%s::bigint)') for _ in WITNESSES)
        q=sql.SQL('''WITH w(old_id,home,away,day,hs,aws,edition) AS (VALUES {})
          SELECT w.old_id,row_to_json(m)::text AS current_row,(m.id=w.old_id) AS same_physical_id,
            (m.match_date=w.day AND m.home_team_id=w.home AND m.away_team_id=w.away AND m.home_score=w.hs AND m.away_score=w.aws AND m.competition_season_id=w.edition) AS exact_expected_fact
          FROM w JOIN core.matches m ON m.id=w.old_id OR
            (((m.home_team_id=w.home AND m.away_team_id=w.away) OR (m.home_team_id=w.away AND m.away_team_id=w.home)) AND m.match_date BETWEEN w.day-31 AND w.day+31)
          ORDER BY w.old_id,m.id LIMIT {}''').format(values,sql.Literal(MAX_ROWS+1))
        collision=query('id_and_pair_candidates',q,[v for row in WITNESSES for v in row])
        if collision is not None and len(collision)>MAX_ROWS:out['not_verified'].append({'read':'id_and_pair_candidates','reason':'row_limit'})
        for f in fks:
            if (f[1],f[2])!=('core','matches') or (f[3],f[4]) not in tables:continue
            joins=sql.SQL(' AND ').join(sql.SQL('m.{}=t.{}').format(sql.Identifier(a),sql.Identifier(b)) for a,b in zip(f[6],f[7]))
            pred=sql.SQL('EXISTS(SELECT 1 FROM core.matches m WHERE m.id=ANY(%s::bigint[]) AND {})').format(joins)
            read_table((f[3],f[4]),{'predicates':[pred],'args':[ids],'reasons':['referenced parent '+f[5]]},'parent.'+f[5])
        if ('ops','schema_migrations') in tables:query('migrations',"SELECT version,encode(checksum,'hex'),applied_at FROM ops.schema_migrations ORDER BY version")
        if ('agg','power_runs') in tables:query('elo_runs','SELECT row_to_json(r)::text FROM agg.power_runs r WHERE r.id IN (SELECT DISTINCT run_id FROM agg.team_elo WHERE match_id=ANY(%s::bigint[])) ORDER BY id',(ids,),raw=True)
        query('match_identity',"SELECT pg_get_serial_sequence('core.matches','id') AS sequence_name")
        out['summary']={k:{c:v for c,v in r.items() if c in ('ok','count','complete','all_physical_columns','omitted_columns','rls_active','sha256','sqlstate')} for k,r in out['reads'].items() if k.startswith(('table.','parent.','elo_'))}
        out['complete']=not out['not_verified']
        out['limitation']='No reported gap within this explicit scope is not proof about PITR availability, event membership, hidden JSON references or tables outside core/agg/ops. No restoration performed.'
    return out
