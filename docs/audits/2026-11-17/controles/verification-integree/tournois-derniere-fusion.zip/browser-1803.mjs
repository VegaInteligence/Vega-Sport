import { createRequire } from "node:module";
import fs from "node:fs/promises";
import path from "node:path";

const [, , pw, binary, origin, out, device, offsetReceipt] = process.argv;
const {chromium} = createRequire(import.meta.url)(pw);
const phone = device === "iphone";
const target = JSON.parse(await fs.readFile(offsetReceipt, "utf8"));
const browser = await chromium.launch({ executablePath: binary });
const page = await browser.newPage({ viewport: phone ? {width:393,height:852} : {width:1440,height:900}, locale:"fr-FR", isMobile:phone, hasTouch:phone });
const result = { device, origin, fixture:target, checks:[], pageErrors:[], http:[] };
await fs.mkdir(out, { recursive:true });
page.setDefaultTimeout(6500);
page.on("pageerror", e => result.pageErrors.push(String(e)));
page.on("response", r => { if (/api\/(cups\/edition|cup-snapshot|fixtures|matches|match-details|nations)/.test(r.url())) result.http.push([r.status(),r.url()]); });
const check = (step, expected, actual) => result.checks.push({step, expected, actual, pass:JSON.stringify(expected)===JSON.stringify(actual)});
const step = async (name, action) => {
  try { await action(); await page.screenshot({path:path.join(out,name+".png"),animations:"disabled"}); }
  catch (error) { result.checks.push({step:name, pass:false, error:String(error), url:page.url()}); }
};
const go = params => page.goto(origin+"/competitions/?"+new URLSearchParams(params), {waitUntil:"domcontentloaded"});
const archive = (edition,view="tableau") => go({id:"open-cup:world-cup-history",edition,view});
const bracket = () => page.locator(".knockout-section");
const cards = () => page.locator(phone ? ".knockout-phone .knockout-group" : ".knockout-grid .knockout-group");
const textOf = l => l.evaluate(node=>node.textContent.trim());
const groupNames = locator => locator.locator(".knockout-group-name span:first-child").allTextContents();

for (const [year, label, groups, leader] of [
  ["1930", "Groupes", ["Groupe 1","Groupe 2","Groupe 3","Groupe 4"], null],
  ["1974", "2e tour", ["Groupe A","Groupe B"], ["Groupe A","Pays-Bas6"]],
  ["1978", "2e tour", ["Groupe A","Groupe B"], ["Groupe B","Argentine5"]],
  ["1982", "2e tour", ["Groupe A","Groupe B","Groupe C","Groupe D"], ["Groupe C","Italie4"]],
]) {
  await step(year+"-opening", async () => {
    await archive(year);
    await bracket().waitFor({state:"attached"});
    if (phone) {
      const selectGroups = page.locator(".knockout-phone").getByRole("button",{name:label,exact:true});
      const present = await selectGroups.count();
      check(year+" opening groups selectable",1,present);
      if (present) await selectGroups.click();
    }
    check(year+" opening groups",groups,(await groupNames(cards())).sort());
    if (leader && await cards().count()) {
      const table = cards().filter({has:page.locator(".knockout-group-name").getByText(leader[0],{exact:true})});
      check(year+" group winner and points",leader[1],await textOf(table.locator(".knockout-winner")));
      if (year==="1978") check("1978 Brazil shares 5 points, group winner from goal difference",true,(await table.textContent()).includes("Brésil5"));
    }
    check(year+" no fabricated quarter-finals",0,await page.locator(".knockout-labels").getByText(/Quarts de finale/).count());
  });
}
await step("1950-explicit-tableau", async () => {
  await archive("1950");
  await page.locator(".edition-head select").waitFor();
  await page.locator(".knockout-final-group,table[aria-label='Poule finale']").first().waitFor();
  check("1950 explicit route holds Tableau","tableau",new URL(page.url()).searchParams.get("view"));
  const pool = page.locator(".knockout-final-group");
  check("1950 pool is the bracket content",1,await pool.count());
  if (await pool.count()) {
    check("1950 points",["Uruguay5","Brésil4","Suède2","Espagne1"],await pool.locator(".knockout-team").allTextContents());
    check("1950 only corroborated champion","Uruguay",await textOf(pool.locator(".knockout-champion")));
    check("1950 no invented final tie",0,await pool.locator(".knockout-final").count());
  }
});
await step("1950-groups-default", async () => {
  await archive("1950","");
  await page.getByRole("table",{name:"Poule finale"}).waitFor();
  check("1950 Groupes remains the default","Groupes",await page.locator(".edition-head button[aria-pressed='true']").innerText());
});

await step("1950-old-score", async () => {
  const query = /\/api\/(?:cups\/edition|cup-snapshot)\?.*season=1950/;
  const handler = async route => {
    const response = await route.fetch();
    const payload = await response.json();
    const row = payload.matches.find(m => m.round === "Final Round" && m.team1 === "Uruguay" && m.team2 === "Brazil");
    if (!row) throw Error("the real fixture is missing");
    delete row.score;
    await route.fulfill({response,json:payload});
  };
  await page.route(query,handler);
  try {
    await archive("1950");
    await page.locator(".knockout-final-group,table[aria-label='Poule finale']").first().waitFor();
    check("1950 incomplete has no champion or group winner",[0,0],[await page.locator(".knockout-final-group .knockout-champion").count(),await page.locator(".knockout-final-group .knockout-winner").count()]);
    if (await page.locator(".knockout-final-group").count()) {
      check("1950 incomplete no quoted points for affected pair",["Uruguay—","Brésil—"],
        (await page.locator(".knockout-final-group .knockout-team").allTextContents()).filter(t=>/Uruguay|Brésil/.test(t)).sort().reverse());
    }
  } finally { await page.unroute(query,handler); }
});
for(const [year,group,ordered] of [
  ["1954","Groupe 2",["Allemagne de l’Ouest","Turquie"]],
  ["1958","Groupe 1",["Irlande du Nord","Tchécoslovaquie"]],
]){
  await step(year+"-playoff",async()=>{
    await archive(year);
    await bracket().waitFor({state:"attached"});
    check(year+" keeps quarter-finals",2,await page.locator(".knockout-labels").getByText("Quarts de finale",{exact:true}).count());
    check(year+" no fake group commencement",0,await page.locator(".knockout-group").count());
    await archive(year,"groupes");
    const table = page.getByRole("table",{name:group,exact:true});
    await table.waitFor();
    check(year+" two tied-point teams ranked by playoff",ordered,(await table.locator("tbody th").allTextContents()).slice(1,3));
    check(year+" playoff excluded from played count",year==="1954"?["2","2"]:["3","3"],
      (await table.locator("tbody tr").evaluateAll(rows=>rows.map(row=>row.cells[2].textContent))).slice(1,3));
  });
}
await step("2028-future",async()=>{
  await go({id:"open-cup:euro",edition:"2028",view:"groupes"});
  await page.getByRole("table",{name:"Groupe A"}).waitFor();
  check("Euro 2028 six groups remain unranked",[6,true],await page.locator(".edition-group table").evaluateAll(t=>[t.length,t.every(x=>[...x.querySelectorAll("tbody tr")].every(r=>r.cells[0].textContent==="—"))]));
});

for (const [year,count] of [["2026",32],["2022",16]]) {
  await step(year+"-native-links",async()=>{
    await go({id:"l_1XLtP0",edition:year,view:"tableau"});
    await bracket().waitFor({state:"attached"});
    const links=await bracket().locator("a.knockout-match-link").evaluateAll(a=>a.map(x=>[x.getAttribute("href"),x.textContent]));
    const ids=[...new Set(links.map(([href])=>new URL(href,"http://test").searchParams.get("id")))];
    check(year+" native unique linked matches",count,ids.length);
    if(year==="2026"){
      const witness=links.find(([,txt])=>txt.includes("Bosnie") && txt.includes("États-Unis"));
      check("2026 UTC-day alias routes to the correct stable ID",target.id,witness ? new URL(witness[0],origin).searchParams.get("id") : null);
    }
    let final=page.locator(".knockout-final a.knockout-match-link").first();
    if (phone && await page.locator(".knockout-phone").isVisible()) {
      const finalTab=page.locator(".knockout-phone").getByRole("button",{name:"Finale",exact:true});
      await finalTab.click();
      final=page.locator(".knockout-phone .knockout-list a.knockout-match-link").first();
    }
    if (await final.count()){
      const href=new URL(await final.getAttribute("href"),origin);
      const expectedId=href.searchParams.get("id");
      await final.click();
      await page.waitForURL(url=>url.pathname.startsWith("/matchs")&&url.searchParams.get("id")===expectedId);
      const dest=new URL(page.url());
      check(year+" final links to local match route",[year,expectedId],[dest.searchParams.get("sourceSeason"),dest.searchParams.get("id")]);
    } else {
      check(year+" final has a linked match",true,false);
    }
  });
}
check("no uncaught js errors",[],result.pageErrors);
await browser.close();
await fs.writeFile(path.join(out,"result.json"),JSON.stringify(result,null,2)+"\n");
console.log(JSON.stringify(result.checks,null,2));
process.exitCode=result.checks.some(c=>!c.pass)?1:0;
