# VI-27 / C28 · Attendus avant la fusion de main 18 h 03

Points gelés. Audit `39e6272bd0deb948ec944384fdecea07c5f41280`, main `1c5a4340d193d2ffd1406f965e4007fdfb6b97fb`, base `e60e80860e6ad1cfa9f330a4b2c2ce66eb9ef35a`. Les trois commits apportent les cartes de groupes dans le tableau (`5b08c5990e`), les liens des matchs natifs (`e45bb0a88f`) et la consignation des mesures et du périmètre encore ouvert (`1c5a4340d1`). La pré-fusion ne modifie pas le worktree. `merge-tree` relève quatre conflits de contenu.

| Surface | Attendu |
|---|---|
| 1930 | Quatre cartes des groupes, puis demies et finale. Les groupes précédents sont de vrais rangs 1 distincts. |
| 1974 et 1978 | Deux cartes du second tour avant leur finale, sans prétendus quarts ou demies. En 1974, Pays-Bas 6 et RFA 6. En 1978, Argentine et Brésil ont 5 dans le groupe B, le départage donne l’Argentine. |
| 1982 | Quatre cartes du second tour avant les deux demies. Italie 4 dans le groupe C. Finale Italie 3–1 RFA. |
| 1950 | Groupes demeure l’entrée de B sur la tuile. Tableau est une vue valide qui rend uniquement la poule finale et, si les six résultats corroborent le classement, son champion. Si un résultat manque ou contredit la table déjà attestée, aucun rang ou champion n’est attribué. |
| 1954 et 1958 | Le tableau commence aux quarts. Les barrages restent le départage du groupe, hors de ses totaux. RFA–Turquie 7–2 en 1954, Irlande du Nord–Tchécoslovaquie 2–1 après prolongation en 1958. |
| Groupes indisponibles | Un tableau sans groupes, avec groupes vides, avec égalité non départagée, avec calendrier incomplet, ou dont une équipe du premier tour n’est pas le premier attesté d’un groupe distinct, commence aux éliminations seulement. Sur iPhone, le passage à une édition plus courte ne rend aucune référence de tour hors limites. |
| Mondial natif | 32 matchs liés en 2026 et 16 en 2022 sur le témoin local complet. Le lien ouvre le match identifié, avec saison et compétition. La différence date locale/UTC et USA–Bosnia & Herzegovina / États-Unis–Bosnia and Herzegovina à une journée sont admises par le contexte national. Préserver l’ordre affiché, le score, le tour et les images par côté. Un candidat ambigu, un autre tour connu, un candidat lointain ou un match annulé ne reçoit pas de lien opportuniste. Les archives conservent leur propre lecteur et leurs résultats. |
| Ancien corps ou donnée contradictoire | La poule finale 1950 sans son dernier score n’affiche aucun Uruguay champion. Les entrées de C28 n’invalident pas le contrôle du corps ancien de 1998, l’Euro 2028 sans rang, les phases absentes, l’annulation 1938 et l’identité du match rejoué. |

Le moteur garde une source de calcul pour chaque règle de groupe. Les cartes du tableau doivent consommer les résultats de ce calcul et refuser un simple premier de la liste de présentation. « Tableau » pour 1950 désigne le tableau accessible de la poule finale, sans fabriquer un match de finale. Les calendriers/sources et les pages avec compositions historiques demandées par l’utilisateur restent avec leurs propriétaires.
