# C28 · Fusion de la livraison tournois de 18 h 03

La fusion `0a7c62d220497856b459239a869955c6e2f5707b` a pour parents la branche audit `39e6272bd0deb948ec944384fdecea07c5f41280` et le main gelé `1c5a4340d193d2ffd1406f965e4007fdfb6b97fb`. Le lot émanant du main contient `5b08c5990e` pour les tableaux de groupes, `e45bb0a88f` pour les liens natifs et `1c5a4340d1` pour le compte rendu du déploiement existant. Le coordinateur a confirmé la CI complète de `39e6272bd0` avant la reprise Sol. [Attendus antérieurs](ATTENDUS.md) · [Journal de fusion](merge.log)

| Parcours | Avant sur audit 39e6272 | Après sur la fusion |
|---|---|---|
| 1930 | Aucune carte de groupe dans Tableau | Groupes 1 à 4 avant les demies |
| 1974 et 1978 | Finale seule comme tour principal | Deux cartes du second tour avant la finale. Pays-Bas 6 en 1974. Argentine et Brésil 5 en 1978, Argentine devant au différentiel |
| 1982 | Demies et finale, zéro carte de groupe | Quatre cartes du second tour. Italie 4 dans le groupe C |
| 1950 | L’adresse explicite `view=tableau` devient `groupes` | L’URL explicite reste Tableau. Uruguay 5, Brésil 4, Suède 2, Espagne 1. Aucun match fictif de finale. Groupes reste l’entrée par défaut |
| 1950 privé du dernier score | La voie Groupes garde le résultat manquant | La poule finale reste visible dans Tableau. Aucun champion ou gagnant de groupe et points indisponibles pour Uruguay et Brésil |
| 1954 et 1958 | Quarts en tête et barrages exclus des totaux | Même début aux quarts. RFA devant Turquie et Irlande du Nord devant Tchécoslovaquie sans nouveau match compté |
| EURO 2028 | 6 groupes de 4 sans rang | 6 groupes de 4 sans rang |
| Mondial natif 2026 | 31 des 32 matchs liés, États-Unis–Bosnie sans lien dans le témoin jour+alias | 32 liens uniques. Le témoin ouvre l’identité locale `m_AA1533` |
| Mondial natif 2022 | 16 liens uniques | 16 liens uniques. Le clic en finale des deux saisons ouvre son identifiant natif et conserve la saison dans l’URL |

Les cartes consomment les mêmes tables que la vue Groupes. La date de fin et la couverture des confrontations permettent de refuser un groupe incomplet. Chaque groupe d’ouverture doit fournir un premier distinct et départagé. La poule de 1950 utilise la corroboration de B. Le lecteur natif accepte un décalage d’un jour et des variantes du nom de la même sélection. Il écarte les candidats ambigus, les correspondances multiples à la même identité et les tours connus qui se contredisent. L’ordre, le tour et le score du match d’archive restent ceux affichés.

Les vérifications remontent de PostgreSQL 18 à l’API et à Next en local. Le navigateur de fusion valide **35/35 sur bureau** et **39/39 sur iPhone simulé**, sans exception JavaScript. La différence correspond aux quatre sélections de l’onglet Groupes sur mobile. Les tests ciblés Node donnent **105/105 exécutés**, avec un contrat API sauté dans cette commande. L’API a été exercée par les deux navigateurs. Son code de lecture est identique depuis B. Deux vérifications de navigation rouge lisaient l’adresse avant la fin du clic. Le tableau ci-dessus ne leur attribue aucun défaut produit. Le rejeu vert attend l’adresse du match cliqué. [Rouge bureau](red-desktop/result.json) · [Vert bureau](final-desktop/result.json) · [Vert iPhone](final-iphone/result.json) · [Node](scoped-node.log)

La base du rejeu était celle rendue par B, construite sur schéma 149. Le schéma et le writer ne changent pas dans ce delta. Les données du Mondial natif sont des copies locales des archives et le décalage UTC/alias a été injecté sur une de ces copies par `native-offset.py`. Le test de 1950 incomplet retire une seule paire de score d’une réponse du lecteur local. Le test n’atteste ni livraison de compositions historiques, ni couverture d’images, ni état courant en production. La branche audit n’a pas été déployée par cette reprise.

## Rejeu de la capsule

Depuis Vega-Sport au commit de fusion, utiliser le PostgreSQL 18 de test sur 127.0.0.1:55459 et les dépendances verrouillées de l’application. Le test utilise Playwright 1.66.0-alpha, Chromium headless 1247 et Next 16.4.6. Le constructeur recrée seulement la base de test nommée `vega_v2_vi27_b_e2e`. Garder les commandes de serveur dans des terminaux séparés.

```sh
export VI27_C28='/absolute/path/to/unpacked-capsule'
export VI27_PLAYWRIGHT_CORE='/absolute/path/to/node_modules/playwright-core'
export VI27_CHROMIUM='/absolute/path/to/chrome-headless-shell'
export VI27_DSN='postgresql://postgres@127.0.0.1:55459/vega_v2_vi27_b_e2e'
python3 -B "$VI27_C28/build_db.py" "$PWD" "$VI27_DSN" "$VI27_C28/continental" "$VI27_C28/rebuilt-db-receipt.json"
PYTHONPATH=backend python3 -B "$VI27_C28/native-fixtures.py"
PYTHONPATH=backend python3 -B "$VI27_C28/featured-catalog.py"
PYTHONPATH=backend python3 -B "$VI27_C28/native-offset.py" > "$VI27_C28/native-offset.json"
node "$VI27_C28/serve-api.mjs" "$PWD" "$VI27_DSN" 8769
```

```sh
cd dashboard
ORION_API_ORIGIN=http://127.0.0.1:8769 NEXT_TELEMETRY_DISABLED=1 node node_modules/next/dist/bin/next dev frontend --hostname 127.0.0.1 --port 3421
```

Depuis la racine de Vega-Sport avec les variables du premier terminal.

```sh
zsh "$VI27_C28/run-browser.sh" replay desktop
zsh "$VI27_C28/run-browser.sh" replay iphone
node --test tests/tournament-rules.test.mjs tests/tournament-editions.test.mjs tests/{cup*,competition*,complementary-leagues,euro-search-flags,knockout-bracket}.test.mjs backend/api/test/nations.test.mjs
```

Pour reproduire les observations rouges sur la révision audit de départ, lancer le même serveur et la même base avec `VI27_BROWSER_SCRIPT="$VI27_C28/browser-1803-red.mjs" zsh "$VI27_C28/run-browser.sh" replay-red desktop`. Le fichier `result.json` de chaque exécution contient l’attendu, l’observé et les réponses HTTP des routes de données. Les captures PNG incluent les écrans avec et sans groupes et les détails des rencontres ouvertes.
