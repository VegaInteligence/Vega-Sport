"""Emulate the measured UTC-day/alias discrepancy on the copied local fixture only."""
from vega.store import Store, connect_local
import json

db = connect_local("postgresql://postgres@127.0.0.1:55459/vega_v2_vi27_b_e2e")
store = Store(db)
with db.transaction():
    alias = store.entity("team", "t_hw26ba", {"name": "Bosnia and Herzegovina"})
    c = db.execute("""SELECT m.id,p.provider_key, h.name,a.name,m.match_date::text,r.name
      FROM core.matches m JOIN core.competition_seasons cs ON cs.id=m.competition_season_id
      JOIN core.provider_ids cp ON cp.entity_type='competition' AND cp.provider='pitchapi' AND cp.entity_id=cs.competition_id
      JOIN core.rounds r ON r.id=m.round_id AND r.name='Round of 32'
      JOIN core.teams h ON h.id=m.home_team_id JOIN core.teams a ON a.id=m.away_team_id
      JOIN core.provider_ids p ON p.entity_type='match' AND p.provider='pitchapi' AND p.entity_id=m.id
      WHERE cp.provider_key='l_1XLtP0' AND cs.native_label='2026' AND h.name='USA'
      AND a.name IN ('Bosnia & Herzegovina','Bosnia and Herzegovina')""").fetchall()
    assert len(c) == 1, c
    mid, public, home, away, day, stage = c[0]
    assert day in ("2026-07-01", "2026-07-02"), c
    changed = db.execute("""UPDATE core.matches SET away_team_id=%s,match_date='2026-07-02',kickoff_at='2026-07-02T01:00:00Z'
       WHERE id=%s AND source='pitchapi' RETURNING match_date::text""", (alias,mid)).fetchone()
    assert changed == ("2026-07-02",)
print(json.dumps({"id":public,"status":"local copy","archive":["2026-07-01",home,"Bosnia & Herzegovina",stage],
    "native":["2026-07-02",home,"Bosnia and Herzegovina",stage]}))
