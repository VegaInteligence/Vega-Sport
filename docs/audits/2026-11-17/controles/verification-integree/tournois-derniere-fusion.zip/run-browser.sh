#!/bin/zsh
set -eu
out=${0:a:h}
phase=$1
device=$2
pw=${VI27_PLAYWRIGHT_CORE:-/Users/lemonnierhugo/.npm/_npx/31e32ef8478fbf80/node_modules/playwright-core}
browser=${VI27_CHROMIUM:-/Users/lemonnierhugo/Library/Caches/ms-playwright/chromium_headless_shell-1247/chrome-headless-shell-mac-arm64/chrome-headless-shell}
origin=${VI27_ORIGIN:-http://127.0.0.1:3421}
node "${VI27_BROWSER_SCRIPT:-$out/browser-1803.mjs}" "$pw" "$browser" "$origin" "$out/$phase-$device" "$device" "$out/native-offset.json"
