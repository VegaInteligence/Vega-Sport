"""Replay the 106 observed squad profiles using the normal Reader on PostgreSQL 18."""
import argparse
from collections import Counter
from datetime import timedelta
from hashlib import sha256
import json
from pathlib import Path
import re
import subprocess
import sys
from urllib.request import urlopen

import psycopg
from psycopg import sql


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("tree", type=Path)
    parser.add_argument("projection", type=Path)
    parser.add_argument("output", type=Path)
    parser.add_argument("--tag", required=True)
    parser.add_argument("--port", type=int, default=55471)
    parser.add_argument("--red", action="store_true")
    args = parser.parse_args()
    assert re.fullmatch(r"[a-z0-9]{2,20}", args.tag) and 1 <= args.port <= 65535
    queue_bytes = args.projection.read_bytes()
    digest = sha256(queue_bytes).hexdigest()
    assert digest == "5dc3b5a266e493ac0c98eebdb691cddbff70497bf3719113ab27bb80bfb8c176"
    projection = json.loads(queue_bytes)["rows"]
    keys = {r["player_key"]: r for r in projection}
    priority_before = Counter(r["profile_queue"]["priority"] for r in projection)
    assert len(keys) == len(projection) == 106 and priority_before == {2: 65, 3: 20, 4: 3, 9: 18}
    assert all(r["season_year"] == 2026 and r["profile_queue"]["attempts"] == 0
               and r["profile_queue"]["read_at"] is None and r["profile_queue"]["error_code"] is None for r in projection)
    tree = args.tree.resolve()
    sys.path.insert(0, str(tree / "backend"))
    from vega import transfermarkt as tm
    from vega.store import migrate

    base = f"postgresql://postgres@127.0.0.1:{args.port}/"
    db_name = "vega_v2_vi31_squad_" + args.tag
    with psycopg.connect(base + "postgres", autocommit=True) as admin:
        assert admin.info.server_version // 10000 == 18
        admin.execute(sql.SQL("CREATE DATABASE {}").format(sql.Identifier(db_name)))
    dsn = base + db_name
    conn = psycopg.connect(dsn, autocommit=True)
    migrate(conn)
    now = conn.execute("SELECT clock_timestamp()").fetchone()[0]
    changed_club = {r["club_key"]: (r["canonical_club_id"], r["canonical_club_name"]) for r in projection}
    assert len(changed_club) == 71
    x = conn.execute
    x("INSERT INTO core.seasons(id,label) VALUES (2026,'2026/2027') ON CONFLICT DO NOTHING")
    x("INSERT INTO core.competitions(id,name) VALUES (900001,'VI-31 local fixture')")
    x("INSERT INTO core.competition_seasons(id,competition_id,season_id) VALUES (900001,900001,2026)")
    x("INSERT INTO core.teams(id,name,is_national) VALUES (900001,'Test Home',true),(900002,'Test Away',true)")
    x("""INSERT INTO core.matches(competition_season_id,season_id,source,status,home_team_id,away_team_id,match_date)
         VALUES (900001,2026,'pitchapi','finished',900001,900002,'2026-11-17')""")
    for key, (ident, name) in changed_club.items():
        x("INSERT INTO core.teams(id,name) VALUES (%s,%s) ON CONFLICT (id) DO NOTHING", (ident, name))
        x("""INSERT INTO core.provider_ids(entity_type,provider,provider_key,entity_id,is_current)
             VALUES ('team','transfermarkt',%s,%s,true)""", (key, ident))
        x("INSERT INTO core.provider_clubs(provider,provider_key,name,read_on) VALUES ('transfermarkt',%s,%s,current_date)", (key, name))
    for key, record in keys.items():
        ident = record["canonical_player_id"]
        x("INSERT INTO core.players(id,name) VALUES (%s,%s)", (ident, record["canonical_player_name"]))
        x("""INSERT INTO core.provider_ids(entity_type,provider,provider_key,entity_id)
             VALUES ('player','transfermarkt',%s,%s)""", (key, ident))
        x("""INSERT INTO core.provider_squads(provider,club_key,season_year,player_key,shirt_number,read_on)
             VALUES ('transfermarkt',%s,%s,%s,%s,%s)""",
          (record["club_key"], record["season_year"], key, record["shirt_number"], record["read_on"]))
        queue = record["profile_queue"]
        x("""INSERT INTO ops.transfermarkt_reads(kind,provider_key,priority,next_due_at)
             VALUES ('profile',%s,%s,%s),('injuries',%s,1,%s)""",
          (key, queue["priority"], queue["next_due_at"], key, now + timedelta(days=1)))
    x("""INSERT INTO ops.transfermarkt_reads(kind,provider_key,priority,next_due_at)
         VALUES ('transfers','9999990000',1,now()-interval '2 days')""")
    x("SET ROLE vega_collect")
    expiry = (now.date() + timedelta(days=365)).isoformat()
    calls = []

    def fetch(path, params):
        batch = [value for name, value in params if name == "ids[]"]
        calls.append({"path": path, "keys": batch})
        data = [{"id": int(k), "name": keys[k]["canonical_player_name"],
                 "lifeDates": {"dateOfBirth": "1995-01-01"},
                 "attributes": {"position": {"name": "Centre-Forward"}, "contractUntil": expiry},
                 "clubAssignments": [{"type": "current", "clubId": keys[k]["club_key"], "start": "2026-07-01"}]}
                for k in batch] if path == "/players" else {"history": {"pending": [], "terminated": []}}
        return 200, {}, json.dumps({"success": True, "data": data}).encode()

    reader = tm.Reader(conn, fetch, clock=lambda: now, interval=0, jitter=0, sleep=lambda _: None, log=lambda *a, **k: None)

    def snapshot():
        return {key: (data, version) for key, data, version in x(
            "SELECT provider_key,to_jsonb(r)-'priority',xmin::text FROM ops.transfermarkt_reads r WHERE kind='profile'")}

    def profile_counts():
        return dict(x("SELECT priority,count(*) FROM ops.transfermarkt_reads WHERE kind='profile' GROUP BY 1"))

    ids_before = x("SELECT to_jsonb(i) FROM core.provider_ids i ORDER BY entity_type,provider,provider_key").fetchall()
    before = snapshot()
    assert all(not row["read_at"] for row, _ in before.values())
    changed = reader.plan()
    after = snapshot()
    priorities = profile_counts()
    assert {key: d for key, (d, _) in after.items()} == {key: d for key, (d, _) in before.items()}
    repeat = reader.plan()
    assert repeat == 0 and after == snapshot()
    first = reader.step()
    report = {"source_sha256": digest, "candidate": subprocess.check_output(
        ["git", "-C", str(tree), "rev-parse", "HEAD"], text=True).strip(), "database": dsn,
        "before": priority_before, "after": priorities, "initial_plan": changed, "repeat_plan": repeat, "first_step": first,
        "before_after_all_fields_except_priority_equal": True, "repeat_identical_xmin": True, "calls": calls}
    if args.red:
        assert priorities == priority_before and changed == 0 and calls[0]["path"].startswith("/transfer/")
    else:
        assert changed == 106 and priorities == {1: 106} and first == "ok"
        assert reader.step() == "ok"
        assert [c["path"] for c in calls] == ["/players", "/players"]
        assert sorted(len(c["keys"]) for c in calls) == [6, 100] and set(k for c in calls for k in c["keys"]) == keys.keys()
        assert ids_before == x("SELECT to_jsonb(i) FROM core.provider_ids i ORDER BY entity_type,provider,provider_key").fetchall()
        assert x("SELECT count(*) FROM core.provider_players WHERE provider='transfermarkt'").fetchone()[0] == 106
        assert x("""SELECT count(*) FROM ops.transfermarkt_reads WHERE kind='profile' AND read_at IS NOT NULL
                    AND last_http_status=200 AND attempts=0 AND error_code IS NULL AND rows_written=1""").fetchone()[0] == 106
        assert x("SELECT read_at FROM ops.transfermarkt_reads WHERE kind='transfers'").fetchone()[0] is None
        successful = snapshot()
        assert reader.plan() == 0 and snapshot() == successful
        x("SET ROLE vega_read")
        public_ids = x("SELECT public_id,observed_contract_until FROM api.player_profiles ORDER BY player_id").fetchall()
        assert len(public_ids) == 106 and {date for _, date in public_ids} == {expiry}
        receipts = []
        with (args.output.parent / (args.tag + "-http.log")).open("w") as log:
            server = subprocess.Popen(["node", str(Path(__file__).with_name("serve.mjs")), str(tree), dsn],
                                      stdout=subprocess.PIPE, stderr=log, text=True)
            try:
                port = int(server.stdout.readline().strip())
                for sample, known in public_ids:
                    with urlopen(f"http://127.0.0.1:{port}/api/players/{sample}", timeout=12) as res:
                        payload = json.load(res)["data"]
                        assert res.status == 200 and payload["id"] == sample and payload["observed_contract_until"] == known
                        receipts.append({"status": res.status, "id": sample, "observed_contract_until": known})
            finally:
                server.terminate()
                server.wait(timeout=10)
        report.update(raw_written=106, API_view_observed_contracts=106, API_HTTP=receipts,
                      completed_profile_rows_unchanged=True, canonical_links_unchanged=True)
    args.output.write_text(json.dumps(report, indent=2, ensure_ascii=False) + "\n")
    print("red confirmed" if args.red else "pass")


if __name__ == "__main__":
    main()
