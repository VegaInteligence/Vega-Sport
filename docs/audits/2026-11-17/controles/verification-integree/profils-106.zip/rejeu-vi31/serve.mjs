import {createServer} from "node:http";
import {resolve} from "node:path";
import {pathToFileURL} from "node:url";

const [tree, dsn] = process.argv.slice(2);
const url = new URL(dsn);
if (url.hostname !== "127.0.0.1" || !url.pathname.startsWith("/vega_v2_vi31_squad_")) {
  throw new Error("Use a dedicated local VI-31 replay database");
}
const {createReader} = await import(pathToFileURL(resolve(tree, "backend/api/src/db.mjs")));
const {createHandler} = await import(pathToFileURL(resolve(tree, "backend/api/src/handler.mjs")));
const reader = createReader(dsn, {role: "vega_read"});
const handle = createHandler({read: reader.read});
const server = createServer(async (request, response) => {
  const result = await handle(new Request("http://127.0.0.1" + request.url));
  response.writeHead(result.status, Object.fromEntries(result.headers));
  response.end(Buffer.from(await result.arrayBuffer()));
});
server.listen(0, "127.0.0.1", () => console.log(server.address().port));
process.on("SIGTERM", () => server.close(async () => { await reader.end(); process.exit(0); }));
