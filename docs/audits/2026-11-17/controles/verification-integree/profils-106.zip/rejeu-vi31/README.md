# Rejouer l’ordre des profils Transfermarkt

Le paquet vérifie VI‑31 par le véritable `Reader.plan` et `Reader.step` sur les 106 clés déjà projetées, puis via `GET /api/players/{id}`. Il utilise PostgreSQL 18 local, les réponses fournisseur contrôlées et le véritable serveur HTTP du dépôt.

Prérequis

- Un checkout de Vega‑Sport au commit `413aaeb75c7289c55be1607ffe6891b22e4c4e8a`, Python avec `backend/requirements.txt`, et les dépendances de `backend/api` installées.
- PostgreSQL 18 jetable sur la boucle locale, avec création de bases possible pour son utilisateur `postgres`. Le test conserve une base `vega_v2_vi31_squad_<tag>` pour inspection.
- `integrite-courante-partage-20261118.zip`, SHA‑256 `8ce26e7d8345eacd1daae9806c44c9e5729dee2fe014e9503c8452f1a16553e7`. Le seul témoin d’entrée utilisé est `data/queue.json`. Le script vérifie son empreinte.

```sh
unzip -p "/chemin/integrite-courante-partage-20261118.zip" data/queue.json > queue.json
python3 -B replay.py "/chemin/vers/Vega-Sport" queue.json resultat.json --port 55471 --tag replay01
```

Le reçu `resultat.json` décrit les priorités initiales et finales, les appels du Reader et les réponses HTTP. La projection contient les vrais identifiants canoniques et fournisseur, les saisons et les échéances observées. Les valeurs de réponse fournisseur, dont l’échéance de contrat en HTTP, servent uniquement de contrôle et proviennent du harnais local. L’option `--red` se joue sur `33266597f766a019f8c75f1c99a4a21692381e06` en utilisant un suffixe de base inédit.
