# VI-31 · Priorité du premier profil de joueur d’effectif

Un profil brut absent et jamais lu doit prendre la priorité calculée par le plan existant si elle est plus urgente. Seul le champ de priorité change. Dans la projection réelle, 65 unités de priorité 2, 20 de priorité 3, trois de priorité 4 et 18 de priorité 9 doivent toutes atteindre 1.

- Une insertion nouvelle garde son échéance de planification. Les saisons multiples sont réduites à la meilleure priorité. Une saison ancienne garde sa priorité calculée et ne dégrade jamais une unité déjà plus urgente.
- Un profil brut disponible, un succès antérieur et un 404 déjà constaté gardent leur état. Le Reader écrit `read_at` lors d’un résultat constaté, y compris un 404 ajourné.
- Un premier essai échoué avec reprise programmée peut être promu. Échéance, tentative, statut, erreur et compteurs restent identiques. Le lecteur attend l’échéance.
- Les autres kinds et les identités restent stables. Le deuxième plan n’écrit aucune ligne de file, y compris `xmin`. Le timestamp de planification global est géré par le Reader.
- Le vrai `Reader.step` choisit les profils promus avant un transfert de même priorité, puis publie chaque profil par son writer habituel. Le transport du banc est inspectable et contrôlé.
