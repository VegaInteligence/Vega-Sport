# Vérification de la navigation VI-22 en production

Entrées publiques du 18 novembre 2026. La fiche du Paris Saint-Germain vient de la recherche publique. Toluca figure parmi ses voisins statistiques de toutes ligues. Les écrans mesurent 1 440 × 900 et 393 × 852 pixels. Le navigateur emploie un profil isolé.

- Ouvrir les liens de chacun des 17 autres clubs du tableau Ligue 1 et vérifier l’identifiant et le nom effectivement affiché.
- Ouvrir chaque résultat et chaque rencontre future visible sur la fiche parisienne. Vérifier l’identifiant du match et l’affichage de l’adversaire et du club.
- Vérifier dans l’interface le top 10 global puis italien, le résultat d’Inter dans les deux listes et la sélection du filtre.
- Pour Toluca, charger les informations de club et le classement européen. Vérifier le message de rang indisponible.
- Vérifier les dix entrées du bandeau « Championnats à la une » et ouvrir les trois compétitions européennes.
- Lire les résultats avec les autres obligations de VI-22, notamment les périodes et statistiques de support. Une navigation réussie renseigne uniquement les parcours testés.

## Rejeu

Le contrôle hors ligne se lance à la racine avec `python3 -B verifier.py`. Pour une nouvelle observation réseau, installer Playwright CLI et un Chromium compatible. Fournir son exécutable dans un fichier JSON au format `{"browser":{"browserName":"chromium","launchOptions":{"executablePath":"/chemin/vers/chromium"}}}`. Depuis la racine extraite, passer au paramètre `--cli` le chemin absolu de l’exécutable ou du lanceur Playwright CLI. Les dossiers de sortie et sessions doivent être neufs. Les noms des équipes et les dates attendues sont ceux de la publication examinée.

```sh
python3 -B run.py 393 essai-mobile --cli /chemin/vers/playwright-cli --config browser-config.json --session vi22-mobile
python3 -B run.py 1440 essai-bureau --cli /chemin/vers/playwright-cli --config browser-config.json --session vi22-bureau
```

Les deux résultats JSON et les six captures donnent les observations de la passe du 18 novembre. Le contrôle des liens vérifie les identifiants effectivement ouverts, le nom de chaque club, les deux participants du match et l’état du bandeau. Le club sélectionné est déjà identifié dans le tableau des clubs de Ligue 1. Ses 17 adversaires sont cliquables. Les deux formats valident 58 navigations et dix contrôles complémentaires, dont six sélections de coupe. Les attributs visibles permettent de reproduire les actions au clavier ou à la souris.
