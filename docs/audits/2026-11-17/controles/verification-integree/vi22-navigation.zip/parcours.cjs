async page => {
 const out={width:WIDTH,at:new Date().toISOString(),checks:[],errors:[]};
 const log=(step,detail)=>out.checks.push({step,...detail});
 const guard=(ok,msg)=>{if(!ok)throw Error(msg)};
 const psg='https://vegasport.vercel.app/clubs?id=t_41iFW3&season=2026%2F2027';
 page.setDefaultTimeout(18000);
 await page.setViewportSize({width:WIDTH,height:WIDTH===393?852:900});
 async function openClub(){
   await page.goto(psg,{waitUntil:'domcontentloaded'});
   await page.getByRole('heading',{name:'Paris Saint-Germain',exact:true}).first().waitFor();
 }
 const section=(pattern)=>page.getByRole('heading',{name:pattern}).first().locator('xpath=ancestor::section[1]');
 async function unfold(sec){
   let toggle=sec.locator('button.phone-fold-toggle').first();
   if(await toggle.count()&&await toggle.isVisible()&&await toggle.getAttribute('aria-expanded')==='false')await toggle.click();
 }
 for (const [key,heading,pathname] of [['clubs',/Résultats et attendus/,'/clubs'],['played',/^Derniers matchs$/,'/matchs'],['future',/^Prochains matchs$/,'/matchs']]){
  try{
   await openClub();let sec=section(heading);await unfold(sec);
   await sec.locator('a[href]').first().waitFor();
   const links=await sec.locator('a[href]').evaluateAll(nodes=>nodes.map(a=>({href:a.getAttribute('href'),title:a.innerText.trim(),label:a.getAttribute('aria-label')})));
   guard(links.length===(key==='clubs'?17:6),'unexpected displayed links '+links.length);
   guard(new Set(links.map(v=>v.href)).size===links.length,'non-unique displayed destinations');
   if(key==='clubs')guard(await sec.locator('tbody tr').count()===18,'standing row count');
   for(let index=0;index<links.length;index++){
     const link=links[index],u=new URL(link.href,psg),id=u.searchParams.get('id');
     try{
       if(index){await openClub();sec=section(heading);await unfold(sec);}
       const row=sec.locator('a[href]').nth(index);
       guard(await row.getAttribute('href')===link.href,'link changed during observation');
       await row.click();
       await page.waitForURL(url=>url.pathname.replace(/\/$/,'')===pathname&&url.searchParams.get('id')===id);
       if(key==='clubs'){
         const name=link.title.replace(/^\s*\d+\s*/,'').trim();
         await page.getByRole('heading',{name,exact:true}).first().waitFor();
         log('opened-club',{id,name,index,actual:page.url()});
       } else {
         const opponent=(key==='played'?['Troyes','Villarreal','Le Havre','Lyon','Barcelona','Strasbourg']:['Nice','Roma','Lorient','Toulouse','Aston Villa','Paris FC'])[index];
         guard(link.title.includes(opponent),'match witness changed '+opponent);
         await page.waitForFunction(({a,b})=>{const text=document.querySelector('main')?.innerText||'';return text.includes(a)&&text.includes(b);},{a:'Paris Saint-Germain',b:opponent});
         const head=await page.locator('main h1,main h2,main h3').allTextContents();
         log('opened-'+key,{id,title:link.title,expected:link.href,actual:page.url(),headings:head.slice(0,12)});
       }
     } catch(e){out.errors.push({step:key,index,href:link.href,error:String(e).slice(0,450)});}
   }
  }catch(e){out.errors.push({step:key,error:String(e).slice(0,400)});}
 }
 try {
   await openClub();await page.getByRole('tab',{name:'Clubs similaires',exact:true}).click();
   const renderer=()=>page.evaluate(()=>[...document.querySelectorAll('[class*="similarHead"]')].map(n=>({name:n.querySelector('strong')?.textContent,score:n.querySelector('b')?.textContent,league:n.querySelector('small')?.textContent})));
   await page.getByText('Inter',{exact:true}).first().waitFor();const all=await renderer();
   const menu=page.getByRole('button',{name:'Tous les championnats',exact:true});await menu.click();
   await page.getByRole('option',{name:/^Serie A/}).click();
   await page.waitForFunction(()=>[...document.querySelectorAll('[class*="similarHead"]')].length===10&&[...document.querySelectorAll('[class*="similarHead"] small:first-of-type')].some(n=>n.textContent.includes('Serie A'))&&![...document.querySelectorAll('[class*="similarHead"] strong')].some(n=>n.textContent==='Barcelona'));
   const italy=await renderer();
   guard(all.length===10&&italy.length===10&&italy.every(r=>r.league.includes('Serie A')),'league filter result');
   const inter=rows=>rows.find(r=>r.name==='Inter')?.score;
   guard(inter(all)===inter(italy)&&inter(all)!=null,'different Inter score');log('similarity',{all,italy});
 }catch(e){out.errors.push({step:'similarity',error:String(e).slice(0,450)});}
 try {
   await page.goto('https://vegasport.vercel.app/clubs?id=t_33VE4n&season=2026%2F2027',{waitUntil:'domcontentloaded'});
   await page.getByRole('heading',{name:'Toluca',exact:true}).first().waitFor();
   await page.locator('.club-overview-info').scrollIntoViewIfNeeded();
   let sec=section(/^Classement UEFA$/);await sec.waitFor();await unfold(sec);
   await sec.getByText('Ce club n’a pas de classement UEFA.',{exact:true}).waitFor();
   guard(await sec.locator('table').count()===0,'table despite empty UEFA data');log('unranked',{name:'Toluca',message:await sec.locator('p').first().innerText()});
 }catch(e){out.errors.push({step:'unranked',error:String(e).slice(0,450)});}
 try {
   const addr='https://vegasport.vercel.app/competitions';
   for(const name of ['Champions League','Europa League','Conference League']){
     await page.goto(addr,{waitUntil:'domcontentloaded'});
     const grid=page.getByRole('region',{name:'Choisir une compétition'});
     const cup=grid.getByRole('button',{name:new RegExp(name)});
     await cup.waitFor();const titles=await grid.getByRole('button').allTextContents();
     guard(titles.length===10,'featured count '+titles.length);
     await cup.click();await page.waitForFunction(label=>[...document.querySelectorAll('.league-spotlight-item')].some(b=>b.textContent.includes(label)&&b.getAttribute('aria-pressed')==='true'),name);const state=await cup.getAttribute('aria-pressed');
     await page.screenshot({path:OUT+'/coupe-'+WIDTH+'-'+name.split(' ')[0]+'.png'});
     log('featured-cup',{name,titles,selected:state,url:page.url(),headings:(await page.getByRole('heading').allTextContents()).slice(0,15)});
   }
 }catch(e){out.errors.push({step:'featured',error:String(e).slice(0,450)});}
 out.finished=new Date().toISOString();return out;
}
