"""Verify the two production navigation observations and the captured viewport dimensions."""
from collections import Counter
from hashlib import sha256
import json
from pathlib import Path
import struct
from urllib.parse import parse_qs, urlsplit

base=Path(__file__).resolve().parent
def read(p):return json.loads(p.read_bytes())
h=lambda b:sha256(b).hexdigest()
all_reports=[]
for width in (393,1440):
    folder=base/str(width)
    artifact=read(folder/'result.json')
    receipt=read(folder/'receipt.json')
    assert h((base/'parcours.cjs').read_bytes())==receipt['script_sha256']
    for p in folder.iterdir():
        if p.name!='receipt.json':
            assert h(p.read_bytes())==receipt['files'][p.name]
    assert artifact['width']==receipt['width']==width and artifact['errors']==[]
    checks=artifact['checks']
    expected={'opened-club':17,'opened-played':6,'opened-future':6,'featured-cup':3,'similarity':1,'unranked':1}
    assert Counter(row['step'] for row in checks)==expected
    opened=[r for r in checks if r['step'].startswith('opened-')]
    assert len({r['id'] for r in opened})==29
    for r in opened:
        parsed=urlsplit(r['actual'])
        assert parsed.hostname=='vegasport.vercel.app' and parse_qs(parsed.query)['id']==[r['id']]
        assert parsed.path.rstrip('/')==('/clubs' if r['step']=='opened-club' else '/matchs')
    sim=next(x for x in checks if x['step']=='similarity')
    assert len(sim['all'])==len(sim['italy'])==10 and all('Serie A' in r['league'] for r in sim['italy'])
    assert [r['score'] for r in sim['all'] if r['name']=='Inter']==[r['score'] for r in sim['italy'] if r['name']=='Inter']==['84/100']
    assert any('Serie A' not in r['league'] for r in sim['all'])
    assert 'pas de classement UEFA' in next(x for x in checks if x['step']=='unranked')['message']
    selected=[r for r in checks if r['step']=='featured-cup']
    assert all(len(r['titles'])==10 and r['selected']=='true' for r in selected)
    screenshots=list(folder.glob('*.png'))
    assert len(screenshots)==3
    for image in screenshots:
        buf=image.read_bytes()
        assert buf.startswith(b'\x89PNG\r\n\x1a\n') and struct.unpack('>II',buf[16:24])==(width,852 if width==393 else 900)
    all_reports.append({'viewport':width,'started':artifact['at'],'finished':artifact['finished'],'steps':expected,'errors':0})
assert len(all_reports)==2
print(json.dumps({'status':'PASS','reports':all_reports,'actual_navigation_clicks':58,'other_observations':10,'screenshots':6},ensure_ascii=False))
