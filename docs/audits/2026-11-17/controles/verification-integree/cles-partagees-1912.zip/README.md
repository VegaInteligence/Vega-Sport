# Clés de match et classements en production

La transaction RDS PostgreSQL du 18 novembre 2026 à 19 h 12 min 15 s UTC est en lecture seule, avec une isolation à lecture répétable. Les quatre fichiers SQL et leurs résultats JSON proviennent du même instantané. Les requêtes agrègent des clés publiques de match et les dates de traitement. Les identifiants de connexion ne figurent pas dans cette livraison.

Le rapprochement porte sur les 4 682 matchs Open Matchday, 4 452 OpenFootball, 167 OpenLigaDB et 409 International Results avec une clé courante. Aucun de ces 9 710 matchs ne porte en plus une clé d’un autre fournisseur. Parmi eux, 2 249 sont programmés. Les 94 081 clés de match de l’ensemble des fournisseurs, dont 84 371 PitchAPI, ont toutes un parent. Les 1 086 lignes SportScore de 60 éditions comportent une seule date de publication par édition. Les 76 périmètres SportScore présentent le statut de dernière lecture « ok ».

Ces observations à un instant donné ne renseignent ni les états intermédiaires de deux imports simultanés, ni la fréquence d’une régression des points ou d’un rattachement à la mauvaise section. Les contre-exemples de la revue utilisent des commandes concurrentes et des données de test.

Depuis le dossier extrait, lancer `python3 -I -B verifier.py`. Le programme attend 9 710 rencontres avec zéro autre fournisseur, zéro clé sans parent et 1 086 lignes réparties sur 60 éditions. Le fichier du reçu rassemble les empreintes et les deux contrôles négatifs. Les SQL peuvent être relus successivement dans une transaction `REPEATABLE READ, READ ONLY` sur la base Vega lors d’une mesure ultérieure.
