SELECT source,status,count(*) AS scopes,min(last_success_at) AS oldest_success,
max(last_success_at) AS newest_success, count(*) FILTER(WHERE last_success_at>last_attempt_at) AS success_after_attempt
FROM ops.source_runs WHERE source IN ('sportscore','open_matchday','openfootball','openligadb','international_results')
GROUP BY source,status ORDER BY source,status