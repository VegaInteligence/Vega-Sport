"""Repeat the scope and parent checks from one captured read-only transaction."""
import json
from pathlib import Path

ROOT = Path(__file__).resolve().parent

def rows(name):
    table = json.loads((ROOT / (name + '.json')).read_bytes())
    return [dict(zip(table['columns'], row, strict=True)) for row in table['rows']]

def main():
    snap = json.loads((ROOT / 'snapshot.json').read_bytes())
    assert snap['read_only'] == 'on' and snap['isolation'] == 'repeatable read'
    scope = rows('multi-source')
    keys = rows('orphelins')
    scores = rows('classements')
    runs = rows('suivi')
    sum_key = lambda items, name: sum(row[name] for row in items)
    supported = {'openfootball', 'open_matchday', 'openligadb', 'international_results'}
    assert {row['owner'] for row in scope} == supported
    assert {row['provider'] for row in keys} == supported | {'pitchapi'}
    assert len({(row['owner'], row['status']) for row in scope}) == len(scope)
    assert len({(row['provider'], row['is_current']) for row in keys}) == len(keys)
    for provider in supported:
        assert sum(row['scoped_matches'] for row in scope if row['owner']==provider) == sum(row['keys'] for row in keys if row['provider']==provider and row['is_current'])
    assert len({row['competition_season_id'] for row in scores})==len(scores)
    assert all(row['rows'] > 0 and row['oldest'] and row['newest'] for row in scores)
    report = {
        'at': snap['at'],
        'matches': sum_key(scope,'scoped_matches'),
        'scheduled': sum(row['scoped_matches'] for row in scope if row['status']=='not_started'),
        'shared': sum_key(scope,'other_provider_evidence'),
        'keys': sum_key(keys,'keys'),
        'missing_parent': sum_key(keys,'missing_parent'),
        'standings_rows': sum_key(scores, 'rows'),
        'standings_editions': len(scores),
        'multiple_timestamps_within_an_edition': sum(row['oldest'] != row['newest'] for row in scores),
        'sportscore_scopes':sum(row['scopes'] for row in runs if row['source']=='sportscore'),
    }
    expected = {'matches':9710, 'scheduled':2249, 'shared':0, 'keys':94081,
                'missing_parent':0, 'standings_rows':1086, 'standings_editions':60,
                'multiple_timestamps_within_an_edition':0,'sportscore_scopes':76}
    for field, value in expected.items():
        if report[field]!=value:
            raise ValueError(f'{field}: {report[field]} != {value}')
    print(json.dumps(report, ensure_ascii=False, indent=2))

if __name__=='__main__':
    main()
