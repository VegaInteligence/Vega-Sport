# Intégrité de la base de production

La transaction PostgreSQL en lecture seule du 18 novembre 2026 à 15 h 20 min 35 s UTC a appliqué 13 requêtes sur un même instantané. Le profil ne renvoie ici que des décomptes, des états de file, des dates extrêmes et les noms des champs. Le reçu relie les résultats compressés à la sonde exécutée sur le worker déployé. Le vérificateur contrôle la correspondance des requêtes, des résultats et du transport, puis recalcule les totaux.

Extraire cette archive et lancer la commande suivante avec Python 3.11 ou ultérieur.

```sh
python3 -B verifier.py
```

Les signatures de doublon détectent des candidats. Elles ne suffisent pas à distinguer les reçus multiples d’un même événement, un véritable match d’appui, une étape intermédiaire de prêt ou deux entités qui portent le même nom. Le comptage des contraintes porte sur leur validation PostgreSQL. Les erreurs de rattachement sportif restent possibles avec des clés étrangères valides. La vérification des 70 Elo orphelins dispose de sa propre capsule dans le rapport.
