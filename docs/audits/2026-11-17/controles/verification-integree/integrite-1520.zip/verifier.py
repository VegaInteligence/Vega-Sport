"""Recompute the 18 November integrity census from its signed read-only transport."""
import hashlib
import json
from pathlib import Path
import zlib

base=Path(__file__).resolve().parent
def digest(b):
    return hashlib.sha256(b).hexdigest()
def run():
    receipt=json.loads((base/'receipt.json').read_bytes())
    raw=(base/'inputs.json.zlib').read_bytes()
    assert receipt['sha256']==digest(raw) and receipt['bytes']==len(raw)
    assert receipt['exit_code']==0 and receipt['definition_end_state']=='INACTIVE'
    assert digest((base/'probe.py').read_bytes())==receipt['probe_sha256']
    doc=json.loads(zlib.decompress(raw))
    assert doc['read_only']=='on' and doc['snapshot']=='4442233:4442233:'
    set_sql=json.loads((base/'requetes.json').read_bytes())
    assert set(set_sql)==set(doc['queries']) and len(set_sql)==13
    rows={}
    for key,sql in set_sql.items():
        source=doc['queries'][key]
        assert source['sql_sha256']==digest(sql.encode()) and 'failed' not in source, key
        rows[key]=[dict(zip(source['columns'],r,strict=True)) for r in source['rows']]
    def total(query,col):
        return sum(int(r[col]) for r in rows[query])
    def pairs(query, key, metric):
        return {r[key]:int(r[metric]) for r in rows[query]}
    entity=pairs('01_identity_candidates','signal','candidate_groups')
    assert entity['team_unspecified_kind_same_name_country']==7 and sum(entity.values())==7
    members=pairs('05_membership_and_transfer','signal','records')
    track=pairs('canonical_edges','metric','n')
    stats=rows['event-integrity'][0]
    assert sum(stats[k] for k in ('both_resolved','one_resolved','neither_resolved'))==stats['event_rows']
    overlap=rows['03_match_overlap']
    assert total('04_match_integrity','matches')==588758
    out={'snapshot':doc['snapshot'],'at':doc['at'],'predicates':len(rows),'read_only':doc['read_only'],
         'matches':total('04_match_integrity','matches'),'candidate_match_groups':total('03_match_overlap','same_day_team_pair_groups'),
         'candidate_match_rows':total('03_match_overlap','candidate_rows'),'conflicting_score_groups':total('03_match_overlap','conflicting_score_groups'),
         'same_day_groups_by_provider_and_edition':overlap,'entity_candidate_groups':entity,
         'provider_keys':total('02_provider_keys','provider_keys'),'provider_groups':len(rows['02_provider_keys']),
         'target_missing':total('02_provider_keys','missing_target_keys'),'multiple_current':total('02_provider_keys','multiple_current_keys'),
         'foreign_keys':sum(r['constraints'] for r in rows['07_fk_catalog'] if r['constraint_type']=='f'),
         'unvalidated_constraints':total('07_fk_catalog','unvalidated'),'finished_without_side':total('04_match_integrity','finished_missing_team'),
         'finished_without_score':total('04_match_integrity','finished_missing_result'),
         'positive_minutes':total('08_player_membership_match','positive_minute_rows'),
         'unrelated_team_positive_minutes':total('08_player_membership_match','unrelated_team'),
         'active_team_contract_conflicts':members['players_with_conflicting_current_contract_teams'],
         'contracts':total('contracts','spells'),'transfers':stats['event_rows'],
         'transfer_missing_canonical_endpoint':stats['one_resolved']+stats['neither_resolved'],
         'transfer_missing_raw_endpoint':stats['missing_raw_side'],'unique_source_keys_repeated':stats['repeated_any_source_key'],
         'candidate_groups_same_transfer_fact':members['transfer_exact_known_date_endpoints_and_kind_groups'],
         'provider_squad_rows':track['provider_squad_memberships'],
         'provider_squad_rows_without_player_profile':members['provider_squad_entries_without_provider_player_record'],
         'quarantined_links':members['quarantined_provider_links'],'conflict_records':members['unresolved_provider_conflict_records']}
    assert [out[k] for k in ('target_missing','multiple_current','unvalidated_constraints','unrelated_team_positive_minutes')]==[0]*4
    assert (out['candidate_match_groups'],out['transfers'],out['transfer_missing_canonical_endpoint'])==(915,104326,64790)
    return out
if __name__=='__main__':
    print(json.dumps(run(),ensure_ascii=False,indent=2))
