import { pathToFileURL } from "node:url";
import path from "node:path";

const [source, dsn, id, previous] = process.argv.slice(2);
const root = path.join(source, "backend/api/src");
const { createReader } = await import(pathToFileURL(path.join(root, "db.mjs")).href);
const { createHandler } = await import(pathToFileURL(path.join(root, "handler.mjs")).href);
const reader = createReader(dsn, { role: "vega_read" });
const handle = createHandler({ read: reader.read, mediaBase: "https://media.test/" });
const url = "https://api.test/api/standings?competition="+id;
try {
  const initial = await handle(new Request(url));
  const json = await initial.json();
  const body = json.data ?? json;
  const etag = initial.headers.get("etag");
  const again = await handle(new Request(url, {headers: {"If-None-Match": previous || etag}}));
  console.log(JSON.stringify({status: initial.status, etag, conditional_status: again.status,
    fetched_at: body.fetchedAt, first_row: body.tables?.[0]?.rows?.[0], source: body.source}));
} finally {
  await reader.end();
}
