"""Rehearse the reviewed supplemental retirement on a fixture enriched by an independent odds provider."""
from pathlib import Path
import argparse
from importlib.util import module_from_spec, spec_from_file_location
import json
import os
import sys
from uuid import uuid4
import psycopg
from psycopg import sql

from local import PORT, ADMIN

parser = argparse.ArgumentParser()
parser.add_argument('--witness',type=Path,required=True)
args=parser.parse_args()
spec=spec_from_file_location('astro_input_provider_fixture',args.witness)
fixture=module_from_spec(spec)
spec.loader.exec_module(fixture)
db_name='vega_v2_audit_odds_'+uuid4().hex[:12]
opts={'host':'127.0.0.1','port':PORT,'user':'postgres'}
observations={}
with psycopg.connect(dbname='postgres',autocommit=True,**opts) as admin:
    admin.execute(sql.SQL('CREATE DATABASE {}').format(sql.Identifier(db_name)))
    try:
        with fixture.store.connect_local(ADMIN+db_name) as conn:
            fixture.store.migrate(conn)
            with conn.transaction():
                fixture.fixture.build(conn,fixture.store.Store(conn))
            observations['initial_import']=fixture.om_import(conn,fixture.c.T0)
            row=conn.execute("SELECT id, season_id FROM core.matches WHERE source='open_matchday' AND status='not_started' ORDER BY id LIMIT 1").fetchone()
            assert row
            mid,season=row
            conn.execute("""INSERT INTO core.match_odds(season_id,match_id,bookmaker,title,home,draw,away,
                first_home,first_draw,first_away,updated_at,fetched_at) VALUES(%s,%s,'witness_bookie','Provider observation',2.5,3,3.5,2.5,3,3.5,now(),now())""",(season,mid))
            def read():
                return {
                    'match':conn.execute('SELECT id,status FROM core.matches WHERE id=%s',(mid,)).fetchall(),
                    'keys':conn.execute("SELECT provider,provider_key,is_current FROM core.provider_ids WHERE entity_type='match' AND entity_id=%s ORDER BY provider,provider_key",(mid,)).fetchall(),
                    'served_odds':conn.execute('SELECT bookmaker,home,draw,away FROM api.match_odds WHERE season_id=%s AND match_key=%s',(season,mid)).fetchall()
                }
            observations['before']=read()
            assert len(observations['before']['keys'])==len(observations['before']['served_odds'])==1
            for name,days in [('withdraw',1),('repeat',2)]:
                observations[name]=fixture.om_import(conn,fixture.c.T0+days*24*fixture.c.H,fixtures=None)
                observations['after_'+name]=read()
    finally:
        admin.execute(sql.SQL('DROP DATABASE {} WITH (FORCE)').format(sql.Identifier(db_name)))
print(json.dumps(observations,indent=2,default=str,ensure_ascii=False))
