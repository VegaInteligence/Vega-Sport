#!/bin/sh
set -eu
if [ "$#" -ne 1 ]; then
    echo 'Usage: sh tools/replay-all.sh OUTPUT_DIRECTORY' >&2
    exit 2
fi
output="$1"
mkdir -p "$output"
port="${VEGA_TEST_PORT:-5432}"
python="${VEGA_REPLAY_PYTHON:-python3}"
export VEGA_TEST_PORT="$port"
export VEGA_REPLAY_REVISION=after
VEGA_REPLAY_REVISION=before "$python" -B tools/probes-avant.py > "$output/probes-avant.json"
"$python" -B tools/probes-apres.py > "$output/probes-apres.json"
VEGA_REPLAY_REVISION=before "$python" -B tools/dependances.py --witness tools/probes-avant.py > "$output/cotes-avant.json"
"$python" -B tools/dependances.py --witness tools/probes-apres.py > "$output/cotes-apres.json"
"$python" -B tools/fraicheur-http.py > "$output/fraicheur.json"
"$python" -B tools/publication-atomique.py > "$output/publication.json"
"$python" -B tools/saudi-controls.py > "$output/saudi.json"
"$python" -B tools/aliases.py --port "$port" > "$output/alias.json"
"$python" -B tools/guard-restore.py > "$output/restauration.json"
"$python" -B tools/verify.py --replays "$output"
