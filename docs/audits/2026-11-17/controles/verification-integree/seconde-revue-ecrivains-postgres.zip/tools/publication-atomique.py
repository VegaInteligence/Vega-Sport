import json
from pathlib import Path
from threading import Event, Thread
from time import monotonic, sleep
from unittest.mock import patch

from run_support import suite as s
here = Path(__file__).resolve().parent

from sportscore_cases import CASES, START, T0, H, replace, tables
from vega.store import connect_local

case = CASES[0]
scope = "standings:" + case["key"]
out = {}
with s.database() as (a, dsn), connect_local(dsn) as b:
    s.migrate(a)
    with a.transaction():
        s.cases.build(a, s.Store(a))
    with patch.object(s.sportscore, "scopes", lambda _: {scope: s.sportscore.PERIOD}):
        def read():
            return a.execute("""SELECT points,as_of FROM api.standings
                              WHERE competition_season_id=5001 AND team_id=101 AND source='sportscore'""").fetchone()
        def run(db, at, points, received=None):
            def get(url):
                if received:
                    received.set()
                return s.cases.widget(tables((None, replace(START, 0, pts=points))), s.cases.slug_of(url))
            return s.sources.run_due(db, get, at, names={"sportscore"})[("sportscore", scope)]
        def status():
            return a.execute("""SELECT last_attempt_at,last_success_at,status,error_code
                                FROM ops.source_runs WHERE source='sportscore' AND scope=%s""", (scope,)).fetchone()
        a.execute("""CREATE FUNCTION ops.reject_success_test() RETURNS trigger LANGUAGE plpgsql AS $$
             BEGIN IF NEW.status='ok' THEN RAISE EXCEPTION 'controlled status failure' USING ERRCODE='check_violation'; END IF; RETURN NEW; END $$;
             CREATE TRIGGER reject_success_test BEFORE INSERT OR UPDATE ON ops.source_runs
             FOR EACH ROW EXECUTE FUNCTION ops.reject_success_test()""")
        failed = run(a, T0, 8)
        out["failing_status"] = {"outcome": failed, "read": read(), "status": status()}
        assert failed == "DATABASE_ERROR" and read() is None
        assert status() == (T0, None, "error", "DATABASE_ERROR")
        assert a.execute("""SELECT version FROM ops.resource_versions WHERE resource_kind='competition_season'
                         AND resource_id=5001""").fetchone() is None
        a.execute("DROP TRIGGER reject_success_test ON ops.source_runs")
        fetched = Event()
        outcomes = []
        def next_run():
            outcomes.append(run(b, T0 + 3 * H, 9, fetched))
        worker = Thread(target=next_run)
        compare = s.sportscore.compare
        def barrier(conn, *args):
            if conn is a:
                worker.start()
                assert fetched.wait(5)
                deadline = monotonic() + 5
                while monotonic() < deadline:
                    blockers, = a.execute("SELECT pg_blocking_pids(%s)", (b.info.backend_pid,)).fetchone()
                    if a.info.backend_pid in blockers:
                        out["concurrent_fetch"] = True
                        break
                    sleep(.01)
                else:
                    raise AssertionError("newer write did not wait")
            return compare(conn, *args)
        with patch.object(s.sportscore, "compare", barrier):
            assert run(a, T0+H, 8) == "ok"  # transport/database retry interval
            worker.join(10)
        assert not worker.is_alive()
        assert outcomes == ["ok"] and read() == (9, T0+3*H)
        assert status() == (T0+3*H, T0+3*H, "ok", None)
        version, = a.execute("""SELECT version FROM ops.resource_versions WHERE resource_kind='competition_season'
                             AND resource_id=5001""").fetchone()
        assert version == 2
        out["ordered_publications"] = {"read": read(), "status": status(), "version": version}
print(json.dumps(out, default=str, indent=2))
