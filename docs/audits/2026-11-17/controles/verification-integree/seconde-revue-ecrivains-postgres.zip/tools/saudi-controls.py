"""Check the seven reported section pairs without enabling a new SportScore scope."""
import json
from pathlib import Path

from run_support import suite as s
here = Path(__file__).resolve().parent

from vega.sources import SourceError

pairs = [
    ((5315, "Al Shabab"), (5584, "Al Shabab")),
    ((5317, "Al Hilal"), (5334, "Al Hilal")),
    ((5318, "Al Qadsiah"), (5328, "Al Qadsiah")),
    ((5322, "Al Nassr FC"), (5329, "Al Nassr")),
    ((5325, "Al Ittihad"), (5331, "Al Ittihad")),
    ((5309, "Al Ahli SC"), (5327, "Al Ahli")),
    ((5316, "NEOM Sports Club"), (5330, "Neom SC")),
]
results = []
with s.database() as (db, dsn):
    s.migrate(db)
    s.Store(db).season("2026/2027")
    for column, edition, name in ((0, 196, "Saudi Pro League"), (1, 197, "Women's Premier League")):
        gender = s.sportscore._gender(name) or "men"
        db.execute("INSERT INTO core.competitions(id,name) VALUES(%s,%s)", (edition, name))
        db.execute("""INSERT INTO core.competition_seasons(id,competition_id,season_id)
                      VALUES(%s,%s,2026)""", (edition, edition))
        values = dict((display, team) for team, display in (pair[column] for pair in pairs))
        for display, team in values.items():
            db.execute("INSERT INTO core.teams(id,name) VALUES(%s,%s)", (team, display))
            db.execute("INSERT INTO core.team_seasons(team_id,competition_season_id) VALUES(%s,%s)", (team, edition))
        def check(names):
            return s.sportscore.link(db, edition, [(None, [{"name": n} for n in names])], gender)
        assert check(values) == values
        accepted = check({n + (" (W)" if gender == "women" else " Men") for n in values})
        assert set(accepted.values()) == set(values.values())
        invalid = " Men" if gender == "women" else " (W)"
        try:
            check({n + invalid for n in values})
        except SourceError as error:
            assert error.code == "UNMATCHED_TEAMS"
        else:
            raise AssertionError("accepted the other section")
        results.append({"source_edition": edition, "name": name, "canonical": values,
                        "compatible_variant": accepted, "contradictory_variant": "UNMATCHED_TEAMS"})
    assert set(results[0]["canonical"].values()).isdisjoint(results[1]["canonical"].values())
print(json.dumps({"pairs":len(pairs), "editions":results},ensure_ascii=False,indent=2))
