"""Verify file integrity and observations without PostgreSQL, Node or network access."""
from argparse import ArgumentParser
from hashlib import sha256
import json
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
PROOF = ROOT / "proof"


def require(condition, message):
    if not condition:
        raise SystemExit("REFUSÉ · " + message)


def read(directory, name):
    return json.loads((directory / name).read_text(encoding="utf-8"))


def inventory():
    manifest = read(ROOT, "manifest.json")
    files = {p.relative_to(ROOT).as_posix() for p in ROOT.rglob("*") if p.is_file()
             and "node_modules" not in p.parts and "__pycache__" not in p.parts}
    require(files == set(manifest["files"]) | {"manifest.json"}, "inventaire différent")
    for name, expected in manifest["files"].items():
        data = (ROOT / name).read_bytes()
        require(len(data) == expected["bytes"] and sha256(data).hexdigest() == expected["sha256"],
                f"fichier altéré · {name}")
    return manifest, len(files)


def verify_probes(avant, apres):
    require(avant["A_http"]["first_row"]["points"] == 8 and avant["A_http"]["conditional_status"] == 200,
            "le témoin initial doit réellement écraser le classement")
    require(avant["learned_wrong_squad"] == [[101, "Aster City Women", "sportscore"]],
            "l’alias initial attendu n’a pas été appris")
    require(not avant["withdraw_after_key_rotation"][2], "le scénario initial doit perdre les trois clés")
    orphan, = avant["shared_withdraw"][2]
    require(orphan[3] is None, "la clé étrangère du témoin initial doit être orpheline")
    require(apres["A_resumes"][0] == "STALE_OBSERVATION", "un ancien classement est encore accepté")
    require(apres["A_http"]["first_row"]["points"] == 9 and apres["A_http"]["conditional_status"] == 304
            and apres["A_http"]["etag"] == apres["B_http"]["etag"], "le classement ou l’ETag a reculé")
    require(apres["final_sport_run"] == [["2026-11-17 11:00:00+00:00"] * 2], "le statut a reculé")
    require(apres["wrong_squad_first"][0] == "UNMATCHED_TEAMS" and not apres["learned_wrong_squad"],
            "un nom de section incompatible a été appris")
    rotation, rows, keys = apres["withdraw_after_key_rotation"]
    require(rotation["outcome"] == ["ok", [0, 1]], "la rotation n’a pas bloqué le retrait")
    require(len(rows) == 2 and {tuple(key) for key in keys} == {tuple(key) for key in apres["B_keys_precommit"]},
            "le retrait a changé le match ou ses clés")
    outcome, rows, shared = apres["shared_withdraw"]
    binding, = shared
    require(outcome == ["ok", [0, 1]] and len(rows) == 2 and binding[2] == binding[3],
            "le match partagé ou la liaison PitchAPI a disparu")


def verify_odds(avant, apres):
    require(not any(avant["after_withdraw"].values()), "le témoin initial doit perdre les cotes et le match")
    require(apres["withdraw"] == apres["repeat"] == ["ok", [0, 1]], "le retrait du match enrichi n’est pas refusé")
    require(apres["before"] == apres["after_withdraw"] == apres["after_repeat"], "les données tierces ont changé")
    odds, = apres["after_repeat"]["served_odds"]
    require(odds[1:] == [2.5, 3.0, 3.5], "les trois cotes publiques diffèrent")


def verify_http(http):
    cases = {
        "after_superseded": "superseded",
        "after_incompatible_label": "women_in_mens_table",
        "women_table_after_refusal": "men_in_womens_table",
        "women_after_manner": "manner_in_womens_table",
        "after_learned_wfc": "learned_wfc_in_mens_table",
    }
    for response, outcome in cases.items():
        require(http[response]["status"] == 304 and
                http[outcome] == ("STALE_OBSERVATION" if outcome == "superseded" else "UNMATCHED_TEAMS"),
                f"issue HTTP différente · {outcome}")
    require(http["scope_after_superseded"] == ["2026-11-17 11:00:00+00:00"] * 2 + ["ok"],
            "le journal du scope a reculé")
    forms = http["markers_in_mens_edition"]
    require(set(forms) == {"Femenino", "Féminines", "Femminile", "WFC"}
            and all(row == ["UNMATCHED_TEAMS", 304] for row in forms.values()), "un marqueur du témoin est passé")
    require(http["women_with_explicit_marker"] == "ok" and http["women_table"]["status"] == 200,
            "le nom féminin légitime est refusé")
    rows = http["canonical_wfc_table"]["body"]["tables"][0]["rows"]
    require(http["canonical_wfc_in_mens_table"] == "ok" and http["canonical_wfc_table"]["status"] == 200
            and rows[0]["name"] == "Aster City W.F.C." and rows[0]["points"] == 13, "le sigle WFC attesté est refusé")


def verify_other(folder):
    atomique = read(folder, "publication.json")
    require(atomique["failing_status"]["outcome"] == "DATABASE_ERROR" and atomique["failing_status"]["read"] is None,
            "l’échec du journal a laissé un classement")
    require(atomique["concurrent_fetch"] and atomique["ordered_publications"]["read"] == [9, "2026-11-17 11:00:00+00:00"]
            and atomique["ordered_publications"]["version"] == 2, "le verrou a bloqué la collecte ou inversé la publication")
    alias = read(folder, "alias.json")
    require((alias["aliases"], alias["checks"], alias["failures"]) == (838, 872, []), "des graphies admises sont perdues")
    saudi = read(folder, "saudi.json")
    editions = saudi["editions"]
    require(saudi["pairs"] == 7 and len(editions) == 2, "nombre de paires saoudiennes différent")
    require(all(row["contradictory_variant"] == "UNMATCHED_TEAMS" and len(row["canonical"]) == 7
                and set(row["canonical"].values()) == set(row["compatible_variant"].values()) for row in editions)
            and set(editions[0]["canonical"].values()).isdisjoint(editions[1]["canonical"].values()),
            "les deux compétitions ne gardent plus leurs identifiants respectifs")
    guard = read(folder, "restauration.json")
    require(guard["accepted_schema"] and guard["latest"] == "151_snapshot_match_ownership.sql"
            and guard["checksum"] == guard["unknown"] == "destination schema mismatch", "la borne du restaurateur diffère")


parser = ArgumentParser()
parser.add_argument("--replays", type=Path, default=PROOF)
parser.add_argument("--negative", action="store_true", help="submit genuine before observations as the corrected result")
args = parser.parse_args()
manifest, count = inventory()
avant = read(args.replays, "probes-avant.json")
apres = avant if args.negative else read(args.replays, "probes-apres.json")
verify_probes(avant, apres)
verify_odds(*(read(args.replays, f"cotes-{mode}.json") for mode in ("avant", "apres")))
verify_http(read(args.replays, "fraicheur.json"))
verify_other(args.replays)
t2 = read(PROOF, "t2.json")
require(t2["candidate"] == manifest["candidate"] and len(t2["replay_summary"]) == 28
        and all(not r["errors"] and r["actual"] == r["expected"] for r in t2["replay_summary"]),
        "les 28 observations T2 ne sont pas valides")
ci = read(PROOF, "ci.json")
require(ci["commit"] == manifest["candidate"] and ci["clean_and_unchanged"]
        and (ci["python"], ci["api"], ci["site"]) == (588, 215, 768), "le reçu de CI ne correspond pas")
print(f"VÉRIFIÉ · {count} fichiers. Fraîcheur, clés, données tierces, sections, migration 151 et témoins de régression.")
