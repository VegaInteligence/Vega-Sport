import json
from pathlib import Path
from unittest.mock import patch

from run_support import suite as s
here = Path(__file__).resolve().parent

from sportscore_cases import CASES, START, T0, H, replace, tables
from vega.store import connect_local
from vega.sources import SourceError

case = CASES[0]
scope = "standings:" + case["key"]
records = {}

with s.database() as (a, dsn), connect_local(dsn) as b:
    s.migrate(a)
    with a.transaction():
        s.cases.build(a, s.Store(a))
    with s.api(dsn, here, "fraicheur") as public, patch.object(s.sportscore, "scopes", lambda _: {scope: s.sportscore.PERIOD}):
        def run(db, at, payload):
            def get(url):
                rows = payload() if callable(payload) else payload
                return s.cases.widget(tables((None, rows)), s.cases.slug_of(url))
            db.execute("SET ROLE vega_collect")
            try:
                return s.sources.run_due(db, get, at, names={"sportscore"})[("sportscore", scope)]
            finally:
                db.execute("RESET ROLE")

        def run_state():
            attempt = a.execute("""SELECT last_attempt_at,last_success_at,status FROM ops.source_runs
                                    WHERE source='sportscore' AND scope=%s""", (scope,)).fetchone()
            return [str(attempt[0]), str(attempt[1]), attempt[2]]

        def recent_then_old():
            records["published_outcome"] = run(b, T0 + 3 * H, replace(START, 0, pts=9))
            records["published_http"] = public(case["key"])
            return START

        records["superseded"] = run(a, T0, recent_then_old)
        records["after_superseded"] = public(case["key"], etag=records["published_http"]["etag"])
        records["scope_after_superseded"] = run_state()
        assert (records["published_outcome"], records["published_http"]["status"], records["superseded"],
                records["after_superseded"]["status"]) == ("ok", 200, "STALE_OBSERVATION", 304)
        assert records["scope_after_superseded"] == [str(T0 + 3 * H)] * 2 + ["ok"]

        a.execute("""INSERT INTO core.entity_names(entity_type,entity_id,name,normalized,kind,source)
                     VALUES ('team',101,'Aster City Women','astercitywomen','source_spelling','sportscore')""")
        records["women_in_mens_table"] = run(a, T0 + 6 * H, replace(START, 0, team="Aster City Women", pts=10))
        records["after_incompatible_label"] = public(case["key"], etag=records["published_http"]["etag"])
        assert (records["women_in_mens_table"], records["after_incompatible_label"]["status"]) == ("UNMATCHED_TEAMS", 304)

        markers = {}
        for hours, label in ((9, "Femenino"), (12, "Féminines"), (15, "Femminile"), (18, "WFC")):
            code = run(a, T0+hours*H, replace(START, 0, team="Aster City " + label, pts=10))
            current = public(case["key"], etag=records["published_http"]["etag"])
            markers[label] = (code, current["status"])
        records["markers_in_mens_edition"] = markers
        assert set(markers.values()) == {("UNMATCHED_TEAMS", 304)}, markers

        # The same name is legitimate inside a proven women's edition, and canonical
        # roster names can omit the qualifier.
        a.execute("UPDATE core.competitions SET name='Women’s Premier League' WHERE id=401")
        records["women_with_explicit_marker"] = run(a, T0 + 21 * H, replace(START, 0, team="Aster City Women", pts=10))
        records["women_table"] = public(case["key"], etag=records["published_http"]["etag"])
        records["men_in_womens_table"] = run(a, T0 + 24 * H, replace(START, 0, team="Aster City Men", pts=11))
        records["women_table_after_refusal"] = public(case["key"], etag=records["women_table"]["etag"])
        assert (records["women_with_explicit_marker"], records["women_table"]["status"], records["men_in_womens_table"],
                records["women_table_after_refusal"]["status"]) == ("ok", 200, "UNMATCHED_TEAMS", 304)
        assert records["women_table"]["etag"] != records["published_http"]["etag"]
        records["manner_in_womens_table"] = run(a, T0+27*H, replace(START, 0, team="Aster City Männer", pts=12))
        records["women_after_manner"] = public(case["key"], etag=records["women_table"]["etag"])
        assert (records["manner_in_womens_table"], records["women_after_manner"]["status"]) == ("UNMATCHED_TEAMS", 304)

        a.execute("UPDATE core.competitions SET name='Ligue 2' WHERE id=401")
        a.execute("""INSERT INTO core.entity_names(entity_type,entity_id,name,normalized,kind,source)
                     VALUES ('team',101,'Aster City WFC','astercitywfc','source_spelling','sportscore')""")
        # Changing the competition name changes the representation independently of
        # ingestion. Capture the ETag after setting up the new edition context.
        records["mens_table_before_learned_wfc"] = public(case["key"])
        records["learned_wfc_in_mens_table"] = run(a, T0+30*H, replace(START, 0, team="Aster City WFC", pts=12))
        records["after_learned_wfc"] = public(case["key"], etag=records["mens_table_before_learned_wfc"]["etag"])
        assert (records["learned_wfc_in_mens_table"], records["after_learned_wfc"]["status"]) == ("UNMATCHED_TEAMS", 304), records["after_learned_wfc"]
        a.execute("UPDATE core.teams SET name='Aster City W.F.C.' WHERE id=101")
        records["canonical_wfc_in_mens_table"] = run(a, T0+33*H, replace(START, 0, team="Aster City WFC", pts=13))
        records["canonical_wfc_table"] = public(case["key"])
        assert records["canonical_wfc_in_mens_table"] == "ok" and records["canonical_wfc_table"]["status"] == 200
        assert "Aster City W.F.C." in json.dumps(records["canonical_wfc_table"]["body"])

print(json.dumps(records, indent=2, ensure_ascii=False))
