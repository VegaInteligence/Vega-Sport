"""Shared local fixtures and real HTTP read API for the portable evidence scripts."""
from contextlib import contextmanager
import json
import subprocess
from types import SimpleNamespace
from urllib.error import HTTPError
from urllib.request import ProxyHandler, Request, build_opener

from local import ROOT, code, database

code()

from vega import sources
from vega.sources import sportscore
from vega.store import Store, migrate
import sportscore_replay as cases

opener = build_opener(ProxyHandler({}))


@contextmanager
def api(dsn, _unused_directory, _unused_name):
    script = ROOT / "tools/serve.mjs"
    proc = subprocess.Popen(["node", str(script), dsn], stdout=subprocess.PIPE, stderr=subprocess.PIPE, text=True)
    try:
        port_text = proc.stdout.readline().strip()
        if not port_text:
            raise RuntimeError("HTTP server did not start: " + proc.stderr.read())
        port = int(port_text)

        def read(key, etag=None):
            req = Request(f"http://127.0.0.1:{port}/api/standings?competition={key}",
                          headers={"If-None-Match": etag} if etag else {})
            try:
                response = opener.open(req, timeout=30)
            except HTTPError as error:
                response = error
            with response:
                body = response.read()
                return {"status": response.status, "etag": response.headers.get("etag"),
                        "body": json.loads(body) if body else None}

        yield read
    finally:
        proc.terminate()
        proc.wait(timeout=15)


suite = SimpleNamespace(database=database, api=api, Store=Store, migrate=migrate,
                        sources=sources, sportscore=sportscore, cases=cases)
