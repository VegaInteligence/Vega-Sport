"""Independent PostgreSQL 18 adversaries. Run from the frozen repository via run.sh."""
import csv
import io
import json
import os
import pathlib
import subprocess
import sys
import threading
import time
import uuid
from datetime import timedelta
from unittest.mock import patch

import psycopg
from psycopg import sql

from local import ROOT as root, PORT, code
code()
from vega import sources, store
from vega.sources import open_matchday as om, sportscore as sport
from vega.sources import snapshot
import sportscore_cases as c
import sportscore_replay as fixture
from test_source_snapshots import FIXTURES, RESULTS, ROUND_RESULTS, FOLDER, league
from vega import power

def plain(data):
    return json.loads(json.dumps(data, default=str))

def standings(db):
    return db.execute("""SELECT s.team_name,s.position,s.played,s.points,s.source,s.as_of,r.version
        FROM api.standings s JOIN ops.resource_versions r ON r.resource_id=s.competition_season_id
        AND r.resource_kind='competition_season' WHERE s.competition_season_id=5001 ORDER BY s.position""").fetchall()

def public_standings(dsn, prior=""):
    js = pathlib.Path(__file__).with_name('http.mjs')
    return json.loads(subprocess.check_output(['node', str(js), str(root), dsn, c.CASES[0]['key'], prior], text=True))

def sparse(db):
    return db.execute("""SELECT m.id,r.name,m.status,m.home_score,m.away_score,m.revision,
        (SELECT count(*) FROM core.provider_ids p WHERE p.entity_type='match' AND p.entity_id=m.id)
        FROM core.matches m LEFT JOIN core.rounds r ON m.round_id=r.id
        WHERE m.source='open_matchday' ORDER BY m.id""").fetchall()

def sport_import(db, rows, at):
    scope = 'standings:' + c.CASES[0]['key']
    def get(url):
        return fixture.widget(c.tables((None, rows)), fixture.slug_of(url))
    with patch.object(sport, 'scopes', lambda now:{scope:sport.PERIOD}):
        return sources.run_due(db, get, at, names={'sportscore'})[('sportscore',scope)]

def om_import(db, at, results=ROUND_RESULTS, fixtures=FIXTURES):
    def get(url, **kw):
        if url.endswith('build_summary.json'):
            return dict(season='2627',generated_utc='2026-11-17T07:19:26Z',leagues=[league(
                results=len(list(csv.DictReader(io.StringIO(results)))),fixtures=len(list(csv.DictReader(io.StringIO(fixtures or '')))))])
        return results if '/results_' in url else fixtures
    code=sources.run_due(db,get,at,names={'open_matchday'}).get(('open_matchday','europe'))
    return code, db.execute("SELECT rows_written,unmatched FROM ops.source_runs WHERE source='open_matchday'").fetchone()

def reset_sport(db):
    db.execute("DELETE FROM core.standings_official WHERE competition_season_id=5001 AND source='sportscore'")
    db.execute("DELETE FROM ops.source_runs WHERE source='sportscore' AND scope=%s",('standings:'+c.CASES[0]['key'],))

def main():
    params = dict(host='127.0.0.1', port=PORT,user='postgres')
    name = 'vega_v2_astra_14068_'+uuid.uuid4().hex[:12]
    dsn = f'postgresql://postgres@127.0.0.1:{PORT}/'+name
    admin=psycopg.connect(dbname='postgres',autocommit=True,**params)
    admin.execute(sql.SQL('CREATE DATABASE {}').format(sql.Identifier(name)))
    ev={}
    try:
        with store.connect_local(dsn) as a,store.connect_local(dsn) as b:
            store.migrate(a)
            store.migrate(a)
            ev['migration']=a.execute("""SELECT version,encode(checksum,'hex') FROM ops.schema_migrations
                  WHERE version ~ '^(134|135|150)_' ORDER BY 1""").fetchall()
            with a.transaction(): fixture.build(a,store.Store(a))
            # Two valid views. Later official correction of 8 to 9 points; all football facts equal.
            latest=[{**row, 'pts':9} if idx==0 else dict(row) for idx,row in enumerate(c.START)]
            qualify=sport.qualify
            def yielded(conn,*args):
                proof=qualify(conn,*args)
                if conn is a:
                    ev['B_commits']=sport_import(b, latest, c.T0+3*c.H),standings(b)
                    ev['B_http']=public_standings(dsn)
                return proof
            with patch.object(sport,'qualify',yielded):
                ev['A_resumes']=sport_import(a,c.START,c.T0),standings(a)
            ev['A_http']=public_standings(dsn,ev['B_http']['etag'])
            ev['final_sport_run']=a.execute("SELECT last_attempt_at,last_success_at FROM ops.source_runs WHERE source='sportscore'").fetchall()
            reset_sport(a)
            variants=[({**row,'team':'Aster City Women'} if i==0 else row) for i,row in enumerate(c.START)]
            ev['wrong_squad_first']=sport_import(a,variants,c.T0+6*c.H),standings(a)
            ev['wrong_squad_http']=public_standings(dsn)
            ev['learned_wrong_squad']=a.execute("SELECT entity_id,name,source FROM core.entity_names WHERE name='Aster City Women'").fetchall()
            ev['impossible']=sport_import(a,[{**row,'w':17} if i==0 else row for i,row in enumerate(variants)],c.T0+9*c.H),standings(a)
            ev['impossible_http']=public_standings(dsn,ev['wrong_squad_http']['etag'])
            # Ordinary CSV, same match without its previously reported round, data and historical keys.
            ev['om_initial']=om_import(a,c.T0),sparse(a)
            first,second=sparse(a)
            a.execute("INSERT INTO core.provider_ids(entity_type,provider,provider_key,entity_id,is_current) VALUES('match','open_matchday','old:key',%s,false)",(second[0],))
            ev['om_blank']=om_import(a,c.T0+24*c.H,results=RESULTS),sparse(a)
            # B changes the current key of the fixture while A is already waiting on its parent row.
            # Hook only obtains a wait point; no application SQL or result is replaced.
            reached=threading.Event()
            results={}
            remove=snapshot.remove
            def proceeding(conn,*args):
                if conn is a: reached.set()
                return remove(conn,*args)
            def worker():
                try: results['outcome']=om_import(a,c.T0+48*c.H,results=RESULTS,fixtures=None)
                except Exception as e: results['error']=repr(e)
            with patch.object(snapshot,'remove',proceeding):
                with b.transaction():
                    b.execute('SELECT id FROM core.matches WHERE id=%s FOR UPDATE',(second[0],))
                    b.execute("UPDATE core.provider_ids SET is_current=false WHERE entity_type='match' AND provider='open_matchday' AND entity_id=%s AND is_current",(second[0],))
                    b.execute("INSERT INTO core.provider_ids(entity_type,provider,provider_key,entity_id) VALUES('match','open_matchday','next:key',%s)",(second[0],))
                    t=threading.Thread(target=worker);t.start()
                    assert reached.wait(8)
                    for _ in range(70):
                        wait=admin.execute("SELECT wait_event_type,wait_event FROM pg_stat_activity WHERE pid=%s",(a.info.backend_pid,)).fetchone()
                        if wait and wait[0]=='Lock':break
                        time.sleep(.05)
                    ev['A_blocked_on_pg']=wait
                    assert wait and wait[0]=='Lock'
                    ev['B_keys_precommit']=b.execute("SELECT provider_key,is_current FROM core.provider_ids WHERE entity_type='match' AND provider='open_matchday' AND entity_id=%s ORDER BY 1",(second[0],)).fetchall()
                t.join(30)
                assert not t.is_alive()
            ev['withdraw_after_key_rotation']=results,sparse(a),a.execute("SELECT provider_key,is_current FROM core.provider_ids WHERE entity_type='match' AND entity_id=%s",(second[0],)).fetchall()
            # Different adverse case. An accepted observation whose two producers share the same canonical match.
            ev['reset_fixture']=om_import(a,c.T0+72*c.H)
            mid=sparse(a)[-1][0]
            a.execute("INSERT INTO core.provider_ids(entity_type,provider,provider_key,entity_id) VALUES('match','pitchapi','independently_attested_match',%s)",(mid,))
            ev['shared_withdraw']=om_import(a,c.T0+96*c.H,fixtures=None),sparse(a),a.execute("""SELECT p.provider,p.provider_key,p.entity_id,m.id FROM core.provider_ids p LEFT JOIN core.matches m ON m.id=p.entity_id WHERE p.provider_key='independently_attested_match'""").fetchall()
            # Administrative control on the fixed path, independent of artificial fixture identity changes.
            ev['server']=a.execute('SELECT version()').fetchone()[0]
    finally:
        admin.execute(sql.SQL('DROP DATABASE {} WITH (FORCE)').format(sql.Identifier(name)))
        admin.close()
    print(json.dumps(plain(ev),indent=2,ensure_ascii=False))
if __name__=='__main__':main()

