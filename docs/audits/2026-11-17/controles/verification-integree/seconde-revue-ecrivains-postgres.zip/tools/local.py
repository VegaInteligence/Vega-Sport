"""Connect only to the local disposable PostgreSQL instance. Select the exact replay source."""
from contextlib import contextmanager
import importlib.abc
import importlib.util
import os
from pathlib import Path
import sys
from uuid import uuid4

import psycopg
from psycopg import sql

ROOT = Path(__file__).resolve().parents[1]
PORT = int(os.environ.get("VEGA_TEST_PORT", "5432"))
BEFORE = os.environ.get("VEGA_REPLAY_REVISION", "after") == "before"
BASE = ROOT / "baselines/original/backend"
ADMIN = f"postgresql://postgres@127.0.0.1:{PORT}/"


class EarlierWriters(importlib.abc.MetaPathFinder):
    def find_spec(self, fullname, path=None, target=None):
        relative = fullname.split(".")
        if relative[0] != "vega":
            return None
        module = (BASE / Path(*relative)).with_suffix(".py")
        if fullname == "vega.sources":
            return importlib.util.spec_from_file_location(
                fullname, BASE / "vega/sources/__init__.py",
                submodule_search_locations=[str(ROOT / "backend/vega/sources")],
            )
        if module.is_file():
            return importlib.util.spec_from_file_location(fullname, module)
        return None


def code():
    if str(ROOT / "backend") not in sys.path:
        sys.path[:0] = [str(ROOT / "backend"), str(ROOT / "backend/tests")]
        if BEFORE:
            sys.meta_path.insert(0, EarlierWriters())


@contextmanager
def database(port=PORT):
    from vega.store import connect_local
    admin = f"postgresql://postgres@127.0.0.1:{port}/"
    name = "vega_v2_writers_" + uuid4().hex
    with psycopg.connect(admin + "postgres", autocommit=True) as ctl:
        if ctl.info.server_version // 10000 != 18:
            raise RuntimeError("PostgreSQL 18 on the loopback interface is required")
        ctl.execute(sql.SQL("CREATE DATABASE {}").format(sql.Identifier(name)))
        try:
            with connect_local(admin + name) as db:
                yield db, admin + name
        finally:
            ctl.execute(sql.SQL("DROP DATABASE {} WITH (FORCE)").format(sql.Identifier(name)))
