import json
from pathlib import Path
import sys
from uuid import uuid4

import psycopg
from psycopg import sql

from local import ADMIN as admin, code
code()
from vega import open_matchday_restore, store

name = "vega_v2_open_matchday_restore_" + uuid4().hex
with psycopg.connect(admin + "postgres", autocommit=True) as ctl:
    ctl.execute(sql.SQL("CREATE DATABASE {}").format(sql.Identifier(name)))
    try:
        with store.connect_local(admin + name) as db:
            store.migrate(db)
            old = db.execute("SELECT version,encode(checksum,'hex'),NULL FROM ops.schema_migrations "
                             "WHERE version <= '133_cohort_max_wait.sql' ORDER BY 1").fetchall()
            first = {"reads": {"migrations": {"ok": True, "rows": old}}}
            receipt = {
                "accepted_schema": open_matchday_restore.guard_schema(db, first, first) is None,
                "latest": db.execute("SELECT max(version) FROM ops.schema_migrations").fetchone()[0],
            }
            for mode, statement, expected in (
                ("checksum", "UPDATE ops.schema_migrations SET checksum=decode(repeat('00',32),'hex') "
                 "WHERE version='133_cohort_max_wait.sql'", "destination schema mismatch"),
                ("unknown", "INSERT INTO ops.schema_migrations(version,checksum) VALUES "
                 "('152_unknown.sql',decode(repeat('00',32),'hex'))", "destination schema mismatch"),
            ):
                with db.transaction(force_rollback=True):
                    db.execute(statement)
                    try:
                        open_matchday_restore.guard_schema(db, first, first)
                    except open_matchday_restore.Refusal as error:
                        assert str(error) == expected, str(error)
                        receipt[mode] = str(error)
                    else:
                        raise AssertionError("unexpectedly accepted " + mode)
            print(json.dumps(receipt, indent=2))
    finally:
        ctl.execute(sql.SQL("DROP DATABASE {} WITH (FORCE)").format(sql.Identifier(name)))
