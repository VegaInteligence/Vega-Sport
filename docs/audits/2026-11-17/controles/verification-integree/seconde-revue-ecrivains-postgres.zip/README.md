# Seconde revue des écritures Vega-Sport

La capsule fige les observations PostgreSQL 18 avant le correctif `14068dfc943cddb3b31f8250e120e00c0fb8c7db` et après `51acd93a52ca41a59bc9e1663c67ba3fa3b858f2`. Elle inclut le code, les migrations, les données contrôlées, les commandes de rejeu et les reçus. [Attendus](ATTENDUS.md) · [Manifeste et versions](manifest.json)

- **Fraîcheur SportScore.** L’observation de 8 h terminée après celle de 11 h laisse en place le classement à 9 points, le journal et l’ETag. Le widget récent peut être chargé pendant que l’autre transaction publie. La publication est annulée si l’écriture du statut échoue. [Avant](proof/probes-avant.json) · [Après](proof/probes-apres.json) · [Publication atomique](proof/publication.json)
- **Propriété des matchs.** Le retrait concurrent à une rotation de clé conserve les trois clés. Une fixture partagée garde aussi son parent et sa liaison PitchAPI. Les tests du dépôt couvrent la correction et le déplacement d’ordre, l’alias historique ajouté tardivement, la tentative d’attacher une nouvelle clé derrière un retrait et le retrait autorisé. [Suite des snapshots](proof/green-snapshots-final.log)
- **Données dépendantes.** Une fixture avec une seule clé garde son match, sa clé et ses prix 2,5 / 3 / 3,5. La suite couvre les événements et des colonnes et périodes statistiques étrangères au flux. Les dépendances relevées sans clé étrangère sont examinées au contrôle, et les insertions tardives dotées d’une clé étrangère sont coordonnées par le verrou du parent. [Cotes avant](proof/cotes-avant.json) · [Cotes après](proof/cotes-apres.json)
- **Sections SportScore.** Les variantes incompatibles sont refusées, même déjà apprises. Les variantes féminines admissibles et WFC avec une graphie canonique restent utilisables. La preuve HTTP prend l’ETag témoin après chaque changement de contexte effectué comme montage du test. Les sept paires de clubs saoudiens gardent leurs 14 identifiants. Les 838 graphies existantes passent 872 contrôles d’édition. [HTTP](proof/fraicheur.json) · [Sept paires](proof/saudi.json) · [Graphies](proof/alias.json)
- **Compatibilité.** L’opérateur accepte la migration 151 et refuse un checksum altéré ou une migration inconnue. Le reçu séparé conserve les 28 observations T2 et la CI du candidat. [Borne de restauration](proof/restauration.json) · [T2](proof/t2.json) · [CI](proof/ci.json)

Les cas sont des réponses contrôlées et des noms issus des captures d’identité. Les nombres T2 et CI sont des résultats archivés. Les commandes de cette capsule rejouent les contre-exemples de la seconde revue. Les autres importateurs et les associations hors SportScore restent dans leurs périmètres respectifs.

## Vérifier les preuves enregistrées

Python 3.14 suffit. Le vérificateur ne se connecte ni à PostgreSQL ni au réseau.

```sh
python3 -B tools/verify.py
python3 -B tools/verify.py --negative
```

La seconde commande substitue le véritable témoin antérieur à la sortie corrigée. Le contrôle doit échouer avec « un ancien classement est encore accepté ».

## Rejouer en local

- Préparer Python 3.14.6 et `psycopg[binary]==3.3.9` depuis un cache ou des roues locales.
- Préparer PostgreSQL **18** jetable sur la boucle locale. Le rôle de test `postgres` doit pouvoir migrer et créer des bases. Chaque script nettoie sa base à nom aléatoire.
- Préparer Node 26.4.0 et le cache npm du lecteur. Le [verrou des dépendances](backend/api/package-lock.json) fixe notamment `pg` à 8.23.1.

Depuis le dossier extrait, remplacer 5432 par le port de l’instance jetable. Le serveur PostgreSQL et le lecteur HTTP local suffisent.

```sh
npm ci --offline --prefix backend/api
observed="$(mktemp -d)"
VEGA_TEST_PORT=5432 sh tools/replay-all.sh "$observed"
```

Dans le témoin original, A s’arrête après sa comparaison SportScore, puis B publie. Dans le témoin corrigé, A s’arrête à la sortie de sa qualification, avant le verrou de publication, pour laisser B finir sans attendre un verrou détenu par A. Le scénario PostgreSQL de rotation de clé garde la barrière originale.
