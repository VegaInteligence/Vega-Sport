# Attendus du lot après revue de 14068dfc

Les contre-exemples d’origine se trouvent dans les pièces de la revue indépendante. Les tests utilisent PostgreSQL 18, les transactions READ COMMITTED et le point d’entrée normal du worker. Une barrière ne remplace aucune instruction SQL. Le classement est relu dans la vue et via l’API HTTP.

| Situation | Résultat attendu |
| --- | --- |
| A charge une réponse SportScore à 08:00 et B publie d’abord 9 points à 11:00, sur une édition jusque-là sans publication. A reprend avec 8 points. | Le classement, son horodatage, sa version, l’ETag et le statut durable de B restent en place. Un échec plus ancien ne remplace ni le dernier essai ni le dernier succès. Une correction plus récente et valide est acceptée après un échec, avec les délais de reprise existants. Le widget peut être chargé avant le verrou de publication. |
| Deux réponses SportScore valides arrivent dans l’autre ordre, ou portent le même instant. | Conserver la progression dans l’ordre des observations. À égalité, la première observation publiée reste valide. Le verrou reste local à la compétition et les requêtes réseau ordinaires peuvent se chevaucher. |
| SportScore reçoit une graphie féminine dans une édition masculine ou une graphie explicitement masculine dans une édition féminine. Une graphie contradictoire a parfois déjà été apprise. | Le refus laisse classement, ETag et noms en place. Dans une édition féminine établie, un club inscrit sous un nom sans marqueur et une variante féminine concordante sont admis. Les sept identités saoudiennes sont des données de contrôle, sans ouverture d’un nouveau flux. |
| Pendant que A retire, corrige ou réordonne un match, B tourne sa clé courante sous verrou sur le parent. | A relit les clés une fois le verrou acquis. L’ancien instantané ne change ni le match, ni ses clés, ni ses dépendances. |
| Une fixture porte des clés Open Matchday et PitchAPI, et disparaît du CSV. | Le résultat de la décision est un refus explicite pour identité partagée. La rencontre, tous les identifiants et les lignes dépendantes sont conservés. Un retrait légitime, sans autre producteur, supprime les clés courantes et historiques de ce producteur. |
| B tente d’attacher une clé de match pendant qu’A détient le verrou du parent qu’elle retire. | L’insertion attend le parent. Si le retrait s’achève, la nouvelle clé est refusée et ne reste pas orpheline. Les insertions normales après création du parent demeurent valides. |

Le contrôle des retraits donne aussi une fixture dotée d'une seule clé et de cotes ou d’un but sans joueur. La présence d’une dépendance indépendante bloque la suppression de la rencontre et de ses lignes. Les statistiques que le flux Open Matchday écrit lui-même restent soumises au retrait ordinaire.

L’opérateur de restauration doit accepter le schéma revu avec la migration 151 appliquée par le migrateur normal. Un checksum modifié, une version appliquée inconnue ou une capture de provenance étrangère doivent encore être refusés.

Retrait avec stat complémentaire. Une possession déjà publiée ou un tir à la mi-temps ne relève pas des données Open Matchday. Ces valeurs doivent retenir le match. L’attente sur une modification d’une ligne de statistique ne doit pas permettre d’effacer ses nouvelles colonnes. Une fixture enrichie seulement de tirs du match entier par le fournisseur demeure retirable.

Un alias du même fournisseur peut aussi être ajouté pendant le retrait sans que la clé courante ne bouge. Le retrait ne doit pas effacer cette nouvelle attestation inattendue. La comparaison porte sur l’ensemble de clés observé pour ce match.

Contrôles de publication supplémentaires. Une erreur SQL lors de l’écriture du statut de succès doit annuler le classement et sa version, puis laisser le scope en attente de reprise. Pendant qu’A détient le verrou de publication, un B plus récent peut déjà charger son widget mais doit attendre A avant de décider et committer son propre classement.

Variantes linguistiques. « Féminines » (français, accent et pluriel) et « Femenino » (espagnol) doivent chacun être refusés dans le championnat masculin. Le refus HTTP rend 304 pour le dernier ETag. Le marqueur n’interdit pas un bon nom dans l’édition féminine correspondante.
Les marqueurs « Femminile » et « Männer » qualifient également des équipes dans les scénarios de revue. Le sigle WFC dans une graphie non attestée ne suffit pas à l’attribuer à une équipe masculine. Une graphie canonique contenant WFC reste recevable, y compris dans un championnat masculin.
