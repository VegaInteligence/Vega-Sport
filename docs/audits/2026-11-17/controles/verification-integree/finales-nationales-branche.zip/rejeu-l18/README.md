# Rejouer les deux finales L18

Le paquet contient les deux fichiers OpenFootball d’archive, le relevé de production de 15 h 47, la projection des équipes et rencontres du témoin RDS, les scripts de lecture et le résultat de référence. `SHA256SUMS` fixe leurs empreintes. Le verdict concerne France 1998 et Italie 1982.

Prérequis

- Checkout Vega‑Sport propre au commit `d29eac65d75ca4eb038a2fc5b24e1bb93d1ae2ab`, avec les dépendances Python du backend et Node de `backend/api` installées.
- PostgreSQL 18 jetable sur `127.0.0.1` avec propriétaire local `postgres` capable de créer une base de contrôle.

```sh
shasum -a 256 -c SHA256SUMS
PYTHONDONTWRITEBYTECODE=1 python3 -B replay.py "/chemin/vers/Vega-Sport" upstream replay01 55439
```

`replay01.json` contient les réponses avant et après ingestion et répétition, les ETags, les lignes physiques et les contrôles de doublons natifs. Choisir un suffixe encore inutilisé. Le trajet utilise les données et les fonctions ordinaires de Vega sur la base jetable. Le fichier `population-readonly.sql` reproduit la sélection SQL des copies pour une mesure séparée.

Le relevé RDS de référence couvre le canal OpenFootball. La présence d’un doublon natif en production est hors du périmètre de ce paquet. Les doublons natifs de contrôle sont créés uniquement sur la base locale à partir des paires et dates attestées des deux finales. Le résultat de référence enregistre aussi leur effet lorsqu’on enlève volontairement leurs scores.

