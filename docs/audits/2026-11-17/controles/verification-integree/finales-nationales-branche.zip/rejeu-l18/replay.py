"""Verify two archived World Cup winners through ingestion and the read API."""
from collections import Counter
from datetime import datetime, timedelta, timezone
from hashlib import sha256
import json
import os
from pathlib import Path
import re
import subprocess
import sys
from urllib.error import HTTPError
from urllib.parse import urlencode
from urllib.request import Request, urlopen
from unittest.mock import patch

import psycopg
from psycopg import sql


out = Path(__file__).resolve().parent
repo, raw = map(lambda x: Path(x).resolve(), sys.argv[1:3])
tag = sys.argv[3]
port = int(sys.argv[4]) if len(sys.argv) > 4 else 55439
assert re.fullmatch(r"[a-z0-9]{2,18}", tag) and 1 <= port <= 65535
projection = out / "rds-target-projection.json"
prod = out.parent / "nations-1547.json"
if not prod.exists():
    prod = out / "nations-1547.json"
source = json.loads(projection.read_bytes())
published = json.loads(prod.read_bytes())
years = ("1982", "1998")
expect = {
    "1982": {"id": "t_v0001032", "team": "Italie", "final_id": 836, "score": (3, 1), "date": "1982-07-11", "pair": (1032, 1130)},
    "1998": {"id": "t_2ysHaw", "team": "France", "final_id": 1056, "score": (0, 3), "date": "1998-07-12", "pair": (5496, 5490)},
}
input_files = {year: raw / f"world-cup-history-{year}.json" for year in years}
input_bodies = {f"world-cup-history:{year}": json.loads(p.read_bytes()) for year, p in input_files.items()}
archive_input = out / "openfootball-two-editions.json"
archive_input.write_text(json.dumps({"editions": input_bodies}, ensure_ascii=False, separators=(",", ":")) + "\n")
candidate = subprocess.check_output(["git", "-C", str(repo), "rev-parse", "HEAD"], text=True).strip()
assert candidate == "d29eac65d75ca4eb038a2fc5b24e1bb93d1ae2ab"
sys.path.insert(0, str(repo / "backend"))
from vega import sources
from vega.sources import cups
from vega.store import migrate

base = f"postgresql://postgres@127.0.0.1:{port}/"
db_name = f"vega_v2_nations_l18_{tag}"
dsn = base + db_name
with psycopg.connect(base + "postgres", autocommit=True) as admin:
    assert admin.info.server_version // 10000 == 18
    admin.execute(sql.SQL("CREATE DATABASE {}").format(sql.Identifier(db_name)))
db = psycopg.connect(dsn, autocommit=True)
migrate(db)
x = db.execute
fixtures = {
    year: {(r["match_date"], r["home_team_name"], r["away_team_name"]): r for r in source["matches"] if r["cup_key"].endswith(year)}
    for year in years
}
assert tuple(map(len, fixtures.values())) == (52, 64)
for t in source["teams"]:
    x("INSERT INTO core.teams(id,name,country_code,is_national) VALUES (%(id)s,%(name)s,%(country_code)s,%(is_national)s)", t)
for t in source["teams"]:
    if t["merged_into"] in {row["id"] for row in source["teams"]}:
        x("UPDATE core.teams SET merged_into=%(merged_into)s WHERE id=%(id)s", t)
for p in source["team_bindings"]:
    x("""INSERT INTO core.provider_ids(entity_type,provider,provider_key,entity_id,is_current)
         VALUES ('team',%(provider)s,%(key)s,%(id)s,%(current)s)""", p)
x("INSERT INTO core.seasons(id,label) VALUES (2026,'2026/2027') ON CONFLICT DO NOTHING")
scopes = {f"open-cups:world-cup-history:{y}": timedelta(seconds=1) for y in years}
bindings = {(r["provider"], r["key"]): r["id"] for r in source["team_bindings"]}

def seed_historical():
    """Store the observed RDS match/week/score columns with source round and provider keys."""
    x("INSERT INTO core.competitions(id,name,kind) VALUES (64,'World Cup','international')")
    x("""INSERT INTO core.provider_ids(entity_type,provider,provider_key,entity_id)
         VALUES ('competition','vega','cup:open-cups:world-cup-history',64)""")
    for year in years:
        projected = cups.bridge("projection", "open-cups", urlencode({"competition": "world-cup-history", "season": year}))
        assert projected["status"] == 200
        typed = cups.match_rows("open-cups", "world-cup-history", year, projected["body"])
        expected_rows = fixtures[year]
        assert len(typed) == len(expected_rows)
        encoded = {k: row for k, row in typed}
        assert len(encoded) == len(typed)
        one = next(iter(expected_rows.values()))
        sid, eid = one["season_id"], one["edition"]
        x("INSERT INTO core.seasons(id,label) VALUES (%s,%s) ON CONFLICT DO NOTHING", (sid, f"{sid}/{sid+1}"))
        x("""INSERT INTO core.competition_seasons(id,competition_id,season_id,native_label,cup_key,cup_name,cup_updated_at)
             VALUES (%s,64,%s,%s,%s,%s,'2026-11-18T00:00:00Z')""",
          (eid, sid, year, one["cup_key"], projected["body"]["name"]))
        for key, row in typed:
            recorded = expected_rows[row["date"], row["home"], row["away"]]
            assert bindings["openfootball", row["home_key"]] == recorded["home_team_id"], (year, row["home"])
            assert bindings["openfootball", row["away_key"]] == recorded["away_team_id"], (year, row["away"])
            rid = cups._round(db, eid, row["round"]) if row["round"] else None
            x("""INSERT INTO core.matches(id,competition_season_id,season_id,match_date,kickoff_at,source,status,
                 home_team_id,away_team_id,home_team_name,away_team_name,home_score,away_score,round_id,group_name,
                 match_number,archive_position,is_neutral)
                 VALUES (%s,%s,%s,%s,%s,'openfootball',%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s)""",
              (recorded["id"], eid, sid, row["date"], recorded["kickoff_at"], recorded["status"],
               recorded["home_team_id"], recorded["away_team_id"], row["home"], row["away"], recorded["home_score"],
               recorded["away_score"], rid, row["group"], row["number"], row["position"], row["is_neutral"]))
            x("""INSERT INTO core.provider_ids(entity_type,provider,provider_key,entity_id)
                 VALUES ('match','openfootball',%s,%s)""", (key, recorded["id"]))
    for seq, table in (("core.matches_id_seq", "core.matches"), ("core.competitions_id_seq", "core.competitions"),
                       ("core.competition_seasons_id_seq", "core.competition_seasons"), ("core.teams_id_seq", "core.teams")):
        x(sql.SQL("SELECT setval(%s,(SELECT max(id) FROM {}))").format(sql.Identifier(*table.split("."))), (seq,))

def state():
    return x("""SELECT p.provider_key,to_jsonb(m),m.xmin::text FROM core.matches m
              JOIN core.provider_ids p ON p.entity_type='match' AND p.provider='openfootball' AND p.entity_id=m.id
              ORDER BY p.provider_key""").fetchall()

def refresh(step):
    with patch.object(cups, "scopes", lambda now: scopes):
        result = sources.run_due(db, None, datetime(2026, 11, 18, 16, tzinfo=timezone.utc) + timedelta(days=step), names={"openfootball"})
    assert len(result) == 2 and set(result.values()) == {"ok"}, result
    return dict(x("SELECT scope,rows_written FROM ops.source_runs WHERE source='openfootball' ORDER BY scope"))

def capture(origin, previous=None):
    receipts = {}
    for year, anchor in expect.items():
        url = f"{origin}/api/nations/{anchor['id']}?season=2026%2F2027"
        req = Request(url, headers={"If-None-Match": previous[year]["etag"]} if previous else {})
        try:
            res = urlopen(req, timeout=15)
        except HTTPError as error:
            res = error
        with res:
            raw_body = res.read()
            if not raw_body:
                receipts[year] = {"status": res.status, "etag": res.headers.get("etag")}
                continue
            doc = json.loads(raw_body)["data"]
            edition, = [t for t in doc["tournaments"] if t["tournament"] == "world-cup" and t["year"] == int(year)]
            final, = [m for m in edition["games"] if m["date"] == anchor["date"] and m["round"] == "Final"]
            receipts[year] = {"status": res.status, "etag": res.headers.get("etag"), "body_sha256": sha256(raw_body).hexdigest(),
                              "team": doc["name"], "id": doc["id"], "stage": edition["stage"], "tone": edition.get("tone"),
                              "games": edition["matches"], "played_status": dict(Counter(m["status"] for m in edition["games"])),
                              "final": final}
    return receipts

def final_rows():
    return [dict(zip(("id","source","status","date","home_id","away_id","home_score","away_score","edition"), r, strict=True))
            for r in x("""SELECT m.id,m.source::text,m.status::text,m.match_date::text,m.home_team_id,m.away_team_id,
                            m.home_score,m.away_score,c.cup_key FROM core.matches m
                          JOIN core.competition_seasons c ON c.id=m.competition_season_id
                          WHERE m.match_date IN ('1982-07-11','1998-07-12') ORDER BY m.match_date,m.id""")]

def add_controls():
    """Isolated duplicate control on two already evidenced same-day team pairs."""
    control = {}
    cid = x("INSERT INTO core.competitions(name,kind) VALUES ('World Cup','international') RETURNING id").fetchone()[0]
    for year, witness in expect.items():
        sid = int(year) - 1
        eid = x("INSERT INTO core.competition_seasons(competition_id,season_id) VALUES (%s,%s) RETURNING id", (cid,sid)).fetchone()[0]
        # Reverse the physical sides to exercise identity-based de-duplication.
        control[year] = x("""INSERT INTO core.matches(competition_season_id,season_id,match_date,source,status,
                          home_team_id,away_team_id,home_score,away_score)
                          VALUES (%s,%s,%s,'pitchapi','finished',%s,%s,%s,%s) RETURNING id""",
                          (eid,sid,witness["date"],*reversed(witness["pair"]),*reversed(witness["score"]))).fetchone()[0]
    return control

with patch.dict(os.environ, {"NODE_OPTIONS": f"--import={(repo/'backend/tests/fake_openfootball_fetch.mjs').as_uri()}",
                            "VEGA_TEST_OPENFOOTBALL": str(archive_input)}):
    seed_historical()
    with (out / f"{tag}-http.log").open("w") as http_log:
        server = subprocess.Popen(["node", str(out/"serve.mjs"), str(repo), dsn],
                                  stdout=subprocess.PIPE, stderr=http_log, text=True)
        try:
            origin = f"http://127.0.0.1:{int(server.stdout.readline())}"
            before = capture(origin)
            old = state()
            for public in published:
                row = before[str(public["year"])]
                assert row["status"] == 200 and row["stage"] == public["stage"] and row["played_status"] == public["played_status"]
                assert all(row["final"][k] == public["final"][k] for k in ("date","status","homeScore","awayScore"))
            x("SET ROLE vega_collect")
            changed = refresh(0)
            after = capture(origin, before)
            physical = final_rows()
            current = state()
            assert [r[1]["id"] for r in old] == [r[1]["id"] for r in current]
            for year, witness in expect.items():
                row = after[year]
                assert row["status"] == 200 and row["stage"] == "Vainqueur" and row["tone"] == "gold" and row["games"] == 7
                assert row["played_status"] == {"finished": 7}
                assert row["final"]["status"] == "finished" and (row["final"]["homeScore"], row["final"]["awayScore"]) == witness["score"]
                assert row["final"]["edition"] == f"open-cups:world-cup-history:{year}" and "id" not in row["final"]
                assert any(r["id"] == witness["final_id"] and (r["home_id"], r["away_id"]) == witness["pair"] for r in physical)
            repeat = refresh(8)
            assert set(repeat.values()) == {0} and state() == current
            conditional = capture(origin, after)
            assert all(row["status"] == 304 and row["etag"] == after[year]["etag"] for year,row in conditional.items())
            x("RESET ROLE")
            controls = add_controls()
            scored_twins = capture(origin)
            for year,row in scored_twins.items():
                assert row["stage"] == "Vainqueur" and row["games"] == 7 and "id" in row["final"]
                assert row["final"]["edition"] is None and row["final"]["status"] == "finished"
            x("UPDATE core.matches SET status='not_started',home_score=NULL,away_score=NULL WHERE id=ANY(%s)", (list(controls.values()),))
            unscored_twins = capture(origin)
            for row in unscored_twins.values():
                assert row["stage"] == "Finale" and row["games"] == 7 and row["final"]["status"] == "not_started"
                assert row["final"]["homeScore"] is None and row["final"]["awayScore"] is None
            result = {"candidate": candidate, "database": dsn, "postgres": db.info.server_version,
                      "inputs_sha256": {p.name: sha256(p.read_bytes()).hexdigest() for p in (*input_files.values(),projection,prod)},
                      "source": "only the two archived OpenFootball editions, plus a separate controlled copy test",
                      "before": before, "after": after, "physical_finals_after": physical, "rows_written": changed,
                      "repeat_rows_written": repeat, "conditional": conditional, "same_116_match_ids": True,
                      "controlled_duplicates_scored": scored_twins, "controlled_duplicates_unscored": unscored_twins}
            (out / f"{tag}.json").write_text(json.dumps(result, ensure_ascii=False, indent=2) + "\n")
            print(json.dumps({"passed": True, "candidate": candidate, "wins": [after[y]["team"] for y in years],
                              "tournament_games": [after[y]["games"] for y in years], "writes": changed, "repeat": repeat}))
        finally:
            server.terminate()
            server.wait(timeout=10)
