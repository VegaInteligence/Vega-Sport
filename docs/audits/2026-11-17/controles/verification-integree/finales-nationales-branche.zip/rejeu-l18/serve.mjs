import {createServer} from "node:http";
import {resolve} from "node:path";
import {pathToFileURL} from "node:url";

const [tree, dsn] = process.argv.slice(2);
const parsed = new URL(dsn);
if (parsed.hostname !== "127.0.0.1" || !parsed.pathname.startsWith("/vega_v2_nations_l18_")) {
  throw new Error("Use the dedicated local L18 replay database");
}
const {createReader} = await import(pathToFileURL(resolve(tree, "backend/api/src/db.mjs")));
const {createHandler} = await import(pathToFileURL(resolve(tree, "backend/api/src/handler.mjs")));
const reader = createReader(dsn, {role: "vega_read"});
const handle = createHandler({read: reader.read});
const server = createServer(async (req, res) => {
  const result = await handle(new Request("http://127.0.0.1" + req.url, {headers: req.headers}));
  res.writeHead(result.status, Object.fromEntries(result.headers));
  res.end(Buffer.from(await result.arrayBuffer()));
});
server.listen(0, "127.0.0.1", () => console.log(server.address().port));
process.on("SIGTERM", () => server.close(async () => { await reader.end(); process.exit(0); }));
