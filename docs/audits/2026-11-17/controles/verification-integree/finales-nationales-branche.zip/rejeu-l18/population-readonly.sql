-- Measure all same-day, same-pair native copies that can shadow a scored national
-- archive. This follows the ordering of 120_nation_match_copies.sql exactly.
BEGIN TRANSACTION READ ONLY;
SET LOCAL TIME ZONE 'UTC';
SET LOCAL statement_timeout = '45s';

WITH archived_pairs AS MATERIALIZED (
  SELECT coalesce(m.match_date, m.kickoff_at::date) AS day,
    least(m.home_team_id, m.away_team_id) AS lo, greatest(m.home_team_id, m.away_team_id) AS hi,
    array_agg(m.id ORDER BY m.id) AS finished_archive_ids,
    array_agg(coalesce(cs.cup_key, cs.archive_key) ORDER BY m.id) AS archive_editions
  FROM core.matches m
  JOIN core.competition_seasons cs ON cs.id = m.competition_season_id
  JOIN core.teams h ON h.id = m.home_team_id
  JOIN core.teams a ON a.id = m.away_team_id
  WHERE (cs.cup_key IS NOT NULL OR cs.archive_key IS NOT NULL)
    AND m.status = 'finished' AND m.home_score IS NOT NULL AND m.away_score IS NOT NULL
    AND coalesce(m.match_date, m.kickoff_at::date) IS NOT NULL
    AND ((h.is_national AND h.merged_into IS NULL) OR (a.is_national AND a.merged_into IS NULL))
  GROUP BY 1, 2, 3
), overlap AS MATERIALIZED (
  SELECT a.*, picked.id AS picked_id, picked.source, picked.status, picked.home_team_id, picked.away_team_id,
    picked.home_score, picked.away_score, picked.home_penalty_score, picked.away_penalty_score
  FROM archived_pairs a
  CROSS JOIN LATERAL (
    SELECT m.id, m.source::text, m.status::text, m.home_team_id, m.away_team_id,
      m.home_score, m.away_score, m.home_penalty_score, m.away_penalty_score
    FROM core.matches m JOIN core.competition_seasons cs ON cs.id = m.competition_season_id
    WHERE cs.cup_key IS NULL AND cs.archive_key IS NULL
      AND (m.match_date = a.day OR (m.match_date IS NULL AND m.kickoff_at >= a.day AND m.kickoff_at < a.day+1))
      AND ((m.home_team_id = a.lo AND m.away_team_id = a.hi) OR (m.home_team_id = a.hi AND m.away_team_id = a.lo))
    ORDER BY (m.home_score IS NOT NULL) DESC, m.id
    LIMIT 1
  ) picked
)
SELECT jsonb_build_object(
  'scored_archive_pairs', (SELECT count(*) FROM archived_pairs),
  'with_native_copy', count(*),
  'native_hides_score', count(*) FILTER (WHERE home_score IS NULL OR away_score IS NULL),
  'native_status_not_finished', count(*) FILTER (WHERE status <> 'finished'),
  'masked_details', coalesce(jsonb_agg(to_jsonb(o) ORDER BY day,lo,hi)
    FILTER (WHERE home_score IS NULL OR away_score IS NULL), '[]'::jsonb)
) AS score_masks FROM overlap o;

-- Fast, independent probe for the two already documented dates and canonical pairs.
WITH witnesses(year,day,lo,hi) AS (
  VALUES (1982,DATE '1982-07-11',1032,1130), (1998,DATE '1998-07-12',5490,5496)
)
SELECT w.year, m.id, m.source::text, m.status::text, m.home_team_id, m.away_team_id, m.home_score, m.away_score,
  m.home_penalty_score, m.away_penalty_score, cs.cup_key, cs.archive_key, r.name AS round
FROM witnesses w
JOIN core.matches m ON
  (m.match_date = w.day OR (m.match_date IS NULL AND m.kickoff_at >= w.day AND m.kickoff_at < w.day+1))
  AND ((m.home_team_id = w.lo AND m.away_team_id = w.hi) OR (m.home_team_id = w.hi AND m.away_team_id = w.lo))
JOIN core.competition_seasons cs ON cs.id = m.competition_season_id
LEFT JOIN core.rounds r ON r.id = m.round_id
ORDER BY w.year, (cs.cup_key IS NULL AND cs.archive_key IS NULL) DESC, (m.home_score IS NOT NULL) DESC, m.id;

ROLLBACK;
