import fs from "node:fs/promises";
import path from "node:path";
import { createRequire } from "node:module";
import { fileURLToPath } from "node:url";

const [, , playwright, executablePath, origin, out, device] = process.argv;
const { chromium } = createRequire(import.meta.url)(playwright);
const phone = device === "iphone";
const result = { device, origin, checks: [], pageErrors: [], apiReads: [] };
await fs.mkdir(out, { recursive: true });
const browser = await chromium.launch({ executablePath });
const page = await browser.newPage({
  viewport: phone ? { width: 393, height: 852 } : { width: 1440, height: 900 },
  locale: "fr-FR", timezoneId: "Europe/Paris", isMobile: phone, hasTouch: phone,
});
page.setDefaultTimeout(10000);
const fixtures = path.dirname(fileURLToPath(import.meta.url));
const emblem = JSON.parse(await fs.readFile(path.join(fixtures, "emblem-receipt.json"), "utf8"));
await page.route(/\/api\/assets\?/, async route => {
  if (new URL(route.request().url()).searchParams.get("url") !== emblem.reference) return route.continue();
  const reply = await route.fetch({ maxRedirects: 0 });
  const objectKey = "data/sources/v2/images/" + emblem.display_sha256 + ".png";
  check("edition asset resolves to the certified object", [307,"https://vega-fixture.invalid/" + objectKey],
    [reply.status(),reply.headers().location]);
  await route.fulfill({ path: path.join(fixtures, "media", objectKey), contentType: "image/png" });
});

page.on("pageerror", (error) => result.pageErrors.push(String(error)));
page.on("response", (r) => { if (new URL(r.url()).pathname.startsWith("/api/")) result.apiReads.push([r.status(),r.url()]); });
const check = (step, expected, actual) => result.checks.push({ step, expected, actual, pass: JSON.stringify(expected) === JSON.stringify(actual) });
const step = async (name, fn) => {
  try { await fn(); await page.screenshot({ path: path.join(out, name + ".png"), animations: "disabled" }); }
  catch (e) { result.checks.push({ step: name, error: String(e), url: page.url(), pass: false }); }
};
const go = (p) => page.goto(origin + p, { waitUntil: "domcontentloaded" });
const p = (params) => "/competitions/?" + new URLSearchParams(params);
const archive = (year, view, team = "") => p({ id: "open-cup:world-cup-history", edition: year, view, team });
const group = (name) => page.getByRole("table", { name, exact: true });
const rows = async (name) => {
  await group(name).waitFor();
  return group(name).locator("tbody tr").evaluateAll(trs => trs.map(tr => [...tr.cells].map(td => td.textContent.trim())));
};

await step("1950-pool", async () => {
  await go(archive("1950", "groupes", "Uruguay"));
  check("1950 podium and barème", [["1","Uruguay","3","+2","5"],["2","Brésil","3","+10","4"],["3","Suède","3","-5","2"],["4","Espagne","3","-7","1"]], await rows("Poule finale"));
  check("1950 positions level", ["1","2=","2=","2="], (await rows("Groupe 2")).map(r => r[0]));
  check("1950 has no bracket tab", 0, await page.locator(".edition-head").getByRole("button", { name: "Tableau", exact: true }).count());
});
await step("1954-playoff", async () => {
  await go(archive("1954", "groupes"));
  check("1954: 7–2 decides 2nd; it does not enter the totals", [["Hongrie","2","4"],["Allemagne de l’Ouest","2","2"],["Turquie","2","2"],["Corée du Sud","2","0"]], (await rows("Groupe 2")).map(r => [r[1],r[2],r[4]]));
  const artwork = page.locator('.edition-logo[data-media-state="ready"] img');
  await artwork.waitFor();
  check("1954 genuine FIFA emblem reaches the edition head", [emblem.reference,150],
    [new URL(await artwork.getAttribute("src"),origin).searchParams.get("url"),await artwork.evaluate(image => image.naturalWidth)]);
});
await step("1982-italie", async () => {
  await go(archive("1982", "matchs", "Italy"));
  const search = page.locator(".cup-controls input");
  const final = page.locator(".cup-match").filter({ hasText: "Italie" }).filter({ hasText: "Allemagne de l’Ouest" });
  await final.first().waitFor();
  await search.fill("Italie");
  check("Italie finds the final", 1, await final.count());
  await search.fill("Italy");
  check("Italy finds the final", 1, await final.count());
  check("Italy–West Germany final", "3 – 1", await final.first().locator(".score").innerText());
});
await step("2028-groups", async () => {
  await go(p({ id: "open-cup:euro", edition: "2028", view: "groupes" }));
  await page.locator(".edition-groups, .cup-detail .empty").first().waitFor({ timeout: 5000 }).catch(() => {});
  check("Euro 2028 has six group tables", 6, await page.locator(".edition-group table").count());
  if (await group("Groupe A").count()) {
    check("Euro 2028 group A anonymous and unranked", [["—","A1"],["—","A2"],["—","A3"],["—","A4"]], (await rows("Groupe A")).map(r => r.slice(0, 2)));
  }
});
for (const [name, id, year, competition, count] of [
  ["argentina","t_v0000152","2024","copa-america",6],
  ["ivoire","t_v0000168","2023","afcon",7],
  ["qatar","t_v0000192","2023","asian-cup",7],
  ["mexico","t_v0000158","2023","gold-cup",6],
]) {
  await step(name, async () => {
    await go("/nations/?" + new URLSearchParams({ id, season: "2026/2027" }));
    const own = page.locator('a[href*="' + competition + '"][href*="edition=' + year + '"]');
    await own.waitFor();
    check(name + " phase and match count", true, (await own.getAttribute("title")).includes("Phase non renseignée · " + count + " matchs"));
    check(name + " no gauge", 0, await own.locator('i').count());
    check(name + " links to match list", "matchs", new URL(await own.getAttribute("href"), origin).searchParams.get("view"));
    await own.click();
    await page.locator(".cup-match").first().waitFor();
    check(name + " opens the expected edition", year, await page.locator(".edition-head select").inputValue());
  });
}
await step("uruguay-1950-tile", async () => {
  await go("/nations/?" + new URLSearchParams({ id: "t_v0000091", season: "2026/2027" }));
  const tile = page.locator('a[href*="world-cup-history"][href*="edition=1950"]');
  await tile.waitFor();
  check("Uruguay medal and view", ["gold","groupes"], [await tile.getAttribute("data-tone"),new URL(await tile.getAttribute("href"),origin).searchParams.get("view")]);
});
await step("native-season", async () => {
  await go(p({ id: "l_1XLtP0", edition: "2026", view: "tableau" }));
  const select = page.locator(".edition-head select");
  await select.waitFor();
  check("native 2026 is selected", "2026", await select.inputValue());
  if (phone) {
    const finalButton = page.locator(".knockout-phone").getByRole("button", { name: "Finale" });
    await finalButton.click();
  }
  await select.selectOption("2022");
  check("native selection updates edition address", "2022", new URL(page.url()).searchParams.get("edition"));
  await page.reload();
  await select.waitFor();
  check("native 2022 persists across reload", "2022", await select.inputValue());
  await go(archive("2022", "tableau"));
  await select.waitFor();
  check("archive screen remains available by direct URL", "2022", await select.inputValue());
  const emblem = page.locator(".edition-head .edition-logo");
  await emblem.waitFor();
  check("unattested family logo leaves empty edition slot", 0, await emblem.locator("img,.image-fallback").count());
});
await step("france-1998", async () => {
  await go("/nations/?" + new URLSearchParams({ id: "t_v0000023", season: "2026/2027" }));
  const tile = page.locator('a[href*="world-cup-history"][href*="edition=1998"]');
  await tile.waitFor();
  check("France 1998 title and bracket address", ["gold","tableau"], [await tile.getAttribute("data-tone"),new URL(await tile.getAttribute("href"), origin).searchParams.get("view")]);
  await tile.click();
  await page.locator(".knockout-final .knockout-team").first().waitFor({ state: "attached" });
  check("France 1998 opens the final, France followed", true, (await page.locator(".knockout-final").textContent()).includes("Brésil0France3"));
  check("France follows from the Nations URL", "France", new URL(page.url()).searchParams.get("team"));
});

await step("historical-cancellation", async () => {
  await go(archive("1938", "matchs"));
  await page.getByRole("button", { name: "Tous", exact: true }).click();
  const cancelled = page.locator(".cup-match").filter({ hasText: "Suède" }).filter({ hasText: "Autriche" });
  await cancelled.waitFor();
  check("1938 Sweden–Austria retains official status", "Annulé", await cancelled.locator(".score").innerText());
  check("1938 cancellation is omitted from missing-score notice", 0, await page.getByText("Certains scores de cette édition ne sont pas encore renseignés.").count());
});

await step("old-api-group-scores", async () => {
  const old = await fs.readFile(path.join(fixtures, "archive-edition-france-old.json"), "utf8");
  const path1998 = /\/api\/(?:cups\/edition|cup-snapshot)\?.*season=1998/;
  const legacy = route => route.fulfill({ status: 200, contentType: "application/json", body: old });
  await page.route(path1998, legacy);
  try {
    await go(archive("1998", "groupes"));
    const france = (await rows("Groupe C")).find(row => row[1] === "France");
    check("captured 1998 old API with incomplete group has no France rank, difference, points", ["—","—","—"],[france[0],france[3],france[4]]);
    check("the group has no fabricated ordinal", true, (await rows("Groupe C")).every(row => row[0] === "—"));
    await page.screenshot({path: path.join(out, "old-api-group-scores.png"), animations:"disabled"});
  } finally { await page.unroute(path1998,legacy); }
});

await step("old-api-phase", async () => {
  const path = /\/api\/nations\/t_v0000152\?/;
  const legacy = async route => {
    const reply = await route.fetch();
    const body = await reply.json();
    const run = body.data.tournaments.find(run => run.tournament === "copa-america");
    run.stage = "1er tour";
    run.tone = "gold";
    await route.fulfill({ response: reply, json: body });
  };
  await page.route(path,legacy);
  try {
    await go("/nations/?" + new URLSearchParams({ id: "t_v0000152", season: "2026/2027" }));
    const tile = page.locator('a[href*="copa-america"][href*="edition=2024"]');
    await tile.waitFor();
    check("old phase label and tone are suppressed in the site", [true,null,0],
      [(await tile.textContent()).includes("Phase non renseignée"),await tile.getAttribute("data-tone"),await tile.locator("i").count()]);
  } finally { await page.unroute(path,legacy); }
});

await step("featured-competitions-banner", async () => {
  await go(p({ id: "l_0bfbkO" }));
  const strip = page.locator(".league-spotlight");
  await strip.getByRole("button", { name: /Champions League/ }).waitFor();
  check("VI-22 featured order", ["Bundesliga", "Premier League", "LaLiga", "Ligue 1", "Serie A", "Eredivisie", "Liga Portugal", "Champions League", "Europa League", "Conference League"],
    await strip.locator("button strong").allTextContents());
  for (const [name,id] of [["Champions League","l_0bfbkO"],["Europa League","l_38d9HA"],["Conference League","l_2WZ2tt"]]) {
    await strip.getByRole("button",{ name: new RegExp(name) }).click();
    await page.waitForURL(new RegExp("id="+id));
    await strip.locator('button[aria-pressed="true"]').filter({ has: page.locator("strong", { hasText: name }) }).waitFor();
    check("VI-22 " + name + " selected once", [1,name], [await strip.locator('button[aria-pressed="true"]').count(),await strip.locator('button[aria-pressed="true"] strong').innerText()]);
  }
});
await step("historical-flags-and-cards", async () => {
  await go(archive("1974", "groupes", "East Germany"));
  const group1974 = group("Groupe 1");
  const eastGermany = group1974.getByRole("row").filter({ hasText: "Allemagne de l’Est" });
  await eastGermany.waitFor();
  check("1974 East Germany, five points with its identified flag", ["5",1],
    [(await eastGermany.locator("td").last().innerText()).trim(),await eastGermany.locator(".fi-dd").count()]);
  check("historic emblems and national flags are distinct", true,
    await eastGermany.locator(".fi-dd").evaluate(node => getComputedStyle(node).backgroundImage.startsWith('url("data:image/svg+xml')));
  check("group tables fit their cards", true, await page.locator(".edition-group").evaluateAll(cards =>
    cards.length > 0 && cards.every(card => card.querySelector("table").getBoundingClientRect().width <= card.getBoundingClientRect().width)));
  check("no horizontal overflow at the viewport", true, await page.evaluate(() => document.documentElement.scrollWidth <= window.innerWidth));
});
check("no uncaught browser error", [], result.pageErrors);
await fs.writeFile(path.join(out, "result.json"), JSON.stringify(result, null, 2) + "\n");
console.log(JSON.stringify(result.checks, null, 2));
await browser.close();
process.exitCode = result.checks.some(c => !c.pass) ? 1 : 0;
