# Rejouer VI-27 B

Extraire la capsule dans un dossier. Dans le même terminal, définir `VI27_OUT` au chemin absolu du dossier extrait et se placer dans le worktree Vega-Sport au commit `193866c359b826ef5307b0af4a368e5355ef021f`. Installer les dépendances verrouillées de Vega-Sport, Python avec psycopg, Node 26 et Playwright avec Chromium. Les vérifications ont utilisé Next.js 16.4.6, playwright-core 1.66.0-alpha et Chromium headless 1247 sur macOS ARM64.

Le test exige PostgreSQL 18 sur 127.0.0.1:55459, avec le rôle postgres local et les deux bases de test dédiées. Le constructeur recrée uniquement `vega_v2_vi27_b_e2e` sur ce serveur. Pour les contrats, la base `vega_v2_api_node_test` doit exister et peut être vide. Le seed des contrats recrée ses schémas.

```sh
export VI27_OUT='/absolute/capsule/path'
export VI27_PLAYWRIGHT_CORE='/absolute/path/to/node_modules/playwright-core'
export VI27_CHROMIUM='/absolute/path/to/chrome-headless-shell'
export VI27_DSN='postgresql://postgres@127.0.0.1:55459/vega_v2_vi27_b_e2e'
python3 -B "$VI27_OUT/build_db.py" "$PWD" "$VI27_DSN" "$VI27_OUT/continental" "$VI27_OUT/rebuilt-db-receipt.json"
PYTHONPATH=backend python3 -B "$VI27_OUT/native-fixtures.py"
PYTHONPATH=backend python3 -B "$VI27_OUT/featured-catalog.py"
PYTHONPATH=backend python3 -B "$VI27_OUT/edition-emblem.py" "$VI27_OUT/edition-pack" "$VI27_OUT"
node "$VI27_OUT/serve-api.mjs" "$PWD" "$VI27_DSN" 8769
```

Dans un autre terminal, depuis Vega-Sport, démarrer le site.

```sh
cd dashboard
ORION_API_ORIGIN=http://127.0.0.1:8769 NEXT_TELEMETRY_DISABLED=1 node node_modules/next/dist/bin/next dev frontend --hostname 127.0.0.1 --port 3421
```

Depuis la racine de Vega-Sport, avec les variables du premier terminal, lancer les vérifications.

```sh
zsh "$VI27_OUT/run-browser.sh" replay desktop
zsh "$VI27_OUT/run-browser.sh" replay iphone
node --test tests/tournament-rules.test.mjs tests/tournament-editions.test.mjs tests/{cup*,competition*,complementary-leagues,euro-search-flags}.test.mjs backend/api/test/nations.test.mjs
VEGA_V2_API_NODE_TEST_DSN=postgresql://postgres@127.0.0.1:55459/vega_v2_api_node_test node --test --test-concurrency=1 backend/api/test/nations.test.mjs backend/api/test/cups.test.mjs
```

Les attendus et les observations figurent dans les deux `result.json` de `final-verified-*`, avec les captures PNG. Le reçu `RECEIPT.md` précise le rôle de chaque donnée. Pour reproduire le rouge de navigateur à la révision A, utiliser `VI27_BROWSER_SCRIPT="$VI27_OUT/browser-initial.mjs"` devant le lanceur avec les archives et les éditions natives locales seulement. Le navigateur ne doit pas avoir besoin d’ouvrir une production distante. L’unique fichier image livré par l’interception est celui du paquet FIFA, avec vérification préalable de l’adresse demandée à l’API locale.
