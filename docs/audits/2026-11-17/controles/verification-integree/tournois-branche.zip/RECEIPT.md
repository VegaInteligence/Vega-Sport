# VI-27 B · Tournois, contrôle local et fusion

Le point de départ de B est `4303a1255d288f8d0ee3a5c7964ebb5a4434f824` dans le worktree `Vega-Sport-audit-20261117`. Claude Opus 5.5 au niveau max a documenté les scénarios §34, lancé les premiers tests en échec et écrit la base locale avec le collecteur. Le run natif `20261118T171716Z-code-879a060c` a terminé à cause du quota. Sur décision explicite, GPT-6.2-Sol/xhigh a repris le même arbre et la même base, sans second worktree. Le coordinateur a figé B sous `3c95a2dfc5532881d32e3387dd87cc24f8c80eda`. J’ai intégré les quatre commits de main jusqu’à `e60e80860e6ad1cfa9f330a4b2c2ce66eb9ef35a` dans cet arbre, avec les tests B. [Décision](../decision-plan.md) · [Départ Opus](../opus/run-B.json) · [Préparation de la base](../opus/integration-B/e2e/db-receipt.json)

## Changements

- `cup-matches.js`, `CupCompetition.jsx` et les tests d’édition mettent les barèmes et les départages dans le calcul de groupes. Une règle inconnue ou une rencontre passée non scorée laisse les rangs indéterminés. Les ex æquo que les données ne départagent pas ont un rang partagé et « Départage indisponible ». Le barrage de 1954 ou de 1958 ordonne le bloc concerné sans influer sur J, les buts ou les points. Les 36 matchs de groupes 2028 donnent six tables de quatre places anonymes.
- Le lecteur API `nations.mjs` et le site utilisent les mêmes noms de phase. Les trois adversaires distincts, le jour, le nom de la sélection et chacun des scores de 1950 doivent concorder pour attribuer un rang et une médaille sur sa fiche. Le calcul des groupes exige les six résultats corroborés pour classer la poule finale. Sans round pour les quatre éditions continentales, le site garde l’année, les matchs et le lien, avec « Phase non renseignée » et sans jauge. Le site traite aussi cet état avec un lecteur ancien.
- Les routes et le sélecteur restent dans la même édition au rechargement. La poule de 1950 ouvre les groupes, les éditions sans phases ouvrent les matchs, le Mondial natif couvre 2022/2026 et les archives restent accessibles par leur URL. Le filtre indexe les noms français et du fournisseur. Le tableau conserve l’identité du match rejoué et différencie l’annulation de 1938.
- La fusion conserve les drapeaux, l’intitulé historique des équipes et les cartes ainsi que les en-têtes du main. Elle garde la règle d’édition au même endroit pour le Mondial et l’EURO. Seul le calcul avec un contexte `competition` et `season` produit le rang d’un groupe. L’option de points de l’utilitaire des ligues reste compatible avec la nouvelle signature de main.

## Reproduction

Depuis le worktree, utiliser Node 26, Next 16.4.6, Chromium headless 1247 et PostgreSQL 18.6 du conteneur Colima `vega-vi27-opus-pg18` sur 127.0.0.1:55459. Les commandes suivantes ne ciblent que l’environnement jetable. Exécuter les commandes de serveur dans des terminaux séparés.

```sh
export VI27_EVIDENCE='/Users/lemonnierhugo/.codex/visualizations/2026/11/17/01a1e6f1-9c43-7b81-a52e-3ee15c953578/production-architecture-review/delivery/actualisation-main-1633'
export VI27_OUT="$VI27_EVIDENCE/sol-tournois-B"
export VI27_DSN='postgresql://postgres@127.0.0.1:55459/vega_v2_vi27_b_e2e'
python3 -B "$VI27_EVIDENCE/opus/integration-B/e2e/build_db.py" "$PWD" "$VI27_DSN" "$VI27_EVIDENCE/phases-manquantes/capture" "$VI27_OUT/rebuilt-db-receipt.json"
PYTHONPATH=backend python3 -B "$VI27_OUT/native-fixtures.py"
PYTHONPATH=backend python3 -B "$VI27_OUT/featured-catalog.py"
PYTHONPATH=backend python3 -B "$VI27_OUT/edition-emblem.py" "$VI27_EVIDENCE/../tracks/7-artwork/world-cup-edition-marks/edition-pack" "$VI27_OUT"
node "$VI27_OUT/serve-api.mjs" "$PWD" "$VI27_DSN" 8769
```

```sh
cd dashboard
ORION_API_ORIGIN=http://127.0.0.1:8769 NEXT_TELEMETRY_DISABLED=1 node node_modules/next/dist/bin/next dev frontend --hostname 127.0.0.1 --port 3421
```

Depuis la racine de W, les tests et les captures se rejouent ainsi.

```sh
zsh "$VI27_OUT/run-browser.sh" final-verified desktop
zsh "$VI27_OUT/run-browser.sh" final-verified iphone
node --test tests/tournament-rules.test.mjs tests/tournament-editions.test.mjs tests/{cup*,competition*,complementary-leagues,euro-search-flags}.test.mjs backend/api/test/nations.test.mjs
VEGA_V2_API_NODE_TEST_DSN=postgresql://postgres@127.0.0.1:55459/vega_v2_api_node_test node --test --test-concurrency=1 backend/api/test/nations.test.mjs backend/api/test/cups.test.mjs
git diff --check
```

Les 26 éditions OpenFootball du dépôt passent dans le véritable writer et le lecteur API local. Les 166 résultats réels des quatre éditions continentales viennent des réponses archivées le 18 novembre. Les données 2022/2026 de l’archive sont copiées dans des éditions natives locales pour exercer cette route et le changement de saison. Les dix entrées du bandeau utilisent les identifiants et pays du catalogue avec un match fictif chacune pour les publier sur la saison active. Aucun constat sportif ne repose sur ces dix matchs. L’emblème officiel FIFA 1954 provient du paquet certifié par le lot visuel. Le script ajuste seulement les identifiants de base du témoin et utilise le writer normal. Le navigateur vérifie le 307 de l’API puis lit les mêmes octets du paquet par l’interception de la réplique de stockage. [Copie de l’ancien lecteur](archive-edition-france-old.json) · [Emblème, origine et SHA](emblem-receipt.json)

Pour le rouge, l’exécution `node --test tests/tournament-rules.test.mjs backend/api/test/nations.test.mjs` sur A avec les tests déjà écrits a donné 3 succès, 14 échecs et un test nécessitant la base de contrats. Le script de navigateur de cette phase est `browser-initial.mjs` avec les mêmes paramètres Playwright, le site A et les données initiales du collecteur et de `native-fixtures.py`. Sur iPhone, 21 des 31 contrôles échouaient. Les erreurs se voyaient sur les points de l’Uruguay, l’ordre RFA–Turquie, les groupes 2028, « Italie », les quatre phases inventées et le rechargement natif. Sur B avant la dernière fusion, 32/32 ont passé sur chaque taille. [Rouge Node](red-node.log) · [Rouge iPhone](red-complete-iphone/result.json) · [B bureau](green-desktop/result.json) · [B iPhone](green-iphone/result.json)

L’essai de fusion initial a obtenu 49/50 sur les deux tailles. Le témoin local de bandeau omettait le pays et l’ordre attendu reproduisait l’ordre des constantes, pas l’ordre de production. Les pays ont été ajoutés aux données locales et l’attendu vérifié dans les observations de production archivées. Le code du bandeau n’a pas été modifié. [Bandeau de production](../parcours/final-desktop/result.json)

## Résultat de fusion

Le commit `193866c359b826ef5307b0af4a368e5355ef021f` a pour parents `3c95a2dfc5532881d32e3387dd87cc24f8c80eda` et `e60e80860e6ad1cfa9f330a4b2c2ce66eb9ef35a`. Les tests ciblés ont donné 97 succès et un test reporté sur la base de contrats. Les contrats PG18 ont donné 12 succès sans test sauté. Sur le dernier rejeu, les 50 assertions passent sur bureau et sur iPhone simulé, sans exception JavaScript.

Le parcours complet rend Uruguay 5, Brésil 4, Suède 2, Espagne 1. Sur le dernier groupe de 1974 contrôlé, la RDA atteint cinq points et son drapeau apparaît dans une carte sans débordement. L’ancien corps de la route 1998 laisse les rangs du groupe C indéterminés et France sans points ni différence. La finale complète Brésil 0–3 France ouvre bien depuis la fiche de la sélection. Sur le lot final, le test du bandeau attend l’état actif de React après le changement d’adresse avant de compter les boutons. [Bureau](final-verified-desktop/result.json) · [iPhone simulé](final-verified-iphone/result.json) · [Contrats API](merged-pg-contract.log) · [Contrats site](merged-node-scope.log)

## Limites

Les départages qui exigent des cartons, des tirages au sort ou d’autres faits absents restent indéterminés. L’acquisition des tours manquants relève de VI-21. Les drapeaux courants et les dessins historiques simplifiés hérités de main n’attestent pas une variante précise utilisée à chaque date. Le PNG de 1954 a été testé localement depuis le paquet officiel. La publication des emblèmes et la couverture des autres éditions relèvent du partenaire. Le chemin natif, la comparaison ancienne et le bandeau ont été vérifiés localement sur les données décrites ci-dessus. La CI intégrée, la publication et les deux avis finaux appartiennent au coordinateur.
