import { createServer } from "node:http";
import { pathToFileURL } from "node:url";

const [, , repo, dsn, port] = process.argv;
if (!/^postgresql:\/\/postgres@127\.0\.0\.1:55459\/vega_v2_vi27_b_e2e$/.test(dsn)) throw Error("expected isolated local database");
const { createReader } = await import(pathToFileURL(repo + "/backend/api/src/db.mjs"));
const { createHandler } = await import(pathToFileURL(repo + "/backend/api/src/handler.mjs"));
const reader = createReader(dsn, { role: "vega_read" });
const handle = createHandler({ read: reader.read, mediaBase: "https://vega-fixture.invalid/" });
const server = createServer(async (req, res) => {
  try {
    const url = new URL(req.url, "http://127.0.0.1:" + port);
    const reply = await handle(new Request(url, { method: req.method, headers: req.headers }));
    res.writeHead(reply.status, Object.fromEntries(reply.headers));
    res.end(Buffer.from(await reply.arrayBuffer()));
    console.log(req.method, url.pathname + url.search, reply.status);
  } catch (error) {
    console.error(error);
    res.writeHead(500).end();
  }
});
server.listen(Number(port), "127.0.0.1");
