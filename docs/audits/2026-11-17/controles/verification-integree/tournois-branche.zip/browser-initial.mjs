import fs from "node:fs/promises";
import path from "node:path";
import { createRequire } from "node:module";

const [, , playwright, executablePath, origin, out, device] = process.argv;
const { chromium } = createRequire(import.meta.url)(playwright);
const phone = device === "iphone";
const result = { device, origin, checks: [], pageErrors: [], apiReads: [] };
await fs.mkdir(out, { recursive: true });
const browser = await chromium.launch({ executablePath });
const page = await browser.newPage({
  viewport: phone ? { width: 393, height: 852 } : { width: 1440, height: 900 },
  locale: "fr-FR", timezoneId: "Europe/Paris", isMobile: phone, hasTouch: phone,
});
page.setDefaultTimeout(10000);
page.on("pageerror", (error) => result.pageErrors.push(String(error)));
page.on("response", (r) => { if (new URL(r.url()).pathname.startsWith("/api/")) result.apiReads.push([r.status(),r.url()]); });
const check = (step, expected, actual) => result.checks.push({ step, expected, actual, pass: JSON.stringify(expected) === JSON.stringify(actual) });
const step = async (name, fn) => {
  try { await fn(); await page.screenshot({ path: path.join(out, name + ".png"), animations: "disabled" }); }
  catch (e) { result.checks.push({ step: name, error: String(e), url: page.url(), pass: false }); }
};
const go = (p) => page.goto(origin + p, { waitUntil: "domcontentloaded" });
const p = (params) => "/competitions/?" + new URLSearchParams(params);
const archive = (year, view, team = "") => p({ id: "open-cup:world-cup-history", edition: year, view, team });
const group = (name) => page.getByRole("table", { name, exact: true });
const rows = async (name) => {
  await group(name).waitFor();
  return group(name).locator("tbody tr").evaluateAll(trs => trs.map(tr => [...tr.cells].map(td => td.textContent.trim())));
};

await step("1950-pool", async () => {
  await go(archive("1950", "groupes", "Uruguay"));
  check("1950 podium and barème", [["1","Uruguay","3","+2","5"],["2","Brésil","3","+10","4"],["3","Suède","3","-5","2"],["4","Espagne","3","-7","1"]], await rows("Poule finale"));
  check("1950 positions level", ["1","2=","2=","2="], (await rows("Groupe 2")).map(r => r[0]));
  check("1950 has no bracket tab", 0, await page.locator(".edition-head").getByRole("button", { name: "Tableau", exact: true }).count());
});
await step("1954-playoff", async () => {
  await go(archive("1954", "groupes"));
  check("1954: 7–2 decides 2nd; it does not enter the totals", [["Hongrie","2","4"],["Allemagne de l’Ouest","2","2"],["Turquie","2","2"],["Corée du Sud","2","0"]], (await rows("Groupe 2")).map(r => [r[1],r[2],r[4]]));
});
await step("1982-italie", async () => {
  await go(archive("1982", "matchs", "Italy"));
  const search = page.locator(".cup-controls input");
  const final = page.locator(".cup-match").filter({ hasText: "Italie" }).filter({ hasText: "Allemagne de l’Ouest" });
  await final.first().waitFor();
  await search.fill("Italie");
  check("Italie finds the final", 1, await final.count());
  await search.fill("Italy");
  check("Italy finds the final", 1, await final.count());
  check("Italy–West Germany final", "3 – 1", await final.first().locator(".score").innerText());
});
await step("2028-groups", async () => {
  await go(p({ id: "open-cup:euro", edition: "2028", view: "groupes" }));
  await page.locator(".edition-groups, .cup-detail .empty").first().waitFor({ timeout: 5000 }).catch(() => {});
  check("Euro 2028 has six group tables", 6, await page.locator(".edition-group table").count());
  if (await group("Groupe A").count()) {
    check("Euro 2028 group A anonymous and unranked", [["—","A1"],["—","A2"],["—","A3"],["—","A4"]], (await rows("Groupe A")).map(r => r.slice(0, 2)));
  }
});
for (const [name, id, year, competition, count] of [
  ["argentina","t_v0000152","2024","copa-america",6],
  ["ivoire","t_v0000168","2023","afcon",7],
  ["qatar","t_v0000192","2023","asian-cup",7],
  ["mexico","t_v0000158","2023","gold-cup",6],
]) {
  await step(name, async () => {
    await go("/nations/?" + new URLSearchParams({ id, season: "2026/2027" }));
    const own = page.locator('a[href*="' + competition + '"][href*="edition=' + year + '"]');
    await own.waitFor();
    check(name + " phase and match count", true, (await own.getAttribute("title")).includes("Phase non renseignée · " + count + " matchs"));
    check(name + " no gauge", 0, await own.locator('i').count());
    check(name + " links to match list", "matchs", new URL(await own.getAttribute("href"), origin).searchParams.get("view"));
    await own.click();
    await page.locator(".cup-match").first().waitFor();
    check(name + " opens the expected edition", year, await page.locator(".edition-head select").inputValue());
  });
}
await step("uruguay-1950-tile", async () => {
  await go("/nations/?" + new URLSearchParams({ id: "t_v0000091", season: "2026/2027" }));
  const tile = page.locator('a[href*="world-cup-history"][href*="edition=1950"]');
  await tile.waitFor();
  check("Uruguay medal and view", ["gold","groupes"], [await tile.getAttribute("data-tone"),new URL(await tile.getAttribute("href"),origin).searchParams.get("view")]);
});
await step("native-season", async () => {
  await go(p({ id: "l_1XLtP0", edition: "2026", view: "tableau" }));
  const select = page.locator(".edition-head select");
  await select.waitFor();
  check("native 2026 is selected", "2026", await select.inputValue());
  if (phone) {
    const finalButton = page.locator(".knockout-phone").getByRole("button", { name: "Finale" });
    await finalButton.click();
  }
  await select.selectOption("2022");
  check("native selection updates edition address", "2022", new URL(page.url()).searchParams.get("edition"));
  await page.reload();
  await select.waitFor();
  check("native 2022 persists across reload", "2022", await select.inputValue());
  await go(archive("2022", "tableau"));
  await select.waitFor();
  check("archive screen remains available by direct URL", "2022", await select.inputValue());
  const emblem = page.locator(".edition-head .edition-logo");
  await emblem.waitFor();
  check("unattested family logo leaves empty edition slot", 0, await emblem.locator("img,.image-fallback").count());
});
check("no uncaught browser error", [], result.pageErrors);
await fs.writeFile(path.join(out, "result.json"), JSON.stringify(result, null, 2) + "\n");
console.log(JSON.stringify(result.checks, null, 2));
await browser.close();
process.exitCode = result.checks.some(c => !c.pass) ? 1 : 0;
