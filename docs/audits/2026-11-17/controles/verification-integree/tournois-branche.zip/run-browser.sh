#!/bin/zsh
set -eu
evidence_dir=${0:a:h}
node "${VI27_BROWSER_SCRIPT:-$evidence_dir/browser.mjs}"   "${VI27_PLAYWRIGHT_CORE:-/Users/lemonnierhugo/.npm/_npx/31e32ef8478fbf80/node_modules/playwright-core}"   "${VI27_CHROMIUM:-/Users/lemonnierhugo/Library/Caches/ms-playwright/chromium_headless_shell-1247/chrome-headless-shell-mac-arm64/chrome-headless-shell}"   "${VI27_ORIGIN:-http://127.0.0.1:3421}" "$evidence_dir/$1-$2" "$2"
