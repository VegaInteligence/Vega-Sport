"""Publish the real featured IDs and display names in the isolated manifest's catalogue.
They provide navigation targets only; this is a local test of the banner, not match coverage.
"""
from vega.store import Store, connect_local
from pathlib import Path
import re

db = connect_local("postgresql://postgres@127.0.0.1:55459/vega_v2_vi27_b_e2e")
store = Store(db)
featured = Path("dashboard/shared/competition-scope.js").read_text().split("];", 1)[0]
records = re.findall(r'id: "(l_[A-Za-z0-9]+)", name: "([^"]+)", country: "([A-Z]+)"', featured)
assert len(records) == 10
with db.transaction():
    home = store.entity("team", "t_seedH1", {"name": "Club témoin A"})
    away = store.entity("team", "t_seedA2", {"name": "Club témoin B"})
    for key, name, country in records:
        competition = store.entity("competition", key, {"name":name, "country_code":country, "kind":"cup" if country=="UEFA" else "league"})
        edition,season = store.edition(competition,"2025/2026")
        db.execute("""INSERT INTO core.matches (competition_season_id,season_id,source,status,match_date,kickoff_at,home_team_id,away_team_id,home_score,away_score)
        SELECT %s,%s,'pitchapi','finished','2025-09-06','2025-09-06T18:00:00Z',%s,%s,0,0
        WHERE NOT EXISTS (SELECT 1 FROM core.matches WHERE competition_season_id=%s)""", (edition,season,home,away,edition))
    db.execute("SELECT ops.refresh_editions()")
print(records)
