"""Validate the sealed FIFA pack. Locally bind its 1954 logo to the same local archive scope."""
from hashlib import sha256
from pathlib import Path
import json
import sys
from vega import artwork
from vega.store import connect_local

pack, output = map(Path, sys.argv[1:])
manifest = pack / "edition-emblems.json"
digest = sha256(manifest.read_bytes()).hexdigest()
records, displays = artwork.load(manifest, pack, digest)
record = next(r for r in records if r["edition_year"] == 1954)
scope = record["resolve_using"]["source_edition_key"]
db = connect_local("postgresql://postgres@127.0.0.1:55459/vega_v2_vi27_b_e2e")
edition, competition, season, label = db.execute("""SELECT cs.id,cs.competition_id,s.id,s.label
 FROM core.competition_seasons cs JOIN core.seasons s ON s.id=cs.season_id WHERE cs.cup_key=%s""", (scope,)).fetchone()
assert db.execute("SELECT name FROM core.competitions WHERE id=%s", (competition,)).fetchone()[0] == record["canonical_name"]
record["canonical_id_at_snapshot"] = edition
record["edition_guard"].update(competition_id_at_snapshot=competition, edition_id_at_snapshot=edition,
                              season_id_at_snapshot=season, season_label_at_snapshot=label)
outcome, ident, ref, detail = artwork.link(db, record, displays, {}, artwork.local_store(output / "media"), digest)
assert outcome in {"linked", "already_linked"}, (outcome, detail)
receipt = {"original_manifest_sha256": digest, "scope": scope, "fixture_edition_id": ident, "reference": ref,
           "display_sha256": record["display_sha256"], "publisher": record["image_url"], "outcome": outcome}
(output / "emblem-receipt.json").write_text(json.dumps(receipt, indent=2) + "\n")
print(json.dumps(receipt))
