"""In the isolated VI-27 test database, publish the frozen 2022/2026 archive matches as a native-path witness.
The same real fixtures make native season routing and the shorter 2022 mobile bracket reproducible offline.
"""
from datetime import datetime, timezone
from vega.store import Store, connect_local
from vega.worker import publish

DSN = "postgresql://postgres@127.0.0.1:55459/vega_v2_vi27_b_e2e"
db = connect_local(DSN)
store = Store(db)
with db.transaction():
    con = store.entity("competition", "l_1XLtP0", {"name":"World Cup", "kind":"cup"})
    for year in ("2022", "2026"):
        ed, sid = store.edition(con, year)
        archive = db.execute("select id from core.competition_seasons where cup_key = %s", (f"open-cups:world-cup-history:{year}",)).fetchone()[0]
        db.execute("""insert into core.rounds(competition_season_id,name,stage) select %s,name,stage from core.rounds where competition_season_id=%s
          on conflict (competition_season_id,name) do nothing""", (ed,archive))
        db.execute("""with copied as (
          insert into core.matches(competition_season_id,season_id,source,status,match_date,kickoff_at,home_team_id,away_team_id,home_score,away_score,home_penalty_score,away_penalty_score,group_name,round_id)
          select %s,%s,'pitchapi',m.status,m.match_date,m.match_date+time '18:00',m.home_team_id,m.away_team_id,m.home_score,m.away_score,m.home_penalty_score,m.away_penalty_score,m.group_name,r.id
          from core.matches m left join core.rounds a on a.id=m.round_id left join core.rounds r on r.competition_season_id=%s and r.name=a.name
          where m.competition_season_id=%s and not exists (select 1 from core.matches n where n.competition_season_id=%s)
          returning id)
          insert into core.provider_ids(entity_type,provider,provider_key,entity_id)
          select 'match','pitchapi','m_'||lpad(id::text,6,'A'),id from copied""", (ed,sid,ed,archive,ed))
    print(publish(db, datetime.now(timezone.utc), force=True))
