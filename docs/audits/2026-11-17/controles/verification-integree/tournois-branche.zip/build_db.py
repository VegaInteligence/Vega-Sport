"""A disposable PostgreSQL 18 base for the VI-27 B end-to-end run, written by the product's own collect.

python3 -B build_db.py <repo> <dsn of a new vega_v2_* database> <phases capture dir> <receipt.json>

- The 23 World Cups and three Euros of backend/tests/fixtures/openfootball/editions.json (frozen OpenFootball
  files) through the real bridge, projection and writer: sources.run_due with the tests' fetch preload
  (backend/tests/fake_openfootball_fetch.mjs), as backend/tests/test_source_snapshots.py does.
- Copa América 2024, CAN 2023, Asian Cup 2023 and Gold Cup 2023: the International Results editions production
  served on 18 Nov 2026 (the coordinator's capture, phases-manquantes/capture/*-snapshot.json), through cups.save.
- The national teams marked by curated.national_teams; the site's season (2026/2027) created.
The database is dropped and created again; nothing else is touched.
"""
from datetime import datetime, timedelta, timezone
import hashlib
import json
import os
from pathlib import Path
import sys
from unittest.mock import patch

repo, dsn, capture, receipt_path = Path(sys.argv[1]), sys.argv[2], Path(sys.argv[3]), Path(sys.argv[4])
sys.path.insert(0, str(repo / "backend"))
import psycopg  # noqa: E402
from vega import sources  # noqa: E402
from vega.sources import cups, curated  # noqa: E402
from vega.store import Store, connect_local, migrate  # noqa: E402

AT = datetime(2026, 11, 18, 18, tzinfo=timezone.utc)
base, name = dsn.rsplit("/", 1)
assert name.startswith("vega_v2_") and ("127.0.0.1" in base or "localhost" in base), "a local vega_v2_* database only"
with psycopg.connect(base + "/postgres", autocommit=True) as admin:
    assert admin.info.server_version // 10000 == 18
    admin.execute(f'DROP DATABASE IF EXISTS "{name}" WITH (FORCE)')
    admin.execute(f'CREATE DATABASE "{name}"')
db = connect_local(dsn)
migrate(db)

fixture = repo / "backend/tests/fixtures/openfootball/editions.json"
editions = json.loads(fixture.read_text())["editions"]
scopes = {f"open-cups:{key}": timedelta(seconds=1) for key in editions}
preload = repo / "backend/tests/fake_openfootball_fetch.mjs"
with patch.dict(os.environ, {"NODE_OPTIONS": f"--import={preload.as_uri()}", "VEGA_TEST_OPENFOOTBALL": str(fixture)}), \
        patch.object(cups, "scopes", lambda now: scopes):
    runs = sources.run_due(db, None, AT, names={"openfootball"})
results = {scope: runs[("openfootball", scope)] for scope in scopes}

captured = {}
for key, season in (("copa-america", "2024"), ("afcon", "2023"), ("asian-cup", "2023"), ("gold-cup", "2023")):
    raw = (capture / f"{key}-snapshot.json").read_bytes()
    with db.transaction():
        written = cups.save(db, "nations-results", key, season, json.loads(raw), AT)
    captured[f"nations-results:{key}:{season}"] = {"sha256": hashlib.sha256(raw).hexdigest(), "written": written}
with db.transaction():
    national = curated.national_teams(db)
Store(db).season("2026/2027")

x = db.execute
counts = x("""SELECT split_part(cs.cup_key, ':', 1) || ':' || split_part(cs.cup_key, ':', 2), count(*),
                     count(*) FILTER (WHERE m.status = 'finished'), count(*) FILTER (WHERE m.status = 'canceled')
              FROM core.matches m JOIN core.competition_seasons cs ON cs.id = m.competition_season_id
              GROUP BY 1 ORDER BY 1""").fetchall()
finals = x("""SELECT cs.cup_key, h.name, a.name, m.home_score, m.away_score, m.status::text
              FROM core.matches m JOIN core.competition_seasons cs ON cs.id = m.competition_season_id
              JOIN core.rounds r ON r.id = m.round_id JOIN core.teams h ON h.id = m.home_team_id JOIN core.teams a ON a.id = m.away_team_id
              WHERE r.name = 'Final' AND cs.cup_key IN ('open-cups:world-cup-history:1982', 'open-cups:world-cup-history:1998')
              ORDER BY 1""").fetchall()
receipt = {
    "dsn": dsn, "at": AT.isoformat(), "fixture_sha256": hashlib.sha256(fixture.read_bytes()).hexdigest(),
    "scopes": results, "captured": captured, "national_teams_marked": national[0],
    "schema_last": x("SELECT max(version) FROM ops.schema_migrations").fetchone()[0],
    "matches": [list(r) for r in counts], "finals": [list(r) for r in finals],
    "nations": x("SELECT count(*) FROM core.teams WHERE is_national").fetchone()[0],
}
receipt_path.write_text(json.dumps(receipt, ensure_ascii=False, indent=2, default=str) + "\n")
print(json.dumps({k: receipt[k] for k in ("schema_last", "nations", "finals", "captured")}, ensure_ascii=False, default=str))
print("scopes not ok:", {k: v for k, v in results.items() if v != "ok"})
