from datetime import date, datetime
import re

RESERVE = re.compile(r"(?:\b(?:b|c|ii|iii)\b|\bu\s?-?(?:1[5-9]|2[0-3])\b|reserv|youth|juvenil|primavera|jong\b|academy)", re.I)

TRANSFER_KINDS = {"ACTIVE_LOAN_TRANSFER": "loan", "RETURNED_FROM_PREVIOUS_LOAN": "loan_return", "INTERNAL_TRANSFER": "internal"}

class Failed(Exception):
    """A request or a response that failed: the unit is tried again later."""

    def __init__(self, code, status=None):
        super().__init__(code)
        self.code, self.status = code, status

def _day(value):
    if not isinstance(value, str) or len(value) < 10:
        return None
    try:
        return date.fromisoformat(value[:10])
    except ValueError:
        return None

def _key(value):
    text = str(value) if value is not None and not isinstance(value, bool) else ""
    return text if re.fullmatch(r"[0-9]{1,10}", text) else None

def _money(money):
    if not isinstance(money, dict) or money.get("value") is None:
        return None
    try:
        value = int(money["value"])
    except (TypeError, ValueError):
        return None
    return value if value > 0 else None

def _container(data, key, kind=list):
    if not isinstance(data, dict):
        raise Failed("SCHEMA_CHANGED")
    value = data.get(key)
    if value is None:
        return kind()
    if not isinstance(value, kind):
        raise Failed("SCHEMA_CHANGED")
    return value

def transfer_kind(record):
    kind = (record.get("typeDetails") or {}).get("type") or ""
    if kind == "STANDARD":
        fee = (record.get("details") or {}).get("fee") or {}
        label = str(((fee.get("compact") or {}) if isinstance(fee, dict) else {}).get("content") or "").strip().lower()
        return "free" if label == "free transfer" else "transfer"
    return TRANSFER_KINDS.get(kind)

def parse_transfers(data):
    """The transfers of a history, pending ones included (marked)."""
    if data is None:
        return []
    history = _container(data, "history", dict)
    out = []
    for record in (history.get("pending") or []) + (history.get("terminated") or []):
        if not isinstance(record, dict) or not _key(record.get("id")):
            continue
        details = record.get("details") or {}
        source, target = record.get("transferSource") or {}, record.get("transferDestination") or {}
        out.append({
            "key": _key(record["id"]), "date": _day(details.get("date")), "season": (details.get("season") or {}).get("display"),
            "from": _key(source.get("clubId")), "to": _key(target.get("clubId")), "kind": transfer_kind(record),
            "fee": _money(details.get("fee")), "value": _money(details.get("marketValue")),
            "contract_until": _day(details.get("contractUntilDate")), "pending": bool(details.get("isPending")),
        })
    return out

def is_reserve(name):
    return bool(RESERVE.search(name or ""))
