from datetime import date, datetime
import re

RESERVE = re.compile(r"(?:\b(?:b|c|ii|iii)\b|\bu\s?-?(?:1[5-9]|2[0-3])\b|reserv|youth|juvenil|primavera|jong\b|academy)", re.I)

TRANSFER_KINDS = {"ACTIVE_LOAN_TRANSFER": "loan", "RETURNED_FROM_PREVIOUS_LOAN": "loan_return", "INTERNAL_TRANSFER": "internal"}

class Failed(Exception):
    """A request or a response that failed: the unit is tried again later."""

    def __init__(self, code, status=None):
        super().__init__(code)
        self.code, self.status = code, status

def _day(value):
    if not isinstance(value, str) or len(value) < 10:
        return None
    try:
        return date.fromisoformat(value[:10])
    except ValueError:
        return None

def _key(value):
    text = str(value) if value is not None and not isinstance(value, bool) else ""
    return text if re.fullmatch(r"[0-9]{1,10}", text) else None

def _money(money):
    if not isinstance(money, dict) or money.get("value") is None:
        return None
    try:
        value = int(money["value"])
    except (TypeError, ValueError):
        return None
    return value if value > 0 else None

def _container(data, key, kind=list):
    if not isinstance(data, dict):
        raise Failed("SCHEMA_CHANGED")
    value = data.get(key)
    if value is None:
        return kind()
    if not isinstance(value, kind):
        raise Failed("SCHEMA_CHANGED")
    return value

def _obj(value):
    return value if isinstance(value, dict) else {}

def _free(record):
    """A free transfer: its fee's label says so."""
    fee = _obj(_obj(record.get("details")).get("fee"))
    return str(_obj(fee.get("compact")).get("content") or "").strip().lower() == "free transfer"

def transfer_kind(record):
    kind = _obj(record.get("typeDetails")).get("type") or ""
    if kind == "STANDARD":
        return "free" if _free(record) else "transfer"
    return TRANSFER_KINDS.get(kind)

MOVE_FACTS = ("date", "season", "from", "to", "kind", "fee", "value", "contract_until")

MOVE_COLUMNS = {"date": "transfer_date", "season": "season_label", "kind": "kind", "fee": "fee_eur",
                "value": "market_value_eur", "contract_until": "contract_until"}

def _move(record, announced):
    """A move's facts as its record states them. The fee is a positive amount, or 0 for a free
    transfer (its label attests it; another 0 is no amount, as for the values). A move of the
    pending list, or marked pending, is announced."""
    details = _obj(record.get("details"))
    display = _obj(details.get("season")).get("display")
    fee = _money(details.get("fee"))
    move = {
        "key": _key(record["id"]), "date": _day(details.get("date")),
        "season": display.strip() if isinstance(display, str) and display.strip() else None,
        "from": _key(_obj(record.get("transferSource")).get("clubId")), "to": _key(_obj(record.get("transferDestination")).get("clubId")),
        "kind": transfer_kind(record), "fee": fee if fee is not None else (0 if _free(record) else None),
        "value": _money(details.get("marketValue")), "contract_until": _day(details.get("contractUntilDate")),
        "pending": announced or bool(details.get("isPending")),
    }
    move["stated"] = frozenset(f for f in MOVE_FACTS if move[f] is not None) | {"pending"}
    return move

def transfer_history(data):
    """The moves of a /transfer/history/player response, one per key, checked whole before
    anything is written; Failed when the response cannot be a whole history: no history object
    or none of its two lists (HISTORY_MISSING), a list or the history of another type
    (SCHEMA_CHANGED), an element without an object or a numeric id (HISTORY_INVALID), one key
    with two different stated facts (HISTORY_CONFLICT). The same move twice is one."""
    if not isinstance(data, dict):
        raise Failed("HISTORY_MISSING" if data is None else "SCHEMA_CHANGED")
    history = data.get("history")
    if history is None:
        raise Failed("HISTORY_MISSING")
    if not isinstance(history, dict):
        raise Failed("SCHEMA_CHANGED")
    lists = {name: history.get(name) for name in ("pending", "terminated")}
    if any(records is not None and not isinstance(records, list) for records in lists.values()):
        raise Failed("SCHEMA_CHANGED")
    if all(records is None for records in lists.values()):
        raise Failed("HISTORY_MISSING")
    moves = {}
    for name, records in lists.items():
        for record in records or []:
            if not isinstance(record, dict) or not _key(record.get("id")):
                raise Failed("HISTORY_INVALID")
            move, seen = _move(record, name == "pending"), moves.get(_key(record["id"]))
            if seen is not None:
                if any(seen[f] != move[f] for f in seen["stated"] & move["stated"]):
                    raise Failed("HISTORY_CONFLICT")
                move = {**seen, **{f: move[f] for f in move["stated"]}, "stated": seen["stated"] | move["stated"]}
            moves[move["key"]] = move
    return list(moves.values())

def parse_transfers(data):
    """The transfers of a history, pending ones included (marked); none for no response."""
    return [] if data is None else transfer_history(data)

def is_reserve(name):
    return bool(RESERVE.search(name or ""))
