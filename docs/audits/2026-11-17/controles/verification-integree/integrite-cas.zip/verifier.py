#!/usr/bin/env python3
"""Offline, stdlib-only verification of projections and actual Vega pure parsers.
Run: python3 -B verifier.py. No network, database, product checkout or writes.
"""
from pathlib import Path
import json,hashlib,datetime,re,collections,csv
P=Path(__file__).resolve().parent

def read(name):return json.loads((P/name).read_text())
def check(ok,why):
 if not ok:raise AssertionError(why)
def records(q):return [dict(zip(q['columns'],r)) for r in q['rows']]
def load_code(label):
 ns={};p=P/'code'/f'{label}-pure.py';exec(compile(p.read_text(),str(p),'exec'),ns);return ns

def main():
 manifest=read('manifest.json');actual={str(p.relative_to(P)) for p in P.rglob('*') if p.is_file() and p.name!='manifest.json'}
 check(actual==set(manifest['files']),'file inventory mismatch')
 for path,h in manifest['files'].items():check(hashlib.sha256((P/path).read_bytes()).hexdigest()==h,f'hash mismatch: {path}')
 prov=read('provenance.json');check(len(prov['captures'])==3,'three captures required')
 check(all(x['read_only']=='on' and not x['errors'] for x in prov['captures']),'capture error/read-write')
 a,b=load_code('deployed'),load_code('branch');t=read('data/transfers.json');candidate_ids=set(t['candidate_physical_ids']);pair_count=0;exact=0;fee_controls=0;different_contract_pairs=0
 for p in t['players']:
  data={'history':p['history']};old=a['parse_transfers'](data);new=b['parse_transfers'](data);db={r['source_key']:r for r in p['stored']}
  check(set(db)=={x['key'] for x in old}=={x['key'] for x in new},'native key set')
  for x in old:
   for target,key in [('transfer_date','date'),('from_provider_club','from'),('to_provider_club','to'),('kind','kind'),('fee_eur','fee'),('contract_until','contract_until'),('pending','pending')]:
    v=x[key].isoformat() if isinstance(x[key],datetime.date) else x[key];check(db[x['key']][target]==v,('RDS projection',p['player_id'],x['key'],target))
   exact+=1
  old_by={x['key']:x for x in old};raw={str(x['id']):x for x in p['history']['pending']+p['history']['terminated']}
  for x in new:
   if old_by[x['key']]['fee']!=x['fee']:
    check(old_by[x['key']]['fee'] is None and x['fee']==0 and raw[x['key']]['details']['fee']['compact']['content']=='Free Transfer','explicit free control');fee_controls+=1
  pair=[x for x in p['stored'] if x['id'] in candidate_ids];check(len(pair)==2,'candidate pair length');pair_count+=1
  check(pair[0]['source_key']!=pair[1]['source_key'],'keys must remain distinct')
  check(all(x['fee_eur'] is None and x['kind']=='internal' and x['transfer_date'].endswith('-07-01') for x in pair),'candidate date/fee/kind')
  if pair[0]['contract_until']!=pair[1]['contract_until']:
   different_contract_pairs+=1;check(p['player_id']==32850 and {x['contract_until'] for x in pair}=={None,'2028-06-30'},'contract counterexample')
  for x in pair:
   day=raw[x['source_key']]['details']['date'];check(a['_day'](day).isoformat()==x['transfer_date'],'calendar prefix retained')
   check(datetime.datetime.fromisoformat(day).astimezone(datetime.timezone.utc).date().isoformat()!=x['transfer_date'],'UTC conversion counterexample')
 check((exact,pair_count,fee_controls,different_contract_pairs)==(37,5,5,1),'transfer counts')
 q=read('data/queue.json');s=q['rows'];check(len(s)==len({x['player_key'] for x in s})==106,'106 profiles');check(len({x['club_key'] for x in s})==71,'71 clubs')
 check(all(x['canonical_player_id'] and x['profile_queue']['read_at'] is None and x['profile_queue']['attempts']==0 and x['profile_queue']['last_http_status'] is None and x['profile_queue']['error_code'] is None for x in s),'linked, queued, never read, no recorded attempt')
 counts=dict(collections.Counter(x['profile_queue']['priority'] for x in s));check(counts=={2:65,3:20,4:3,9:18},'priority histogram')
 # Exact numerical expression used by Reader.enqueue, using measured current season.
 check(all(min(9,max(1,2026-x['season_year']+1))==1 for x in s),'producer priority')
 for row in q['expected_priority']['rows']:check(row[:4]==[2026,2026,row[2],1],'priority RDS control')
 for label in ('deployed','branch'):
  snippets={x['name']:x['source'] for x in read(f'code/{label}-reader-excerpts.json')}
  check('ON CONFLICT DO NOTHING' in snippets['enqueue'] and 'min(least(9, greatest(1, %s - q.season_year + 1)))' in snippets['enqueue'],'actual producer expression')
  check('ORDER BY priority, array_position' in snippets['next_units'] and 'next_due_at <= now()' in snippets['next_units'],'actual eligibility and numerical order')
  check('pick_search(' in snippets['write_search'] and 'is_reserve' not in snippets['write_search'],'search path has no reserve check')
  check('is_current' in snippets['team_of'] and 'provider_link_conflicts' not in snippets['team_of'],'reader ignores historical team-conflict rows')
 c=read('data/conflicts.json');check(len(c['rows'])==3,'three conflicts')
 expected={'2440':(False,True),'75142':(False,True),'947':(True,False)}
 for r in c['rows']:
  key=r['conflict']['provider_key']
  for f in (a,b):check((f['is_reserve'](r['team_name']),f['is_reserve'](r['provider_club_name']))==expected[key],'reserve-name false positive/control')
 clubs={x['id']:x for x in read('sources/club-identities.json')['clubs']};check(clubs['75142']['baseDetails']['mainClubId']=='14602' and clubs['75142']['baseDetails']['clubTypeId']==3,'reserve distinct from parent')
 check(clubs['947']['baseDetails']['shortName']=='B.93' and clubs['2440']['baseDetails']['clubTypeId']==1,'first-team controls')
 exposure={r['kind']:r['rows'] for r in c['exposure']};check(list(exposure.values())==[27,6,3,4,0],'exposure counts')
 team=next(x for x in c['identity'] if x['id']==604);check(any(x['provider']=='transfermarkt' and x['provider_key']=='75142' and x['is_current'] for x in team['keys']),'reserve link remains active')
 fin=read('data/final.json');values=records(fin['queries']['reserve_values']);moves=records(fin['queries']['reserve_transfers']);check(len(values)==3 and all(x['visible_in_api_view'] and x['team_id']==604 for x in values),'three values visible in API SQL view')
 check(len(moves)==4 and all(x['to_provider_club']=='75142' and x['to_team_id']==604 and x['updated_at']>'2026-11-18 00:31:27' for x in moves),'four transfers attached after conflict timestamp')
 state=records(fin['queries']['state'])[0];check(state['paused_until'] is None and state['gave_up_at'] is None and state['blocks_in_row']==0,'current reader not paused')
 queue=records(fin['queries']['queue_current']);priority1={x['kind']:x for x in queue if x['priority']==1};check(priority1['transfers']['due']==8737 and priority1['profile']['due']==0,'current backlog ahead of profile priority 2+')
 check(max(x['latest_read'] or '' for x in queue if x['kind']=='profile')=='2026-11-18 06:32:01.368048+00:00','latest profile read')
 omd=read('data/open-matchday.json');check(len(omd['candidate_rows'])==8,'8 OMD rows')
 groups=collections.defaultdict(list)
 for r in omd['all_sources']:groups[(r['day'],r['lo'],r['hi'])].append(r)
 check(sorted(len(g) for g in groups.values())==[2,2,3,3],'all-source 3+3+2+2')
 only=[g for g in groups.values() if {r['source'] for r in g}=={'open_matchday'}];check(len(only)==2 and sum(map(len,only))==4,'OMD-only census 2 groups/4 rows')
 check({x['id']:x['elo_sides'] for x in omd['candidate_rows']}=={5345:0,5355:0,5374:0,5377:0,5475:2,5479:0,5494:0,5500:0},'physical dependency counts')
 sources=read('sources/open-matchday-projections.json');selected=[(s,r) for s in sources for r in s['selected']];check(len(selected)==8,'eight native aliases')
 for m in omd['candidate_rows']:
  for source,r in selected:
   if (r['date'],r['home'],r['away'])==(m['match']['played'],m['match']['home_team_name'],m['match']['away_team_name']):
    rawkey=m['edition']['cup_key'].removeprefix('open-matchday:')+':'+r['date']+'|'+r['home']+'|'+r['away'];check(any(x['provider_key']==rawkey for x in m['provider_ids']),'raw alias survives provider key');break
  else:raise AssertionError('native source row missing')
 official={x['key']:x for x in read('sources/official-snippets.json')};check('1-2' in official['toposs']['projection'][0] and official['toposs']['projection'][1]=='28 oktober 2026','independent club result');check('BOLDKLUBBEN AF 1893' in official['b93']['projection'][0] and 'B.93' in official['b93']['projection'][0],'official B93 identity')
 # Operator CSVs must describe the same projected facts, including physical identifiers.
 def csvrows(name):
  with (P/'operateur'/name).open(newline='') as stream:return list(csv.DictReader(stream))
 check({int(r['id']) for r in csvrows('transferts-candidats.csv')}==candidate_ids,'operator transfer IDs')
 check({r['provider_player_key'] for r in csvrows('affiliations-106.csv')}=={r['player_key'] for r in s},'operator squad IDs')
 check({int(r['id']) for r in csvrows('matchs-8.csv')}=={r['id'] for r in omd['candidate_rows']},'operator match IDs')
 check({int(r['id']) for r in csvrows('reserve-transfers.csv')}=={r['id'] for r in moves},'operator reserve transfer IDs')
 check({(int(r['player_id']),r['valued_at']) for r in csvrows('reserve-values.csv')}=={(r['player_id'],r['valued_at']) for r in values},'operator reserve valuation keys')
 check({r['provider_key'] for r in csvrows('liaisons-3.csv')}==set(expected),'operator conflict keys')
 result={'status':'PASS' ,'files':len(actual),'transfers_replayed':exact,'candidate_pairs':pair_count,'explicit_free_controls':fee_controls,'squad_profiles_pending':len(s),'reserve_values':len(values),'reserve_transfers':len(moves),'omd_rows_filtered_first':8,'omd_only_rows_grouped_all_sources':4,'limits':'Offline projected evidence and exact pure functions. No production write, no fresh HTTP request, no full Reader/DB E2E. Infinite starvation, independent existence of two transfers per pair, and legal transfer dates are unproved.'}
 print(json.dumps(result,ensure_ascii=False,indent=2))
if __name__=='__main__':main()
