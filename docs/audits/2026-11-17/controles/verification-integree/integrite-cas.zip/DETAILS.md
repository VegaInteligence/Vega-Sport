# Intégrité courante — contre-épreuve indépendante du 18 novembre 2026

Revue **gpt-6-astra / xhigh**, lecture seule. Trois captures RDS : **15:27:07, 15:32:03 et 15:37:01 UTC**, aucune erreur. Produit mesuré : `8018e0836ca0f32e8b2eb51fc2847154abff7f13`. Code de branche comparé : `773554b49a4b21bca80eac717714542f01755870`. Les corrections T3/T4 de branche ne sont pas réputées déployées. Aucun changement produit ou RDS.

| Signal | Qualification établie | Propriétaire |
|---|---|---|
| Cinq paires de transferts | Dix clés natives distinctes effectivement présentes dans le fournisseur. Pas de répétition d’une même clé ; fusion sur signature injustifiée. | **VI-31** : contrat du lecteur et clarification fournisseur ; VI-21 seulement pour alignement des clubs. |
| 106 affiliations sans profil brut | 106 joueurs canoniques liés, 71 clubs, saison 2026. Profils en queue mais jamais lus. Priorité demandée 1, conservée à 2–9. | **VI-31** : couverture et priorité de lecture. |
| Trois conflits fournisseur | Une liaison réserve/première active, deux faux positifs du détecteur de réserve, dont un conflit historique déjà suivi d’un lien correct. | **VI-21** : identité première/II et arbitrage des liens. |
| Deux groupes OMD au recensement global | Quatre lignes OMD seules ; le filtre OMD avant groupement ajoute deux paires DFB déjà accompagnées d’OpenLigaDB, soit huit lignes. | **VI-27** : clé d’ingestion issue des alias ; **VI-21** : adjudication et réparation des références sportives. |

## Transferts : conserver les identifiants natifs

| Joueur canonique | Clés Transfermarkt des mouvements | Date fournisseur | Extrémités fournisseur |
|---|---|---|---|
| Rafiki Saïd `16483` | `6570362 / 6570363` | 2015-07-01 | `100150 → 107750` |
| Dimitrije Šarić `28928` | `5224800 / 5227843` | 2024-07-01 | `98606 → 54866` |
| Aleksa Jelić `30364` | `5205075 / 5209013` | 2024-07-01 | `90882 → 44345` |
| Tobias Brenan `32850` | `5832597 / 5832599` | 2025-07-01 | `9268 → 1071` |
| Jovan Mrvaljević `33388` | `5224797 / 5227842` | 2024-07-01 | `98606 → 54866` |

Les cinq réponses `/transfer/history/player/{clé}` ont été lues entre 15:28:41 et 15:28:52 UTC. Le rejeu des fonctions pures Vega compare **37 mouvements aux 37 lignes RDS**, sans différence sur les faits testés ; les deux parseurs conservent les mêmes clés. Quatre paires ont les mêmes faits natifs hors identifiant/URL. Brenan porte une échéance absente sur l’une et **2028-06-30** sur l’autre : contre-exemple concret à la fusion automatique.

Le montant natif `-` signifie ici valeur non renseignée, pas zéro. Cinq mouvements témoins du même échantillon portent explicitement `Free Transfer` : branche = 0, produit mesuré = NULL. Les dates natives sont à minuit `+02:00` ; Vega conserve le jour civil annoncé. Une conversion UTC donnerait la veille. Ni ces dates conventionnelles ni la double clé ne prouvent deux opérations sportives juridiquement distinctes.

## Profils : retard mesuré, absence de promotion

`Reader.step → plan → enqueue` s’exécute après le plan horaire ; la dernière planification mesurée est **15:31:49 UTC**. Le producteur prend `max(season_id)` des matchs terminés, ici 2026, et demande `min(9,max(1,2026−saison+1))` : **1 pour tous les 106**. L’insertion `ON CONFLICT DO NOTHING` conserve les priorités déjà présentes : **65 × 2, 20 × 3, 3 × 4, 18 × 9**. Le producteur des joueurs déjà liés peut également créer ces entrées selon leur dernière saison jouée ; le créateur historique de chaque ligne n’est pas journalisé.

Tous les 106 ont `read_at=NULL`, zéro tentative, aucun HTTP/erreur enregistré et une échéance due depuis le 16 ou le 17 novembre. `next_units` choisit d’abord la priorité numérique, ensuite le type, puis l’échéance ; il ne réserve pas la priorité aux seuls profils. À 15:37, **8 737 transferts de priorité 1 sont dus**, contre zéro profil de priorité 1. Dernier profil lu **06:32:01**, dernier transfert **15:36:58** ; lecteur sans pause ni abandon enregistré. Un lot `profile` sélectionné peut ensuite inclure jusqu’à 100 profils dus, y compris de priorités inférieures : le relevé ne démontre donc pas que les 8 737 transferts devront tous finir avant chaque profil. Cela établit le retard et la non-promotion, **pas une famine permanente** ni une rupture de FK : le snapshot d’effectif brut n’exige pas encore de profil brut.

## Identité de réserve : affectation effective, aucune désaffectation constatée

`604`, Estudiantes de Río Cuarto, joue dans l’édition 45 de Liga Profesional. Sa clé actuelle Transfermarkt **75142** désigne **AA Estudiantes de Río Cuarto II**, avec `mainClubId=14602` et `clubTypeId=3` dans la réponse officielle. Le lien `club_search_squad`, preuve 6, est daté du **16/11 à 21:51:17 UTC**. Le conflit `reserve_side` est daté du **18/11 à 00:31:27 UTC** ; le lien reste actuel, sans quarantaine.

Le chemin `write_search → pick_search → _link` ne contrôle pas le statut de réserve. Le chemin de vote `link_clubs` écrit ensuite un conflit sans retirer le lien. `team_of` consulte directement la clé actuelle ; `attach_teams`, `write_values` et `write_transfers` la réutilisent. Les quatre transferts physiques **82621, 63313, 77477, 86811** portent encore `to_provider_club=75142, to_team_id=604`, avec mises à jour **11:17–13:38 UTC le 18/11**, après le conflit. Trois valeurs datées du **22/05 et du 17/09/2026** portent la même affectation. Les sept faits et leurs dates exactes sont dans `operateur/reserve-*.csv`.

Les trois valeurs sont présentes dans `api.player_market_values`. La route `/api/player-market-values` publie **date et montant**, sans club : l’affectation erronée du club dans le stockage est démontrée, son affichage par cette route ne l’est pas. Parmi les 27 profils bruts de la réserve, six sont liés ; **zéro contrat dans le prédicat ciblé**, et aucun club/terme de contrat publié pour ces six profils. Nous n’avons pas une trace d’événements permettant de reconstruire tous les changements antérieurs du lien.

Les deux autres conflits sont différents : `DC United / D.C. United` déclenche le motif isolé `c`, mais la clé 2440 est correctement liée depuis le 16/11 à 17:50, après le conflit de 14:30. `B 93` déclenche le motif isolé `b` ; la source donne clé 947, nom Boldklubben af 1893 et abréviation B.93, confirmée par les [statuts du club](https://b93.dk/klubben/om-klubben/vedtaegter/). Il n’existe pas de lien actif à 947 dans la capture. Ces faux positifs n’autorisent aucune liaison automatique.

## Open Matchday : mêmes équipes, clés physiques issues des alias

Les paires **5345/5355** et **5374/5377** sont dans l’édition DFB 321 et possèdent aussi les témoins OpenLigaDB **2729** et **2748**, édition 307. Voilà pourquoi le groupement global ne les classe pas parmi les groupes exclusivement OMD. Les deux autres paires, édition KNVB 322, sont **5475/5479**, PEC Zwolle–TOP Oss, 28/10, 1–2 ; et **5494/5500**, Go Ahead Eagles–TOP Oss, **01/12 futur**, sans résultat.

Les huit lignes existent dans le CSV fournisseur figé `13a434955de865f66f95a71937205a3a286488c6`, sous alias Soccerway/ESPN. Le collecteur bâtit sa clé avec date et noms bruts ; la résolution canonique ultérieure des clubs ne réunit pas ces clés. Le [compte rendu officiel de TOP Oss du 28 octobre](https://toposs.nl/nieuws/top-oss-stunt-in-zwolle-en-bekert-verder-na-1-2-overwinning-op-pec) corrobore le résultat 1–2. Les autres rencontres n’ont pas reçu ici de seconde validation d’organisateur. **5475 possède deux côtés Elo, 5479 aucun** : aucune suppression par signature ou choix arbitraire d’ID n’est justifiée. Les références doivent être inventoriées avant réparation ; aucun calendrier ou modèle VI-21 n’a été modifié.

Rejeu : `python3 -B verifier.py`. Il vérifie les empreintes, les fonctions pures exactes, les projections et les décomptes. Il ne constitue ni un E2E du writer complet ni une intervention sur la production. Les sources complètes personnelles restent privées ; les projections publiques et sportives, leurs SHA originels et leurs SHA de projection accompagnent le ZIP.
