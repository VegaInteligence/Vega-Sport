"""Bounded independent qualification of the four 15:20 integrity signals. Read only.
No product imports, source fetch, AWS, or write. Caps stop rather than silently truncate.
"""
def collect(db):
    with db.transaction():
        db.execute("SET TRANSACTION ISOLATION LEVEL REPEATABLE READ READ ONLY")
        at,snap,ro=db.execute("SELECT transaction_timestamp(),pg_current_snapshot()::text,current_setting('transaction_read_only')").fetchone();assert ro=='on'
        out={'version':'integrity-candidates-v1','at':str(at),'snapshot':snap,'read_only':ro,'queries':{},'errors':{}}
        def get(key,sql,args=(),cap=1000):
            try:
                with db.transaction():
                    cur=db.execute(sql,args or None);rows=cur.fetchall();assert len(rows)<=cap,(key,'over cap',cap)
                    out['queries'][key]={'sql':sql,'params':args,'columns':[c.name for c in cur.description],'rows':rows}
                return rows
            except Exception as e:
                out['errors'][key]={'type':type(e).__name__,'sqlstate':getattr(e,'sqlstate',None),'message':str(e)[:600],'sql':sql,'params':args};return []
        candidates=get('transfer_candidates',"""WITH x AS (
          SELECT t.*,count(*) OVER(PARTITION BY player_id,source,transfer_date,from_provider_club,to_provider_club,from_team_id,to_team_id,kind) AS same_fact_rows
          FROM core.player_transfers t WHERE transfer_date IS NOT NULL
          AND (from_team_id IS NOT NULL OR from_provider_club IS NOT NULL) AND (to_team_id IS NOT NULL OR to_provider_club IS NOT NULL))
          SELECT x.player_id,p.name AS player_name,p.birth_date,to_jsonb(x) AS transfer
          FROM x JOIN core.players p ON p.id=x.player_id WHERE same_fact_rows>1
          ORDER BY x.player_id,x.transfer_date,x.id LIMIT 201""",cap=200)
        players=sorted({r[0] for r in candidates})
        get('candidate_player_links',"SELECT entity_type,entity_id,provider,provider_key,is_current FROM core.provider_ids WHERE entity_type='player' AND entity_id=ANY(%s) ORDER BY entity_id,provider,provider_key",(players,))
        histories=get('candidate_transfer_histories',"SELECT to_jsonb(t) AS transfer FROM core.player_transfers t WHERE player_id=ANY(%s) ORDER BY player_id,transfer_date,id LIMIT 2001",(players,),cap=2000)
        get('candidate_profile_contracts',"""SELECT p.id,p.name,i.provider_key,to_jsonb(pp) AS provider_profile,
          (SELECT jsonb_agg(to_jsonb(c) ORDER BY start_date,team_id) FROM core.player_contracts c WHERE c.player_id=p.id) AS contracts
          FROM core.players p LEFT JOIN core.provider_ids i ON i.entity_type='player' AND i.entity_id=p.id AND i.provider='transfermarkt' AND i.is_current
          LEFT JOIN core.provider_players pp ON pp.provider=i.provider AND pp.provider_key=i.provider_key WHERE p.id=ANY(%s) ORDER BY p.id""",(players,))
        get('candidate_transfer_queue',"""SELECT to_jsonb(q) AS queue FROM ops.transfermarkt_reads q WHERE q.provider_key IN
          (SELECT provider_key FROM core.provider_ids WHERE entity_type='player' AND provider='transfermarkt' AND entity_id=ANY(%s))
          ORDER BY provider_key,kind""",(players,))
        get('transfer_endpoint_clubs',"""SELECT p.provider_key,p.name,p.country_key,p.is_national,p.read_on,i.entity_id,t.name AS canonical_name,t.merged_into
          FROM core.provider_clubs p LEFT JOIN core.provider_ids i ON i.entity_type='team' AND i.provider=p.provider AND i.provider_key=p.provider_key AND i.is_current
          LEFT JOIN core.teams t ON t.id=i.entity_id WHERE p.provider='transfermarkt' AND p.provider_key IN
          (SELECT from_provider_club FROM core.player_transfers WHERE player_id=ANY(%s) UNION SELECT to_provider_club FROM core.player_transfers WHERE player_id=ANY(%s))
          ORDER BY p.provider_key LIMIT 1001""",(players,players))
        get('squad_without_profile',"""SELECT s.provider,s.club_key,s.season_year,s.player_key,s.shirt_number,s.read_on,
          pc.name AS provider_club_name,ci.entity_id AS canonical_club_id,ct.name AS canonical_club_name,
          pi.entity_id AS canonical_player_id,cp.name AS canonical_player_name,to_jsonb(q) AS profile_queue
          FROM core.provider_squads s LEFT JOIN core.provider_clubs pc ON pc.provider=s.provider AND pc.provider_key=s.club_key
          LEFT JOIN core.provider_ids ci ON ci.entity_type='team' AND ci.provider=s.provider AND ci.provider_key=s.club_key AND ci.is_current
          LEFT JOIN core.teams ct ON ct.id=ci.entity_id
          LEFT JOIN core.provider_ids pi ON pi.entity_type='player' AND pi.provider=s.provider AND pi.provider_key=s.player_key AND pi.is_current
          LEFT JOIN core.players cp ON cp.id=pi.entity_id
          LEFT JOIN ops.transfermarkt_reads q ON q.kind='profile' AND q.provider_key=s.player_key
          WHERE NOT EXISTS(SELECT 1 FROM core.provider_players p WHERE p.provider=s.provider AND p.provider_key=s.player_key)
          ORDER BY s.provider,s.player_key,s.season_year,s.club_key LIMIT 501""",cap=500)
        get('conflicts',"""SELECT to_jsonb(c) AS conflict,t.name AS team_name,p.name AS player_name,
          (SELECT jsonb_agg(to_jsonb(i)) FROM core.provider_ids i WHERE i.entity_type=c.entity_type AND i.provider=c.provider AND (i.provider_key=c.provider_key OR i.entity_id=c.entity_id)) AS current_keys,
          (SELECT jsonb_agg(to_jsonb(l)) FROM ops.provider_links l WHERE l.entity_type=c.entity_type AND l.provider=c.provider AND (l.provider_key=c.provider_key OR l.entity_id=c.entity_id)) AS evidence_links,
          pc.name AS provider_club_name,pp.name AS provider_player_name
          FROM ops.provider_link_conflicts c LEFT JOIN core.teams t ON c.entity_type='team' AND t.id=c.entity_id
          LEFT JOIN core.players p ON c.entity_type='player' AND p.id=c.entity_id
          LEFT JOIN core.provider_clubs pc ON c.entity_type='team' AND pc.provider=c.provider AND pc.provider_key=c.provider_key
          LEFT JOIN core.provider_players pp ON c.entity_type='player' AND pp.provider=c.provider AND pp.provider_key=c.provider_key
          ORDER BY c.entity_type,c.provider,c.provider_key,c.entity_id LIMIT 51""",cap=50)
        matches=get('open_matchday_same_edition',"""WITH x AS (
          SELECT m.*,coalesce(m.match_date,(m.kickoff_at AT TIME ZONE 'UTC')::date) AS played,
          least(coalesce(h.merged_into,h.id),coalesce(a.merged_into,a.id)) AS lo,
          greatest(coalesce(h.merged_into,h.id),coalesce(a.merged_into,a.id)) AS hi
          FROM core.matches m JOIN core.teams h ON h.id=m.home_team_id JOIN core.teams a ON a.id=m.away_team_id
          WHERE m.source='open_matchday'), g AS (
          SELECT played,lo,hi FROM x WHERE played IS NOT NULL AND lo<>hi GROUP BY played,lo,hi HAVING count(*)>1 AND count(DISTINCT competition_season_id)=1)
          SELECT x.id,to_jsonb(x) AS match,h.name AS home,a.name AS away,to_jsonb(cs) AS edition,to_jsonb(r) AS round,
          (SELECT jsonb_agg(to_jsonb(i)) FROM core.provider_ids i WHERE i.entity_type='match' AND i.entity_id=x.id) AS provider_ids,
          (SELECT jsonb_agg(to_jsonb(s)) FROM core.team_match_stats s WHERE s.match_id=x.id) AS team_stats,
          (SELECT count(*) FROM core.match_events e WHERE e.match_id=x.id) AS events,
          (SELECT count(*) FROM agg.team_elo e WHERE e.match_id=x.id) AS elo_sides
          FROM x JOIN g USING(played,lo,hi) JOIN core.teams h ON h.id=x.home_team_id JOIN core.teams a ON a.id=x.away_team_id
          JOIN core.competition_seasons cs ON cs.id=x.competition_season_id LEFT JOIN core.rounds r ON r.id=x.round_id
          ORDER BY x.competition_season_id,x.played,x.id LIMIT 51""",cap=50)
        return out
