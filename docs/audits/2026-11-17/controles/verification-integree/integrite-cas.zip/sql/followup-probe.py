"""Read-only closure of the observed 8/4 grouping, queue priority and reserve-link exposure."""
def collect(db):
    with db.transaction():
        db.execute("SET TRANSACTION ISOLATION LEVEL REPEATABLE READ READ ONLY")
        at,snap,ro=db.execute("SELECT transaction_timestamp(),pg_current_snapshot()::text,current_setting('transaction_read_only')").fetchone();assert ro=='on'
        out={'version':'integrity-followup-v1','at':str(at),'snapshot':snap,'read_only':ro,'queries':{},'errors':{}}
        def get(k,sql,args=(),cap=500):
            try:
                with db.transaction():
                    cur=db.execute(sql,args or None);rows=cur.fetchall();assert len(rows)<=cap
                    out['queries'][k]={'sql':sql,'params':args,'columns':[c.name for c in cur.description],'rows':rows}
            except Exception as e:out['errors'][k]={'sql':sql,'params':args,'sqlstate':getattr(e,'sqlstate',None),'message':str(e)[:300]}
        get('queue_expected_priority',"""WITH current AS (SELECT max(season_id) AS season FROM core.matches WHERE status='finished'),
          missing AS(SELECT s.*,q.priority,q.read_at,q.next_due_at,least(9,greatest(1,c.season-s.season_year+1)) AS squad_priority,c.season AS current_season
          FROM core.provider_squads s CROSS JOIN current c LEFT JOIN ops.transfermarkt_reads q ON q.kind='profile' AND q.provider_key=s.player_key
          WHERE NOT EXISTS(SELECT 1 FROM core.provider_players p WHERE p.provider=s.provider AND p.provider_key=s.player_key))
          SELECT current_season,season_year,priority,squad_priority,count(*),count(*) FILTER(WHERE read_at IS NULL),min(next_due_at),max(next_due_at)
          FROM missing GROUP BY 1,2,3,4 ORDER BY 3""")
        get('four_pairs_all_sources',"""WITH w(day,lo,hi) AS(VALUES ('2026-08-22'::date,4991,5065),('2026-10-27'::date,4806,5065),
          ('2026-10-28'::date,941,5079),('2026-12-01'::date,941,5084))
          SELECT w.day,w.lo,w.hi,m.id,m.source,m.competition_season_id,cs.cup_key,cs.archive_key,m.status,m.home_team_id,m.away_team_id,m.home_score,m.away_score
          FROM w JOIN core.matches m ON coalesce(m.match_date,(m.kickoff_at AT TIME ZONE 'UTC')::date)=w.day
          JOIN core.teams h ON h.id=m.home_team_id JOIN core.teams a ON a.id=m.away_team_id
          JOIN core.competition_seasons cs ON cs.id=m.competition_season_id
          WHERE least(coalesce(h.merged_into,h.id),coalesce(a.merged_into,a.id))=w.lo AND greatest(coalesce(h.merged_into,h.id),coalesce(a.merged_into,a.id))=w.hi
          ORDER BY w.day,m.source,m.id""")
        get('three_teams_identity',"""SELECT t.id,t.name,t.country_code,t.is_national,t.merged_into,
          (SELECT jsonb_agg(to_jsonb(i)) FROM core.provider_ids i WHERE i.entity_type='team' AND i.entity_id=t.id) AS keys,
          (SELECT jsonb_agg(DISTINCT jsonb_build_object('competition_id',c.id,'competition',c.name,'edition',cs.id,'cup_key',cs.cup_key,'archive_key',cs.archive_key))
           FROM core.matches m JOIN core.competition_seasons cs ON cs.id=m.competition_season_id JOIN core.competitions c ON c.id=cs.competition_id
           WHERE m.season_id=2026 AND (m.home_team_id=t.id OR m.away_team_id=t.id)) AS competitions
          FROM core.teams t WHERE t.id IN(604,4748,5336) ORDER BY t.id""")
        get('reserve_link_exposure',"""SELECT 'provider_profiles_at_75142' AS kind,count(*) AS rows FROM core.provider_players WHERE provider='transfermarkt' AND provider_club='75142'
          UNION ALL SELECT 'linked_player_profiles_at_75142',count(*) FROM core.provider_players p JOIN core.provider_ids i ON i.entity_type='player' AND i.provider=p.provider AND i.provider_key=p.provider_key AND i.is_current WHERE p.provider='transfermarkt' AND p.provider_club='75142'
          UNION ALL SELECT 'market_value_rows_75142_to_604',count(*) FROM core.player_market_values WHERE source='transfermarkt' AND provider_club='75142' AND team_id=604
          UNION ALL SELECT 'transfer_rows_75142_to_604',count(*) FROM core.player_transfers WHERE source='transfermarkt' AND ((from_provider_club='75142' AND from_team_id=604) OR (to_provider_club='75142' AND to_team_id=604))
          UNION ALL SELECT 'contracts_604_for_profiles_75142',count(*) FROM core.player_contracts c JOIN core.provider_ids i ON i.entity_type='player' AND i.provider='transfermarkt' AND i.entity_id=c.player_id AND i.is_current JOIN core.provider_players p ON p.provider=i.provider AND p.provider_key=i.provider_key WHERE c.source='transfermarkt' AND c.team_id=604 AND p.provider_club='75142'""")
        get('reserve_link_player_examples',"""SELECT i.entity_id AS player_id,p.provider_key,p.name,p.birth_date,p.joined_on,p.contract_until,p.read_on,
          a.contract_team,a.contract_until AS published_contract_until,a.observed_contract_team,a.observed_contract_until
          FROM core.provider_players p JOIN core.provider_ids i ON i.entity_type='player' AND i.provider=p.provider AND i.provider_key=p.provider_key AND i.is_current
          LEFT JOIN api.player_profiles a ON a.player_id=i.entity_id WHERE p.provider='transfermarkt' AND p.provider_club='75142' ORDER BY i.entity_id LIMIT 51""",cap=50)
        return out
