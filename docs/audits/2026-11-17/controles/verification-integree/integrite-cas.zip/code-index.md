# Repères du code figé

## deployed 8018e0836ca0f32e8b2eb51fc2847154abff7f13

- [current_season](https://github.com/VegaInteligence/Vega-Sport/blob/8018e0836ca0f32e8b2eb51fc2847154abff7f13/backend/vega/transfermarkt.py#L502) : lignes 502–503.
- [plan](https://github.com/VegaInteligence/Vega-Sport/blob/8018e0836ca0f32e8b2eb51fc2847154abff7f13/backend/vega/transfermarkt.py#L505) : lignes 505–519.
- [_link](https://github.com/VegaInteligence/Vega-Sport/blob/8018e0836ca0f32e8b2eb51fc2847154abff7f13/backend/vega/transfermarkt.py#L521) : lignes 521–533.
- [link_clubs](https://github.com/VegaInteligence/Vega-Sport/blob/8018e0836ca0f32e8b2eb51fc2847154abff7f13/backend/vega/transfermarkt.py#L544) : lignes 544–587.
- [attach_teams](https://github.com/VegaInteligence/Vega-Sport/blob/8018e0836ca0f32e8b2eb51fc2847154abff7f13/backend/vega/transfermarkt.py#L589) : lignes 589–599.
- [quarantine](https://github.com/VegaInteligence/Vega-Sport/blob/8018e0836ca0f32e8b2eb51fc2847154abff7f13/backend/vega/transfermarkt.py#L637) : lignes 637–650.
- [enqueue](https://github.com/VegaInteligence/Vega-Sport/blob/8018e0836ca0f32e8b2eb51fc2847154abff7f13/backend/vega/transfermarkt.py#L652) : lignes 652–712.
- [next_units](https://github.com/VegaInteligence/Vega-Sport/blob/8018e0836ca0f32e8b2eb51fc2847154abff7f13/backend/vega/transfermarkt.py#L716) : lignes 716–729.
- [team_of](https://github.com/VegaInteligence/Vega-Sport/blob/8018e0836ca0f32e8b2eb51fc2847154abff7f13/backend/vega/transfermarkt.py#L756) : lignes 756–760.
- [write_search](https://github.com/VegaInteligence/Vega-Sport/blob/8018e0836ca0f32e8b2eb51fc2847154abff7f13/backend/vega/transfermarkt.py#L852) : lignes 852–883.
- [write_values](https://github.com/VegaInteligence/Vega-Sport/blob/8018e0836ca0f32e8b2eb51fc2847154abff7f13/backend/vega/transfermarkt.py#L961) : lignes 961–979.
- [write_transfers](https://github.com/VegaInteligence/Vega-Sport/blob/8018e0836ca0f32e8b2eb51fc2847154abff7f13/backend/vega/transfermarkt.py#L981) : lignes 981–997.
- [step](https://github.com/VegaInteligence/Vega-Sport/blob/8018e0836ca0f32e8b2eb51fc2847154abff7f13/backend/vega/transfermarkt.py#L1030) : lignes 1030–1051.
## branch 773554b49a4b21bca80eac717714542f01755870

- [current_season](https://github.com/VegaInteligence/Vega-Sport/blob/773554b49a4b21bca80eac717714542f01755870/backend/vega/transfermarkt.py#L595) : lignes 595–596.
- [plan](https://github.com/VegaInteligence/Vega-Sport/blob/773554b49a4b21bca80eac717714542f01755870/backend/vega/transfermarkt.py#L598) : lignes 598–612.
- [_link](https://github.com/VegaInteligence/Vega-Sport/blob/773554b49a4b21bca80eac717714542f01755870/backend/vega/transfermarkt.py#L614) : lignes 614–626.
- [link_clubs](https://github.com/VegaInteligence/Vega-Sport/blob/773554b49a4b21bca80eac717714542f01755870/backend/vega/transfermarkt.py#L637) : lignes 637–680.
- [attach_teams](https://github.com/VegaInteligence/Vega-Sport/blob/773554b49a4b21bca80eac717714542f01755870/backend/vega/transfermarkt.py#L682) : lignes 682–692.
- [quarantine](https://github.com/VegaInteligence/Vega-Sport/blob/773554b49a4b21bca80eac717714542f01755870/backend/vega/transfermarkt.py#L730) : lignes 730–743.
- [enqueue](https://github.com/VegaInteligence/Vega-Sport/blob/773554b49a4b21bca80eac717714542f01755870/backend/vega/transfermarkt.py#L745) : lignes 745–805.
- [next_units](https://github.com/VegaInteligence/Vega-Sport/blob/773554b49a4b21bca80eac717714542f01755870/backend/vega/transfermarkt.py#L809) : lignes 809–822.
- [team_of](https://github.com/VegaInteligence/Vega-Sport/blob/773554b49a4b21bca80eac717714542f01755870/backend/vega/transfermarkt.py#L849) : lignes 849–853.
- [write_search](https://github.com/VegaInteligence/Vega-Sport/blob/773554b49a4b21bca80eac717714542f01755870/backend/vega/transfermarkt.py#L945) : lignes 945–977.
- [write_values](https://github.com/VegaInteligence/Vega-Sport/blob/773554b49a4b21bca80eac717714542f01755870/backend/vega/transfermarkt.py#L1125) : lignes 1125–1143.
- [write_transfers](https://github.com/VegaInteligence/Vega-Sport/blob/773554b49a4b21bca80eac717714542f01755870/backend/vega/transfermarkt.py#L1145) : lignes 1145–1199.
- [step](https://github.com/VegaInteligence/Vega-Sport/blob/773554b49a4b21bca80eac717714542f01755870/backend/vega/transfermarkt.py#L1255) : lignes 1255–1276.
