# Contre-épreuve intégrité — capsule opérateur

Lire **[integrite-cas.md](integrite-cas.md)**. Python 3.10+ standard uniquement, sans réseau, base de données ni checkout produit :

```sh
python3 -B verifier.py
```

Résultat attendu : PASS ; 37 transferts rejoués, cinq paires, cinq témoins de gratuité explicite, 106 profils en attente, trois valeurs et quatre transferts affectés à une clé de réserve, huit lignes OMD dont quatre restent dans les groupes exclusivement OMD.

- `operateur/` : tableaux CSV utilisables pour l’arbitrage, avec IDs physiques/canoniques et clés fournisseur. Aucune instruction de fusion ou de mutation.
- `data/` : projections RDS sportives des trois captures en lecture seule ; elles ne contiennent ni date de naissance, âge, coordonnées, adresse, ni données d’authentification.
- `sources/` : projections des réponses publiques Transfermarkt et du CSV OMD ; extraits minimaux TOP Oss et B.93. SHA des réponses HTTP complètes conservés, sans embarquer leurs pieds de page ou profils complets.
- `code/` : fonctions pures exactes extraites des commits indiqués et extraits de lecteurs ; fichiers source complémentaires figés. Aucune dépendance au checkout courant. Le vérificateur exécute seulement les fonctions pures.
- `sql/` : sondes originales en lecture seule destinées au transport de l’opérateur. Leur sortie brute complète est privée ; ne pas la partager sans projection.
- `provenance.json` et `manifest.json` : origine, délimitations et SHA-256 de tous les fichiers livrés. Les SHA d’originaux omis ne permettent pas à eux seuls de reconstituer ou d’authentifier leurs octets hors du dossier privé.

Le replay n’appelle aucun transport AWS ou HTTP et ne modifie aucun fichier. Il ne démontre pas une famine permanente, deux opérations sportives distinctes par paire de transferts, une date juridique de mutation, ni l’affichage HTTP de toutes les colonnes RDS. Les clichés sont successifs, pas une transaction commune. Le traitement des défauts appartient aux propriétaires indiqués dans la synthèse.
