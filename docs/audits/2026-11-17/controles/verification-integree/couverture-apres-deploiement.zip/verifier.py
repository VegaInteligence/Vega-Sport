"""Verify frozen ECS/RDS evidence, recalculate both grids and replay the cell comparison offline."""
import gzip
import hashlib
import json
from pathlib import Path
import shutil
import subprocess
import sys
import tempfile

ROOT = Path(__file__).resolve().parent


def run(*parts):
    subprocess.run([sys.executable, "-B", *(str(p) for p in parts)], check=True)


def compare_files(actual, reference, names):
    for name in names:
        assert (actual/name).read_bytes() == (reference/name).read_bytes(), name


with tempfile.TemporaryDirectory(prefix="vega-releve-rds-") as tmp:
    wh = Path(tmp)
    manifest = json.loads((ROOT/"empreintes.json").read_bytes())
    for name, expected in manifest.items():
        assert hashlib.sha256((ROOT/name).read_bytes()).hexdigest() == expected, name
    for folder, response in (("reference-1555", "source-1555"), ("releve-rds", "source-apres")):
        raw = wh/folder
        shutil.copytree(ROOT/folder, raw)
        run(raw/"scores/build-score-grid.py")
        run(raw/"verify_grid.py")
        compare_files(raw/"scores",ROOT/folder/"scores",(
          "coverage-by-edition-and-entity.csv","coverage-by-season-and-entity.csv","grid-validation.json"))
        run(ROOT/"calculer.py",raw,wh/response)
        for name in ("scores-par-edition.csv.gz", "scores-par-saison.csv.gz"):
            assert gzip.decompress((wh/response/name).read_bytes()) == gzip.decompress((ROOT/response/name).read_bytes()), name
        summaries = [json.loads((root/response/"resultats.json").read_bytes()) for root in (wh, ROOT)]
        for s in summaries:
            s.pop("output_sha256")
        assert summaries[0] == summaries[1]
    run(ROOT/"comparer.py",wh/"reference-1555",wh/"releve-rds",ROOT/"source-1555",ROOT/"source-apres",wh/"comparaison")
    compare_files(wh/"comparaison",ROOT/"comparaison",[p.name for p in (ROOT/"comparaison").iterdir()])
pulse=subprocess.check_output([sys.executable, "-B", str(ROOT/"suivi-elo.py")])
assert pulse == (ROOT/"suivi-elo.json").read_bytes()
print(f"Vérifié hors ligne · {len(manifest)} fichiers · deux panoramas et comparaison")
