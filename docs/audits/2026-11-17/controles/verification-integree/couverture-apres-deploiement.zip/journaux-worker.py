"""Keep only typed operational evidence from the currently observed worker's log stream."""
from datetime import datetime, timezone
import json
from pathlib import Path
import re
import subprocess

base = Path(__file__).resolve().parent
receipt = json.loads((base/"releve-rds/receipt.json").read_bytes())
aws = ["aws","--profile","statarena","--region","us-east-2","--output","json"]


def read(*parts):
    return json.loads(subprocess.check_output(aws + list(parts)))


live = read("ecs","describe-tasks","--cluster","vega-v2","--tasks",receipt["worker_task"])["tasks"][0]
worker = live["containers"][0]
assert worker["imageDigest"] == receipt["image_digest"] and worker["image"] == receipt["image"]
definition = read("ecs","describe-task-definition","--task-definition",live["taskDefinitionArn"],
                  "--query","taskDefinition.containerDefinitions[0].{name:name,options:logConfiguration.options}")
opts = definition["options"]
stream = f"{opts['awslogs-stream-prefix']}/{definition['name']}/{live['taskArn'].rsplit('/',1)[1]}"
time_args = ["--start-time",str(int(datetime.fromisoformat(live["startedAt"]).timestamp()*1000))]
lines = []
pagination = []
token = None
for _ in range(8):
    p = read("logs","get-log-events","--log-group-name",opts["awslogs-group"],"--log-stream-name",stream,
             "--start-from-head",*time_args,*(["--next-token",token] if token else []))
    for event in p["events"]:
        line = event["message"]
        if re.search(r"\b(day|daily|elo|models|power|nations-league|world-cup-history|vega_v2)\b",line,re.I) and len(line) < 450:
            if re.search(r"(?i)authorization|password|token\s*[:=]|credential|secret",line):
                continue
            lines.append({"at":datetime.fromtimestamp(event["timestamp"]/1000,timezone.utc).isoformat(),"line":line})
    cursor = p["nextForwardToken"]
    pagination.append(len(p["events"]))
    if cursor == token:
        break
    token = cursor
else:
    raise ValueError("Operational log pagination did not converge")
result={"task":live["taskArn"],"worker_started_at":live["startedAt"],"image_digest":worker["imageDigest"],
        "captured_at":datetime.now(timezone.utc).isoformat(),"pagination":pagination,"events":lines}
(base/"journaux-worker.json").write_text(json.dumps(result,indent=2)+"\n")
print(len(lines),pagination)
