"""Reconcile the exact Elo gate, persisted scores, and queue evidence in three captures."""
from collections import Counter, defaultdict
import json
from pathlib import Path

from comparer import capture_validation, read_json, sql_index

HERE = Path(__file__).resolve().parent
BEFORE = HERE/"reference-1555"
AFTER = HERE/"releve-rds"
PULSE = HERE/"suivi-rds"
KEYS = ("structurally_admissible","matched_copy","expected_sides","stored_valid","missing","invalid")
captures = (BEFORE, AFTER, PULSE)
receipts = [capture_validation(s) for s in captures]
assert receipts[1]["image_digest"] == receipts[2]["image_digest"]
assert receipts[1]["inputs"] == receipts[2]["inputs"]
snapshots = [r["common_snapshot"] for r in receipts]
assert sorted(s["at"] for s in snapshots) == [s["at"] for s in snapshots]
assert len({s["snapshot"] for s in snapshots}) == 3


def rows(folder):
    path = folder/"db/team_exact/team-exact.json"
    return {r["edition_id"]:r for r in sql_index(path) if r["entity_type"]=="national team"}


def counts(editions):
    return {k:sum(r[k] for r in editions.values()) for k in KEYS}


older, updated, pulse = map(rows, captures)
assert updated == pulse
parts = defaultdict(Counter)
fixture_delta = read_json(HERE/"comparaison/comparaison.json")["fixtures"]["edition_rows_changed"]
for edition in fixture_delta:
    eid, key = edition["edition_id"], edition["cup_key"]
    before, after = older.get(eid, {}), updated.get(eid, {})
    scope = "mondial-openfootball" if key.startswith("open-cups:world-cup-history:") else "ligue-nations"
    dest = parts[scope]
    dest.update({"editions":1,"finished_delta":edition["finished_delta"],"recorded_delta":edition["recorded_matches_delta"]})
    for metric in KEYS:
        dest[metric] += after.get(metric,0) - before.get(metric,0)
assert set(parts) == {"mondial-openfootball","ligue-nations"}
for key in KEYS:
    assert sum(s[key] for s in parts.values()) == counts(updated)[key] - counts(older)[key]
assert parts["mondial-openfootball"]["matched_copy"] == updated[292]["matched_copy"] - older[292]["matched_copy"]
table = lambda t: sql_index(PULSE/f"db/pulse/pulse-{t}.json")
publications = table("publication")
markings = table("marquages")
activity = table("activite")
ingestion = table("ingestion")
native = table("native")
assert len(ingestion) == len(fixture_delta)
assert {r["edition_id"] for r in ingestion} == {r["edition_id"] for r in fixture_delta}
assert all(r["status"]=="ok" and r["archive_key"] is None for r in ingestion)
assert publications[0]["status"] == "published"
result = {"snapshots":snapshots,"nations":[counts(s) for s in (older,updated,pulse)],
          "deltas":dict(parts),"latest_elo_publication":publications[0],
          "elo_runs_running_rows":[r for r in publications if r["status"]=="running"], "visible_database_activity":activity,
          "dirty_marks":markings,"native_trigger":native,"source_ingestion":ingestion,
          "elo_model_inputs_identical_through_followup":updated==pulse}
print(json.dumps(result,ensure_ascii=False,indent=2,sort_keys=True))
