"""Replay only the bounded Elo gate and five small diagnostics."""
from pathlib import Path
from types import ModuleType

here = Path(__file__).resolve().parent
original = here / "capture.py"
script = original.read_text()
start = script.index("for src in sorted((prior/'db').rglob('*.sql')):")
end = script.index("for src in ['scores/team_exact.py'", start)
script = script[:start] + """for src in sorted(here.glob('pulse-*.sql')):
    add(src,'pulse')
baseline=json.loads((prior/'receipt.json').read_bytes())
queries={key:normalize(path) for key,path in sorted(query_files.items())}
""" + script[end:]
start = script.index("    for script,log in")
end = script.index("finally:", start)
script = script[:start] + """    print(snap,flush=True)
""" + script[end:]
script = script.replace("vega-audit-readonly-vi27", "vega-audit-readonly-vi27")
unit = ModuleType("transient_pulse")
unit.__file__ = str(original)
exec(compile(script, str(original), "exec"), unit.__dict__)
