"""Prepare and run a pinned RDS score census with one MVCC snapshot, then verify every result."""
import argparse,base64,csv,datetime,hashlib,json,os,re,shutil,subprocess,sys,time,zlib
from pathlib import Path
here=Path(__file__).resolve().parent
root=here.parents[2]
sys.path.insert(0,str(root))
from query_batch import aws
aws_transport=aws
def aws(*args):
    # Log operation names; credentials and service/override JSON stay in the existing ECS transport.
    with (here/'transport.log').open('a') as log:
        print(datetime.datetime.now(datetime.timezone.utc).isoformat(), *args[:2], file=log)
    return aws_transport(*args)
def sha(data):return hashlib.sha256(data).hexdigest()
def encode(data):return repr(base64.b64encode(zlib.compress(data,9)).decode())
def dump(path,value):path.write_text(json.dumps(value,indent=2,ensure_ascii=False)+'\n')
def normalize(path):
    sql=re.sub(r'--[^\n]*','',path.read_text()).strip().rstrip(';')
    if not re.match(r'(?i)^(select|with)\b',sql) or ';' in sql or re.search(r'(?i)\b(insert|delete|update|truncate|alter|drop|create|pg_sleep|pg_terminate_backend|__season_id__)\b',sql):raise ValueError(path)
    return sql
a=argparse.ArgumentParser();a.add_argument('destination',type=Path);a.add_argument('--prepare-only',action='store_true');a.add_argument('--after',type=datetime.datetime.fromisoformat);args=a.parse_args()
if args.after:
    if args.after.tzinfo is None:raise ValueError('Use an explicit time zone')
    while (remaining:=(args.after-datetime.datetime.now(datetime.timezone.utc)).total_seconds())>0:time.sleep(min(30,remaining))
out=args.destination.resolve();out.mkdir(exist_ok=False,parents=True)
prior=here/'reference-1555'
live_source=here/'fixture-universe.sql'
query_files={}
def add(path,group):
    key=path.stem
    assert key not in query_files,key
    local=out/'db'/group/path.name;local.parent.mkdir(exist_ok=True,parents=True)
    shutil.copyfile(path,local);query_files[key]=local
for src in sorted((prior/'db').rglob('*.sql')):
    add(src,src.parent.name)
queries={key:normalize(path) for key,path in sorted(query_files.items())}
baseline=json.loads((prior/'receipt.json').read_bytes())
assert {k:sha(v.encode()) for k,v in queries.items()}==baseline['query_sha256']
add(live_source,'audit')
queries[live_source.stem]=normalize(live_source)
for src in ['scores/team_exact.py','scores/build-score-grid.py','verify_grid.py']:
    dst=out/src;dst.parent.mkdir(exist_ok=True);shutil.copyfile(prior/src,dst)
code=(here/'probe.py').read_text().replace('FROZEN_QUERIES',encode(json.dumps(queries).encode())).replace('FROZEN_TEAM_PROBE',encode((out/'scores/team_exact.py').read_bytes()))
compile(code,'<rds-score-census>','exec')
receipt={'query_sha256':{k:sha(v.encode()) for k,v in queries.items()},'probe_sha256':sha(code.encode()),'probe_bytes':len(code.encode()),'local_harness_sha256':sha(Path(__file__).read_bytes()),'inputs':{name:sha((out/name).read_bytes()) for name in ('scores/team_exact.py','scores/build-score-grid.py','verify_grid.py')}}
rec=out/'receipt.json';dump(rec,receipt)
assert receipt['inputs']==baseline['inputs']
(out/'probe.executed.py').write_text(code)
if args.prepare_only:
    print(len(queries),len(code.encode()),'prepared and compiled');sys.exit(0)
release='b2e6dd82d36a2ca0f439ec84bf2e5dbbcd3013d9'
cluster='vega-v2'
svc=aws('ecs','describe-services','--cluster',cluster,'--services','vega-v2-worker')['services'][0]
tasks=aws('ecs','list-tasks','--cluster',cluster,'--service-name','vega-v2-worker','--desired-status','RUNNING')['taskArns']
live=next(t for t in aws('ecs','describe-tasks','--cluster',cluster,'--tasks',*tasks)['tasks'] if t['lastStatus']=='RUNNING' and t['taskDefinitionArn']==svc['taskDefinition'])
image=live['containers'][0]['image'];digest=live['containers'][0]['imageDigest'];assert image.rsplit(':',1)[1]==release and digest.startswith('sha256:')
diag=aws('ecs','describe-task-definition','--task-definition','vega-v2-diagnose')['taskDefinition']
allowed=('networkMode','taskRoleArn','executionRoleArn','containerDefinitions','volumes','placementConstraints','requiresCompatibilities','cpu','memory','runtimePlatform','ephemeralStorage')
spec={k:diag[k] for k in allowed if k in diag};cn=spec['containerDefinitions'][0];assert len(spec['containerDefinitions'])==1 and cn['entryPoint']==['python','-c']
cn['image']=image;cn['command']=[code];spec['family']='vega-audit-readonly-vi27'
receipt.update(worker_task=live['taskArn'],worker_definition=svc['taskDefinition'],
               worker_started_at=live.get('startedAt'),release=release)
assert svc['runningCount']>=1 and any(d['status']=='PRIMARY' and d['rolloutState']=='COMPLETED' for d in svc['deployments'])
dump(rec,receipt)
definition=aws('ecs','register-task-definition','--cli-input-json',json.dumps(spec))['taskDefinition']['taskDefinitionArn']
receipt.update(image=image,running_digest=digest,definition=definition);dump(rec,receipt)
try:
    launched=aws('ecs','run-task','--cluster',cluster,'--task-definition',definition,'--launch-type','FARGATE','--started-by','vega-audit-vi27','--network-configuration',json.dumps(svc['networkConfiguration']))
    if launched['failures']:raise RuntimeError(launched['failures'])
    task=launched['tasks'][0]['taskArn'];receipt['task']=task;dump(rec,receipt)
    for _ in range(125):
        state=aws('ecs','describe-tasks','--cluster',cluster,'--tasks',task)['tasks'][0]
        if state['lastStatus']=='STOPPED':break
        time.sleep(8)
    else:raise RuntimeError('Read task still active, inspect task receipt')
    actual=state['containers'][0];receipt.update(exit_code=actual.get('exitCode'),image_digest=actual.get('imageDigest'),start=state.get('startedAt'),end=state.get('stoppedAt'),stop_reason=state.get('stoppedReason'));dump(rec,receipt)
    assert actual.get('imageDigest')==digest
    opt=cn['logConfiguration']['options'];stream=opt['awslogs-stream-prefix']+'/'+cn['name']+'/'+task.split('/')[-1]
    for _ in range(6):
        logs=aws('logs','get-log-events','--log-group-name',opt['awslogs-group'],'--log-stream-name',stream,'--start-from-head')
        lines=[event['message'] for event in logs['events']]
        if 'COVER_COMPLETE' in lines or actual['exitCode']!=0:break
        time.sleep(4)
    if actual['exitCode']!=0 or 'COVER_COMPLETE' not in lines:
        raise ValueError([s[:350] for s in lines if not s.startswith(('COVER ','DIGEST '))][-10:])
    chunks={};witness={}
    for s in lines:
        if s.startswith('COVER '):
            _,k,offset,content=s.split(' ',3);chunks.setdefault(k,{})[int(offset)]=content
        if s.startswith('DIGEST '):
            _,k,d=s.split(' ',2);witness[k]=d
    assert chunks.keys()==witness.keys()==set(queries)|{'team-exact','snapshot'}
    for k,parts in chunks.items():
        raw=zlib.decompress(base64.b64decode(''.join(parts[i] for i in sorted(parts))));assert sha(raw)==witness[k]
        result=json.loads(raw)
        if k=='snapshot':path=out/'snapshot.json'
        elif k=='team-exact':path=out/'db/team_exact/team-exact.json';path.parent.mkdir()
        else:path=query_files[k].with_suffix('.json')
        dump(path,result)
    snap=json.loads((out/'snapshot.json').read_bytes())
    for path in (out/'db').rglob('*.json'):
        row=json.loads(path.read_bytes());assert row['snapshot']==snap['snapshot'] and row['at']==snap['at']
    receipt['common_snapshot']=snap;receipt['result_sha256_transport']=witness;dump(rec,receipt)
    for script,log in [('scores/build-score-grid.py','grid.log'),('verify_grid.py','verification.log')]:
        with (out/log).open('w') as f:subprocess.run([sys.executable,str(out/script)],cwd=out,check=True,stdout=f,stderr=subprocess.STDOUT)
    print((out/'verification.log').read_text(),flush=True)
finally:
    receipt['definition_end_state']=aws('ecs','deregister-task-definition','--task-definition',definition,'--query','taskDefinition.status');dump(rec,receipt)
