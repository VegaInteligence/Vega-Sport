"""Build the portable evidence bundle and verify it from a fresh extraction."""
import hashlib
import json
from pathlib import Path
import subprocess
import sys
import tempfile
import zipfile

BASE = Path(__file__).resolve().parent
groups = ("reference-1555","releve-rds","suivi-rds","source-1555","source-apres","comparaison")
selected = set()
for group in groups:
    inside = BASE/group
    selected.update(p.relative_to(BASE) for p in inside.rglob("*")
                    if p.is_file() and p.name != ".DS_Store" and "__pycache__" not in p.parts)
selected.update(p.relative_to(BASE) for p in BASE.iterdir()
                if p.is_file() and p.suffix in {".log",".md",".py",".txt",".sql",".json"}
                and p.name not in {"empreintes.json","paquet-recu.json","verification-isolee.log"})
names = {p.as_posix() for p in selected}
for group in groups:
    assert any(p.startswith(group+"/") for p in names), group


def digest(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


manifest = {p.as_posix():digest(BASE/p) for p in sorted(selected)}
(BASE/"empreintes.json").write_text(json.dumps(manifest, indent=2, sort_keys=True)+"\n")
selected.add(Path("empreintes.json"))
archive = BASE/"couverture-vega-apres-b2e6dd82-1705-1711.zip"
with zipfile.ZipFile(archive,"w",compression=zipfile.ZIP_DEFLATED) as bundle:
    for path in sorted(selected):
        bundle.write(BASE/path, path.as_posix())
with tempfile.TemporaryDirectory(prefix="vega-elo-apres-deploiement-") as temp:
    extracted = Path(temp)
    with zipfile.ZipFile(archive) as bundle:
        assert bundle.testzip() is None
        assert set(bundle.namelist()) == {p.as_posix() for p in selected}
        bundle.extractall(extracted)
    for path in selected:
        assert (extracted/path).read_bytes() == (BASE/path).read_bytes(), path
    check = subprocess.run([sys.executable,"-B","verifier.py"],cwd=extracted,
                           stdout=subprocess.PIPE,stderr=subprocess.STDOUT)
    (BASE/"verification-isolee.log").write_bytes(check.stdout)
    if check.returncode:
        print(check.stdout.decode())
        raise SystemExit(check.returncode)
receipt = {"file":archive.name,"sha256":digest(archive),"bytes":archive.stat().st_size,"files_verified":len(selected),
           "python":sys.version.split()[0],"verification_isolee_sha256":digest(BASE/"verification-isolee.log"),
           "snapshots":["2026-11-18T15:55:42.264282Z","2026-11-18T17:05:26.592852Z","2026-11-18T17:11:17.692724Z"]}
(BASE/"paquet-recu.json").write_text(json.dumps(receipt,indent=2)+"\n")
print(json.dumps(receipt,indent=2))
