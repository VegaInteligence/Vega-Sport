# Couverture des scores après le déploiement AWS

Le 18 novembre 2026 à **17 h 05 min 26,592852 s UTC**, le même calcul dénombre **1 388 nouveaux côtés de match sans Elo pour les sélections**. Les notes de joueurs et les Elo de clubs restent inchangés. La mesure légère de **17 h 11 min 17,692724 s UTC** retrouve exactement les mêmes côtés admissibles et les mêmes absences.

| Entité | Attendus à 15 h 55 → 17 h 05 | Valides persistés | Manquants à 15 h 55 → 17 h 05 |
| --- | ---: | ---: | ---: |
| Joueurs | 2 296 998 → 2 296 998 | 2 282 580 | 14 418 → 14 418 |
| Clubs, côtés Elo | 161 932 → 161 932 | 161 912 | 20 → 20 |
| Sélections, côtés Elo | 1 864 → 3 252 | 1 864 | 0 → 1 388 |

Les **615** participations dont le rôle manque restent hors de l’attendu chiffré des joueurs. Le plan n’a ajouté aucune statistique de joueur. Les deux modules Elo et identité importés du runtime sont octet-identiques avant/après. [Totaux](source-apres/resultats.json) · [Comparaison](comparaison/comparaison.json)

## Origine des 1 388 côtés

| Groupe de rencontres | Rencontres ajoutées | Statut terminé en plus | Copies écartées en plus | Côtés admis en plus | Côtés nouvellement notés |
| --- | ---: | ---: | ---: | ---: | ---: |
| 18 éditions historiques OpenFootball de la Coupe du monde | 0 | 665 | 7, édition 2022 | 1 316 | 0 |
| Une édition Ligue des nations, International Results | 36 | 36 | 0 | 72 | 0 |
| Total | 36 | 701 | 7 | 1 388 | 0 |

Les 665 résultats historiques complètent des rencontres déjà présentes. Sept de 2022 correspondent à des copies qui restent exclues par la politique de rapprochement. Les 658 autres deviennent admissibles. Les 36 rencontres terminées supplémentaires sont dans le complément Nations League B/C/D. Les 19 éditions portent un `cup_key` et leur `archive_key` est nul. Le modèle leur applique donc les règles des coupes complémentaires. [Éditions](comparaison/ressources-editions.csv) · [Rejeu Elo et sources](suivi-elo.json)

## Recalcul et publication

Le dernier calcul Elo publié est **#2097**, terminé le **18 novembre à 01:49:24 UTC**, avec **81 923** matchs. Le relevé de 17 h 11 ne montre aucun run Elo en cours, aucune activité SQL contemporaine visible sous le rôle du diagnostic et aucun marquage `ops.dirty_scopes` pour les 19 éditions. Les nouveaux résultats sont déjà marqués comme collectés avec succès. Ces constats s’appliquent à l’instant mesuré et à la visibilité du rôle.

Le worker vérifie le travail quotidien toutes les 60 secondes après la fin de la passe. Il lance Elo quand une saison native est due. Le test exclut les éditions avec `cup_key` avant d’examiner les dates ou modifications natives. Pour la saison 2026, le dernier match natif terminé modifié à 00:37:51 précède le dernier calcul des niveaux commencé à 01:15:36. Les deux collectes ne déclenchent donc pas à elles seules un calcul Elo. Un futur cycle natif peut les reprendre. Aucun rattrapage n’était observable à 17 h 11. [Marquages et publication](suivi-elo.json) · [Journal actif du worker](journaux-worker.json) · [Condition de déclenchement](worker-extrait.txt)

## Grilles et univers des rencontres

| Grille | Lignes comparées | Cellules comparées | Cellules modifiées |
| --- | ---: | ---: | ---: |
| Publiée par édition et entité | 6 447 | 128 940 | 116 |
| Publiée par saison et entité | 471 | 3 297 | 36 |
| Reconstituée par compétition et entité | 624 | 6 240 | 13 |
| Diagnostic brut par édition et entité | 6 447 | 477 078 | 173 |
| Diagnostic brut par saison et entité | 471 | 14 130 | 113 |

Aucune clé ajoutée ou retirée. Les changements publiés d’édition portent sur 60 champs de rencontre, 19 compteurs de côtés connus, 19 champs d’admissibilité et 18 valeurs manquantes. La colonne de notes valides reste identique cellule par cellule. Les joueurs n’ont ni nouveau signal de participation ni note supplémentaire. Les 19 changements classés en intrants dans la grille publiée sont des compteurs de côtés de sélections. La grille brute comptabilise aussi 19 augmentations de matchs sans signal de joueur. [Diff détaillé](comparaison/ecarts-edition-publiee.csv) · [Détail brut](comparaison/ecarts-edition-brute.csv)

| Source physique | Rencontres enregistrées | Terminées | Terminées avec score |
| --- | ---: | ---: | ---: |
| engsoccerdata | 179 928 | 179 587 | 179 587 |
| footballcsv | 190 152 | 190 152 | 190 152 |
| international_results | 409 | 409 | 409 |
| openfootball | 65 926 | 65 791 | 65 271 |
| openligadb | 167 | 159 | 159 |
| open_matchday | 4 682 | 2 576 | 2 576 |
| pitchapi | 84 371 | 75 355 | 75 355 |
| worldclub | 63 159 | 63 159 | 63 159 |
| Total | 588 794 | 577 188 | 576 668 |

Le décompte par source mesure les lignes de production, y compris les copies conservées physiquement. Il couvre la saison et l’édition via l’ID d’édition. Les 588 794 lignes et les 577 188 terminées se recoupent avec l’inventaire d’éditions. Les 520 terminées sans score restent visibles. Les anciennes grilles ne contiennent pas le regroupement par source. Les deltas par édition proviennent des deux inventaires comparables. [Détail SQL et résultat par source/édition](releve-rds/db/audit/)

## Reproduction

La tâche de couverture réutilise les **44 SELECT** du relevé de **15:55:42.264282 UTC**, les trois scripts d’origine, et le code Elo importé du conteneur actif. Elle ajoute un regroupement des rencontres par source et édition. Le suivi Elo réduit le périmètre à cinq SELECT d’exploitation et au même calcul d’admissibilité. Chaque tâche ouvre sa propre transaction `REPEATABLE READ READ ONLY`, avec vérification commune de l’instant et du snapshot pour tous les résultats. Les deux tâches finissent avec le code 0 et désactivent leur définition éphémère. La révision ECS active 143 et les deux tâches de diagnostic portent la même image de commit **b2e6dd82d36a2ca0f439ec84bf2e5dbbcd3013d9**, digest **sha256:8ecb6624e75135f2e741146fd160fe756e7478a2d18fd1139c16b28c817c67e5**. [Couverture ECS](releve-rds/receipt.json) · [Suivi ECS](suivi-rds/receipt.json) · [Déploiement](run-actions.json)

Après décompression, exécuter `python3 -B verifier.py` avec Python 3.10 ou ultérieur pour reconstituer les grilles et la comparaison sans accès AWS. Les commandes de diagnostic en ligne sont conservées à titre de preuve. [Commandes](commandes.txt)
