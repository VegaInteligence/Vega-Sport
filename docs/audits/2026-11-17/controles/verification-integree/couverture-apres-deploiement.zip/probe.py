"""Run the reviewed SQL and deployed Elo gate within a single bounded, read-only snapshot."""
import base64,datetime,hashlib,json,os,time,zlib
import psycopg
def unpack(value):return zlib.decompress(base64.b64decode(value))
def emit(name,obj):
    data=json.dumps(obj,default=str,ensure_ascii=False).encode()
    packet=base64.b64encode(zlib.compress(data,9)).decode()
    for i in range(0,len(packet),8000):print('COVER',name,i,packet[i:i+8000],flush=True)
    print('DIGEST',name,hashlib.sha256(data).hexdigest(),flush=True)
plan=json.loads(unpack(FROZEN_QUERIES))
team_code=unpack(FROZEN_TEAM_PROBE).decode()
options='-c default_transaction_read_only=on -c statement_timeout=100000 -c lock_timeout=1500 -c max_parallel_workers_per_gather=0'
with psycopg.connect(host=os.environ['V2_DB_HOST'],dbname=os.environ['V2_DB_NAME'],user=os.environ['V2_DB_USER'],password=os.environ['V2_DB_PASSWORD'],sslmode='verify-full',sslrootcert='/app/rds-ca.pem',application_name='vega_vi27_atomic_coverage',options=options,autocommit=True) as db:
    with db.transaction():
        db.execute('SET TRANSACTION ISOLATION LEVEL REPEATABLE READ, READ ONLY')
        stamp,snapshot,database,readonly,isolation=db.execute("SELECT transaction_timestamp(),pg_current_snapshot()::text,current_database(),current_setting('transaction_read_only'),current_setting('transaction_isolation')").fetchone()
        assert database=='vega_v2' and readonly=='on' and isolation=='repeatable read'
        checks={'at':str(stamp),'snapshot':snapshot,'database':database,'isolation':isolation,'read_only':readonly}
        emit('snapshot',checks)
        started=time.monotonic()
        for name,query in plan.items():
            if time.monotonic()-started>780:raise RuntimeError('transaction budget exceeded')
            now=db.execute('SELECT statement_timestamp()').fetchone()[0]
            c=db.execute(query)
            emit(name,{**checks,'statement_at':str(now),'columns':[s.name for s in c.description],'rows':c.fetchall()})
        funcs={}
        exec(team_code,funcs)
        computed=funcs['audit'](db)
        emit('team-exact',{**checks,**computed})
        assert db.execute('select pg_current_snapshot()::text').fetchone()[0]==snapshot
print('COVER_COMPLETE',flush=True)
