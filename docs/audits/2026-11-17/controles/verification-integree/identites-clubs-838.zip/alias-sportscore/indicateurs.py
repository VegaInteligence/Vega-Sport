"""Name comparison signals. No link is created or corrected by this filter."""
import re
import unicodedata
def words(s):
    return ' '.join(re.findall(r'[a-z0-9]+',unicodedata.normalize('NFKD',s or '').encode('ascii','ignore').decode().lower()))

def key(s):
    return words(s).replace(' ','')

def signature(s):
    name=words(re.sub(r"\b([FCAS])\.([FCAS])\.?", r"\1\2", s or "", flags=re.I))
    if name in {"juan pablo ii","juan pablo ii college","primavera","primavera sp"}:
        return []  # documented senior club names, checked against the two federations
    grades=set()
    for match in re.finditer(r'\b(?:u|under|sub|unter|moins de)\s*([1-2][0-9])\b',name):
        grades.add('U'+match[1])
    for token in re.findall(r'\b(?:ii|iii|iv|b|c|2|3|4)\b(?=(?:\s+(?:fc|cf|sc|afc|women|ladies|w|f|femenino|feminin))*$)',name):
        grades.add({'ii':'second','b':'second','2':'second','iii':'third','c':'third','3':'third','iv':'fourth','4':'fourth'}[token])
    if re.search(r'\b(?:reserve|reserves|reservas|reserveelf|youth|academy|primavera|jong|beloften|espoirs|promesas|castilla|filial|juvenil|futures|nxt)\b',name):
        grades.add('development')
    if re.search(r'\b(?:women|womens|woman|ladies|feminin|feminines|feminine|femenil|femenino|femenina|femeninas|feminino|feminina|femminile|femminili|dames|damen|frauen|femenis|damallsvenskan|femmes|kvinner|vrouwen|wfc)\b',name) or re.search(r'\b(?:w|f)$',name):
        grades.add('women')
    return sorted(grades)
