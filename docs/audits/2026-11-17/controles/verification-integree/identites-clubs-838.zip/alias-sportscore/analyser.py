"""Offline analysis of the bounded alias/source-name census."""
from examiner import a,by,fk,ed,ex,fam,read
from indicateurs import signature,key
from pathlib import Path
from collections import Counter
from hashlib import sha256
import csv,json
root=Path(__file__).resolve().parent
def dump(k,v): (root/k).write_text(json.dumps(v,ensure_ascii=False,indent=2)+'\n')
for base in (root,root/'contexte'):
    rec=json.loads((base/'receipt.json').read_bytes())
    assert rec['exit_code']==0 and rec['definition_end_state']=='INACTIVE' and rec['snapshot']['read_only']=='on'
    for n,h in rec['result_sha256'].items():assert sha256((base/(n+'.json')).read_bytes()).hexdigest()==h
assert len(a)==838 and len(ex)<18001 and len(fam)<8001 and len(ed)==60
assert all(r['kind']=='source_spelling' for r in a)
assert len({r['id'] for r in a})==len({key(r['alias']) for r in a})==838
women={5315:5584,5317:5334,5318:5328,5322:5329,5325:5331,5309:5327,5316:5330}
cal=read('contexte/calendar')
frozen=json.loads((root/'equipes-feminines-1002.json').read_bytes())['rows']
for tgt,peer in women.items():
    assert any(i['id']==peer and 'Women' in i['name'] for i in cal) or frozen[str(peer)][1]==1002
roles={845:'collision globale Andorra CF / FC Andorra',705:'collision globale NK Varteks / NK Varaždin',4845:'réserve établie par la Pro League',
       4852:'réserve établie par la Pro League',1030:'nouveau nom du Celta B établi par le club',
       1015:'nom propre du club péruvien confirmé par la FPF',5254:'nom propre du club brésilien confirmé par la FPF',
       5287:'changement de nom York United confirmé par la CPL',707:'alias équatorien correct, calendrier européen rattaché à tort à la même clé',
       5116:'homonyme chilien distinct dans une autre compétition'}
count=Counter(); seen=set()
reg=[]
for r in a:
    id=r['id']; alias=r['alias']; own=by[id,alias]; self=[x for x in own if x['peer_id']==id]
    peers=[x for x in own if x['peer_id']!=id and x['merged_into']!=id]
    direct=any(x['source']=='core' for x in self)
    typ='nom canonique ou court exact' if direct else ('autre fournisseur, graphie acquise exacte' if self else 'SportScore est la seule preuve exacte sur cet ID')
    count[typ]+=1
    ens={x['peer_id'] for x in peers}; same={x['peer_id'] for x in peers if x['shared']}; fams={x['peer_id'] for x in fk[id,alias] if x['merged_into']!=id}
    assert not same
    if ens: count['autre_ID_actif_exact']+=1
    if any(x['peer_id']!=id for x in own):count['autre_ID_exact_avec_redirections']+=1
    if r['sportscore_editions']:count['membre_classement_courant']+=1
    if fams:count['famille_avec_autre_ID_actif']+=1
    sg,sc=signature(alias),signature(r['canonical'])
    if sg or sc:count['paires_marquees']+=1
    if sg!=sc:count['marqueurs_differents']+=1
    if id in women:
        assert (women[id] in ens or women[id] in fams or key(r['canonical'])==key(frozen[str(women[id])][0]))
        decision='équipes masculine et féminine portant le même nom de club, échéances distinctes'
    else:decision=roles.get(id,'marqueurs compatibles' if sg or sc else ('abréviation FC' if id in {4820,697,870} else 'aucune contradiction démontrée par ce contrôle'))
    reg.append([id,alias,r['canonical'],r['country'],'|'.join(map(str,r['sportscore_editions'])),'|'.join(sg),'|'.join(sc),typ,'|'.join(map(str,sorted(ens))),'|'.join(map(str,sorted(fams))),decision])
with (root/'registre-838.csv').open('w',newline='') as f:
    w=csv.writer(f);w.writerow(['team_id','graphie_SportScore','canonique','pays','editions_classees','marqueurs_source','marqueurs_canoniques','appui_exact_sur_meme_ID','autres_ID_exacts_non_rediriges_vers_cible','voisins_famille_non_rediriges_vers_cible','disposition']);w.writerows(reg)
dump('totaux.json',{'aliases':len(a),'unique_alias_strings':838,'unique_target_ids':838,'exacts_candidates_rows':len(ex),'family_candidates_rows':len(fam),'edition_shared_conflicts':0,'saudi_gender_disambiguations':women,'statistics':dict(count)})
print(dict(count))
