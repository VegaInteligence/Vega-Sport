WITH off AS (SELECT DISTINCT o.competition_season_id AS ed,o.team_id AS id FROM core.standings_official o
 WHERE o.source='sportscore' AND o.stage IS NULL) SELECT cs.id,c.id competition_id,c.name,cs.season_id,c.country_code,cs.native_label FROM core.competition_seasons cs
 JOIN core.competitions c ON cs.competition_id=c.id WHERE cs.id IN (SELECT ed FROM off) ORDER BY cs.id LIMIT 151