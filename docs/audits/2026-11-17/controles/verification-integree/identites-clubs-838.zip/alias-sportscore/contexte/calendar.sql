WITH t AS (SELECT id FROM core.teams WHERE id IN (194,653,705,707,737,755,796,845,876,1030,4845,4852,4866,5001,5116,5127,5315,5317,5318,5322,5325,5328,5329,5331,5334,5584,5607,6116,12300) OR lower(name) LIKE ANY(ARRAY['%varteks%','%varaždin%','%varazdin%','andorra c%'])),
 sides AS (SELECT t.id,m.competition_season_id ed,m.away_team_id opp,m.season_id,m.match_date FROM t JOIN core.matches m ON m.home_team_id=t.id
 UNION ALL SELECT t.id,m.competition_season_id,m.home_team_id,m.season_id,m.match_date FROM t JOIN core.matches m ON m.away_team_id=t.id)
 SELECT s.id,c.id AS competition,c.name,c.country_code,min(s.season_id) first_season,max(s.season_id) last_season,count(*) matches,
 (array_agg(DISTINCT t.name ORDER BY t.name) FILTER (WHERE t.name IS NOT NULL))[1:4] AS example_opponents
 FROM sides s JOIN core.competition_seasons cs ON cs.id=s.ed JOIN core.competitions c ON c.id=cs.competition_id
 LEFT JOIN core.teams t ON t.id=s.opp GROUP BY s.id,c.id,c.name,c.country_code ORDER BY s.id,c.id LIMIT 2001