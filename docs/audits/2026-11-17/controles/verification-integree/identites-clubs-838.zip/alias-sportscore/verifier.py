"""Vérifie la capsule puis reconstruit ses trois tableaux et la trace sur une copie."""
import csv
import hashlib
import json
import os
from pathlib import Path
import shutil
import subprocess
import sys
import tempfile

BASE = Path(__file__).resolve().parent

def digest(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()

def require(condition, message):
    if not condition:
        raise ValueError(message)

def check_inputs():
    entries = json.loads((BASE / 'manifest-sha256.json').read_bytes())
    paths = {p.relative_to(BASE).as_posix() for p in BASE.rglob('*') if p.is_file()}
    expected = set(entries) | {'manifest-sha256.json'}
    require(paths == expected, 'inventaire divergent : ' + ', '.join(sorted(paths ^ expected)))
    require(not any(p.is_symlink() for p in BASE.rglob('*')), 'lien symbolique présent')
    for name, reference in entries.items():
        require(digest(BASE / name) == reference, 'SHA-256 divergent : ' + name)
    for folder in (BASE, BASE/'contexte', BASE/'barcelone'):
        rec = json.loads((folder/'receipt.json').read_bytes())
        snapshot = json.loads((folder/'snapshot.json').read_bytes())
        require(all(snapshot.get(k)==v for k,v in rec['snapshot'].items()), 'reçu de transaction divergent')
        require(snapshot['isolation']=='repeatable read' and snapshot['read_only']=='on', 'transaction inattendue')
        for group, suffix in [('query_sha256', '.sql'), ('result_sha256', '.json')]:
            for k, reference in rec[group].items():
                raw = (folder / (k+suffix)).read_bytes()
                hashed = hashlib.sha256(raw.strip() if suffix == '.sql' else raw).hexdigest()
                require(hashed == reference, f'{group} divergent : {folder.name}/{k}')
    evidence = BASE/'barcelone/source_extraits'
    trace = json.loads((BASE/'barcelone/trace.json').read_bytes())
    provenance = json.loads((evidence/'provenance.json').read_bytes())
    require(provenance['commit'] == trace['git'], 'commit divergent')
    for name, sha in trace['blob_sha256'].items():
        require(provenance['files']['backend/vega/'+name]['sha256_original'] == sha, 'source divergente : '+name)
    for origin, record in provenance['files'].items():
        if record['module']:
            body = (evidence/record['module']).read_text()
            import ast
            spans = ast.parse(body).body
            lines = body.splitlines(keepends=True)
            definitions = {}
            for node in spans:
                key = node.name if isinstance(node, ast.FunctionDef) else node.targets[0].id if isinstance(node, ast.Assign) else None
                if key:
                    block = ''.join(lines[node.lineno-1:node.end_lineno])
                    definitions[key] = hashlib.sha256(block.encode()).hexdigest()
            require(definitions == {n: sha for n, _, _, sha in record['definitions']}, 'définitions divergentes : '+origin)
    return entries

def rebuild(entries):
    with tempfile.TemporaryDirectory() as temporary:
        root = Path(temporary) / 'copie'
        shutil.copytree(BASE, root)
        products = ['registre-838.csv', 'totaux.json', 'barcelone/matches-15.csv']
        for product in products:
            (root/product).unlink()
        for script in ('analyser.py','barcelone/tracer.py','barcelone/analyser.py'):
            result = subprocess.run([sys.executable, '-E', '-s', '-B', str(root/script)], cwd=root,
                                    capture_output=True, text=True, env={'PATH':os.defpath})
            require(result.returncode==0, f'{script} a échoué : {result.stderr}')
        for product in products:
            require(digest(root/product) == entries[product], 'résultat reconstruit divergent : '+product)
        with (root/'barcelone/matches-15.csv').open(newline='') as stream:
            rows = list(csv.DictReader(stream))
        require(len(rows)==15 and sum(int(r['published_sides']) for r in rows)==12,'total Elo inattendu')
        totals = json.loads((root/'totaux.json').read_bytes())
        return {'graphies':totals['aliases'],'graphies_classement':totals['statistics']['membre_classement_courant'],
                'homonymes_exacts_autre_id':totals['statistics']['autre_ID_actif_exact'],
                'matchs_termines':len(rows),'cotes_elo_2099':12,'resolutions_sur_deux_candidats':[707,707],
                'produits_regeneres':{p:digest(root/p) for p in products}}

if __name__=='__main__':
    try:
        print(json.dumps(rebuild(check_inputs()), ensure_ascii=False, sort_keys=True))
    except (OSError, KeyError, ValueError) as error:
        sys.exit(str(error))
