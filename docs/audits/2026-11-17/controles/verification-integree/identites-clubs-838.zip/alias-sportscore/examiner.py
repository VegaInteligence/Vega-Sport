from indicateurs import *
from pathlib import Path
import json,collections,difflib
def read(n):
 x=json.loads((Path(__file__).parent/(n+'.json')).read_bytes());return [dict(zip(x['columns'],r)) for r in x['rows']]
a=read('aliases'); ex=read('exact'); fam=read('family'); ed={r['id']:r for r in read('editions')}
by=collections.defaultdict(list); fk=collections.defaultdict(list)
for r in ex:by[r['id'],r['alias']].append(r)
for r in fam:fk[r['id'],r['alias']].append(r)
if __name__=='__main__':
 print('COUNTS',len(a),len(ex),len(fam),len(ed),collections.Counter(r['kind'] for r in a))
 count=collections.Counter()
 for r in a:
  s1=signature(r['alias']);s2=signature(r['canonical']); peers=by[r['id'],r['alias']]; other=[x for x in peers if x['peer_id']!=r['id'] and x['merged_into']!=r['id']]
  same=[x for x in other if x['shared']]
  own=[x for x in peers if x['peer_id']==r['id']]
  count['alias_only']+=not own;count['otherid']+=bool(other);count['sameed']+=bool(same); count['marked']+=bool(s1 or s2); count['diff']+=s1!=s2
  if s1 or s2:print('MARK',r['id'],r['alias'],'→',r['canonical'],s1,s2,[ed[i]['name'] for i in r['sportscore_editions']])
  if same:print('SHARED',r['id'],r['alias'],'→',r['canonical'],[(x['peer_id'],x['peer'],x['source'],x['shared']) for x in same])
  if not own and not set(words(r['alias']).split()) & set(words(r['canonical']).split()):
   print('DISTANT',r['id'],r['alias'],'→',r['canonical'],[(x['peer_id'],x['peer']) for x in other][:3])
 print(count)
