WITH a AS MATERIALIZED (SELECT n.entity_id AS id,n.name AS alias,n.kind::text AS kind,t.name AS canonical,t.short_name,t.country_code AS country,t.merged_into
 FROM core.entity_names n JOIN core.teams t ON t.id=n.entity_id
 WHERE n.entity_type='team' AND n.source='sportscore'), names AS MATERIALIZED (SELECT t.id,t.name disp,'canonical' AS kind,'core' AS source FROM core.teams t UNION ALL
 SELECT t.id,t.short_name,'short','core' FROM core.teams t WHERE t.short_name IS NOT NULL UNION ALL
 SELECT entity_id,name,kind::text,source::text FROM core.entity_names WHERE entity_type='team'), ak AS MATERIALIZED (SELECT a.*,regexp_replace(lower(normalize(a.alias,NFKD) COLLATE "C"),'[^a-z0-9]','','g') AS k FROM a), nk AS MATERIALIZED (SELECT names.*,regexp_replace(lower(normalize(disp,NFKD) COLLATE "C"),'[^a-z0-9]','','g') AS k FROM names), off AS (SELECT DISTINCT o.competition_season_id AS ed,o.team_id AS id FROM core.standings_official o
 WHERE o.source='sportscore' AND o.stage IS NULL)
 SELECT a.id,a.alias,n.id AS peer_id,t.name AS peer,t.merged_into,t.country_code,n.disp,n.kind,n.source,
 ARRAY(SELECT DISTINCT ts.competition_season_id FROM core.team_seasons ts WHERE ts.team_id=n.id AND ts.competition_season_id IN (SELECT ed FROM off WHERE id=a.id) ORDER BY 1) AS shared,
 ARRAY(SELECT ed FROM off WHERE id=n.id ORDER BY 1) AS peer_official
 FROM ak a JOIN nk n ON a.k=n.k AND a.k<>'' JOIN core.teams t ON t.id=n.id
 WHERE NOT(n.id=a.id AND n.source='sportscore')
 ORDER BY a.id,a.alias,n.id,n.kind,n.source,n.disp LIMIT 18001