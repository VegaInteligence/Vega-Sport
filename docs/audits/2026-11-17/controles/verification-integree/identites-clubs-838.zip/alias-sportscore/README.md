# Alias SportScore et quinze rencontres du FC Barcelona

Le relevé du 18 novembre 2026 retrouve 838 graphies, dont 818 associées à un classement SportScore courant. Les noms « Andorra CF » et « NK Varteks Varazdin » demandent un contexte pour identifier le club. Dans un autre circuit d’ingestion, quinze matchs du FC Barcelona espagnol portent la clé du Barcelona équatorien. Le run Elo 2099 a publié douze côtés sur les six matchs de coupe espagnole. Le total des effets ultérieurs sur l’Elo reste inconnu. [Rapport des graphies](RAPPORT.md) · [Dossier des quinze rencontres](barcelone/RAPPORT.md)

## Vérifier sur sa machine

Utiliser Python 3.9 ou plus récent avec sa bibliothèque standard. Depuis le répertoire décompressé, exécuter :

```sh
python3 -I -B verifier.py
```

Le contrôle vérifie l’inventaire et chaque empreinte SHA-256 du manifeste, y compris celles des neuf requêtes SQL dans les trois reçus. Il copie ensuite les pièces dans un dossier temporaire, efface les trois tableaux de résultats, les reconstruit, vérifie chaque octet et exécute les deux fonctions du code publié sur les deux identités capturées. Le résultat attendu est 838 graphies, 818 classées, 114 graphies présentes sur un autre identifiant indépendant, quinze matchs terminés, douze côtés Elo et deux résolutions vers 707. Le SHA-256 communiqué avec le ZIP permet de contrôler l’archive avant extraction.

Le témoin négatif de l’archive se reproduit dans **une seconde extraction jetable** avec les commandes suivantes. Le premier octet ajouté change le fichier de résultats sans modifier le manifeste. Le vérificateur doit échouer avec le nom du fichier altéré.

```sh
python3 -c "from pathlib import Path; p=Path('barcelone/matches.json'); p.write_bytes(p.read_bytes()+b' ')"
python3 -I -B verifier.py
```

## Données et périmètre

Les trois transactions capturées à 18 h 43, 18 h 46 et 18 h 50 UTC contiennent les seules projections nécessaires des matchs, noms, identifiants, calendriers et publications Elo. Les JSON tabulaires donnent leurs colonnes et valeurs dans l’ordre renvoyé par PostgreSQL. Les réponses HTTP sont des projections datées, accompagnées de l’empreinte du corps reçu à l’époque. Les noms privés d’infrastructure et les lanceurs de diagnostic sont exclus. Le témoin secondaire de l’édition féminine 1002 conserve son extrait et l’empreinte de son fichier parent.

Les neuf SQL sont fournis avec leurs résultats historiques. Pour les réexécuter indépendamment sur une **copie compatible de Vega** à laquelle le lecteur a déjà accès, utiliser un fichier par commande. Exemple pour les quinze rencontres :

```sh
psql -X -v ON_ERROR_STOP=1 -c 'BEGIN ISOLATION LEVEL REPEATABLE READ READ ONLY' -c "SET LOCAL statement_timeout = '45s'" -f barcelone/matches.sql -c 'ROLLBACK'
```

Le rejeu local vérifie les résultats effectivement enregistrés. Une nouvelle sélection SQL dépend du contenu de la copie. Les tableaux ne reconstituent ni l’ensemble de la base ni les variations ultérieures d’Elo. La capture HTTP générique inclut des réponses 404. Les vues de coupe et d’archive ont affiché les bons noms source. L’origine historique du premier mauvais rattachement demeure indéterminée. [Trace des deux résolutions](barcelone/trace.json) · [Extraits et empreintes de la révision](barcelone/source_extraits/provenance.json)
