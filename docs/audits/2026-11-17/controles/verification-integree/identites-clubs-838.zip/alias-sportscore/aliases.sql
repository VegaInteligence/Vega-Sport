WITH a AS (SELECT n.entity_id AS id,n.name AS alias,n.kind::text AS kind,t.name AS canonical,t.short_name,t.country_code AS country,t.merged_into
 FROM core.entity_names n JOIN core.teams t ON t.id=n.entity_id
 WHERE n.entity_type='team' AND n.source='sportscore'), off AS (SELECT DISTINCT o.competition_season_id AS ed,o.team_id AS id FROM core.standings_official o
 WHERE o.source='sportscore' AND o.stage IS NULL) SELECT a.*,ARRAY(SELECT s.ed FROM off s WHERE s.id=a.id ORDER BY 1) AS sportscore_editions,
 ARRAY(SELECT DISTINCT p.provider::text||':'||p.provider_key FROM core.provider_ids p WHERE p.entity_type='team' AND p.entity_id=a.id AND p.is_current ORDER BY 1) AS provider_keys
 FROM a ORDER BY a.id,a.alias LIMIT 1201