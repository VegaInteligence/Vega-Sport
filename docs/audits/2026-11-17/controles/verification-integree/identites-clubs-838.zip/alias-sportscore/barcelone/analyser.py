"""Verify the 15 public match keys, Elo rows, core identity and HTTP projections from the saved receipts."""
from collections import Counter
from hashlib import sha256
from pathlib import Path
import csv,json
p=Path(__file__).resolve().parent
def obj(s):return json.loads((p/s).read_bytes())
def read(s):
 x=obj(s+'.json');return [dict(zip(x['columns'],row)) for row in x['rows']]
receipt=obj('receipt.json')
assert receipt['exit_code']==0 and receipt['definition_end_state']=='INACTIVE' and receipt['snapshot']['read_only']=='on'
for k,h in receipt['result_sha256'].items():assert sha256((p/(k+'.json')).read_bytes()).hexdigest()==h
rows=read('matches'); teams={r['id']:r for r in read('identites')}
assert sorted({(r['id'],r['country_code'],r['public_id']) for r in teams.values() if r['id'] in (707,740)})==[(707,'ECU','t_2fucJi'),(740,'ESP','t_32jSEF')]
assert 'openfootball:name:FC Barcelona' in teams[707]['current_keys'] and 'vega:archive:europe:fc barcelona' in teams[707]['current_keys']
assert len(rows)==len({r['id'] for r in rows})==len({r['public_id'] for r in rows})==15
assert {r['status'] for r in rows}=={'finished'}
assert Counter(r['source'] for r in rows)=={'footballcsv':2,'worldclub':7,'openfootball':6}
assert all((r['home_team_id']==707)^(r['away_team_id']==707) for r in rows)
out=[]
for r in rows:
 hs=r['home_team_id']==707; pub=r['published_elo']; sa=r['source_home'] if hs else r['source_away']
 assert sa=='FC Barcelona'
 if r['archive_key']:assert pub==[]
 else:
  assert len(pub)==2 and {e['team'] for e in pub}=={r['home_team_id'],r['away_team_id']} and {e['run'] for e in pub}=={2099}
 out.append([r['id'],r['public_id'],r['season_id'],r['native_label'],r['match_date'],r['edition'],r['competition'],r['public_competition'],r['competition_name'],
 r['status'],r['source'],r['source_home'],r['home_team_id'],r['public_home'],r['source_away'],r['away_team_id'],r['public_away'],r['home_score'],r['away_score'],
 'home' if hs else 'away',707,'t_2fucJi',740,'t_32jSEF',r['archive_key'] or '',r['cup_key'] or '',len(pub),2099 if pub else '', '|'.join(r['match_keys'])])
with (p/'matches-15.csv').open('w',newline='') as f:
 w=csv.writer(f);w.writerow('match_id public_match season edition_label date edition_id competition_id public_competition competition status source home_source home_id public_home away_source away_id public_away home_goals away_goals affected_side stored_club stored_public_club sporting_club sporting_public_club archive_key cup_key published_sides run match_provider_key'.split());w.writerows(out)
near=read('voisins');assert len(near)==15 and all(x['neighbour'] is None for x in near)
urls=obj('http-archives.json'); cup=next(r for r in urls if 'l_v0000071' in r['url'])
directories=next(r for r in urls if '/read/clubs' in r['url'])
assert {(t['id'],t['country']) for t in directories['selected']}=={('t_2fucJi','ECU'),('t_32jSEF','ESP')}
for r in rows:
 if r['cup_key']:
  assert any(s['date']==r['match_date'] and s['score']['ft']==[r['home_score'],r['away_score']] and s['team1']==r['source_home'] and s['team2']==r['source_away'] for s in cup['selected'])
 else:
  source=next(u for u in urls if '/read/archive' in u['url'] and str(r['season_id']) in u['url'])
  assert any(s['date']==r['match_date'] and s['team1']==r['source_home'] and s['team2']==r['source_away'] and s['score']==[r['home_score'],r['away_score']] for s in source['selected'])
trace=obj('trace.json');assert trace['cup_fc_barcelona_country_unspecified']==707 and trace['europe_archive_fc_barcelona']==[707,True]
print('15 finished matches, six cup matches with 12 published Elo sides / nine archives with zero sides. Two distinct public Barcelona keys. Historical routes show source names on all fifteen.')
