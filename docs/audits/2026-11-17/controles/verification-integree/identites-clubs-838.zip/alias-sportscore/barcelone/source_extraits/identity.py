import re
import unicodedata
from .base import normalize

EUROPE = "europe"


COUNTRY_SUFFIX = re.compile(r"^(.*\S)\s*\(([A-Z]{3})\)$")


WORLD_CLUB_SPELLINGS = {
    "Al Ain FC (UAE)": "Al Ain", "Al Jazira Club (UAE)": "Al Jazira", "Botafogo RJ (BRA)": "Botafogo", "CF Monterrey (MEX)": "Monterrey",
    "CF Pachuca (MEX)": "Pachuca", "Chelsea FC (ENG)": "Chelsea", "Club León (MEX)": "León", "Flamengo RJ (BRA)": "Flamengo",
    "Fluminense RJ (BRA)": "Fluminense", "Mamelodi Sundowns (RSA)": "Mamelodi Sundowns FC", "RB Salzburg (AUT)": "Salzburg",
    "Seattle Sounders (USA)": "Seattle Sounders FC", "SL Benfica (POR)": "Benfica",
    # The confederations' club competitions of 2021 to 2026, reviewed one by one on 14 November
    # 2026 against the PitchAPI clubs of each country (a club PitchAPI does not hold has no entry:
    # Uruguay's, most of Africa's). "Universidad Técnica" is UTC Cajamarca, not ADT.
    "Atlanta United FC (USA)": "Atlanta United", "Houston Dynamo (USA)": "Houston Dynamo FC", "Los Angeles Galaxy (USA)": "LA Galaxy",
    "St. Louis City SC (USA)": "St. Louis City",
    "Atlético Goianiense (BRA)": "Atlético-GO", "Atlético Mineiro (BRA)": "Atlético-MG", "CA Mineiro (BRA)": "Atlético-MG", "Bahia BA (BRA)": "Bahia", "EC Bahia (BRA)": "Bahia", "Botafogo FR (BRA)": "Botafogo",
    "CA Paranaense (BRA)": "Athletico Paranaense", "CR Flamengo (BRA)": "Flamengo", "Ceará CE (BRA)": "Ceará",
    "Corinthians SP (BRA)": "Corinthians", "SC Corinthians Paulista (BRA)": "Corinthians", "Cruzeiro EC (BRA)": "Cruzeiro",
    "Cuiabá MT (BRA)": "Cuiabá", "Fluminense FC (BRA)": "Fluminense", "Fortaleza CE (BRA)": "Fortaleza", "Fortaleza EC (BRA)": "Fortaleza",
    "Goiás GO (BRA)": "Goiás", "Grêmio FBPA (BRA)": "Grêmio", "Grêmio Porto Alegre (BRA)": "Grêmio", "Mirassol FC (BRA)": "Mirassol",
    "Red Bull Bragantino (BRA)": "RB Bragantino", "SC Internacional (BRA)": "Internacional", "SE Palmeiras (BRA)": "Palmeiras",
    "Santos FC (BRA)": "Santos", "São Paulo FC (BRA)": "São Paulo", "Vasco da Gama RJ (BRA)": "Vasco da Gama", "Vitória BA (BRA)": "Vitória",
    "AA Argentinos Juniors (ARG)": "Argentinos Juniors", "Arsenal de Sarandí (ARG)": "Arsenal Sarandi", "Belgrano de Córdoba (ARG)": "Belgrano",
    "CA Boca Juniors (ARG)": "Boca Juniors", "CA Central Córdoba (ARG)": "Central Córdoba de Santiago", "CA Huracán (ARG)": "Huracán",
    "CA Lanús (ARG)": "Lanús", "CA Platense (ARG)": "Club Atlético Platense", "CA River Plate (ARG)": "River Plate",
    "CA Rosario Central (ARG)": "Rosario Central", "CA San Lorenzo de Almagro (ARG)": "San Lorenzo", "CA Talleres (ARG)": "Talleres",
    "Talleres de Córdoba (ARG)": "Talleres", "CA Vélez Sarsfield (ARG)": "Vélez Sarsfield", "CD Godoy Cruz Antonio Tomba (ARG)": "Godoy Cruz",
    "CS Independiente Rivadavia (ARG)": "Independiente Rivadavia", "Colón de Santa Fe (ARG)": "Colon", "Estudiantes de La Plata (ARG)": "Estudiantes",
    "Gimnasia de La Plata (ARG)": "Gimnasia LP", "Unión de Santa Fe (ARG)": "Unión",
    "AD Tarma (PER)": "ADT", "Ayacucho FC (PER)": "Ayacucho", "CS Cristal (PER)": "Sporting Cristal", "CSD Sport Huancayo (PER)": "Sport Huancayo",
    "Club Alianza Lima (PER)": "Alianza Lima", "Club Universitario de Deportes (PER)": "Universitario", "Universitario de Deportes (PER)": "Universitario",
    "Cusco FC (PER)": "Cusco", "FBC Melgar (PER)": "Melgar", "Mannucci (PER)": "Carlos Mannucci", "Universidad Cesar Vallejo (PER)": "César Vallejo",
    "Universidad Técnica (PER)": "UTC Cajamarca",
    "Alianza FC (COL)": "Alianza", "Atlético Junior (COL)": "Junior", "CDP Junior FC (COL)": "Junior", "CA Bucaramanga (COL)": "Atlético Bucaramanga",
    "CD Independiente Medellín (COL)": "Independiente Medellín", "CD Tolima (COL)": "Deportes Tolima", "CDC Atlético Nacional (COL)": "Atlético Nacional",
    "Millonarios FC (COL)": "Millonarios", "Rionegro Águilas (COL)": "Águilas Doradas", "Santa Fe (COL)": "Independiente Santa Fe",
    "Atlas Guadalajara (MEX)": "Atlas", "Deportivo Guadalajara (MEX)": "Chivas", "Deportivo Toluca (MEX)": "Toluca", "Pumas UNAM (MEX)": "Pumas",
    "UANL Tigres (MEX)": "Tigres",
    "Barcelona SC (ECU)": "Barcelona", "CAR Independiente del Valle (ECU)": "Independiente Valle", "Independiente del Valle (ECU)": "Independiente Valle",
    "CSCyD El Nacional (ECU)": "El Nacional", "Delfín SC (ECU)": "Delfín", "LDU de Quito (ECU)": "LDU Quito", "Orense SC (ECU)": "Orense",
    "SD Aucas (ECU)": "Aucas",
    "CD Cobresal (CHI)": "Cobresal", "CD Coquimbo Unido (CHI)": "Coquimbo Unido", "CD Huachipato (CHI)": "Huachipato", "CD Iquique (CHI)": "Deportes Iquique",
    "CD Nublense (CHI)": "Ñublense", "CD Palestino (CHI)": "Palestino", "CD Universidad Católica (CHI)": "Universidad Católica",
    "CF Universidad de Chile (CHI)": "Universidad de Chile", "CSD Colo-Colo (CHI)": "Colo Colo", "O'Higgins FC (CHI)": "O'Higgins",
    "CD Blooming (BOL)": "Blooming", "CD Guabirá (BOL)": "Guabirá", "Club Always Ready (BOL)": "Always Ready", "Club Aurora (BOL)": "Aurora",
    "Club Bolívar (BOL)": "Bolívar", "Club Nacional Potosí (BOL)": "Nacional Potosí", "Club The Strongest (BOL)": "The Strongest",
    "Independiente Petrolero (BOL)": "Independiente",
    "Carabobo FC (VEN)": "Carabobo", "Caracas FC (VEN)": "Caracas", "Deportivo La Guaira FC (VEN)": "Deportivo La Guaira",
    "Deportivo Táchira FC (VEN)": "Deportivo Táchira", "Metropolitanos FC (VEN)": "Metropolitanos", "Monagas SC (VEN)": "Monagas",
    "Portuguesa FC (VEN)": "Portuguesa", "Universidad Central de Venezuela FC (VEN)": "UCV", "Zamora FC (VEN)": "Zamora",
    "Club Cerro Porteño (PAR)": "Cerro Porteño", "Club Libertad Asuncion (PAR)": "Libertad", "Club Nacional (PAR)": "Nacional Asunción",
    "Club Olimpia (PAR)": "Olimpia", "Olimpia Asuncion (PAR)": "Olimpia", "General Caballero DJLM (PAR)": "General Caballero JLM",
    "Guaraní (PAR)": "Club Guaraní",
    "Cavalry FC (CAN)": "Cavalry", "Forge FC (CAN)": "Forge",
}


WORLD_CLUB_KEYS = {"Al Hilal (KSA)": "t_2r8ytM", "Al Ittihad (KSA)": "t_4BG5Jn",
                   # The three Canadian MLS clubs, which PitchAPI files under the United States (CAN in the
                   # source): "Toronto FC" is not the Canadian league's Inter Toronto, nor "Vancouver
                   # Whitecaps" its Vancouver FC.
                   "CF Montréal (CAN)": "t_0vjCk0", "Toronto FC (CAN)": "t_1TFG85", "Vancouver Whitecaps (CAN)": "t_2CuHdk"}


NATION_SPELLINGS = {
    "Allemagne": "Germany", "Angleterre": "England", "Autriche": "Austria", "Belgique": "Belgium", "Bosnie-Herzégovine": "Bosnia and Herzegovina",
    "Croatie": "Croatia", "Danemark": "Denmark", "Écosse": "Scotland", "Espagne": "Spain", "Norvège": "Norway", "Pays-Bas": "Netherlands",
    "Pays de Galles": "Wales", "Pologne": "Poland", "Serbie": "Serbia", "Suède": "Sweden", "Suisse": "Switzerland", "Tchéquie": "Czechia",
    "Turquie": "Turkiye",
    "Bosnia & Herzegovina": "Bosnia and Herzegovina", "Bosnia-Herzegovina": "Bosnia and Herzegovina", "Côte d'Ivoire": "Ivory Coast",
    "Czech Republic": "Czechia", "Turkey": "Turkiye", "United States": "USA",
}


def match_team(pitch, name, national, country, reviewed=None):
    from .curated import CLUB_ALIASES

    spelling = None
    if not national:
        if name in WORLD_CLUB_KEYS:
            return (reviewed or {}).get(WORLD_CLUB_KEYS[name])
        suffix = COUNTRY_SUFFIX.match(name or "")
        if suffix:
            spelling, name, country = WORLD_CLUB_SPELLINGS.get(name), suffix.group(1), suffix.group(2)
    names = {normalize(name)}
    if spelling:
        names.add(normalize(spelling))
    if national and name in NATION_SPELLINGS:
        names.add(normalize(NATION_SPELLINGS[name]))
    if not national and name in CLUB_ALIASES:
        names.add(normalize(CLUB_ALIASES[name]))
    found = set()
    for n in names:
        for team, team_country in pitch.get((n, national), ()):
            if national or not country or not team_country or team_country == country:
                found.add(team)
    return found.pop() if len(found) == 1 else None


CLUB_FORMS = {"fc", "afc", "cf", "sc", "ac", "ssc", "cd", "ud", "sv", "fk", "sk", "bk", "if", "as", "us", "rc", "ca", "cfc", "club",
              "calcio", "football", "futbol", "fussball", "1"}


def club_parts(name):
    """A club's name without the club-form words at either end, and those words.

    The ordinal of "1. FC Köln" says nothing of the club's form, and "FK" is how some
    sources write "FC": neither can contradict.
    """
    folded = unicodedata.normalize("NFKD", name or "").encode("ascii", "ignore").decode().lower()
    words = [w for w in re.split(r"[^a-z0-9]+", folded) if w]
    forms = set()
    while words and words[0] in CLUB_FORMS:
        forms.add(words.pop(0))
    while words and words[-1] in CLUB_FORMS:
        forms.add(words.pop())
    forms.discard("1")
    return "".join(words), frozenset("fc" if form == "fk" else form for form in forms)


ARCHIVE_SPELLINGS = {"Porto": "FC Porto", "Dundee": "Dundee FC", "Panserraikos": "Panserraikos FC",
                     "Crvena Zvezda": "FK Crvena Zvezda", "Houston Dynamo": "Houston Dynamo FC"}


def _archive_match(clubs, name, country):
    """(club, found by its exact name?) for an archive team, or (None, False)."""
    if not country:
        return None, False
    exact, core = clubs
    where = None if country == EUROPE else country
    found = exact.get((where, normalize(name)), ()) or exact.get((where, normalize(ARCHIVE_SPELLINGS.get(name, name))), ())
    if found:
        return (next(iter(found)), True) if len(found) == 1 else (None, False)
    key, forms = club_parts(name)
    found = core.get((where, key), {}) if key else {}
    if len(found) != 1:
        return None, False
    ((team, known),) = found.items()
    return (team, False) if all(other <= forms for other in known) else (None, False)
