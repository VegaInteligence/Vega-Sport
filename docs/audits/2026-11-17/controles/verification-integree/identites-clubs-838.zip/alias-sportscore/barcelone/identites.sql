SELECT t.id,api.public_id('team',t.id) public_id,t.name,t.country_code,t.merged_into,
 ARRAY(SELECT p.provider::text||':'||p.provider_key FROM core.provider_ids p WHERE p.entity_type='team' AND p.entity_id=t.id AND p.is_current ORDER BY 1) AS current_keys,
 ARRAY(SELECT n.source::text||':'||n.kind::text||':'||n.name FROM core.entity_names n WHERE n.entity_type='team' AND n.entity_id=t.id ORDER BY 1) AS spellings
FROM core.teams t
WHERE (t.name ILIKE '%Barcelona%' AND (t.country_code IN ('ESP','ECU') OR t.merged_into IS NOT NULL OR t.name IN ('Barcelona','FC Barcelona','FC Barcelona (ESP)'))) OR t.id=707
ORDER BY t.id LIMIT 151
