import re
import unicodedata

def normalize(name):
    """Comparison form of a name: ASCII, lower case, letters and digits only."""
    folded = unicodedata.normalize("NFKD", name or "").encode("ascii", "ignore").decode().lower()
    return re.sub(r"[^a-z0-9]", "", folded)
