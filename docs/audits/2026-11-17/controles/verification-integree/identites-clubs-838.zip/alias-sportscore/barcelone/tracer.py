"""Run the unchanged resolver definitions against the two archived candidates."""
from pathlib import Path
import json
from source_extraits import identity
r=Path(__file__).resolve().parent
expected=json.loads((r/'trace.json').read_bytes())
sha=expected['git']
src=json.loads((r/'identites.json').read_bytes())
rows=[dict(zip(src['columns'],v)) for v in src['rows']]
exact,core,pitch={},{},{}
effective={}
for t in rows:
 if not any(x.startswith('pitchapi:') for x in t['current_keys']):continue
 valid={t['name']}
 for spelling in t['spellings']:
   source,kind,name=spelling.split(':',2)
   if kind!='source_spelling':valid.add(name)
 effective[t['id']]=sorted(valid)
 for n in valid:
  norm=identity.normalize(n)
  pitch.setdefault((norm,False),set()).add((t['id'],t['country_code']))
  key,forms=identity.club_parts(n)
  exact.setdefault((None,norm),set()).add(t['id'])
  core.setdefault((None,key),{}).setdefault(t['id'],set()).add(forms)
cup=identity.match_team(pitch,'FC Barcelona',False,None)
arc=identity._archive_match((exact,core),'FC Barcelona',identity.EUROPE)
result={'git':sha,'effective_pitch_names_among_captured':effective,
 'cup_fc_barcelona_country_unspecified':cup,'europe_archive_fc_barcelona':[arc[0],arc[1]],
 'limitations':'Subset of captured candidates, no timestamped historic merge log. Keys already bound in the observed database are used directly by the two writers.'}
assert (cup,arc)==(707,(707,True))

for key,value in result.items():
    assert json.loads(json.dumps(value))==expected[key], key
print('Deux règles sur les deux candidats archivés : coupe 707, archive Europe 707 (exact).')
