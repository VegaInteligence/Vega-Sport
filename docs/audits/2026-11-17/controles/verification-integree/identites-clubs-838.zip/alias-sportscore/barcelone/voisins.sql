WITH targets AS (
 SELECT m.id, m.match_date, m.home_team_id, m.away_team_id FROM core.matches m
 JOIN core.competition_seasons cs ON cs.id=m.competition_season_id WHERE cs.competition_id IN (71,209,231) AND (m.home_team_id=707 OR m.away_team_id=707)
), variants AS (
 SELECT t.id,t.match_date,t.home_team_id,t.away_team_id,h.id corrected_home,a.id corrected_away
 FROM targets t JOIN core.teams h ON (t.home_team_id=707 AND h.name='Barcelona' AND h.country_code='ESP' AND h.merged_into IS NULL) OR (t.home_team_id<>707 AND h.id=t.home_team_id)
 JOIN core.teams a ON (t.away_team_id=707 AND a.name='Barcelona' AND a.country_code='ESP' AND a.merged_into IS NULL) OR (t.away_team_id<>707 AND a.id=t.away_team_id))
 SELECT v.id,v.corrected_home,v.corrected_away,m.id neighbour,api.public_id('match',m.id) public_id,m.match_date,m.source::text,m.status::text,cs.archive_key,cs.cup_key,
 m.home_team_id,m.away_team_id,m.home_score,m.away_score
 FROM variants v LEFT JOIN core.matches m ON m.id<>v.id AND m.match_date BETWEEN v.match_date-3 AND v.match_date+3
 AND ((m.home_team_id=v.corrected_home AND m.away_team_id=v.corrected_away) OR (m.home_team_id=v.home_team_id AND m.away_team_id=v.away_team_id))
 LEFT JOIN core.competition_seasons cs ON cs.id=m.competition_season_id ORDER BY v.id,m.match_date,m.id LIMIT 101
