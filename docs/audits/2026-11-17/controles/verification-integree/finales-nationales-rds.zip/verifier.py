"""Check the production transaction and the two confirmed final IDs without contacting an API."""
from hashlib import sha256
import json,zlib
from pathlib import Path
base=Path(__file__).resolve().parent
if (base/'releve').is_dir():
    captured=base/'releve'
    sql=base.parent/'nations-precedence.sql'
else:
    captured=base
    sql=base/'nations-precedence.sql'
def h(b):return sha256(b).hexdigest()
rc=json.loads((captured/'receipt.json').read_bytes())
data=(captured/'inputs.json.zlib').read_bytes()
assert rc['exit_code']==0 and rc['definition_end_state']=='INACTIVE' and rc['sha256']==h(data) and rc['probe_sha256']==h((base/'probe.py').read_bytes())
d=json.loads(zlib.decompress(data))
assert d['readonly']=='on' and h(sql.read_text().strip().encode())==d['sha256_sql']
population,=[r for kind,r in d['rows'] if kind=='population']
cases=[r for kind,r in d['rows'] if kind=='world_cup_final_date']
assert [(r['id'],r['home_team_id'],r['away_team_id'],r['status'],r['home_score'],r['away_score']) for r in cases]==[(836,1032,1130,'not_started',None,None),(1056,5496,5490,'not_started',None,None)]
assert not [r for kind,r in d['rows'] if kind=='masked_pair'] and population['native_masks_finished_pair']==0
print(json.dumps({'at':d['at'],'snapshot':d['snapshot'],'population':population,'finals':cases},indent=2))
