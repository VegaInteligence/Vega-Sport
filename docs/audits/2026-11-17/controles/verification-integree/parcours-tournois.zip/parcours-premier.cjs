async page => {
  const origin = 'https://vegasport.vercel.app';
  const outDir = __OUTPUT__, device = __DEVICE__, mobile = device === 'iphone';
  const data = {device, started:new Date().toISOString(), checks:[], errors:[], publicReads:[], consoleErrors:[]};
  const archive = 'open-cup:world-cup-history';
  const targets = [
    {key:'france', name:'France', id:'t_2ysHaw', year:'1998', day:'1998-07-12', pastPair:/^(?:Brésil|Brazil) – France$/i, sides:['Brésil','France']},
    {key:'italie', name:'Italie', id:'t_v0001032', year:'1982', day:'1982-07-11', pastPair:/^Italie – (?:Allemagne(?: de l’Ouest| de l'Ouest)?|RFA|West Germany|Germany FR)$/i, sides:['Italie','Allemagne de l’Ouest']},
  ];
  const featured = [
    ['Champions League','l_0bfbkO'], ['Europa League','l_38d9HA'], ['Conference League','l_2WZ2tt']
  ];
  const labels = ['Bundesliga','Premier League','LaLiga','Ligue 1','Serie A','Eredivisie','Liga Portugal','Champions League','Europa League','Conference League'];
  const text = value => String(value).replace(/\s+/g,' ').trim();
  const guard = (ok,msg) => {if(!ok) throw new Error(msg)};
  const record = (step,value) => data.checks.push({step,...value});
  const run = async (step,fn) => {try {await fn()} catch(e) {data.errors.push({step,url:page.url(),error:String(e).slice(0,1300)})}};
  const samePath = (url, expected) => url.pathname.replace(/\/$/,'')===expected;
  const hasParams = (url, expected) => Object.entries(expected).every(([k,v]) => url.searchParams.get(k) === v);
  const screenshot = name => page.screenshot({path:outDir+'/'+name+'.png',animations:'disabled',scale:'css'});
  const click = async locator => {if(mobile){await locator.tap()}else{await locator.click()}};
  const pageGo = path => page.goto(origin+path,{waitUntil:'domcontentloaded'});
  const search=()=>page.getByRole('searchbox',{name:'Rechercher une sélection'});
  const nationOk=(url,id)=>samePath(url,'/nations')&&url.searchParams.get('id')===id;
  page.setDefaultTimeout(12000);
  page.on('response',r=>{
    const u=new URL(r.url());
    if(/\/api\/(?:nations|cups\/edition|cups\/index|cup-snapshot|open-cups)(?:\/|$)/.test(u.pathname))
      data.publicReads.push({url:r.url(),status:r.status()});
  });
  page.on('pageerror',error=>data.consoleErrors.push(String(error).slice(0,500)));
  data.render = await page.evaluate(()=>({width:innerWidth,height:innerHeight,devicePixelRatio,hasTouch:navigator.maxTouchPoints,userAgent:navigator.userAgent}));

  async function index() {
    await pageGo('/nations/');
    await search().waitFor();
    await click(page.getByRole('button',{name:/Toutes les sélections/}));
    await page.locator('tbody tr a[href^="/nations"]').first().waitFor();
  }
  async function landing(t) {
    await page.waitForURL(url=>nationOk(url,t.id));
    const rail=page.getByRole('complementary',{name:'Identité de la sélection'});
    await rail.getByRole('heading',{name:t.name,exact:true}).waitFor();
    return rail;
  }
  async function openNation(t) {
    await index();
    await search().fill(t.name);
    const link=page.getByRole('link',{name:t.name,exact:true});
    await link.waitFor();const href=await link.getAttribute('href');
    guard(nationOk(new URL(href,origin),t.id),'national search ID: '+href);
    await click(link);
    await landing(t);
    record('identity',{nation:t.name,id:t.id,href,url:page.url()});
  }
  async function tab(name) {
    const button=page.getByRole('tab',{name,exact:true});
    await click(button);
    const panel=page.getByRole('tabpanel',{name,exact:true});
    await panel.waitFor();
    guard(await button.getAttribute('aria-selected')==='true','Nation tab unavailable '+name);
    return panel;
  }
  const banner=()=>page.getByRole('region',{name:'Choisir une compétition'});
  const cup=(name)=>page.locator('.edition-tools').getByRole('button',{name,exact:true});
  const edition=()=>page.getByRole('combobox',{name:'Édition de la coupe',exact:true});
  const bracket=()=>page.getByRole('region',{name:'Tableau éliminatoire',exact:true});
  const box=locator=>locator.evaluate(el=>{
    const r=el.getBoundingClientRect();
    return {top:r.top,left:r.left,right:r.right,bottom:r.bottom,width:r.width,height:r.height,
            scrollWidth:el.scrollWidth,clientWidth:el.clientWidth,scrollHeight:el.scrollHeight,clientHeight:el.clientHeight};
  });
  async function finalShape(t, check, image) {
    const b=bracket();
    await b.waitFor();
    let phoneRounds = [];
    if(mobile) {
      const rounds=b.locator('.knockout-rounds');
      await rounds.waitFor();
      phoneRounds=await rounds.getByRole('button').evaluateAll(nodes=>nodes.map(n=>({name:n.innerText,pressed:n.getAttribute('aria-pressed')})));
      const finalButton=rounds.getByRole('button',{name:'Finale',exact:true});
      await click(finalButton);
      guard(await finalButton.getAttribute('aria-pressed')==='true','Finale mobile unavailable');
    }
    await page.evaluate(()=>window.scrollTo({top:0,behavior:'instant'}));
    const visual=b.locator(mobile?'.knockout-phone':'.knockout-bracket');
    await visual.waitFor();
    const match=mobile?visual.locator('.knockout-list:not(.knockout-third .knockout-list) .knockout-match').first():visual.locator('.knockout-final .knockout-match');
    await match.waitFor();
    const teams=await match.locator('.knockout-team').evaluateAll(nodes=>nodes.map(n=>({
      name:n.querySelector('.knockout-team-name')?.textContent?.trim(),
      score:n.querySelector('strong')?.textContent?.trim() ?? null,
      date:n.querySelector('.knockout-when')?.textContent?.trim() ?? null,
      follows:n.classList.contains('knockout-own'),
      winner:n.classList.contains('knockout-winner'),
      penalties:n.querySelector('small')?.getAttribute('aria-label') ?? null,
    })));
    const third=visual.locator('.knockout-third');
    const viewPort=await page.evaluate(()=>({width:innerWidth,height:innerHeight,bodyScrollWidth:document.documentElement.scrollWidth,scrollY}));
    const visibleMatch=await box(match), visibleThird=await third.isVisible()?await box(third):null, grid=await box(visual);
    record(check,{nation:t.name,year:t.year,teams,title:await match.getAttribute('title'),
      finalsVisible:await match.isVisible(),finalMatchNativeLink:await match.getAttribute('href'),
      third:visibleThird?text(await third.innerText()):null,champion:await visual.locator('.knockout-champion').count()?text(await visual.locator('.knockout-champion').innerText()):null,
      phoneRounds,layout:{viewPort,grid,visibleMatch,visibleThird},accessible:(await b.ariaSnapshot()).slice(0,4500)});
    guard(JSON.stringify(teams.map(x=>x.name))===JSON.stringify(t.sides),'Final sides wrong '+JSON.stringify(teams));
    await screenshot(image);
  }
  await run('nation-index',async()=>{
    await index();
    const count=await page.locator('tbody tr a[href^="/nations"]').count();
    record('nation-index',{count,ranked:text(await page.getByRole('button',{name:/Classées cette saison/}).innerText())});
  });
  for(const t of targets) {
    await run('profile-'+t.key,async()=>{
      await openNation(t);
      const shown=await tab('Matchs');
      await shown.getByRole('heading',{name:'Tous les matchs',exact:true}).waitFor();
      let found=[];
      for(const pair of await shown.getByText(t.pastPair).all()){
        const row=pair.locator('xpath=../..');
        const display=text(await row.innerText());
        if(/Coupe du monde/.test(display)&&/\bFinale\b/.test(display)&&!/[-‑]finale/.test(display)){
          found.push({display,href:await row.getAttribute('href')});
          await row.scrollIntoViewIfNeeded();
          await screenshot('nation-finale-'+t.key);
        }
      }
      record('national-match',{nation:t.name,finals:found});
      const players=await tab('Joueurs');
      record('national-players',{nation:t.name,count:await players.locator('a[href^="/joueurs"]').count(),text:text(await players.innerText()).slice(0,320)});
      const history=await tab('Historique');
      await history.getByRole('heading',{name:'Grands tournois',exact:true}).waitFor();
      const link=history.locator('a[href*="edition='+t.year+'"]');
      await link.waitFor();
      const href=await link.getAttribute('href'), params={id:archive,edition:t.year,view:'tableau',team:t.name};
      guard(samePath(new URL(href,origin),'/competitions')&&hasParams(new URL(href,origin),params),'Edition link differs '+href);
      await link.evaluate(el=>el.scrollIntoView({block:'center',behavior:'instant'}));
      record('edition-link',{nation:t.name,year:t.year,href,title:await link.getAttribute('title'),tone:await link.getAttribute('data-tone'),
        label:text(await link.innerText()),accessible:await link.ariaSnapshot()});
      await screenshot('edition-lien-'+t.key);
      if(mobile)await click(link);else{await link.focus();await link.press('Enter')}
      await page.waitForURL(url=>samePath(url,'/competitions')&&hasParams(url,params));
      await edition().waitFor();
      guard(await edition().inputValue()===t.year,'wrong selector value');
      const follow=page.getByRole('button',{name:'Ne plus suivre '+t.name,exact:true});
      await follow.waitFor();
      guard(await cup('Tableau').getAttribute('aria-pressed')==='true','wrong default tournament view');
      record('edition-landing',{nation:t.name,year:await edition().inputValue(),url:page.url(),
        selected:await cup('Tableau').getAttribute('aria-pressed'),standaloneBannerCount:await banner().count(),
        follow:await follow.ariaSnapshot(),heading:text(await page.locator('.edition-head h1,.edition-head h2').innerText())});
    });
    await run('bracket-'+t.key,async()=>{await finalShape(t,'bracket','tableau-'+t.key);});
    await run('views-'+t.key,async()=>{
      await click(cup('Groupes'));
      await page.waitForURL(url=>url.searchParams.get('view')==='groupes'&&url.searchParams.get('edition')===t.year);
      await page.locator('.edition-group table').first().waitFor();
      record('groups',{nation:t.name,url:page.url(),tables:await page.locator('.edition-group table').count()});
      await click(cup('Matchs'));
      await page.waitForURL(url=>url.searchParams.get('view')==='matchs');
      const totals=page.getByRole('button',{name:'Tous',exact:true});
      await click(totals);
      const filter=page.getByRole('searchbox',{name:'Rechercher une équipe dans la coupe'});
      await filter.fill(t.name);
      const row=page.locator('.cup-match').filter({has:page.getByText('Finale',{exact:true})}).first();
      await row.waitFor();
      await row.scrollIntoViewIfNeeded();
      record('edition-match',{nation:t.name,url:page.url(),date:text(await row.locator('.match-date').innerText()),
        sides:await row.locator('.team-name').allTextContents(),score:text(await row.locator('.score').innerText())});
      await screenshot('edition-finale-'+t.key);
      await click(cup('Tableau'));
      await page.waitForURL(url=>url.searchParams.get('view')==='tableau');
      await page.reload({waitUntil:'domcontentloaded'});
      await edition().waitFor();
      await bracket().waitFor();
      guard(await edition().inputValue()===t.year,'edition after reload');
      guard(await page.getByRole('button',{name:'Ne plus suivre '+t.name,exact:true}).count()===1,'team after reload');
      record('edition-reload',{nation:t.name,url:page.url(),value:await edition().inputValue(),view:await cup('Tableau').getAttribute('aria-pressed')});
    });
    await run('return-index-'+t.key,async()=>{
      await pageGo('/nations/?id='+t.id);
      await landing(t);
      const back=page.getByRole('link',{name:/Toutes les nations/});
      const href=await back.getAttribute('href');
      await click(back);
      await page.waitForURL(url=>nationOk(url,null));
      await search().waitFor();
      record('return-index',{nation:t.name,href,url:page.url()});
    });
  }
  await run('match-return-france',async()=>{
    const t=targets[0];
    await pageGo('/nations/?id='+t.id);
    await landing(t);const panel=await tab('Matchs');
    const link=panel.locator('a[href^="/matchs"][href*="m_1HdHEO"]').first();
    await link.waitFor();await click(link);
    await page.waitForURL(url=>samePath(url,'/matchs')&&url.searchParams.get('id')==='m_1HdHEO');
    const country=page.locator('a[href^="/nations"][href*="'+t.id+'"]').first();
    await country.waitFor();const title=text(await country.innerText());await click(country);await landing(t);
    record('match-return',{id:'m_1HdHEO',title,url:page.url()});
  });
  for(const [name,id] of featured){
    await run('spotlight-'+name,async()=>{
      await pageGo('/competitions');
      const region=banner(), button=region.getByRole('button',{name:new RegExp('^'+name)});
      await button.waitFor();
      const buttonNames=await region.getByRole('button').evaluateAll(nodes=>nodes.map(n=>n.querySelector('strong')?.innerText.trim()));
      guard(JSON.stringify(buttonNames)===JSON.stringify(labels),'spotlight order differs '+JSON.stringify(buttonNames));
      await click(button);
      await page.waitForURL(url=>samePath(url,'/competitions')&&url.searchParams.get('id')===id);
      const active=region.locator('button[aria-pressed="true"]');
      await active.waitFor();
      guard(await active.count()===1 && await button.getAttribute('aria-pressed')==='true','featured selection');
      await button.scrollIntoViewIfNeeded();
      record('featured-cup',{name,id,buttonNames,url:page.url(),pressed:await button.getAttribute('aria-pressed'),
        regionWidth:(await box(region)).width,layout:await page.evaluate(()=>({viewport:innerWidth,documentWidth:document.documentElement.scrollWidth})),
        accessible:(await region.ariaSnapshot()).slice(0,1900)});
      await screenshot('bandeau-'+id);
    });
  }
  data.finished=new Date().toISOString();
  return data;
}
