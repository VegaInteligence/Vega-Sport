"""Capture the public Nations, archive, and delivered-document witnesses."""
from datetime import datetime, timezone
import hashlib
import json
from pathlib import Path
from urllib.error import HTTPError, URLError
from urllib.parse import urlencode
from urllib.request import Request, urlopen

OUT = Path(__file__).resolve().parent / "http"
OUT.mkdir()
ORIGIN = "https://vegasport.vercel.app"
ARCHIVE = "open-cup:world-cup-history"
headers = {"User-Agent": "Vega Sport public audit 18 November", "Accept": "application/json"}
receipts = {}


def capture(label, path, document=False):
    url = ORIGIN + path
    request = Request(url, headers=dict(headers, Accept="text/html") if document else headers)
    now = datetime.now(timezone.utc).isoformat()
    try:
        response = urlopen(request, timeout=25)
    except HTTPError as exc:
        response = exc
    except URLError as exc:
        receipts[label] = {"url": url, "at": now, "status": None, "error": str(exc)}
        return None
    with response:
        content = response.read()
        meta = {key.lower(): value for key, value in response.headers.items()
                if key.lower() in {"content-type", "etag", "date", "age", "last-modified", "x-vercel-id", "x-vercel-cache", "x-cache"}}
        item = {
            "url": url, "final_url": response.url, "at": now, "status": response.status,
            "sha256": hashlib.sha256(content).hexdigest(), "bytes": len(content), "headers": meta,
        }
    suffix = ".html" if document else ".json"
    (OUT / (label + suffix)).write_bytes(content)
    item["file"] = label + suffix
    receipts[label] = item
    if document:
        return None
    try:
        return json.loads(content)
    except (UnicodeError, ValueError):
        return None


cup_index = capture("index-cups", "/api/cups/index")
entries = (cup_index or {}).get("cups", [])
found = next((item for item in entries if item.get("key") == "world-cup-history" and item.get("format") == "matches-v1"), None)
for key, nation, eid, yr in (("france", "France", "t_2ysHaw", "1998"), ("italie", "Italie", "t_v0001032", "1982")):
    capture("nation-" + key, f"/api/nations/{eid}?" + urlencode({"season": "2026/2027"}))
    capture("archive-ancienne-route-" + key, "/api/open-cups?" + urlencode({"competition": "world-cup-history", "season": yr}))
    if found:
        capture("archive-edition-" + key, "/api/cups/edition?" + urlencode({"competition": found["id"], "season": yr}))
        capture("archive-snapshot-" + key, "/api/cup-snapshot?" + urlencode({"kind": "edition", "competition": found["id"], "season": yr}))
    capture("page-" + key, "/competitions/?" + urlencode({"id": ARCHIVE, "edition": yr, "view": "tableau", "team": nation}), document=True)
(OUT / "receipt.json").write_text(json.dumps({"mapping": found, "requests": receipts}, ensure_ascii=False, indent=2) + "\n")
for key, value in receipts.items():
    print(key, value["status"], value.get("headers", {}).get("etag", ""), value.get("bytes", ""))
