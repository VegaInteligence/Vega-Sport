"""Verify the captured public evidence offline and compare it with the 15:42 and 16:10 receipts."""
from collections import Counter
import hashlib
import json
from pathlib import Path
import struct
from urllib.parse import parse_qs, urlsplit

ROOT = Path(__file__).resolve().parent
ARCHIVE = "open-cup:world-cup-history"
EXPECTED = {
    "France": ("france", "t_2ysHaw", 1998, "1998-07-12", "Brazil", "France", (0, 3), 64, 4),
    "Italie": ("italie", "t_v0001032", 1982, "1982-07-11", "Italy", "West Germany", (3, 1), 52, 1),
}
FEATURED = {"Champions League": "l_0bfbkO", "Europa League": "l_38d9HA", "Conference League": "l_2WZ2tt"}


def read(file):
    return json.loads((ROOT / file).read_bytes())


def digest(file):
    return hashlib.sha256((ROOT / file).read_bytes()).hexdigest()


def step(data, kind, nation=None):
    return next(item for item in data["checks"] if item["step"] == kind and (nation is None or item["nation"] == nation))


def archive_match(payload, day, kind):
    key = "team1" if kind == "cup" else "round"
    expected = [row for row in payload["matches"] if row["date"] == day and row.get("round") == "Final"]
    assert len(expected) == 1, (key, day)
    return expected[0]


def main():
    source = ROOT.joinpath("git-source.txt").read_text()
    assert source.startswith("08fa22e7875dd971e4e2ea415d6d5be13eb72347 2f25e3e58fa752d34ab0dcc494ff87d6d99fac22")
    assert "b2e6dd82d36a2ca0f439ec84bf2e5dbbcd3013d9\trefs/heads/main" in (ROOT/"remote-after.txt").read_text()
    assert (ROOT/"commits-between.txt").read_text().splitlines() == ["M\tWORKLOG.md"]
    assert digest("front-latest.html") == digest("http/page-france.html")
    http = read("http/receipt.json")
    direct = read("cloudfront/receipt.json")
    assert http["mapping"]["id"] == "l_v0000064"
    for request in http["requests"].values():
        assert digest("http/" + request["file"]) == request["sha256"]
    for key, item in direct.items():
        assert item["status"] == 200 and digest("cloudfront/" + key + ".json") == item["sha256"]
    prior = {row["team"]: row for row in read("prior/L18-http-1547.json")}
    finals = {}
    for country, (key, team_id, year, day, raw_home, raw_away, score, count, scored) in EXPECTED.items():
        doc = read(f"http/nation-{key}.json")["data"]
        direct_doc = read(f"cloudfront/nation-{key}.json")["data"]
        assert doc["id"] == direct_doc["id"] == team_id
        profile_game = archive_match(doc, day, "nation")
        assert profile_game == archive_match(direct_doc, day, "nation")
        tournament = next(row for row in direct_doc["tournaments"] if row["year"] == year)
        statuses = Counter(m["status"] for m in tournament["games"])
        expected_prior = prior[country]
        assert tournament["stage"] == expected_prior["stage"] == "Finale"
        assert statuses == expected_prior["played_status"]
        assert [profile_game.get(k) for k in ("status", "homeScore", "awayScore")] == ["not_started", None, None]
        edition = read(f"http/archive-edition-{key}.json")
        fallback = read(f"http/archive-snapshot-{key}.json")
        snapshot = read(f"cloudfront/snapshot-{year}.json")
        assert fallback == snapshot and edition["matches"] == snapshot["matches"]
        assert len(snapshot["matches"]) == count
        assert sum(row.get("score") is not None for row in snapshot["matches"]) == scored
        round_game = archive_match(snapshot, day, "cup")
        assert (round_game["team1"], round_game["team2"], round_game.get("score")) == (raw_home, raw_away, None)
        assert any(row.get("round") == "Third place match" for row in snapshot["matches"])
        for request in (f"nation-{key}", f"archive-edition-{key}", f"archive-snapshot-{key}", f"page-{key}"):
            assert http["requests"][request]["status"] == 200
        assert http["requests"][f"archive-ancienne-route-{key}"]["status"] == 404
        finals[country] = {
            "id": team_id, "year": year, "date": day,
            "history": {"previous": expected_prior["stage"], "current": tournament["stage"], "games": statuses},
            "nation_api": {"status": profile_game["status"], "home": profile_game["home"], "away": profile_game["away"], "score": [None, None]},
            "tournament_api": {"score": None, "record": round_game, "scored": scored, "total": count, "worker": snapshot["worker"]},
            "historical_score": score,
        }
    devices = {}
    for device, width, height in (("desktop", 1440, 900), ("iphone", 393, 852)):
        folder = f"final-{device}"
        data, receipt = read(folder + "/result.json"), read(folder + "/receipt.json")
        assert not data["errors"] and not data["consoleErrors"]
        assert data["render"]["width"] == width and data["render"]["height"] == height
        assert bool(data["render"]["hasTouch"]) == (device == "iphone")
        assert receipt["script_sha256"] == digest("parcours.cjs")
        for name, checksum in receipt["files"].items():
            assert digest(folder + "/" + name) == checksum, name
            if name.endswith(".png"):
                assert struct.unpack(">II", (ROOT / folder / name).read_bytes()[16:24]) == (width, height)
        before_l18 = read(f"prior/L18-1610-{width}.json")
        before_l22 = read(f"prior/L22-1542-{width}.json")
        before_spotlight = {c["name"]: c for c in before_l22["checks"] if c["step"] == "featured-cup"}
        geometry = {}
        for nation, (_, ident, year, _, _, _, _, _, _) in EXPECTED.items():
            assert step(data,"identity",nation)["id"] == step(before_l18,"identity",nation)["id"] == ident
            assert step(data,"national-players",nation)["count"] == step(before_l18,"players",nation)["count"]
            ed_link = step(data, "edition-link",nation)
            landing = step(data,"edition-landing",nation)
            reload = step(data, "edition-reload", nation)
            assert "Finale" in step(before_l18,"history",nation)["tile"] and "Finale" in ed_link["label"]
            for addr in (ed_link["href"],landing["url"],reload["url"]):
                query = parse_qs(urlsplit(addr).query)
                assert [query[k] for k in ("id","team","view","edition")] == [[ARCHIVE], [nation], ["tableau"], [str(year)]]
            assert landing["standaloneBannerCount"] == 0 and reload["view"] == "true"
            br = step(data,"bracket",nation)
            last = br["layout"]["grid"]
            assert 0 <= last["top"] < last["bottom"] <= height
            assert 0 <= last["left"] < last["right"] <= width
            assert br["finalsVisible"] and br["third"] and br["champion"] is None
            assert br["finalMatchNativeLink"] is None and br["teams"][0]["score"] is None and br["teams"][1]["score"] == "–"
            assert step(data,"edition-match",nation)["score"] == "À venir"
            assert all(row["cells"][2:] == ["0","0","0"] for row in step(data,"groups",nation)["groupRows"])
            assert any(r["status"] == 200 and f"competition=l_v0000064&season={year}" in r["url"] for r in data["publicReads"])
            geometry[nation] = {"layout": br["layout"], "phone_initial": br["initialPhoneLayout"],
                                "final_round_in_accessibility_snapshot": "Finale" in br["accessible"], "cards": br["matchCards"]}
        assert step(data,"localized-match-search","Italie")["empty"]
        assert step(data,"edition-match","Italie")["query"] == "Italy"
        assert step(data,"match-return")["id"] == "m_1HdHEO"
        assert step(data,"clear-following","France")
        selected_cups = [c for c in data["checks"] if c["step"] == "featured-cup"]
        assert {c["name"]:c["id"] for c in selected_cups} == FEATURED
        for cup in selected_cups:
            prior_cup = before_spotlight[cup["name"]]
            assert parse_qs(urlsplit(prior_cup["url"]).query)["id"] == [cup["id"]]
            assert prior_cup["selected"] == cup["pressed"] == "true"
            assert len(cup["buttonNames"]) == 10
            assert all(old.startswith(new) for old,new in zip(prior_cup["titles"],cup["buttonNames"]))
            assert cup["layout"]["viewport"] == cup["layout"]["documentWidth"] == width
        devices[device] = {"observations": len(data["checks"]), "started": data["started"], "ended": data["finished"],
            "spotlight": selected_cups, "geometry": geometry}
    report = {
        "source": "08fa22e7875dd971e4e2ea415d6d5be13eb72347",
        "product_change_commit": "2f25e3e58fa752d34ab0dcc494ff87d6d99fac22",
        "remote_followup": {"sha": "b2e6dd82d36a2ca0f439ec84bf2e5dbbcd3013d9",
                            "files":["WORKLOG.md"], "identical_served_france_document_sha256":digest("front-latest.html")},
        "outcome": "Comparison reproduced, with the historical data and language findings recorded",
        "finals": finals, "devices": devices,
        "localization_witness": {"translated_search": "Italie", "working_archive_alias": "Italy", "observed_devices": 2},
        "iphone_clear_follow": {
            "earlier_runner_error": next(item for item in read("verification-iphone/result.json")["errors"] if item["error"] == "Error: clear following state"),
            "final_observation": step(read("final-iphone/result.json"), "clear-following", "France"),
            "interpretation": "Immediate DOM assertion preceded the committed URL render; a clean replay after detachment passed.",
        },
        "scores_historically_correct": False,
        "historical_points_proved": False,
        "source_verified": {"national_matches": "Vercel and actual CloudFront browser endpoint",
                            "tournaments": "CloudFront /api/cup-snapshot and public edition mirror"},
    }
    (ROOT / "comparison.json").write_text(json.dumps(report, ensure_ascii=False, indent=2) + "\n")
    print("Reproduced receipts and 58 browser observations for two formats. Historical discrepancies retained.")


if __name__ == "__main__":
    main()
