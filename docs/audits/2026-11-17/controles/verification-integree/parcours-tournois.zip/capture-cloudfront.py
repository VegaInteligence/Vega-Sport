"""Repeat the actual public transport URLs seen in Chromium."""
from datetime import datetime, timezone
import hashlib
import json
from pathlib import Path
from urllib.parse import parse_qs, urlparse
from urllib.request import Request, urlopen

HERE = Path(__file__).resolve().parent
OUT = HERE / "cloudfront"
OUT.mkdir()
data = json.loads((HERE / "verification-desktop" / "result.json").read_bytes())
routes = {}
for read in data["publicReads"]:
    u = urlparse(read["url"])
    qu = parse_qs(u.query)
    assert u.hostname in {"dngp6kh9jx2bl.cloudfront.net", "vegasport.vercel.app"}, u
    if u.path == "/api/cup-snapshot" and qu.get("competition") == ["l_v0000064"] and qu.get("season") in (["1998"], ["1982"]):
        routes["snapshot-" + qu["season"][0]] = read["url"]
    for id_, name in (("t_2ysHaw", "france"), ("t_v0001032", "italie")):
        if u.path == f"/api/nations/{id_}" and qu.get("season") == ["2026/2027"]:
            routes["nation-" + name] = read["url"]
assert len(routes) == 4, routes
out = {}
for key, route in sorted(routes.items()):
    started = datetime.now(timezone.utc).isoformat()
    with urlopen(Request(route, headers={"Accept": "application/json"}), timeout=20) as response:
        body = response.read()
        out[key] = {
            "url": route, "status": response.status, "started": started, "etag": response.headers.get("etag"),
            "age": response.headers.get("age"), "bytes": len(body), "sha256": hashlib.sha256(body).hexdigest(),
        }
    (OUT / f"{key}.json").write_bytes(body)
(OUT / "receipt.json").write_text(json.dumps(out, ensure_ascii=False, indent=2) + "\n")
print("CloudFront", len(out), "response bodies retained")
