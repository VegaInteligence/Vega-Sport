# Rejouer la vérification

Extraire le ZIP, ouvrir son dossier et exécuter `python3 -B verifier.py`. Le vérificateur contrôle les empreintes puis reproduit la comparaison à partir des pièces présentes. Il ne dépend pas d’un worktree. Le JSON conserve les défauts historiques et de traduction, ainsi que l’erreur intermédiaire de synchronisation du harnais.

Pour un nouveau relevé public, utiliser une copie du dossier de preuves, les exécutables locaux Playwright CLI et Chromium et deux noms de sessions inédits. Les deux premières commandes enregistrent des réponses actuelles et elles peuvent observer une version différente de celle décrite. `capture-cloudfront.py` s’appuie sur le fichier de la passe intermédiaire bureau pour retrouver les URL CloudFront de cette preuve.

```sh
python3 -B run.py desktop nouveau-bureau --cli "$PLAYWRIGHT_CLI" --chromium "$CHROMIUM" --session l18-bureau-neuf
python3 -B run.py iphone nouvel-iphone --cli "$PLAYWRIGHT_CLI" --chromium "$CHROMIUM" --session l18-iphone-neuf
python3 -B verifier.py
```

Le résultat de preuve est daté. Les événements navigateur, captures, reçus HTTP et données d’avant déploiement se lisent dans les sous-dossiers. [Rapport](RAPPORT.md)
