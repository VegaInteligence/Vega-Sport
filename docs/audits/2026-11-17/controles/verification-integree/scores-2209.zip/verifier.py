"""Verify packaged input bytes and regenerate the published results offline."""
from argparse import ArgumentParser
import hashlib
import json
from pathlib import Path
import re
import sys
from tempfile import TemporaryDirectory

BASE = Path(__file__).resolve().parent
sys.path.insert(0, str(BASE / "outils"))
from reconcilier import generate


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def audit_manifest():
    manifest = json.loads((BASE / "manifeste.json").read_bytes())
    listed = manifest["files"]
    actual = {f.relative_to(BASE).as_posix() for f in BASE.rglob("*") if f.is_file() and
              f.name != "manifeste.json" and "__pycache__" not in f.parts}
    if set(listed) != actual or any(
        (BASE/name).is_symlink() or not (BASE/name).resolve().is_relative_to(BASE) or
        sha(BASE/name) != mark["sha256"] or (BASE/name).stat().st_size != mark["bytes"]
        for name, mark in listed.items()
    ):
        raise ValueError("manifeste · fichier manquant, ajouté ou altéré")
    for relative in (f for f in listed if f.endswith(".md")):
        markdown = BASE/relative
        for link in re.findall(r"\]\(([^)]+)\)", markdown.read_text(encoding="utf-8")):
            if not link.startswith(("https://","http://","#")) and not (markdown.parent/link.split("#",1)[0]).is_file():
                raise ValueError(f"lien relatif absent · {link}")
    return len(actual)


def verify(negative):
    count = audit_manifest()
    with TemporaryDirectory() as path:
        scratch = Path(path)
        result = generate(scratch, negative)
        reproduced = {f.name:sha(f) for f in scratch.iterdir()}
    published = {f.name:sha(f) for f in (BASE/"resultats").iterdir()}
    if reproduced != published:
        raise ValueError("sortie publiée différente du rejeu")
    return {"files_checked":count, "derived_files":len(published),
            "rows":result["rows"],"source_snapshots":len(result["snapshots"]),
            "source_queries_per_snapshot":[entry["sql_count"] for entry in result["snapshots"].values()]}


if __name__ == "__main__":
    cli = ArgumentParser()
    cli.add_argument("--negative",action="store_true",help="invalider la liaison édition dans le calcul")
    args = cli.parse_args()
    try:
        print(json.dumps(verify(args.negative),sort_keys=True))
    except (AssertionError, KeyError, RuntimeError, ValueError) as error:
        cli.exit(1,str(error)+"\n")
