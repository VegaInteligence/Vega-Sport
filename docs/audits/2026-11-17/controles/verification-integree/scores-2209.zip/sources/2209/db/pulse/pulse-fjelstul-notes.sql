WITH linked AS (
SELECT w.tournament_key,w.match_key,m.id,m.season_id FROM core.worldcup_matches w JOIN core.matches m ON m.id=w.match_id
)
SELECT k.tournament_key,count(*) AS linked_matches,
count(*) FILTER (WHERE EXISTS (SELECT 1 FROM core.lineups l WHERE (l.match_id,l.season_id)=(k.id,k.season_id))) AS native_lineup_matches,
count(*) FILTER (WHERE EXISTS (SELECT 1 FROM core.player_match_stats z WHERE (z.match_id,z.season_id)=(k.id,k.season_id))) AS native_player_stat_matches,
count(*) FILTER (WHERE EXISTS (SELECT 1 FROM agg.team_elo t WHERE (t.match_id,t.season_id)=(k.id,k.season_id))) AS with_elo,
count(*) FILTER (WHERE EXISTS (SELECT 1 FROM core.worldcup_appearances a WHERE a.match_key=k.match_key AND a.role='player')) AS fjelstul_player_matches
FROM linked k GROUP BY k.tournament_key ORDER BY k.tournament_key