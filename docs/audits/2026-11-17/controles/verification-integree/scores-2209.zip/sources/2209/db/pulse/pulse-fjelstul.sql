SELECT t.tournament_key,count(DISTINCT w.match_key) AS source_matches,
count(DISTINCT w.match_key) FILTER (WHERE w.match_id IS NOT NULL) AS linked_matches,
count(*) FILTER (WHERE a.role='player' AND a.starter IS TRUE) AS starters,
count(*) FILTER (WHERE a.role='player' AND a.starter IS FALSE) AS entered_substitutes,
count(*) FILTER (WHERE a.role='referee') AS referees,
count(*) FILTER (WHERE a.role='manager') AS managers
FROM core.worldcup_tournaments t LEFT JOIN core.worldcup_matches w ON w.tournament_key=t.tournament_key
LEFT JOIN core.worldcup_appearances a ON a.match_key=w.match_key GROUP BY t.tournament_key ORDER BY t.tournament_key