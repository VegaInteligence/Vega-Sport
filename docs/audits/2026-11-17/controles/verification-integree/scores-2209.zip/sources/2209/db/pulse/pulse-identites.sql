SELECT provider,is_current,count(*) AS match_keys,
count(*) FILTER (WHERE m.id IS NULL) AS orphaned_match_keys
FROM core.provider_ids p LEFT JOIN core.matches m ON p.entity_id=m.id WHERE p.entity_type='match'
GROUP BY provider,is_current ORDER BY provider,is_current