"""Validate and aggregate three recorded censuses. This module never connects to a source."""
import ast
from collections import Counter, defaultdict
import csv
from datetime import datetime
import gzip
import hashlib
import io
import json
from pathlib import Path
import re
import shutil
import subprocess
import sys
from tempfile import TemporaryDirectory

from comparer import capture_validation

ROOT = Path(__file__).resolve().parents[1]
LABELS = ("1753", "1837", "2209")
ENTITIES = ("player", "club", "national team")
METRICS = ("expected_algorithm", "actual_valid", "missing_from_storage", "role_unavailable",
           "known_participations_minimum", "known_without_stats", "known_without_measured_minutes")
CATALOG_META = ("season_id", "season", "competition_id", "competition", "country_code", "competition_kind")


def require(condition, message):
    if not condition:
        raise ValueError(message)


def sha(raw):
    return hashlib.sha256(raw).hexdigest()


def load(path):
    return json.loads(path.read_bytes())


def rows(path):
    obj = load(path)
    require(len(obj["columns"]) == len(set(obj["columns"])), f"colonnes dupliquées · {path.name}")
    return [dict(zip(obj["columns"], row, strict=True)) for row in obj["rows"]]


def unique(sequence, *columns):
    index = {}
    for row in sequence:
        key = tuple(row[c] for c in columns)
        require(key not in index, f"clé dupliquée · {key}")
        index[key] = row
    return index


def read_csv(path):
    payload = path.read_bytes()
    if path.suffix == ".gz":
        payload = gzip.decompress(payload)
    return list(csv.DictReader(io.StringIO(payload.decode("utf-8"), newline="")))


def write_csv(path, records):
    require(bool(records), f"aucune ligne · {path.name}")
    with path.open("w", newline="", encoding="utf-8") as stream:
        writer = csv.DictWriter(stream, fieldnames=tuple(records[0]), lineterminator="\n")
        writer.writeheader()
        writer.writerows(records)


def parse_time(value):
    return datetime.fromisoformat(value)


def run_script(script, *args, cwd):
    command = [sys.executable, "-B", str(script), *map(str, args)]
    result = subprocess.run(command, cwd=cwd, capture_output=True, text=True, check=False)
    require(result.returncode == 0, f"{script.name} · {result.stderr or result.stdout}")
    return result.stdout.strip()


def source_files(base):
    return {p.stem: p for p in (base / "db").rglob("*.json")}


def fixture_catalog(base):
    """Reconcile every edition with the independently queried, source-disjoint fixture counts."""
    index = source_files(base)
    catalog = {eid: r for (eid,), r in unique(rows(index["editions"]), "edition_id").items()}
    by_edition = defaultdict(Counter)
    editions_sources = defaultdict(set)
    by_source = defaultdict(Counter)
    measure = ("recorded", "finished", "finished_scored", "finished_scored_both_teams",
               "archive_recorded", "archive_finished_scored_both_teams")
    fixtures = unique(rows(index["fixture-universe"]), "source", "edition_id")
    for (source, edition), row in fixtures.items():
        if edition is None:
            continue
        require(edition in catalog, f"édition de source inconnue · {edition}")
        values = {metric: int(row[metric]) for metric in measure}
        require(0 <= values["finished_scored_both_teams"] <= values["finished_scored"] <= values["finished"] <= values["recorded"],
                f"bornes des rencontres invalides · {edition}")
        by_edition[edition].update(values)
        by_source[source].update(values)
        editions_sources[edition].add(source)
    totals = {}
    for (source, edition), row in fixtures.items():
        if edition is None:
            require(all(by_source[source][metric] == row[metric] for metric in measure),
                    f"sous-total fournisseur divergent · {source}")
            totals[source] = dict(by_source[source])
    require(set(totals) == set(by_source), "une source n'a pas de total")
    for ed, row in catalog.items():
        detail = by_edition[ed]
        require((row["recorded_matches"], row["finished"], row["finished_unknown_score"])
                == (detail["recorded"], detail["finished"], detail["finished"] - detail["finished_scored"]),
                f"univers des rencontres divergent · {ed}")
    return catalog, editions_sources, totals


def verify_edition_grid(base, catalog, grid):
    expected_keys = {(edition, entity) for edition in catalog for entity in ENTITIES}
    index = {(int(edition), entity): row for (edition, entity), row in unique(grid, "edition_id", "entity_type").items()}
    require(index.keys() == expected_keys, "jointure incomplète catalogue × entités")
    results = source_files(base)
    player_rows, pending = {}, defaultdict(Counter)
    for query, source in results.items():
        actual_rows = rows(source)
        if actual_rows and "edition_id" in actual_rows[0]:
            require(all(row["edition_id"] is None or row["edition_id"] in catalog for row in actual_rows),
                    f"édition de résultat inconnue · {query}")
        if re.fullmatch(r"player-scores-\d{4}", query):
            year = int(query[-4:])
            for row in actual_rows:
                edition = row["edition_id"]
                require(edition not in player_rows and catalog[edition]["season_id"] == year,
                        f"partition de scores discordante · {edition}")
                player_rows[edition] = row
        if re.fullmatch(r"award-role-\d{4}", query):
            for row in actual_rows:
                assignable = row["current_assignable"] + row["recovered_by_award_history"]
                unknown = row["no_model_role_after_award_history"]
                require(assignable + unknown == row["pending"], f"rôle sans partition · {row['edition_id']}")
                pending[row["edition_id"]].update(assignable=assignable, unknown=unknown)
    exact = unique(rows(results["team-exact"]), "edition_id", "entity_type")
    for (edition, entity), item in index.items():
        physical = catalog[edition]
        for field in (*CATALOG_META, "recorded_matches", "finished"):
            require(item[field] == ("" if physical[field] is None else str(physical[field])),
                    f"catalogue différent · {edition}, {field}")
        expected, actual, missing = (int(item[k]) for k in METRICS[:3])
        require(0 <= actual <= expected and missing == expected - actual,
                f"arithmétique de couverture invalide · {edition}, {entity}")
        if entity == "player":
            bin_ = player_rows.get(edition, {})
            role = pending[edition]
            require((expected, actual, int(item["role_unavailable"])) ==
                    (int(bin_.get("proven_scorable") or 0) + role["assignable"],
                     int(bin_.get("scorable_valid_persisted") or 0), role["unknown"]),
                    f"jointure des notes et rôles invalide · {edition}")
            before = int(bin_.get("algorithm_inputs_before_coverage") or 0)
            require(expected + role["unknown"] == before, f"base de calcul incomplète · {edition}")
        else:
            row = exact.get((edition, entity), {})
            require((expected, actual, missing) == tuple(int(row.get(k) or 0) for k in ("expected_sides", "stored_valid", "missing")),
                    f"jointure Elo invalide · {edition}, {entity}")
    return index


def local_capture(stage, label):
    original = ROOT / "sources" / label
    receipt = capture_validation(original)
    base = stage / label
    shutil.copytree(original, base)
    logs = [run_script(base/"scores/build-score-grid.py", cwd=base),
            run_script(base/"verify_grid.py", cwd=base)]
    out = base / "published"
    logs.append(run_script(ROOT/"outils/calculer.py", base, out, cwd=base))
    catalog, editions_sources, by_source = fixture_catalog(base)
    grid = verify_edition_grid(base, catalog, read_csv(out/"scores-par-edition.csv.gz"))
    annual = {(year, entity): row for (year, entity), row in unique(read_csv(out/"scores-par-saison.csv.gz"), "season_id", "entity_type").items()}
    totals = defaultdict(Counter)
    for row in grid.values():
        totals[row["season_id"], row["entity_type"]].update({k: int(row[k] or 0) for k in METRICS[:4]})
    require(annual.keys() == totals.keys(), f"couverture des saisons incomplète · {label}")
    for key, measures in totals.items():
        require(all(int(annual[key][m] or 0) == n for m, n in measures.items()), f"sous-total saison divergent · {key}")
    return {"receipt":receipt,"catalog":catalog,"sources":editions_sources,"by_source":by_source,
            "grid":grid,"raw_grid":read_csv(base/"scores/coverage-by-edition-and-entity.csv"),
            "annual":annual,"logs":logs,"summary":load(out/"resultats.json")}


def compare(before, after):
    def delta(left, right):
        shared = left.keys() & right.keys()
        return {"before_rows":len(left),"after_rows":len(right),"shared_rows":len(shared),
                "added_rows":len(right.keys()-left.keys()),"removed_rows":len(left.keys()-right.keys()),
                "different_rows":sum(left[key] != right[key] for key in shared),
                "cells_compared":sum(len(left[key]) for key in shared),
                "cells_changed":sum(sum(a != right[key][field] for field,a in left[key].items()) for key in shared)}
    return {"by_edition":delta(before["grid"],after["grid"]),
            "by_season":delta(before["annual"],after["annual"]),
            "raw_editions":delta(unique(before["raw_grid"],"edition_id","entity_type"),
                                 unique(after["raw_grid"],"edition_id","entity_type"))}


def bound_controls(folder, name, snapshot_file, response_names):
    receipt = load(folder/(name+".json"))
    require(receipt["exit_code"] == 0 and receipt["definition_end_state"] == "INACTIVE", "preuve auxiliaire incomplète")
    require(load(folder/snapshot_file) == receipt["snapshot"] and receipt["snapshot"]["read_only"] == "on",
            "instantané auxiliaire incorrect")
    require(sha((folder/snapshot_file).read_bytes()) == receipt["result_sha256"]["snapshot"], "empreinte instantané auxiliaire")
    for raw in response_names:
        require(sha((folder/(raw+".json")).read_bytes()) == receipt["result_sha256"][raw], f"empreinte auxiliaire · {raw}")
        require(sha((folder/(raw+".sql")).read_bytes()) == receipt["query_sha256"][raw], f"empreinte SQL auxiliaire · {raw}")
    return receipt["snapshot"]


def policies(catalog, negative):
    folder = ROOT/"sources/perimetres"
    clocks = {
        "pitch_aggregate":bound_controls(folder,"controle-pitch","snapshot.json",("perimetres","source")),
        "exact_links":bound_controls(folder,"liaisons-exactes","liaisons-snapshot.json",("liaisons",)),
    }
    declared = {}
    defs = {"REMOVED":("native",""),"REMOVED_FOLDERS":("dossier","cup:open-matchday:"),
            "REMOVED_ARCHIVES":("archive","archive:")}
    for entry in ast.parse((folder/"scope-202f.py").read_text()).body:
        if isinstance(entry,ast.Assign) and isinstance(target:=entry.targets[0],ast.Name) and target.id in defs:
            domain, prefix = defs[target.id]
            declared.update({(domain,prefix+key):label for key,label in ast.literal_eval(entry.value).items()})
    require(set(Counter(k[0] for k in declared)) == {"native","dossier","archive"}, "listes de retrait incomplètes")
    mapped = unique(rows(folder/"liaisons.json"),"domain","provider_key","edition_id")
    require({(domain,key) for domain,key,_ in mapped} == declared.keys(), "les clés SQL diffèrent du code déployé")
    linked_editions = defaultdict(set)
    scoped_editions = defaultdict(set)
    scoped_competitions = defaultdict(set)
    configured = set()
    for ident,row in mapped.items():
        domain, key, edition = ident
        if edition is None:
            require(row["competition_id"] is None or not any(e["competition_id"]==row["competition_id"] for e in catalog.values()),
                    "un périmètre est déclaré vide malgré le catalogue")
            continue
        if negative:
            edition = -1
        require(edition in catalog, f"liaison hors du catalogue exact · {edition}")
        ed = catalog[edition]
        require((ed["competition_id"],ed["season_id"],ed["competition"]) ==
                (row["competition_id"],row["season_id"],row["name"]), f"identité de liaison différente · {edition}")
        require((domain!="archive" or bool(ed["archive_key"])) and (domain!="dossier" or bool(ed["cup_key"])),
                f"nature de la source incompatible · {edition}")
        configured.add((domain,key))
        linked_editions[edition].add((domain,key))
        scoped_editions[(domain,key)].add(edition)
        scoped_competitions[(domain,key)].add(row["competition_id"])
    aggregate = unique(rows(folder/"perimetres.json"),"k")
    require({key for (key,) in aggregate} == {key for domain,key in declared if domain=="native"}, "liste Pitch non exhaustive")
    for (key,), row in aggregate.items():
        ids = scoped_editions[("native",key)]
        require((row["editions"],row["fixtures"],row["finished"]) ==
                (len(ids),sum(catalog[ed]["recorded_matches"] for ed in ids),sum(catalog[ed]["finished"] for ed in ids))
                and ({row["competition_id"]} if row["competition_id"] is not None else set())==scoped_competitions[("native",key)],
                f"observation Pitch non réconciliée · {key}")
    return declared, linked_editions, scoped_editions, scoped_competitions, configured, clocks


def fjelstul(index):
    all_ = unique(rows(index["pulse-fjelstul"]), "tournament_key")
    joined = unique(rows(index["pulse-fjelstul-notes"]), "tournament_key")
    require(joined.keys() <= all_.keys(), "tournoi Fjelstul inconnu")
    output = []
    for key, data in sorted(all_.items()):
        links = joined.get(key,{})
        require(0 <= data["linked_matches"] <= data["source_matches"]
                and data["linked_matches"] == links.get("linked_matches",0), f"liaison Fjelstul invalide · {key[0]}")
        require(all(0 <= int(v) <= data["linked_matches"] for field,v in links.items() if field!="tournament_key"),
                f"activité rattachée Fjelstul invalide · {key[0]}")
        known = data["starters"] + data["entered_substitutes"]
        all_linked = data["linked_matches"] == data["source_matches"]
        missing_link = data["linked_matches"] == 0
        output.append({**data,"known_player_appearances":known,
            "known_in_linked_tournaments":known if all_linked else 0 if missing_link else "",
            "known_in_unlinked_tournaments":known if missing_link else 0 if all_linked else "",
            **{metric:links.get(metric,0) for metric in ("fjelstul_player_matches","native_lineup_matches",
                "native_player_stat_matches","with_elo")}})
    summable = [name for name in output[0] if name!="tournament_key"]
    def summarize(selection):
        return {field:sum(int(x[field] or 0) for x in selection) for field in summable}
    return output, {"all":summarize(output),
                    "men_1970_2018":summarize([r for r in output if 1970<=int(r["tournament_key"][-4:])<=2018 and r["linked_matches"]]),
                    "men_2022":summarize([r for r in output if r["tournament_key"]=="WC-2022"]),
                    "tournaments":len(output),"linked_tournaments":len(joined)}


def summarize(catalog, grid, edition_ids):
    metrics = defaultdict(Counter)
    for edition in sorted(edition_ids):
        for entity in ENTITIES:
            row = grid[edition,entity]
            metrics[entity].update({field:int(row[field] or 0) for field in
                (*METRICS, "archive_policy_excluded", "matched_copies_excluded")})
    return {"editions":len(edition_ids),
            "competitions":len({catalog[ed]["competition_id"] for ed in edition_ids}),
            "matches":sum(catalog[ed]["recorded_matches"] for ed in edition_ids),
            "finished":sum(catalog[ed]["finished"] for ed in edition_ids),
            "by_entity":dict(metrics)}


def regroup(catalog, grid, keys):
    output = []
    for labels, edition_ids in sorted(keys.items()):
        sample = summarize(catalog,grid,edition_ids)
        for entity in ENTITIES:
            metrics = sample["by_entity"].get(entity,Counter())
            output.append({**dict(labels), "entity_type":entity,
                           **{key:sample[key] for key in ("editions","competitions","matches","finished")},
                           **{field:metrics[field] for field in METRICS[:3]},
                           "role_unavailable":metrics["role_unavailable"] if entity=="player" else ""})
    return output


def saudi(catalog, mapped):
    source = ROOT/"sources/saudi"
    archive = load(source/"trois-editions.json")
    evidence = read_csv(source/"202-rencontres.csv")
    unique(evidence,"edition","saff_fixture")
    target = mapped["native","l_1SGwQT"]
    require(target == {int(r["edition"]) for r in evidence}, "liaison manquante d'une édition saoudienne")
    official, missing = [], []
    for ed in archive["editions"]:
        fixtures = [r for r in evidence if int(r["edition"])==ed["edition"]]
        reported = [r for r in fixtures if r["score_saff"]]
        equal = [r for r in reported if r["resultat_identique"]=="True"]
        absent = [r for r in reported if r["resultat_manquant"]=="True"]
        require(len(fixtures) == ed["calendrier"] == catalog[ed["edition"]]["recorded_matches"]
                and len(reported) == ed["joues_saff"] and len(equal) == ed["scores_confirmes"]
                and len(reported) == len(equal)+len(absent) and len(absent) == ed["resultats_manquants"],
                f"écart fédération/lecteur non réconcilié · {ed['edition']}")
        official.append({"edition":ed["edition"],"season":ed["saison"],"saff_finished_prior_audit":len(reported),
                         "same_result_prior_audit":len(equal),"missing_prior_audit":len(absent),
                         "physical_finished_2209":catalog[ed["edition"]]["finished"]})
        missing.extend(absent)
    require(len(missing)==20 and {r["edition"] for r in missing}=={"1002"}, "20 rencontres historiques saoudiennes")
    return missing, {"league_key":"l_1SGwQT","editions":official,
                     "official_calendar":"https://www.saff.com.sa/en/championship.php?id=428&type=all"}


def generate(destination, negative=False):
    with TemporaryDirectory() as root:
        captures = {label:local_capture(Path(root),label) for label in LABELS}
    now = captures["2209"]
    catalog = now["catalog"]
    grid = now["grid"]
    input_data = source_files(ROOT/"sources/2209")
    declared, linked, scoped, competitions, configured, clocks = policies(catalog,negative)
    fj_table, fj_summary = fjelstul(input_data)
    sa_table, sa_summary = saudi(catalog,scoped)
    track_columns = ["snapshot","at","isolation","read_only"]
    snapshots = {}
    for label, capture in captures.items():
        rec = capture["receipt"]
        snap = rec["common_snapshot"]
        snapshots[label] = {k:snap[k] for k in track_columns}
        snapshots[label].update(release=rec["release"], sql_count=len(rec["query_sha256"]))
    pairs = {}
    for earlier, later in zip(LABELS, LABELS[1:]):
        old, new = captures[earlier],captures[later]
        require(parse_time(snapshots[earlier]["at"]) < parse_time(snapshots[later]["at"]), "ordre des captures")
        old_queries, new_queries = (c["receipt"]["query_sha256"] for c in (old,new))
        changed = sorted(q for q in old_queries.keys() & new_queries.keys() if old_queries[q]!=new_queries[q])
        require(not changed and old_queries.keys()<=new_queries.keys(), f"SQL antérieur modifié · {changed}")
        pairs[earlier+"_"+later] = {**compare(old,new), "same_query_bytes":len(old_queries),
                                     "additional_queries":sorted(new_queries.keys()-old_queries.keys())}
    full_ids, target_ids = set(catalog), set(linked)
    outside_ids = full_ids - target_ids
    competition_seasons = defaultdict(set)
    calendar = defaultdict(set)
    details, pending = [], []
    reason = defaultdict(Counter)
    for query, path in input_data.items():
        if re.fullmatch(r"award-role-\d{4}", query):
            for r in rows(path):
                if r["current_assignable"] + r["recovered_by_award_history"]:
                    reason[r["edition_id"]][r["award"]] += r["current_assignable"] + r["recovered_by_award_history"]
    for edition, physical in sorted(catalog.items()):
        status = "retire_declare_presents" if edition in target_ids else "hors_liste_retraits"
        fields = {"scope_status":status,"scope_keys":"|".join(key for _,key in sorted(linked.get(edition,()))),
                  "match_sources":"|".join(sorted(now["sources"][edition])),
                  "cup_key":physical["cup_key"] or "", "archive_key":physical["archive_key"] or ""}
        scope_cols = tuple((k,physical[k] if physical[k] is not None else "") for k in ("season_id","season"))
        calendar[scope_cols].add(edition)
        competition_seasons[scope_cols + (("competition_id",physical["competition_id"]),("competition",physical["competition"]),
                              ("scope_status",status))].add(edition)
        for entity in ENTITIES:
            item = grid[edition,entity]
            details.append({**item,**fields})
            if entity=="player" and int(item["missing_from_storage"]):
                require(int(item["missing_from_storage"]) == sum(reason[edition].values()), f"millésime des notes pendantes · {edition}")
                pending.append({**item, **fields, "award_years":"|".join(map(str,sorted(reason[edition])))})
    scoped_table = {(("scope_domain",domain),("provider_key",key),("scope_label",name),
                    ("scope_status","retire_declare_presents" if (domain,key) in configured else "sans_edition_liee")):scoped[domain,key]
                    for (domain,key),name in declared.items()}
    filing = {}
    for (domain,key), name in declared.items():
        total = summarize(catalog,grid,scoped[domain,key])
        filing[key] = {"domain":domain,"label":name,"competition_ids":sorted(competitions[domain,key]),**total}
    physical = {label:summarize(catalog,grid,ids) for label,ids in (
                    ("all",full_ids),("declared_removed_present",target_ids),("outside_list",outside_ids))}
    domains = {domain:summarize(catalog,grid,set().union(*(ids for (family,_),ids in scoped.items() if family==domain)))
               for domain in sorted({domain for domain,_ in declared})}
    t = physical["all"]["by_entity"]
    require(sum(int(row["missing_from_storage"]) for row in pending) == t["player"]["missing_from_storage"],
            "notes attendues non ventilées")
    require(all(physical["declared_removed_present"][f]+physical["outside_list"][f]==physical["all"][f]
                for f in ("editions","matches","finished")), "périmètres physiques non disjoints")
    publication = rows(input_data["pulse-publication"])
    matches = rows(input_data["pulse-matchday"])
    ingest = rows(input_data["pulse-ingestion"])
    ids = rows(input_data["pulse-identites"])
    pulses = {"elo_publications":publication,"already_removed_match_ids":[r["id"] for r in matches
        if r["matches"] is None and r["provider_ids"] is None and r["elo"] is None],
        "historic_ingestion_status_counts":dict(Counter(r["status"] for r in ingest)),
        "historic_dirty_markers":len(rows(input_data["pulse-marquages"])),
        "migrations":rows(input_data["pulse-migrations"]),"provider_match_keys":ids}
    results = {"snapshots":snapshots,"comparison":pairs,"physical":physical, "domains":domains,
               "declared_keys":len(declared),"keys_with_edition":len(configured),"perimeter_snapshots":clocks,
               "perimeter":filing, "pending_by_award":now["summary"]["pending_by_award"],
               "pending_edition_count":len(pending),"fixture_sources":now["by_source"],
               "fjelstul":fj_summary,"saudi":sa_summary,"pulses":pulses,
               "verification":{label:capture["logs"] for label,capture in captures.items()},
               "rows":{"edition":len(details),"season":len(now["annual"]),"pending":len(pending)}}
    destination.mkdir(parents=True,exist_ok=True)
    for name, data in (
        ("scores-par-edition",details),
        ("scores-par-competition-saison-et-entite",regroup(catalog,grid,competition_seasons)),
        ("scores-par-saison",regroup(catalog,grid,calendar)),
        ("scores-par-perimetre",regroup(catalog,grid,scoped_table)),
        ("notes-en-attente",pending),
        ("fjelstul-par-tournoi",fj_table),
        ("saudi-20-resultats-hors-perimetre",sa_table),
        ("rencontres-par-source",[{"source":k,**v} for k,v in sorted(now["by_source"].items())])):
        write_csv(destination/(name+".csv"),data)
    (destination/"resultats.json").write_text(json.dumps(results,ensure_ascii=False,sort_keys=True,indent=2)+"\n",encoding="utf-8")
    return results


if __name__ == "__main__":
    import argparse
    parser = argparse.ArgumentParser()
    parser.add_argument("destination",type=Path)
    parser.add_argument("--negative",action="store_true")
    args = parser.parse_args()
    try:
        data = generate(args.destination,args.negative)
    except ValueError as error:
        parser.exit(1,str(error)+"\n")
    print(json.dumps(data["rows"],sort_keys=True))
