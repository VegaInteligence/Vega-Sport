"""Join per-edition stored scores, algorithm gates and unresolved roles from the same MVCC transaction."""
import argparse,csv,gzip,hashlib,io,json
from collections import Counter,defaultdict
from pathlib import Path
p=argparse.ArgumentParser();p.add_argument('snapshot',type=Path);p.add_argument('destination',type=Path);a=p.parse_args()
s=a.snapshot;out=a.destination
out.mkdir(exist_ok=True,parents=True)
def read(f):return json.loads(f.read_bytes())
def h(b):return hashlib.sha256(b).hexdigest()
def integer(v):return 0 if v in ('',None) else int(v)
rc=read(s/'receipt.json');snap=read(s/'snapshot.json');assert rc['exit_code']==0 and rc['common_snapshot']==snap and snap['read_only']=='on'
def result_rows(fn):
    j=read(fn)
    assert j['at']==snap['at'] and j['snapshot']==snap['snapshot']
    return [dict(zip(j['columns'],r)) for r in j['rows']]
pending=defaultdict(Counter)
awards=defaultdict(Counter)
roles=sorted((s/'db/longitudinal').glob('award-role-*.json'))
assert len(roles)==6
for f in roles:
    for r in result_rows(f):
        edition=str(r['edition_id']); award=str(r['award'])
        assigned=int(r['current_assignable'])+int(r['recovered_by_award_history'])
        unknown=int(r['no_model_role_after_award_history'])
        assert assigned+unknown==int(r['pending'])
        for c in [pending[edition],awards[award]]:
            c.update(assignable=assigned,unknown_role=unknown)
def csvbytes(rows):
    b=io.StringIO();w=csv.DictWriter(b,fieldnames=list(rows[0]),lineterminator='\n');w.writeheader();w.writerows(rows);return b.getvalue().encode()
fields=['season_id','season','competition_id','competition','edition_id','country_code','competition_kind','entity_type']
source=list(csv.DictReader((s/'scores/coverage-by-edition-and-entity.csv').open()))
grid=[];tot=defaultdict(Counter);years=defaultdict(Counter)
for r in source:
    p=r['entity_type']=='player'
    category=r['entity_type']
    rs=pending.get(r['edition_id'],Counter()) if p else Counter()
    active_expected=integer(r['expected_proven'])+rs['assignable']
    actual=integer(r['actual_valid']);missing=active_expected-actual
    assert missing>=0
    if p:
        assert rs['assignable']+rs['unknown_role']==integer(r['admitted_without_power_match'])
        assert active_expected+rs['unknown_role']==integer(r['algorithm_inputs_before_coverage'])
    else:assert missing==integer(r['genuine_missing_after_computation'])
    counted=Counter(expected_algorithm=active_expected,actual_valid=actual,missing_from_storage=missing)
    row={k:r[k] for k in fields}
    row.update(known_participations_minimum=integer(r['known_participations_minimum']),recorded_matches=r['recorded_matches'],finished=r['finished'],**counted)
    row.update(role_unavailable=rs['unknown_role'] if p else '',known_without_stats=r['known_participants_without_stats'] if p else '',known_without_measured_minutes=r['known_participants_without_measured_minutes'] if p else '',archive_policy_excluded=r['archive_policy_excluded'] if not p else '',matched_copies_excluded=r['matched_copy'] if not p else '',eligibility_basis=('position and positive minutes, current or same award role' if p else 'deployed Elo gate over all competitions'))
    grid.append(row)
    tot[category].update(counted);years[(r['season_id'],r['season'],category)].update(counted)
    if p:
        tot[category]['role_unavailable']+=rs['unknown_role'];years[(r['season_id'],r['season'],category)]['role_unavailable']+=rs['unknown_role']
catalog=json.loads((s/'db/catalog_verified/editions.json').read_bytes())
assert len(grid)==3*len(catalog['rows']) and len({(r['edition_id'],r['entity_type']) for r in grid})==len(grid)
annual=[{'season_id':k[0],'season':k[1],'entity_type':k[2],**{name:v[name] for name in ('expected_algorithm','actual_valid','missing_from_storage')},'role_unavailable':v['role_unavailable'] if k[2]=='player' else ''} for k,v in sorted(years.items())]
for n,data in [('scores-par-edition.csv.gz',grid),('scores-par-saison.csv.gz',annual)]:
    (out/n).write_bytes(gzip.compress(csvbytes(data),mtime=0))
summary={'snapshot':snap,'source_query_sha256':rc['query_sha256'],'rows':len(grid),'season_rows':len(annual),'editions':len({r['edition_id'] for r in grid}),'competitions':len({r['competition_id'] for r in grid}),'totals':dict(tot),'pending_by_award':dict(sorted(awards.items())),'output_sha256':{p.name:h(p.read_bytes()) for p in sorted(out.glob('scores-*.gz'))},'missing_teams':[{k:r[k] for k in (*fields,'expected_algorithm','actual_valid','missing_from_storage')} for r in grid if r['entity_type']!='player' and r['missing_from_storage']]}
(out/'resultats.json').write_text(json.dumps(summary,ensure_ascii=False,indent=2)+'\n')
print(summary['rows'],summary['totals'])
