"""Compare all stored cells of two validated coverage snapshots by stable IDs."""
import argparse
from collections import Counter, defaultdict
import csv
import gzip
import hashlib
import io
import json
from pathlib import Path
import re

TABLES = (
    ("edition-publiee", "scores-par-edition.csv.gz", ("edition_id", "entity_type"), False),
    ("saison-publiee", "scores-par-saison.csv.gz", ("season_id", "entity_type"), False),
    ("edition-brute", "coverage-by-edition-and-entity.csv", ("edition_id", "entity_type"), True),
    ("saison-brute", "coverage-by-season-and-entity.csv", ("season_id", "entity_type"), True),
)
COUNTS = ("expected_algorithm", "actual_valid", "missing_from_storage", "role_unavailable")
IDENTITY = {"edition_id", "season_id", "season", "competition_id", "competition",
            "country_code", "competition_kind", "entity_type", "cup_key", "archive_key"}
FIXTURE = {"recorded_matches", "finished", "finished_unknown_score", "finished_unknown_team",
           "finished_sides", "other_status", "first_finished_date", "last_finished_date"}
INPUTS = {"known_participations_minimum", "known_without_stats", "known_without_measured_minutes",
          "known_participants_without_stats", "known_participants_without_measured_minutes",
          "matches_no_starter_sub_or_positive_minute", "lineup_presence_unconfirmed_before_event_enrichment",
          "stats_records", "positive_minutes", "minutes_unknown"}
GATE = {"archive_policy_excluded", "insufficient_result_or_identity", "excluded_date_or_team_type",
        "self_pair", "excluded_folder", "candidate_sides_before_copy_rules", "refused_self",
        "refused_folder", "matched_copy", "matched_copies_excluded", "expected_algorithm", "expected_proven",
        "algorithm_inputs_before_coverage", "admitted_without_power_match", "role_unavailable"}
SCORES = {"missing_from_storage", "genuine_missing_after_computation", "actual_valid", "grades",
          "stored_matched_sides", "invalid_or_mismatched", "stored_on_stats", "min_z", "mean_z", "max_z", "sd_z"}


def read_json(path):
    return json.loads(path.read_bytes())


def digest(raw):
    return hashlib.sha256(raw).hexdigest()


def table(path, key):
    raw = path.read_bytes()
    payload = gzip.decompress(raw) if path.suffix == ".gz" else raw
    reader = csv.DictReader(io.StringIO(payload.decode(), newline=""))
    fields = tuple(reader.fieldnames)
    rows = {}
    for row in reader:
        ident = tuple(row[k] for k in key)
        assert ident not in rows and None not in row, (path, ident)
        rows[ident] = row
    return fields, rows, digest(payload)


def classify(column):
    base = column.removesuffix("_verified_editions")
    if base in IDENTITY:
        return "catalogue"
    if base in FIXTURE:
        return "rencontre"
    if base in INPUTS:
        return "intrants_participation"
    if base in GATE:
        return "regle_eligibilite"
    if base in SCORES:
        return "notation"
    return "diagnostic"


def typed_delta(before, after):
    if before is None or after is None:
        return None
    if not (re.fullmatch(r"-?\d+", before) and re.fullmatch(r"-?\d+", after)):
        return None
    return int(after) - int(before)


def write_csv(path, records, fields):
    with path.open("w", encoding="utf-8", newline="") as f:
        writer = csv.DictWriter(f, fieldnames=fields, lineterminator="\n")
        writer.writeheader()
        writer.writerows(records)


def differences(left, right, key, output):
    fields, before, before_digest = left
    other_fields, after, after_digest = right
    assert fields == other_fields, (fields, other_fields)
    shared = before.keys() & after.keys()
    changed_fields = Counter()
    changed_classes = Counter()
    changed_entities = Counter()
    changed_rows = []
    diffs = []
    for ident in sorted(shared):
        old, new = before[ident], after[ident]
        changes = [f for f in fields if old[f] != new[f]]
        if changes:
            changed_rows.append(dict(zip(key, ident, strict=True)))
        for name in changes:
            cls = classify(name)
            diffs.append({**dict(zip(key, ident, strict=True)), "column": name, "kind": cls,
                          "before": old[name], "after": new[name], "delta": typed_delta(old[name], new[name])})
            changed_fields[name] += 1
            changed_classes[cls] += 1
            changed_entities[new.get("entity_type", "")] += 1
    write_csv(output, diffs, (*key, "column", "kind", "before", "after", "delta"))
    return {"rows_before":len(before), "rows_after":len(after),
            "comparable_cells":len(shared)*len(fields), "cells_changed":len(diffs),
            "rows_changed":len(changed_rows), "changed_keys":changed_rows,
            "added_rows":[after[k] for k in sorted(after.keys()-before.keys())],
            "removed_rows":[before[k] for k in sorted(before.keys()-after.keys())],
            "by_field":dict(sorted(changed_fields.items())),
            "by_kind":dict(sorted(changed_classes.items())),
            "by_entity":dict(sorted(changed_entities.items())),
            "before_content_sha256":before_digest, "after_content_sha256":after_digest}


def competition(rows, output):
    keys = ("competition_id", "entity_type")
    grouped = defaultdict(Counter)
    descriptions = {}
    for row in rows.values():
        key = tuple(row[k] for k in keys)
        group = grouped[key]
        for column in COUNTS:
            if row[column]:
                group[column] += int(row[column])
        group["editions"] += 1
        group["recorded_matches"] += int(row["recorded_matches"])
        group["finished"] += int(row["finished"])
        label = row["competition"]
        assert descriptions.setdefault(key, label) == label
    fields = (*keys, "competition", "editions", "recorded_matches", "finished", *COUNTS)
    result = []
    for key, group in sorted(grouped.items()):
        values = {f: group[f] for f in fields[3:]}
        if key[1] != "player":
            values["role_unavailable"] = ""
        result.append({**dict(zip(keys, key, strict=True)), "competition":descriptions[key], **values})
    write_csv(output, result, fields)
    return table(output, keys)


def sql_results(base):
    return {path.stem: path for path in (base/"db").rglob("*.json")}


def sql_index(path):
    obj = read_json(path)
    return [dict(zip(obj["columns"], row, strict=True)) for row in obj["rows"]]


def capture_validation(base):
    rec = read_json(base/"receipt.json")
    snap = read_json(base/"snapshot.json")
    assert rec["common_snapshot"] == snap and snap["read_only"] == "on" and snap["isolation"] == "repeatable read"
    assert rec["image_digest"] == rec["running_digest"] and rec["exit_code"] == 0
    assert rec["definition_end_state"] == "INACTIVE"
    sql = {p.stem: p for p in (base/"db").rglob("*.sql")}
    assert sql.keys() == rec["query_sha256"].keys()
    for key, path in sql.items():
        canonical = re.sub(r"--[^\n]*", "", path.read_text()).strip().rstrip(";")
        assert digest(canonical.encode()) == rec["query_sha256"][key], path
    response = {"snapshot":base/"snapshot.json", **sql_results(base)}
    assert response.keys() == rec["result_sha256_transport"].keys()
    for name, path in response.items():
        value = read_json(path)
        assert all(value[k] == v for k, v in snap.items()), path
        binary = json.dumps(value, ensure_ascii=False).encode()
        assert digest(binary) == rec["result_sha256_transport"][name], path
    for name, expected in rec["inputs"].items():
        assert digest((base/name).read_bytes()) == expected, name
    return rec


def fixture_observations(old, new, fixtures, output):
    counts = ("recorded_matches", "finished", "finished_unknown_score", "finished_unknown_team")
    before = {r["edition_id"]: r for r in sql_index(old)}
    after = {r["edition_id"]: r for r in sql_index(new)}
    rows = []
    for eid in sorted(before.keys() | after.keys()):
        a, b = before.get(eid, {}), after.get(eid, {})
        if all(a.get(k) == b.get(k) for k in counts):
            continue
        row = {k: (b or a)[k] for k in ("edition_id", "competition", "season", "archive_key", "cup_key")}
        for key in counts:
            row[f"{key}_before"] = a.get(key, 0)
            row[f"{key}_after"] = b.get(key, 0)
            row[f"{key}_delta"] = row[f"{key}_after"] - row[f"{key}_before"]
        rows.append(row)
    fields = ("edition_id", "competition", "season", "archive_key", "cup_key",
              *(f"{k}_{suffix}" for k in counts for suffix in ("before","after","delta")))
    write_csv(output/"ressources-editions.csv", rows, fields)
    sources = [r for r in sql_index(fixtures) if r["edition_id"] is None]
    for fixture, editions in (("recorded", "recorded_matches"), ("finished", "finished")):
        assert sum(r[fixture] for r in sources) == sum(r[editions] for r in after.values())
    assert (sum(r["finished"] - r["finished_scored"] for r in sources)
            == sum(r["finished_unknown_score"] for r in after.values()))
    summary = {}
    for label, group in (("tous", rows), ("archives", [r for r in rows if r["archive_key"]])):
        summary[label] = {**{k: sum(r[f"{k}_delta"] for r in group) for k in counts}, "editions_changed":len(group)}
    return {"by_source_after":sources, "matches_net_changed":summary,
            "edition_rows_changed":rows,
            "source_basis":"core.matches.source; parts on a single snapshot; no source history or dedup cross-source"}


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    for name in ("previous", "current", "published_before", "published_after", "output"):
        parser.add_argument(name, type=Path)
    args = parser.parse_args()
    prior, current, out = args.previous, args.current, args.output
    out.mkdir(parents=True, exist_ok=True)
    old, new = capture_validation(prior), capture_validation(current)
    assert new["release"] == "b2e6dd82d36a2ca0f439ec84bf2e5dbbcd3013d9"
    assert new["image"].split(":")[-1] == new["release"]
    assert old["common_snapshot"]["at"] < new["common_snapshot"]["at"]
    assert old["common_snapshot"]["snapshot"] != new["common_snapshot"]["snapshot"]
    common = old["query_sha256"].keys() & new["query_sha256"].keys()
    assert common == old["query_sha256"].keys() and len(common) == 45
    assert all(old["query_sha256"][k] == new["query_sha256"][k] for k in common)
    assert old["inputs"] == new["inputs"]
    for raw_dir, published, receipt in ((prior,args.published_before,old),(current,args.published_after,new)):
        source = read_json(published/"resultats.json")
        assert source["snapshot"] == receipt["common_snapshot"] and source["source_query_sha256"] == receipt["query_sha256"]
        for filename, checksum in source["output_sha256"].items():
            assert digest((published/filename).read_bytes()) == checksum,filename
    tables, stock = {}, {}
    for label, name, key, raw in TABLES:
        left, right = (prior/"scores", current/"scores") if raw else (args.published_before, args.published_after)
        pair = (table(left/name, key), table(right/name, key))
        stock[label] = pair
        tables[label] = differences(*pair, key, out/f"ecarts-{label}.csv")
    competitions = tuple(competition(s[1],out/f"scores-par-competition-{side}.csv")
                         for s,side in zip(stock["edition-publiee"],("avant","apres"),strict=True))
    tables["competition"] = differences(*competitions, ("competition_id","entity_type"), out/"ecarts-competition.csv")

    left_total, right_total = (read_json(p/"resultats.json")["totals"] for p in (args.published_before,args.published_after))
    for label in ("edition-publiee", "saison-publiee", "competition"):
        assert label in tables
        for index, (side, totals) in enumerate(zip(
                stock.get(label, competitions), (left_total,right_total),strict=True)):
            for entity, values in totals.items():
                for column, value in values.items():
                    assert sum(int(r[column]) for r in side[1].values() if r["entity_type"] == entity) == value, (label, index, entity, column)
    deltas = {entity:{k:right_total[entity].get(k,0)-left_total[entity].get(k,0)
                     for k in right_total[entity].keys() | left_total[entity].keys()}
              for entity in left_total.keys() | right_total.keys()}
    old_sql, new_sql = sql_results(prior), sql_results(current)
    audit_tables = {}
    for name in sorted(old_sql.keys() & new_sql.keys()):
        a, b = read_json(old_sql[name]), read_json(new_sql[name])
        assert a["columns"] == b["columns"], name
        audit_tables[name] = {"rows_before":len(a["rows"]), "rows_after":len(b["rows"]),
                              "same_rows_including_order":a["rows"] == b["rows"]}
    metadata = read_json(new_sql["team-exact"])["metadata"]
    fixture = fixture_observations(old_sql["editions"], new_sql["editions"], new_sql["fixture-universe"],out)
    basis = {"snapshots":[old["common_snapshot"],new["common_snapshot"]],
             "worker_image":new["image"],"worker_digest":new["image_digest"],
             "source_queries_shared":len(common),"supplementary_queries":sorted(new["query_sha256"].keys() - common),
             "grids":tables,"total_before":left_total,"total_after":right_total,"total_delta":deltas,
             "sql_tables":audit_tables,"elo_proof":{"before":read_json(old_sql["team-exact"])["metadata"],
             "after":metadata},
             "fixtures":fixture}
    (out/"comparaison.json").write_text(json.dumps(basis,ensure_ascii=False,indent=2,sort_keys=True)+"\n", encoding="utf-8")
    print(json.dumps({"at":new["common_snapshot"]["at"],"categories":right_total,
                      "grid_cells_changed":{key:row["cells_changed"] for key,row in tables.items()},
                      "source_count":len(fixture["by_source_after"]),"fixture_delta":fixture["matches_net_changed"]},ensure_ascii=False))


if __name__ == "__main__":
    main()
