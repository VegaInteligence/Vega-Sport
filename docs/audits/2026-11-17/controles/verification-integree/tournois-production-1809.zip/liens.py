"""Recouper les liens effectivement rendus avec leurs propres fiches et le calendrier de l’archive."""
import argparse,concurrent.futures,datetime,hashlib,json,unicodedata,urllib.parse,urllib.request
from pathlib import Path
p=Path(__file__).resolve().parent
base='https://dngp6kh9jx2bl.cloudfront.net'
def load(rel):return json.loads((p/rel).read_bytes())
def save(rel,data):(p/rel).write_text(json.dumps(data,ensure_ascii=False,indent=2)+'\n')
def get(route):
    with urllib.request.urlopen(base+route,timeout=18) as response:
        raw=response.read()
        return json.loads(raw),{'path':route,'status':response.status,'etag':response.headers.get('etag'),'at':response.headers.get('Date'),'sha256':hashlib.sha256(raw).hexdigest()}
def fetch():
    disk=p/'fiches';disk.mkdir(exist_ok=True)
    by_year={}
    for year in ['2022','2026']:
        tile=next(c for c in load('desktop/lecture.json')['cases'] if c['name']=='liens-'+year)
        ids={urllib.parse.parse_qs(urllib.parse.urlsplit(x['href']).query)['id'][0] for x in tile['result']['rows'] if x['href']}
        by_year[year]=sorted(ids)
        d,r=get('/api/cups/edition?competition=l_v0000064&season='+year)
        save('fiches/archive-'+year+'.json',{'receipt':r,'matches':d['matches']})
    def one(ident):
        d,r=get('/api/matches/'+ident+'/summary')
        m=d['data']['match']
        result={k:m.get(k) for k in ['id','season','leagueId','date','roundName','status']}
        for k in ['home','away']:result[k]={i:m[k].get(i) for i in ['id','name','score']}
        save('fiches/'+ident+'.json',{'receipt':r,'match':result})
    with concurrent.futures.ThreadPoolExecutor(max_workers=3) as pool:list(pool.map(one,[i for v in by_year.values() for i in v]))
    save('fiches/liens.json',by_year)
def key(name):
    k=''.join(c.lower() for c in unicodedata.normalize('NFKD',name) if c.isalnum())
    return {'unitedstates':'usa','unitedstatesofamerica':'usa','korearepublic':'southkorea','republicofkorea':'southkorea','turkiye':'turkey','czechia':'czechrepublic','iriran':'iran','bosniaandherzegovina':'bosniaherzegovina','ivorycoast':'cotedivoire','caperverde':'caboverde','capeverde':'caboverde','congodr':'drcongo','democraticrepublicofthecongo':'drcongo','curacao':'curacao'}.get(k,k)
def compare():
    output=[]
    for year,ls in load('fiches/liens.json').items():
        items=[r for r in load('fiches/archive-'+year+'.json')['matches'] if not r.get('group') and 'matchday' not in r['round'].lower()]
        for id in ls:
            m=load('fiches/'+id+'.json')['match']
            a,b=key(m['home']['name']),key(m['away']['name'])
            pair=[r for r in items if {key(r['team1']),key(r['team2'])}=={a,b} and abs((datetime.date.fromisoformat(r['date'])-datetime.date.fromisoformat(m['date'])).days)<=1]
            r=pair[0] if len(pair)==1 else None
            score=r.get('score') if r else None
            if isinstance(score,dict):score=score.get('et') or score.get('ft')
            official=None if score is None else (score if a==key(r['team1']) else score[::-1])
            native=[m['home']['score'],m['away']['score']]
            output.append({'year':year,'id':id,'teams':[m['home']['name'],m['away']['name']],'nativeRound':m['roundName'],'nativeDate':m['date'],'storedSeason':m['season'],'archiveCandidates':len(pair),'archiveRound':r['round'] if r else None,'archiveTeams':[r['team1'],r['team2']] if r else None,'archiveDate':r['date'] if r else None,'scoreArchive':official,'scoreNative':native,'scoresMatch':official==native if official is not None else None,'identity':m['id']==id and m['leagueId']=='l_1XLtP0' and m['date'][:4]==year and (r is not None and r['date'][:4]==year)})
    save('comparaison-liens.json',output)
    print(len(output),'fiches',sum(r['archiveCandidates']==1 and r['identity'] for r in output),'identités concordantes;',sum(r['scoresMatch'] is True for r in output),'scores concordants.')
if __name__=='__main__':
    parser=argparse.ArgumentParser();parser.add_argument('--capturer',action='store_true')
    if parser.parse_args().capturer:fetch()
    compare()
