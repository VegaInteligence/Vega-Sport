import { createRequire } from "node:module";
import fs from "node:fs/promises";
import path from "node:path";
const [modulePath, chromiumPath, device, folder] = process.argv.slice(2);
const {chromium} = createRequire(import.meta.url)(modulePath);
const browser = await chromium.launch({executablePath: chromiumPath});
const mobile=device==="iphone";
const page=await browser.newPage({viewport:mobile?{width:393,height:852}:{width:1440,height:900},isMobile:mobile,hasTouch:mobile,locale:"fr-FR",timezoneId:"Europe/Paris"});
const origin="https://vegasport.vercel.app";
const checks=[],cases=[],errors=[];
page.on("pageerror",ex=>errors.push(ex.message));
page.setDefaultTimeout(20000);
await fs.mkdir(folder,{recursive:true});
function check(name,expected,actual){checks.push({name,expected,actual,meets:JSON.stringify(expected)===JSON.stringify(actual)});}
async function readCase(name,params,fn) {
  const url=origin+params; let status;
  try {
    status=(await page.goto(url,{waitUntil:"domcontentloaded"})).status();
    const result=await fn();
    await page.screenshot({path:path.join(folder,name+".png"),animations:"disabled"});
    cases.push({name,url,status,result});
  } catch(exception) {cases.push({name,url,status,error:String(exception)});}
}
function edition(id,year,view){return "/competitions/?"+new URLSearchParams({id:"open-cup:"+id,edition:year,view});}
for(const [id,year,table,label] of [["world-cup-history","1974","Groupe 1","rda"],["world-cup-history","1950","Poule finale","poule-finale"],["world-cup-history","1954","Groupe 2","barrage"],["euro","2020","Groupe F","confrontation"]]){
  await readCase(year,edition(id,year,"groupes"),async()=>{
    const grid=page.getByRole("table",{name:table,exact:true});
    await grid.waitFor();
    const saved=await grid.evaluate(table=>{
      const card=table.closest(".edition-group").getBoundingClientRect(),box=table.getBoundingClientRect();
      return {rows:[...table.tBodies[0].rows].map(tr=>({cells:[...tr.cells].map(td=>td.textContent.trim()),flag:tr.querySelector(".national-flag")?.className??null})),fits:box.left>=card.left-1&&box.right<=card.right+1,cardWidth:card.width,tableWidth:box.width};
    });
    if(label==="rda"){
      const east=saved.rows.find(r=>r.cells[1].includes("Est"));
      check("RDA 1974 points","5",east?.cells[4]);check("RDA 1974 identité visuelle",true,east?.flag?.includes("fi-dd")??false);
      check("table dans sa carte",true,saved.fits);
    } else if(label==="poule-finale")check("1950 points par place",["5","4","2","1"],saved.rows.map(r=>r.cells[4]));
    else if(label==="barrage")check("1954 barragiste qualifié deuxième","Allemagne de l’Ouest",saved.rows[1].cells[1]);
    else check("EURO 2020 Allemagne devant Portugal","Allemagne",saved.rows[1].cells[1]);
    return saved;
  });
}
await readCase("euro2028",edition("euro","2028","groupes"),async()=>{
  await page.locator(".edition-group table,.cup-detail .empty,.cup-detail .empty-state").first().waitFor({timeout:4500}).catch(()=>{});
  const groups=await page.locator(".edition-group table").count();check("2028 groupes",6,groups);return {groups,visible:(await page.locator("main").innerText()).slice(-1200)};
});
await readCase("italie",edition("world-cup-history","1982","matchs"),async()=>{
  const final=page.locator(".cup-match").filter({hasText:"Italie"}).filter({hasText:"Allemagne de l’Ouest"});
  await final.first().waitFor();
  const input=page.locator(".cup-controls input");
  await input.fill("Italie");const fr=await final.count();
  await input.fill("Italy");const en=await final.count();
  check("recherche libellé français",1,fr);check("recherche libellé source",1,en);return {fr,en};
});
const index=JSON.parse(await fs.readFile(new URL("./index-nations.json",import.meta.url)));
const ids=[];
function findIds(value){
  if(value && typeof value==="object"){
    if(value.name==="Uruguay" && value.id)ids.push(value.id);
    Object.values(value).forEach(findIds);
  }
}
findIds(index);
if(new Set(ids).size!==1)throw Error("Identité nationale Uruguay ambiguë");
await readCase("uruguay","/nations/?id="+ids[0]+"&season=2026%2F2027",async()=>{
  const tile=page.locator('a[href*="world-cup-history"][href*="edition=1950"]').first();
  await tile.waitFor();const tone=await tile.getAttribute("data-tone"),title=await tile.getAttribute("title");
  check("Uruguay champion 1950","gold",tone);return {tone,title};
});
for(const year of ["1974","1978","1982","1950"]){
  await readCase("tableau-"+year,edition("world-cup-history",year,"tableau"),async()=>{
    await page.locator(".knockout-section").first().waitFor();
    const choice=page.locator(".knockout-section").getByRole("button",{name:"2e tour",exact:true}).first();
    if(mobile && year!=="1950" && await choice.isVisible())await choice.click();
    const visibleGroups=page.locator(".knockout-group:visible");
    const expectedGroups={"1950":1,"1974":2,"1978":2,"1982":4};
    await visibleGroups.first().waitFor();
    check("groupes rendus dans le tableau "+year,expectedGroups[year],await visibleGroups.count());
    const matches=await page.locator(".knockout-group, .knockout-final-group, .knockout-group-card").count();
    const labels=await page.locator(".knockout-section").first().innerText();
    const classes=await page.locator(".knockout-section [class*=group]").evaluateAll(els=>[...new Set(els.map(e=>e.className))]);
    return {groups_dom:matches,classes,labels:labels.slice(0,900)};
  });
}
for(const year of ["2022","2026"]){
  await readCase("liens-"+year,"/competitions/?"+new URLSearchParams({id:"l_1XLtP0",edition:year,view:"tableau"}),async()=>{
    await page.locator(".knockout-match-link").first().waitFor({state:"attached"});
    const projected=await page.locator(".knockout-match").evaluateAll(els=>els.map(el=>({text:el.innerText.slice(0,200),href:el.getAttribute("href")})));
    const ids=projected.map(p=>p.href?new URL(p.href,origin).searchParams.get("id"):null);
    const linked=new Set(ids.filter(Boolean));
    check("confrontations natives avec fiche "+year,year==="2026"?32:16,linked.size);
    return {rendered:ids.length,distinct:linked.size,missing:ids.filter(id=>!id).length,rows:projected};
  });
}
await browser.close();
await fs.writeFile(path.join(folder,"lecture.json"),JSON.stringify({device,origin,finished:new Date().toISOString(),checks,cases,errors},null,2)+"\n");
console.log(device,checks.filter(c=>c.meets).length,checks.length,cases.filter(c=>c.error).map(c=>c.name));
if(cases.some(c=>c.error))process.exitCode=1;
