"""Recalcul avec les seules observations embarquées."""
import hashlib,json,subprocess,sys
from pathlib import Path
p=Path(__file__).resolve().parent
for name,h in json.loads((p/'empreintes.json').read_bytes()).items():
 assert hashlib.sha256((p/name).read_bytes()).hexdigest()==h,name
expected_fails={'1954 barragiste qualifié deuxième','EURO 2020 Allemagne devant Portugal','2028 groupes','recherche libellé français','Uruguay champion 1950'}
d=[]
for key in ['desktop','iphone']:
 j=json.loads((p/('final-'+key)/'lecture.json').read_bytes())
 assert j['device']==key and len(j['cases'])==13 and all(c['status']==200 and 'error' not in c for c in j['cases']) and not j['errors']
 assert len(j['checks'])==16 and {c['name'] for c in j['checks'] if not c['meets']}==expected_fails
 assert all(c['meets']==(c['expected']==c['actual']) for c in j['checks'])
 d.append({'format':key,'at':j['finished'],'pages':len(j['cases']),'satisfaits':sum(c['meets'] for c in j['checks']),'observes':len(j['checks'])})
before=(p/'comparaison-liens.json').read_bytes()
subprocess.run([sys.executable,'-B',str(p/'liens.py')],cwd=p,check=True,stdout=subprocess.DEVNULL)
assert (p/'comparaison-liens.json').read_bytes()==before
observed=json.loads(before)
assert len(observed)==48 and all(r['archiveCandidates']==1 and r['identity'] and r['scoresMatch'] for r in observed)
stages={'Round of 32':'1/16','Round of 16':'1/8','Quarter-final':'1/4','Quarter-finals':'1/4','Semi-finals':'1/2','Semi-final':'1/2','Match for third place':'bronze','Final':'final'}
assert all(stages[r['archiveRound']]==r['nativeRound'] for r in observed)
assert {r['storedSeason'] for r in observed if r['year']=='2022'}=={'2022/2023'}
assert {r['storedSeason'] for r in observed if r['year']=='2026'}=={'2025/2026'}
assert sum(r['nativeDate']!=r['archiveDate'] for r in observed)==8
print(json.dumps({'commit':'1c5a4340d193d2ffd1406f965e4007fdfb6b97fb','navigations':d,'fiches':48,'tours_scores_equipes_concordants':48,'ecarts_un_jour':8,'ecarts_produit':sorted(expected_fails)},ensure_ascii=False))
