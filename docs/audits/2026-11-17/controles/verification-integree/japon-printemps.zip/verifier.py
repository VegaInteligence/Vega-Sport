"""Verify signed official results, public reads and the read-only cross-competition search offline."""
from pathlib import Path
import csv,hashlib,json,subprocess,sys,zlib
p=Path(__file__).resolve().parent
source=p/'lectures-publiques-j1'
def digest(data):return hashlib.sha256(data).hexdigest()
for name,expected in json.loads((p/'empreintes.json').read_bytes()).items():
    assert digest((p/name).read_bytes())==expected,name
before={name:digest((source/name).read_bytes()) for name in ('printemps-resultats.json','printemps-200.csv')}
result=subprocess.run([sys.executable,'comparer_printemps.py'],check=True,cwd=source,stdout=subprocess.PIPE)
assert all(digest((source/name).read_bytes())==h for name,h in before.items())
recs=json.loads((source/'recus.json').read_bytes())
for row in recs:
    assert row['status']==200 and digest((source/(row['key']+'.json')).read_bytes())==row['sha256']
comparison=json.loads((source/'printemps-resultats.json').read_bytes())
assert comparison['official']==200 and comparison['exact_scores']==199 and len(comparison['no_exact_match'])==1 and not comparison['unmapped_names']
match=comparison['no_exact_match'][0]
assert (match['federation_id'],match['home_score'],match['away_score'])==('2026020603',1,3)
rds=source/'rencontre-manquante/rds-2';raw=(rds/'inputs.json.zlib').read_bytes()
assert digest(raw)==json.loads((rds/'receipt.json').read_bytes())['sha256']
src=json.loads(zlib.decompress(raw))
assert src['read_only']=='on' and {v[0] for v in src['roots']['rows']}=={857,4878}
rows=[dict(zip(src['matches']['columns'],r)) for r in src['matches']['rows']]
assert not [r for r in rows if '2026-02-04' <= (r['match_date'] or '') <= '2026-02-09']
assert {(r['id'],r['competition_season_id']) for r in rows}=={(43298,140),(43497,140),(33992,22)}
f={r['key']:(r['source'],r['played']) for r in recs}
assert f['j1-courante']==f['j1-2027']==f['j1-2027-2028']==('SportScore',[14])
assert f['j1-2026']==f['j1-2026-2027']==('Vega',[32,33,34])
print(json.dumps({'status':'passed','spring_results':200,'matched':199,'unmatched_in_RDS':'2026020603','official_score':[1,3],'all_provider_names_mapped':True,'comparison_fixture_ids':sorted(r['id'] for r in rows),'public_responses_verified':len(recs),'signed_files':len(json.loads((p/'empreintes.json').read_bytes()))}))
