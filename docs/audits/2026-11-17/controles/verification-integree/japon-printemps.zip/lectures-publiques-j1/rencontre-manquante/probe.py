def collect(db):
    with db.transaction():
        db.execute("SET TRANSACTION ISOLATION LEVEL REPEATABLE READ READ ONLY")
        stamp,snap,ro=db.execute("SELECT transaction_timestamp(),pg_current_snapshot()::text,current_setting('transaction_read_only')").fetchone()
        assert ro=='on'
        out={'at':str(stamp),'snapshot':snap,'read_only':ro}
        def get(key,q,args=()):
            cur=db.execute(q,args or None)
            out[key]={'sql':q,'params':args,'columns':[c.name for c in cur.description],'rows':cur.fetchall()}
        get('roots',"""SELECT t.id,t.name,t.merged_into,t.is_national,t.country_code FROM core.teams t
        WHERE t.name ILIKE '%Nagasaki%' OR t.name ILIKE '%Hiroshima%' OR EXISTS
        (SELECT 1 FROM core.entity_names n WHERE n.entity_type='team' AND n.entity_id=t.id AND (n.name ILIKE '%Nagasaki%' OR n.name ILIKE '%Hiroshima%'))
        ORDER BY t.id""")
        roots=[r[0] for r in out['roots']['rows']]
        get('matches',"""SELECT m.id,m.match_date,m.kickoff_at,m.status,m.home_team_id,h.name AS home,m.away_team_id,a.name AS away,
        m.home_score,m.away_score,m.competition_season_id,m.season_id,cs.native_label,c.name AS competition,m.source::text
        FROM core.matches m LEFT JOIN core.competition_seasons cs ON cs.id=m.competition_season_id LEFT JOIN core.competitions c ON c.id=cs.competition_id
        LEFT JOIN core.teams h ON h.id=m.home_team_id LEFT JOIN core.teams a ON a.id=m.away_team_id
        WHERE ((m.match_date BETWEEN DATE '2026-02-04' AND DATE '2026-02-09' OR m.kickoff_at::date BETWEEN DATE '2026-02-04' AND DATE '2026-02-09')
               AND (m.home_team_id=ANY(%s) OR m.away_team_id=ANY(%s)))
        OR ((m.match_date BETWEEN DATE '2026-01-01' AND DATE '2026-12-31' OR m.season_id IN (2026,2027))
               AND m.home_team_id=ANY(%s) AND m.away_team_id=ANY(%s))
        ORDER BY m.match_date,m.id""",(roots,roots,roots,roots))
        return out
