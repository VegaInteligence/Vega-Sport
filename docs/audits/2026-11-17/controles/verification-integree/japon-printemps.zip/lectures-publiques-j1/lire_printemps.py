from pathlib import Path
from playwright.sync_api import sync_playwright
import hashlib,json,os
D=Path(__file__).resolve().parent
meta=json.loads((D/'printemps-organisateur.json').read_bytes());raw=(D/'printemps-organisateur.raw').read_bytes(); assert hashlib.sha256(raw).hexdigest()==meta['sha256']
with sync_playwright() as runner:
    browser=runner.chromium.launch(headless=True,executable_path=os.environ.get('CHROMIUM',str(Path.home()/'Library/Caches/ms-playwright/chromium-1228/chrome-mac-arm64/Google Chrome for Testing.app/Contents/MacOS/Google Chrome for Testing')))
    p=browser.new_page(viewport={'width':1420,'height':860})
    def stub(route):
        if route.request.is_navigation_request() and route.request.url==meta['url']:
            route.fulfill(body=raw,status=200,content_type='text/html; charset=utf-8')
        else:route.abort()
    p.route('**/*',stub)
    p.goto(meta['url'],wait_until='load',timeout=60000)
    cards=p.locator('div.m-schedule[id]').evaluate_all("""cards=>cards.map(c=>{
      let group=c.closest('.p-game-schedule__group')
      return {id:c.id, label:group?.querySelector('.m-section-header__h2-eyebrow--logo-text-container')?.textContent.trim(), day:group?.id, names:[...c.querySelectorAll('.m-schedule__team-name[data-media="pc"]')].map(e=>e.textContent.trim()), score:[...c.querySelectorAll('p.m-schedule__score')].map(e=>e.textContent.trim()),link:c.querySelector('a[href]')?.getAttribute('href')}
    })""")
    browser.close()
assert len(cards)==200 and len({c['id'] for c in cards})==200
(D/'printemps-cartes.json').write_text(json.dumps(cards,ensure_ascii=False,indent=2)+'\n')
print(len(cards),[(r['id'],r['day'],r['label'],r['names'],r['score']) for r in cards[:3]])
