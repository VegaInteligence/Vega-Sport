from collections import Counter,defaultdict
import csv,hashlib,html,json,re,unicodedata,zlib
from pathlib import Path
P=Path(__file__).resolve().parent
def norm(s):return ''.join(c for c in unicodedata.normalize('NFKC',s).casefold() if c.isalnum())
b=(P/'printemps-organisateur.raw').read_bytes()
assert hashlib.sha256(b).hexdigest()==json.loads((P/'printemps-organisateur.json').read_bytes())['sha256']
s=b.decode();source_ids={norm(r['nom_officiel']):int(r['team_id']) for r in csv.DictReader((P.parent/'federations/36-clubs.csv').open()) if r['edition']=='22'}
# Spring entrants absent from the autumn league can still match an exact native name.
rds=json.loads(zlib.decompress((P.parent/'renouvellement-reel/rds-context/inputs.json.zlib').read_bytes()))
for id_,name,_,_ in rds['teams']['rows']:
    if norm(name) not in source_ids:source_ids[norm(name)]=id_
cards=list(re.finditer(r' id="(20[0-9]{8})"',s))
labels=list(re.finditer(r'>(MEIJI YASUDA J1 100Year League [^<>]{1,85})</span>',s))
rows=[dict(zip(rds['calendar']['columns'],x)) for x in rds['calendar']['rows'] if x[1]==140 and x[3]<'2026-07-01']
lookup=defaultdict(list)
for r in rows:lookup[r['match_date'],r['home_team_id'],r['away_team_id']].append(r)
out=[];unknown=set()
for card in json.loads((P/'printemps-cartes.json').read_bytes()):
    n=card['id'];when=card['day'][:10];title=card['label'];names=card['names']
    assert title.startswith('MEIJI YASUDA J1 100Year League')
    ids=[source_ids.get(norm(v)) for v in names];unknown.update(v for v,i in zip(names,ids) if i is None)
    nums=[int(v) for v in card['score']]
    assert len(ids)==2 and len(nums)==2,(n,names,nums)
    opt=lookup[when,*ids]
    assert len(opt)<=1
    r=opt[0] if opt else {}
    out.append(dict(date=when,home=names[0],away=names[1],federation_id=n,phase=title,home_score=nums[0],away_score=nums[1],vega_id=r.get('id'),vega_home=r.get('home_score'),vega_away=r.get('away_score'),scores_match=nums==[r.get('home_score'),r.get('away_score')] if r else None,source_match='https://www.jleague.jp/en/match/j1/'+n[:4]+'/'+n[4:]+'/'))
assert len(out)==200 and len({x['federation_id'] for x in out})==200
with (P/'printemps-200.csv').open('w',newline='') as f:
    w=csv.DictWriter(f,fieldnames=list(out[0]),lineterminator='\n');w.writeheader();w.writerows(out)
result={'edition':140,'snapshot':rds['at'],'source_digest':hashlib.sha256(b).hexdigest(),'official':len(out),'vega_spring':len(rows),'exact_date_and_pair':len([x for x in out if x['vega_id']]),'exact_scores':sum(x['scores_match'] is True for x in out),'no_exact_match':[x for x in out if not x['vega_id']],'score_mismatch':[x for x in out if x['scores_match'] is False],'unmapped_names':sorted(unknown),'sources':'Fédération J.League, registre RDS gelé et captures publiques du classement.'}
(P/'printemps-resultats.json').write_text(json.dumps(result,ensure_ascii=False,indent=2)+'\n')
print([result[k] for k in ('official','vega_spring','exact_date_and_pair','exact_scores','unmapped_names')])
