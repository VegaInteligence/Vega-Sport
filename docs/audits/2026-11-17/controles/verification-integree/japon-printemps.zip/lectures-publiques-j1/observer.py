"""Public GETs from the deployed read API for current, native and canonical season selectors."""
from concurrent.futures import ThreadPoolExecutor
from datetime import datetime,timezone
from pathlib import Path
from urllib.parse import urlencode
from urllib.request import Request,urlopen
from urllib.error import HTTPError
import hashlib,json
P=Path(__file__).resolve().parent
queries=[('j1-'+(s or 'courante').replace('/','-'),'l_2ApGa4',s) for s in (None,'2026','2027','2026/2027','2027/2028')]+[('allsvenskan','l_1XsMdH','2026')]
def get(x):
    key,comp,season=x; params={'competition':comp}
    if season:params['season']=season
    url='https://dngp6kh9jx2bl.cloudfront.net/api/standings?'+urlencode(params)
    stamp=datetime.now(timezone.utc).isoformat()
    try:
        resp=urlopen(Request(url,headers={'User-Agent':'Vega source audit'}),timeout=30)
    except HTTPError as err:
        resp=err
    with resp:
        body=resp.read()
        p=P/(key+'.json');p.write_bytes(body);data=json.loads(body)
        tables=data.get('tables',[]); rows=[r for table in tables for r in table.get('rows',table.get('standings',[]))]
        return {'key':key,'status':resp.status,'etag':resp.headers.get('etag'),'url':url,'at':stamp,'sha256':hashlib.sha256(body).hexdigest(),'response_season':data.get('season'),'source':data.get('source'),'fetchedAt':data.get('fetchedAt'),'tables':len(tables),'rows':len(rows),'table_keys':list(tables[0]) if tables else [],'played':sorted({r.get('played') for r in rows}), 'top_team':rows[0].get('name',rows[0].get('team')) if rows else None}
with ThreadPoolExecutor(max_workers=3) as ex:out=list(ex.map(get,queries))
(P/'recus.json').write_text(json.dumps(out,indent=2,ensure_ascii=False)+'\n')
print([(r['key'],r['status'],r['rows'],r['source'],r['played']) for r in out])
