SELECT kind,count(*) AS dated_rows,count(*) FILTER (WHERE fee_eur IS NULL) AS unknown_fee,
 count(*) FILTER (WHERE fee_eur=0) AS known_zero_fee,
 count(*) FILTER (WHERE fee_eur>0) AS positive_fee,
 count(*) FILTER (WHERE fee_eur<0) AS negative_fee,
 count(*) FILTER (WHERE from_name IS NULL AND to_name IS NULL) AS neither_name
 FROM api.player_transfers GROUP BY kind ORDER BY kind
