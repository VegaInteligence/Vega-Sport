import fs from "node:fs/promises";
import path from "node:path";
import { createRequire } from "node:module";
import { fileURLToPath } from "node:url";
import { careerMoves } from "./career-moves-fc0de.mjs";

const [, , playwright, executablePath, device] = process.argv;
const { chromium } = createRequire(import.meta.url)(playwright);
const dir = path.dirname(fileURLToPath(import.meta.url));
const data = JSON.parse(await fs.readFile(path.join(dir, "public-receipt.json"), "utf8"));
const phone = device === "phone";
const result = { device, checks:[], players:[], relevantHttp:[], pageErrors:[] };
const out = path.join(dir, device);
await fs.mkdir(out, { recursive:true });
const browser = await chromium.launch({ executablePath });
const page = await browser.newPage({ viewport:phone ? { width:393,height:852 } : { width:1440,height:900 },locale:"fr-FR",timezoneId:"Europe/Paris",isMobile:phone,hasTouch:phone });
page.setDefaultTimeout(21000);
page.on("pageerror", error => result.pageErrors.push(String(error)));
page.on("response", r=>{ if (/\/transfers(?:\?|$)|\/api\/player-market-values/.test(r.url())) result.relevantHttp.push({status:r.status(),url:r.url()}); });
const check = (step,expected,actual) => result.checks.push({step,expected,actual,pass:JSON.stringify(expected)===JSON.stringify(actual)});
const names = values => values.map(v=>v.club.name);
for (const key of ["giroud", data.sample.negative || "yamal"]) {
  const info=data.players[key];
  const marker={key,id:info.player.id,name:info.player.name};
  result.players.push(marker);
  try {
    const transfers = info.transfers.status === 200 ? JSON.parse(await fs.readFile(path.join(dir,info.transfers.body),"utf8")).data.transfers : null;
    const valuations = info.values.status === 200 ? JSON.parse(await fs.readFile(path.join(dir,info.values.body),"utf8")).data.history : [];
    const expected = careerMoves(valuations,transfers);
    const base="https://vegasport.vercel.app/joueurs/?"+new URLSearchParams({id:info.player.id,season:data.season,playerView:"evolution"});
    await page.goto(base,{waitUntil:"domcontentloaded"});
    const heading=page.getByRole("heading",{name:"Valeur marchande",exact:true});
    await heading.waitFor();
    const card=heading.locator("xpath=ancestor::section[1]");
    const mainPlot=card.locator('[class*="marketPlot"]');
    const badges=mainPlot.locator('span[role="img"][aria-label]');
    if (expected.curve.length) await badges.first().waitFor();
    if (valuations.length) await mainPlot.locator('svg[aria-label="Historique des estimations de valeur marchande"]').waitFor();
    const list=card.locator("ol li strong");
    if (expected.list.length) await list.first().waitFor();
    check(key+" route requested career view","evolution",new URL(page.url()).searchParams.get("playerView"));
    check(key+" list matches known moves or inference",names(expected.list),await list.allTextContents());
    const expectedTitles=expected.curve.map(({from,club})=>from?from.name+" → "+club.name:club.name);
    const labels=await badges.evaluateAll(nodes=>nodes.map(n=>n.getAttribute("aria-label")));
    check(key+" graph badges use the expected club transitions",expectedTitles,labels.map(l=>l.split(", ")[0]));
    const details=await badges.evaluateAll(nodes=>nodes.map(n=>({
      label:n.getAttribute("aria-label"),
      inferred:/Estimation/.test(n.getAttribute("aria-label")),
      imageReady:[...n.querySelectorAll('img')].some(i=>i.complete&&i.naturalWidth>0),
      initials:n.querySelector(".image-fallback")?.textContent||null,
      left:n.style.left,top:n.style.top
    })));
    marker.valuations={count:valuations.length,first:valuations[0],last:valuations.at(-1)};
    marker.transfers={http:info.transfers.status,count:transfers?.length??null,feeZero:transfers?.filter(x=>x.feeEur===0).length??0,feeUnknown:transfers?.filter(x=>x.feeEur===null).length??0};
    marker.curveRules=expected.curve.map(({club,date,at,kind,feeEur})=>({club:club.name,date,at,kind,feeEur}));
    marker.badges=details;
    check(key+" card fits viewport",true,await card.evaluate(node=>node.getBoundingClientRect().width<=window.innerWidth+.1));
    if (key==="giroud") {
      const latest=badges.filter({has:page.locator("img")});
      marker.markedAssets=await latest.count();
      const free=labels.filter(l=>l.includes("Transfert libre"));
      check("Giroud free moves identified accurately",2,free.length);
      const anchor=expected.curve.find(m=>m.kind==="loan_return");
      check("Giroud loan return before start is clamped to the valuation origin",true,
        Boolean(anchor&&anchor.at===valuations[0].date&&anchor.date<anchor.at&&labels.filter(l=>l.includes("Retour de prêt")).length===1));
      check("Giroud unknown fee is absent from the tooltip while marked free",true,free.every(l=>!l.includes("Montant")));
    } else if (key==="yamal") {
      check("Yamal promotion starts at Barcelona and no youth destination marker",true,
        labels.length===1&&labels[0].includes("→ Barcelona, Équipe première"));
    } else if (transfers===null) {
      check(key+" inferred changes read Estimation",true,labels.every(l=>l.includes("Estimation")));
    } else {
      check(key+" read transfers are distinct from valuation inferences",true,labels.every(l=>!l.includes("Estimation"))||expected.curve.some(m=>m.kind==="estimate"));
    }
    await heading.scrollIntoViewIfNeeded();
    // Sticky header on both sizes leaves more room for the curve at its own crop.
    await card.screenshot({path:path.join(out,key+"-career-card.png"),animations:"disabled"});
    await page.screenshot({path:path.join(out,key+"-viewport.png"),animations:"disabled"});
  } catch(error) { result.checks.push({step:key,pass:false,url:page.url(),error:String(error)}); }
}
check("no uncaught page exceptions",[],result.pageErrors);
await fs.writeFile(path.join(out,"result.json"),JSON.stringify(result,null,2)+"\n");
console.log(JSON.stringify(result.checks,null,2));
await browser.close();
process.exitCode=result.checks.some(c=>!c.pass)?1:0;
