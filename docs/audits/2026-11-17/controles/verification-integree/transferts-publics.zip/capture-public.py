"""Bounded public player, transfer-history and report-image checks."""
from concurrent.futures import ThreadPoolExecutor
from datetime import datetime, timezone
from hashlib import sha256
import json
from pathlib import Path
from struct import unpack
from urllib.error import HTTPError
from urllib.parse import urlencode
from urllib.request import Request,urlopen

HERE=Path(__file__).resolve().parent
API="https://dngp6kh9jx2bl.cloudfront.net"
SITE="https://vegasport.vercel.app"
SEASON="2026/2027"
def save(path,data):path.write_text(json.dumps(data,indent=2,ensure_ascii=False)+'\n')
def read(origin, route, stem, params=()):
    url=origin+route+('?' + urlencode(params) if params else '')
    request=Request(url,headers={'User-Agent':'Vega verification (public read)'})
    try:response=urlopen(request,timeout=19)
    except HTTPError as e:response=e
    with response:
        data=response.read()
        headers={key:response.headers.get(key) for key in ('content-type','etag','date','x-vercel-id','x-vercel-cache','x-cache','cache-control') if response.headers.get(key)}
        full={'status':response.code,'url':response.geturl(),'headers':headers,'bytes':len(data),'sha256':sha256(data).hexdigest()}
    if 'image/png' in headers.get('content-type','') and data[:8]==b'\x89PNG\r\n\x1a\n':
        path=HERE/f'{stem}.png'
        full['dimensions']=unpack('>II',data[16:24])
        payload=None
    else:
        path=HERE/f'{stem}.json'
        try:payload=json.loads(data)
        except ValueError:payload=None;path=HERE/f'{stem}.txt'
    path.write_bytes(data)
    full['body']=path.name
    return full,payload

def actor(params):
    key,needle=params
    search,payload=read(API,'/api/search',f'{key}-search',[('q',needle),('season',SEASON)])
    if not payload or search['status']!=200:return key,{'search':search}
    exact=[p for p in payload.get('players',[]) if needle.casefold() in p['name'].casefold()]
    if not exact:return key,{'search':search,'result':'name unavailable'}
    player=exact[0]
    identity=player['id']
    tm,body=read(API,f'/api/players/{identity}/transfers',f'{key}-transfers')
    mv,values=read(API,'/api/player-market-values',f'{key}-values',[('id',identity)])
    transfers=(body or {}).get('data',{}).get('transfers')
    values=(values or {}).get('data',{}).get('history')
    return key,{'search':search,'player':player,'transfers':tm,'transfer_count':None if transfers is None else len(transfers),
      'values':mv,'value_points':len(values or []),'value_points_with_club':sum(bool(v.get('club')) for v in values or [])}
def main():
    with ThreadPoolExecutor(max_workers=3) as pool:
        actors=dict(pool.map(actor,[('giroud','Giroud'),('yamal','Yamal'),('cubarsi','Cubarsí'),('saka','Saka')]))
    positive='giroud'
    assert actors[positive].get('transfer_count'),actors[positive]
    negatives=[k for k in ('yamal','cubarsi','saka') if actors[k].get('values',{}).get('status')==200 and actors[k].get('transfer_count') in (0,None)]
    if not negatives:
        with ThreadPoolExecutor(max_workers=3) as pool:
            actors.update(pool.map(actor,[('dowman','Max Dowman'),('mbaye','Ibrahim Mbaye'),('karl','Lennart Karl'),('orl','O’Reilly'),('vicky','Vicky López'),('mbappe','Kylian Mbappé')]))
        negatives=[k for k in actors if k!=positive and actors[k].get('values',{}).get('status')==200 and actors[k].get('transfer_count') in (0,None)]
    negative=negatives[0] if negatives else None
    reports={}
    for key in [positive,negative or 'yamal']:
        pid=actors[key]['player']['id']
        meta,_=read(SITE,'/api/rapport/image',f'{key}-report-5',[('id',pid),('n','5'),('season',SEASON)])
        reports[key]=meta
    result={'at':datetime.now(timezone.utc).isoformat(),'season':SEASON,'sample':{'positive':positive,'negative':negative},'players':actors,'reports':reports}
    save(HERE/'public-receipt.json',result)
    print(json.dumps({k:(x.get('player',{}).get('id'),x.get('transfers',{}).get('status'),x.get('transfer_count'),x.get('value_points'),x.get('value_points_with_club')) for k,x in actors.items()},ensure_ascii=False))
    print(json.dumps(reports,ensure_ascii=False))
if __name__=='__main__': main()
