import assert from "node:assert/strict";
import { readFileSync } from "node:fs";
import { careerMoves as original } from "./career-moves.pinned.mjs";
import { careerMoves as current } from "./career-moves-fc0de.mjs";

function read(file) {
  return JSON.parse(readFileSync(new URL(file, import.meta.url),"utf8"));
}

function facts(moves) {
  return {
    list: moves.list.map(({date,club,kind,feeEur}) => ({date,club:club.name,kind,feeEur})),
    curve: moves.curve.map(({date,at,club,kind,feeEur}) => ({date,at,club:club.name,kind,feeEur})),
  };
}

const receipt = read("./public-receipt.json");
const samples = Object.entries(receipt.players).flatMap(([key, record]) => {
  if (!record.transfers || record.transfers.status !== 200 || record.values.status !== 200) return [];
  const transfers = read(record.transfers.body).data.transfers;
  const history = read(record.values.body).data.history;
  return [{ key, name: record.player.name, id: record.player.id, transfers, history }];
});

const observed = samples.map(({key,name,id,transfers,history}) => ({
  key,name,id,
  count:transfers.length,
  valuations:history.length,
  numericZero:transfers.filter(row=>row.feeEur===0).length,
  unknown:transfers.filter(row=>row.feeEur===null).length,
  positive:transfers.filter(row=>row.feeEur>0).length,
}));
const comparison = Object.fromEntries(samples.filter(({key})=>key==="giroud"||key==="yamal").map(({key,transfers,history})=>[
  key, { asShippedIn5956: facts(original(history,transfers)), asShippedInFc0de: facts(current(history,transfers)) },
]));
const clubA={id:"control-a",name:"Control A"};
const clubB={id:"control-b",name:"Control B"};
const clubC={id:"control-c",name:"Control C"};
const history=[
  {date:"2024-01-10",club:clubA,valueEur:100000},
  {date:"2024-02-01",club:clubB,valueEur:125000},
  {date:"2024-03-01",club:clubC,valueEur:150000},
];
const move={date:"2024-02-01",kind:"transfer",from:clubA,to:clubB};
const fixtures={};
for (const [label, compute] of [["5956",original],["fc0de",current]]) {
  const knownZero=facts(compute(history,[{...move,feeEur:0}]));
  const unknown=facts(compute(history,[{...move,feeEur:null}]));
  const positive=facts(compute(history,[{...move,feeEur:250000}]));
  const absent=facts(compute(history,null));
  const empty=facts(compute(history,[]));
  const unresolved=facts(compute(history,[{...move,to:null}]));
  const shortLoan=facts(compute(history,[
    {...move,kind:"loan_return"},
    {...move,date:"2024-03-01",from:clubB,to:clubC},
  ]));
  assert.deepEqual(knownZero,unknown);
  assert.equal(knownZero.list[0].feeEur,null);
  assert.equal(positive.list[0].feeEur,250000);
  assert.deepEqual(absent.curve.map(({kind})=>kind),["estimate","estimate","estimate"]);
  assert.deepEqual(empty.curve.map(({kind})=>kind),["estimate"]);
  assert.equal(unresolved.list.length,0);
  assert.equal(shortLoan.list.some(({kind})=>kind==="loan_return"),true);
  assert.equal(shortLoan.curve.some(({kind})=>kind==="loan_return"),false);
  fixtures[label]={ source:"controlled inputs", fees:{knownZero,unknown,positive}, absent, empty, unresolved, shortLoan };
}
console.log(JSON.stringify({source:receipt.at, observed, comparison, fixtures},null,2));
