# Courbe des transferts en production

Relevé du 18 novembre 2026. Lecture des routes publiques en saison `2026/2027`, revue des deux versions du code et navigateur Chromium aux largeurs 1440 et 393 px.

## Versions et résultats

| Surface | Version attestée | Preuve |
|---|---|---|
| API et worker AWS | `5956a83cd76bf0b41924795e05b5024c8e1770d6` | Déploiement réussi à 18:27:46 UTC. Le digest du worker de ce SHA est confirmé par le [reçu RDS indépendant](../../calibration-xg/RECEIPT.md). [Action AWS](https://github.com/VegaInteligence/Vega-Sport/actions/runs/44368285359) |
| Déploiement Vercel initial | `5956a83cd76bf0b41924795e05b5024c8e1770d6` | `dpl_GpfZw7qX1Gs9N3vUGRLVLrdKtFLY` READY et alias public à 18:36:19 UTC. Sa propre URL renvoyait HTTP 302 vers Vercel SSO. `vercel-5956.json`, `pin-shell-status.txt`. |
| Vercel des captures publiques | `fc0deba100288117b0ea122e7199d1c9db9dcc37` | `dpl_7WjuoJZrNNfDxxKcjbXFj63B4tUG` READY à 18:39:58 UTC et alias public vérifié à 18:43:26 UTC. Le delta porte sur les promotions, les équipes de jeunes et les noms de clubs dissous. `vercel-alias-current.json`, `git-delta-fc0de.json`. |
| API publique | HTTP 200 pour les transferts et valorisations des 8 joueurs trouvés | 47 mouvements dont 7 indemnités positives, 40 `null` et aucun zéro numérique. Les 8 fiches ont au moins un transfert connu et des valorisations. Deux recherches nominatives supplémentaires sans correspondance. La couverture complète du public et l'absence d'historique en production restent non établies. `public-receipt.json`, réponses brutes et `selection-replay.json`. |
| Chromium sur l'alias | 13/13 à 1440×900, 13/13 à 393×852 | Deux fiches, 4 réponses attendues 200 à chaque largeur, zéro exception de page. Liste, ordre et libellés des repères, taille de carte et critères d'observation ci-dessous. `desktop/`, `phone/` et journaux. |
| Rapports publics PNG | HTTP 200 et 1080×1350 pour les deux fiches | Obtenus à 18:40:34 et 18:40:35 UTC, réponses Vercel MISS. Inspection visuelle des PNG bruts, avec contrôle du repère Barça, des huit repères de Giroud et des initiales de Tours. `giroud-report-5.png`, `yamal-report-5.png`. |

La version initiale du frontend est rejouée hors ligne sur les réponses API téléchargées. Un premier essai navigateur comparait cette version au nouvel alias et a fait ressortir cinq écarts par largeur, dont un attendu erroné sur le repère d'origine du prêt. Les assertions ont ensuite été liées à `fc0deba` et corrigées. Les premiers journaux sont archivés dans `initial-browser/` hors capsule et ne qualifient aucun navigateur exécutant `5956`.

## Contrats et témoins

- Olivier Giroud (`p_1cjL14`) a 11 mouvements et 44 valorisations. La fiche liste 10 clubs et trace 8 repères. Le retour de prêt d'Istres à Grenoble du 30/06/2008 reste dans la liste et sert de repère d'origine de la série au 18/08/2008. Le libellé retient la date réelle. L'écart de 63 jours jusqu'au transfert à Tours place ce retour dans la fenêtre de transit de 92 jours. Un retour bref au milieu d'une série est conservé dans la liste et omis sur la courbe, vérifié hors ligne avec des dates contrôlées. [Fiche Giroud](https://vegasport.vercel.app/joueurs/?id=p_1cjL14&season=2026%2F2027&playerView=evolution)
- Giroud présente aussi la limite des clubs à identité incomplète. `Tours FC (- 2025)` arrive avec un nom et sans identifiant ou blason. Dans les deux affichages et le PNG, le club apparaît sous la forme « Tours FC » avec `TF` et le repère conserve les 150 000 € de l'API. Les sept autres repères de Giroud chargent un blason dans le navigateur. Un club sans nom est écarté de la liste et de la courbe par le calcul. Les candidats à un prêt bref et au regroupement avant origine suivent la [sélection front figée](https://github.com/VegaInteligence/Vega-Sport/blob/fc0deba100288117b0ea122e7199d1c9db9dcc37/dashboard/frontend/src/services/career-moves.js).
- Lamine Yamal (`p_2e0FPo`) a 4 mouvements et 12 valorisations. La fiche affiche « FC Barcelona U19 → Barcelona, Équipe première 01/07/2023 » au premier point du 21/08/2023. Le PNG affiche le blason du Barça. Le calcul initial `5956` rejoué sur les mêmes entrées aurait placé « FC Barcelona Youth » à cette origine. Le delta `fc0deba` retient les changements internes vers un club admissible et écarte les destinations sans identité interne dont le statut jeune ou réserve ressort du nom. [Fiche Yamal](https://vegasport.vercel.app/joueurs/?id=p_2e0FPo&season=2026%2F2027&playerView=evolution)
- L'API conserve la distinction entre `0` et `null` avec `r.fee_eur ?? null`. Les deux versions du calcul de présentation gardent seulement `feeEur > 0` et rendent donc les deux entrées indiscernables pour un même type de mouvement. Les deux « Transfert libre » de Giroud sont déterminés par `kind: "free"` et n'affichent pas de montant. Un montant numérique nul réel n'est apparu dans aucune des 47 lignes lues. L'effet du zéro est vérifié sur des entrées contrôlées. [Route API figée](https://github.com/VegaInteligence/Vega-Sport/blob/5956a83cd76bf0b41924795e05b5024c8e1770d6/backend/api/src/routes/profiles.mjs#L409-L428)
- L'API distingue lecture réussie sans mouvement, `200 []`, et historique indisponible, `404`. Hors ligne, un historique indisponible produit un repère `estimate` par changement de club visible dans les valorisations, daté du premier point dans ce club. La liste se remplit de ces mêmes observations. Avec `200 []`, seule l'origine de la courbe peut montrer le club de la première valorisation et la liste est vide. L'infobulle de la fiche nomme une estimation « Estimation ». Le détail de liste indique le mois sans qualifier une estimation, et le rapport PNG ne transmet au rendu que date, nom et image du club. Aucun témoin avec valorisations et historique indisponible ou vide n'a été observé dans les huit fiches. [Client des transferts](https://github.com/VegaInteligence/Vega-Sport/blob/fc0deba100288117b0ea122e7199d1c9db9dcc37/dashboard/frontend/src/services/player-transfers.js), [données du rapport](https://github.com/VegaInteligence/Vega-Sport/blob/fc0deba100288117b0ea122e7199d1c9db9dcc37/dashboard/frontend/src/server/report-data.js#L100-L106)
- La vue 135 écarte les mouvements en attente, sans date et les liens joueur mis en quarantaine. Le collecteur du SHA publié remplace l'historique d'un joueur lors d'une lecture réussie. L'API ne fournit aucun état explicite « annulé ». Aucun cycle réel annonce–annulation n'a été suivi dans ce contrôle. Sur la branche d'intégration, la migration 139 conserve les disparitions dans `absent_since`. La vue 135 publiée ignore ce champ, ce qui appelle une vérification du sens métier lors de la fusion. Une disparition du jeu source n'atteste pas d'une annulation. [Vue 135](https://github.com/VegaInteligence/Vega-Sport/blob/5956a83cd76bf0b41924795e05b5024c8e1770d6/backend/sql/135_player_transfers.sql), [collecteur publié](https://github.com/VegaInteligence/Vega-Sport/blob/5956a83cd76bf0b41924795e05b5024c8e1770d6/backend/vega/transfermarkt.py#L981-L999)
- Le delta backend introduit une route et une vue de lecture des tables Transfermarkt existantes. Le diff ne présente de modification ni du collecteur ni des workflows. Les blasons sont réutilisés depuis les URL déjà liées aux clubs, via les chemins de présentation du site et du rapport. Aucun nouveau flux de collecte fournisseur n'apparaît dans les commits contrôlés. Cette vérification correspond au périmètre du diff et des requêtes observées. [Delta des versions](https://github.com/VegaInteligence/Vega-Sport/compare/1c5a4340d193d2ffd1406f965e4007fdfb6b97fb...5956a83cd76bf0b41924795e05b5024c8e1770d6)

## Contre-lecture RDS indépendante à 18:48:11 UTC

La transaction en lecture seule effectuée ensuite par le coordinateur a compté 136 570 lignes de la vue `api.player_transfers`, réparties sur cinq types. Aucun type ne contient d'indemnité numériquement égale à zéro. Les 31 152 mouvements `free` ont tous une indemnité SQL `NULL`. Ces données élargissent la mesure au-delà des 47 lignes du relevé HTTP de 18:40. Cela situe l'effacement d'un zéro dans le contrat de présentation et le rejeu contrôlé, sans effet observé sur les lignes de cette vue à 18:48. La requête qui établit ce compte et son résultat sont dans `contre-lecture-rds/`. Le reçu de transport de cette mesure est conservé dans [le dossier de la contre-lecture](../../corrections-revue/alias-match/mesure/receipt.json).

## Rejeu

Reçu horodaté `public-receipt.json` (18:40:36 UTC), requêtes GET et deux PNG inclus. `summary.json` donne les SHA, les compteurs et la répartition des limites. Les scripts live écrivent dans leur propre dossier. Les copier dans un dossier de rejeu pour préserver le relevé daté.

```sh
# Comparaison hors ligne avec les réponses datées et les deux modules figés.
node replay-selection.mjs > selection-replay.rerun.json
cmp selection-replay.json selection-replay.rerun.json

# Nouveau relevé borné de l'API publique et des images.
python3 capture-public.py

# Avec Playwright Core et Chromium préinstallés, ou en indiquant leurs chemins.
export VI27_PLAYWRIGHT_CORE=/path/to/playwright-core
export VI27_CHROMIUM=/path/to/chrome-headless-shell
zsh run-browser.sh desktop
zsh run-browser.sh phone
```

L'alias en direct peut changer. Avant un rejeu public, comparer ses métadonnées Git au `vercel-alias-current.json` conservé. Le script navigateur compare la présentation aux règles de `fc0deba`. Le résultat attendu reste la liste et les repères enregistrés dans les `result.json` tant que données et présentation n'ont pas changé. Les deux PNG de rapport utilisent `n=5` et les mêmes identités publiques.
