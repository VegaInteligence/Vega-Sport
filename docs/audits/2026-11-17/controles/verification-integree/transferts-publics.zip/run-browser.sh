#!/bin/zsh
set -eu
here=${0:a:h}
pw=${VI27_PLAYWRIGHT_CORE:-/Users/lemonnierhugo/.npm/_npx/31e32ef8478fbf80/node_modules/playwright-core}
browser=${VI27_CHROMIUM:-/Users/lemonnierhugo/Library/Caches/ms-playwright/chromium_headless_shell-1247/chrome-headless-shell-mac-arm64/chrome-headless-shell}
node "$here/browser-public.mjs" "$pw" "$browser" "$1"
