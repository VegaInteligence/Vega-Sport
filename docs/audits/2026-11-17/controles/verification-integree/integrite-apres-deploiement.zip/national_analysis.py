"""Portable national-team identity census; diagnostics only, no database writes or merging."""
from collections import defaultdict,Counter
import re,unicodedata

def normalize(s):return re.sub(r'[^a-z0-9]','',unicodedata.normalize('NFKD',s or '').encode('ascii','ignore').decode().lower())
def analyze(d,t):
 teams={x['id']:x for x in t['nations']};active={k:v for k,v in teams.items() if v['merged_into'] is None}
 def canon(k):
  seen=set()
  while k in teams and teams[k]['merged_into'] is not None:
   assert k not in seen,'cyclic national redirect';seen.add(k);k=teams[k]['merged_into']
  return k
 raw_names=defaultdict(set)
 for k,x in teams.items():
  z=normalize(x['name'])
  if z:raw_names[z].add(k)
 canonical=defaultdict(set);combined=defaultdict(set);provider=defaultdict(set);evidence=defaultdict(list);keygroups=defaultdict(set)
 for k,x in active.items():
  z=normalize(x['name'])
  if z:canonical[z].add(k)
 for k,x in teams.items():
  for field in ('name','short_name'):
   z=normalize(x[field])
   if z:combined[z].add(canon(k));evidence[z].append({'entity':k,'canonical':canon(k),'source':'core.teams','field':field,'name':x[field]})
 for x in t['aliases']:
  z=normalize(x['name'])
  if z:
   combined[z].add(canon(x['entity_id']));provider[(x['source'],z)].add(canon(x['entity_id']));evidence[z].append({'entity':x['entity_id'],'canonical':canon(x['entity_id']),'source':x['source'],'field':x['kind'],'name':x['name'],'stored_normalized':x['normalized']})
 for x in t['keys']:
  # These two adapters use reviewed provider names as keys; others are opaque IDs.
  label=x['provider_key'][5:] if x['provider']=='openfootball' and x['provider_key'].startswith('name:') else x['provider_key'] if x['provider']=='international_results' else None
  if label:
   z=normalize(label);combined[z].add(canon(x['entity_id']));provider[(x['provider'],z)].add(canon(x['entity_id']));evidence[z].append({'entity':x['entity_id'],'canonical':canon(x['entity_id']),'source':x['provider'],'field':'provider_name_key','name':label,'is_current':x['is_current']})
  if x['is_current']:keygroups[(x['provider'],x['provider_key'])].add(canon(x['entity_id']))
 def collisions(g):
  return [{'key':k,'entities':[dict(id=i,name=teams.get(i,{}).get('name')) for i in sorted(v)]} for k,v in sorted(g.items()) if len(v)>1]
 cc=collisions(canonical);ac=collisions(combined);pc=collisions(provider);kc=collisions(keygroups)
 for x in ac:x['evidence']=evidence[x['key']]
 out={'at':d['at'],'snapshot':d['snapshot'],'total_national_rows':len(teams),'active_national_rows':len(active),'redirected_national_rows':len(teams)-len(active),'active_country_null':sum(x['country_code'] is None for x in active.values()),'canonical_same_normalized_name_groups':len(cc),'alias_same_normalized_name_groups':len(ac),'provider_scoped_alias_collision_groups':len(pc),'current_key_multiple_targets':len(kc),'key_rows':len(t['keys']),'alias_rows':len(t['aliases']),'aliases_by_source':dict(Counter(x['source'] for x in t['aliases'])),'canonical_collisions':cc,'alias_collisions':ac,'provider_alias_collisions':pc,'key_collisions':kc,'known_national_scope_flags':t['flags_in_known_national_scopes'],'names_with_age_gender_historic_hints':[x for x in teams.values() if re.search(r'\b(women|feminin|feminine|u[- ]?\d{2}|under|olympic|ussr|soviet|yugoslav|czechoslovak|gdr|east germany|west germany|youth)\b',unicodedata.normalize('NFKD',x['name']).encode('ascii','ignore').decode(),re.I)],'limits':['name normalization removes accents/punctuation; it is a candidate detector, not identity proof','aliases in different languages with no shared normalized spelling remain undetected','gender/age/historical continuity is not established by is_national or a federation country key','NULL country rows are included; unknown is_national teams are only checked in explicitly identified national scopes']}

 usage={x['team_id']:x for x in t['usage']}
 placeholders=[x for x in active.values() if re.match(r'^(?:[A-F][1-4]$|Winner |Runner-up |3rd Group)',x['name'])]
 out['draw_placeholders']={'rows':len(placeholders),'match_sides':sum(usage.get(x['id'],{}).get('match_sides',0) for x in placeholders),'earliest':min(usage[x['id']]['earliest'] for x in placeholders if x['id'] in usage),'latest':max(usage[x['id']]['latest'] for x in placeholders if x['id'] in usage),'entities':placeholders}
 out['nonredirected_nonplaceholder_rows']=len(active)-len(placeholders)
 out['raw_name_collisions_before_resolving_redirects']=collisions(raw_names)
 def projection(k):
  return {'team':teams[k],'keys':[x for x in t['keys'] if x['entity_id']==k],'aliases':[x for x in t['aliases'] if x['entity_id']==k],'usage':usage.get(k)}
 out['multilingual_positive_controls']=[projection(k) for k in (1155,5503,5500,5510,5507,5485,5508)]
 out['historical_families_require_policy']=[{'ids':list(ids),'rows':[projection(k) for k in ids]} for ids in ((1130,1140,5508),(1133,1038),(1117,1167,6569),(1126,5503),(1142,5485),(1127,13516))]
 out['distinct_partial_name_controls']=[{'ids':list(ids),'rows':[projection(k) for k in ids]} for ids in ((1132,1155),(1136,5469),(13458,13467,13470))]
 return out
