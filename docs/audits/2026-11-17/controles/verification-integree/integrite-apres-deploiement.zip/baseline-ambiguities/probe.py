"""Final read-only sports-only closure: seven reserve-attached facts and current queue eligibility."""
def collect(db):
    with db.transaction():
        db.execute("SET TRANSACTION ISOLATION LEVEL REPEATABLE READ READ ONLY")
        at,snap,ro=db.execute("SELECT transaction_timestamp(),pg_current_snapshot()::text,current_setting('transaction_read_only')").fetchone();assert ro=='on'
        out={'version':'integrity-final-v1','at':str(at),'snapshot':snap,'read_only':ro,'queries':{},'errors':{}}
        def get(k,sql,cap=200):
            try:
                with db.transaction():
                    c=db.execute(sql);r=c.fetchall();assert len(r)<=cap
                    out['queries'][k]={'sql':sql,'params':[],'columns':[x.name for x in c.description],'rows':r}
            except Exception as e:out['errors'][k]={'sql':sql,'sqlstate':getattr(e,'sqlstate',None),'message':str(e)[:300]}
        get('reserve_values',"""SELECT v.player_id,v.valued_at,v.value_eur,v.provider_club,v.team_id,v.as_of,v.updated_at,
          EXISTS(SELECT 1 FROM api.player_market_values a WHERE a.player_id=v.player_id AND a.valued_at=v.valued_at) AS visible_in_api_view
          FROM core.player_market_values v WHERE v.source='transfermarkt' AND v.provider_club='75142' AND v.team_id=604 ORDER BY v.player_id,v.valued_at""")
        get('reserve_transfers',"""SELECT id,player_id,transfer_date,source_key,from_provider_club,from_team_id,to_provider_club,to_team_id,kind::text,fee_eur,as_of,updated_at
          FROM core.player_transfers WHERE source='transfermarkt' AND ((from_provider_club='75142' AND from_team_id=604) OR (to_provider_club='75142' AND to_team_id=604)) ORDER BY player_id,transfer_date,id""")
        get('queue_current',"""SELECT kind,priority,count(*) AS tracked,count(*) FILTER(WHERE next_due_at<=now()) AS due,
          count(*) FILTER(WHERE read_at IS NULL) AS never_read,max(read_at) AS latest_read
          FROM ops.transfermarkt_reads WHERE kind IN('profile','transfers') GROUP BY kind,priority ORDER BY kind,priority""")
        get('state',"""SELECT planned_at,paused_until,gave_up_at,last_request_at,blocked_since,blocks_in_row FROM ops.transfermarkt_state WHERE id=1""",cap=1)
        return out
