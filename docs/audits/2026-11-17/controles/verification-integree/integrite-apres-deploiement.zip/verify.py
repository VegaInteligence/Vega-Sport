"""Portable offline verification and comparison, Python 3.11+, standard library only."""
from pathlib import Path
from collections import Counter,defaultdict
import argparse,csv,gzip,hashlib,io,json,zlib
B=Path(__file__).resolve().parent
sha=lambda b:hashlib.sha256(b).hexdigest()
def load(folder):
 r=json.loads((folder/'receipt.json').read_bytes());raw=(folder/'inputs.json.zlib').read_bytes()
 assert sha(raw)==r['sha256'] and len(raw)==r['bytes']
 assert sha((folder/'probe.py').read_bytes())==r['probe_sha256']
 assert r['exit_code']==0 and r['definition_end_state']=='INACTIVE'
 d=json.loads(zlib.decompress(raw));assert d.get('readonly',d.get('read_only'))=='on'
 assert not d.get('errors'),d.get('errors')
 tables=d.get('tables',d.get('queries'));queries=json.loads((folder/'queries.json').read_bytes())
 assert set(tables)==set(queries)
 for k,q in queries.items():
  assert not tables[k].get('failed'),k
  recorded=tables[k].get('sha256_sql',tables[k].get('sql_sha256'))
  if recorded is not None:assert sha(q.encode())==recorded,k
  else:assert tables[k]['sql']==q and not tables[k].get('params'),k
 def records(v):
  seen=Counter();columns=[]
  for name in v['columns']:
   seen[name]+=1;columns.append(name if seen[name]==1 else name+'__'+str(seen[name]))
  return [dict(zip(columns,x,strict=True)) for x in v['rows']]
 return d,{k:records(v) for k,v in tables.items()}
def authority(d,t):
 e=t['14_competition_source_editions'];u,=t['competition_universe'];providers=defaultdict(Counter);editions=defaultdict(set)
 for x in e:
  assert 0<=x['finished_with_score']<=x['recorded_finished']<=x['recorded_matches']
  providers[x['match_provider']].update(edition_provider_rows=1,matches=x['recorded_matches'],finished=x['recorded_finished'],finished_scored=x['finished_with_score'])
  if x['match_provider']:editions[x['edition_id']].add(x['match_provider'])
 assert sum(x['recorded_matches'] for x in e)==u['stored_matches']
 assert sum(x['recorded_finished'] for x in e)==u['paired_finished']
 p=t['15_open_matchday_precedence'];mixed=[x for x in t['03_match_overlap'] if len(x['providers'])>1];status=Counter()
 for x in t['06_sources_runtime']:status[x['status']]+=x['scopes']
 return dict(at=d['at'],snapshot=d['snapshot'],universe=u,editions=len(editions),competitions=len({x['competition_id'] for x in e}),providers=providers,multiple_providers_in_one_physical_edition=sum(len(x)>1 for x in editions.values()),
  configured_omd_precedences=len(p),resolved_omd_precedences=sum(x['pitch_edition_2026'] is not None for x in p),omd_supplemental_copies=sum(x['supplemental_editions_still_stored'] for x in p),source_statuses=status,
  mixed_source_candidate_groups=sum(x['same_day_team_pair_groups'] for x in mixed),mixed_source_candidate_rows=sum(int(x['candidate_rows']) for x in mixed),mixed_source_score_conflicts=sum(x['conflicting_score_groups'] for x in mixed))
def integrity(d,t):
 total=lambda q,k:sum(int(x[k]) for x in t[q]);pairs=lambda q,k,v:{x[k]:int(x[v]) for x in t[q]}
 members=pairs('05_membership_and_transfer','signal','records');edge=pairs('canonical_edges','metric','n');event,=t['event-integrity'];assert sum(event[k] for k in ['both_resolved','one_resolved','neither_resolved'])==event['event_rows']
 return dict(at=d['at'],snapshot=d['snapshot'],matches=total('04_match_integrity','matches'),candidate_match_groups=total('03_match_overlap','same_day_team_pair_groups'),candidate_match_rows=total('03_match_overlap','candidate_rows'),conflicting_score_groups=total('03_match_overlap','conflicting_score_groups'),
  entity_candidates=pairs('01_identity_candidates','signal','candidate_groups'),provider_keys=total('02_provider_keys','provider_keys'),provider_key_groups=len(t['02_provider_keys']),provider_target_missing=total('02_provider_keys','missing_target_keys'),multiple_current_provider_keys=total('02_provider_keys','multiple_current_keys'),
  foreign_keys=sum(x['constraints'] for x in t['07_fk_catalog'] if x['constraint_type']=='f'),unvalidated_constraints=total('07_fk_catalog','unvalidated'),finished_missing_team=total('04_match_integrity','finished_missing_team'),finished_missing_result=total('04_match_integrity','finished_missing_result'),matches_referencing_merged_team=total('04_match_integrity','rows_referencing_merged_team'),same_team_both_sides=total('04_match_integrity','same_team_both_sides'),wrong_or_missing_edition=total('04_match_integrity','wrong_or_missing_edition'),
  positive_minute_rows=total('08_player_membership_match','positive_minute_rows'),positive_minutes_unrelated_team=total('08_player_membership_match','unrelated_team'),positive_minutes_missing_match=total('08_player_membership_match','missing_match'),positive_minutes_unknown_team=total('08_player_membership_match','unknown_team'),contracts=total('contracts','spells'),transfers=event['event_rows'],transfer_missing_canonical_endpoint=event['one_resolved']+event['neither_resolved'],transfer_missing_raw_side=event['missing_raw_side'],repeated_transfer_source_key=event['repeated_any_source_key'],memberships=members,canonical_edges=edge,provider_link_drift=t['12_provider_link_drift'])
def delta(before,after):
 out={}
 for k in sorted(set(before)|set(after)):
  x,y=before.get(k),after.get(k)
  if isinstance(x,dict) and isinstance(y,dict):
   z=delta(x,y)
   if z:out[k]=z
  elif x!=y:out[k]={'before':x,'after':y,**({'delta':y-x} if type(x) in (int,float) and type(y) in (int,float) else {})}
 return out
def csv_text(rows):
 s=io.StringIO(newline='');w=csv.DictWriter(s,fieldnames=list(rows[0]),lineterminator='\n');w.writeheader();w.writerows(rows);return s.getvalue().encode()
def compute():
 c,ct=load(B/'current');a,at=load(B/'baseline-authority');i,it=load(B/'baseline-integrity')
 olda,newa=authority(a,at),authority(c,ct);oldi,newi=integrity(i,it),integrity(c,ct)
 assert newa['universe']['stored_matches']==newi['matches']
 before={x['edition_id']:x for x in at['14_competition_source_editions']};changed=[]
 for x in ct['14_competition_source_editions']:
  prior=before.get(x['edition_id'])
  if prior is None or any(x[k]!=prior[k] for k in ('match_provider','recorded_matches','recorded_finished','finished_with_score')):changed.append({'edition_id':x['edition_id'],'competition':x['competition'],'season':x['season'],'source':x['match_provider'],'changes':delta(prior or {},x)})
 out={'current':{'authority':newa,'integrity':newi,'migrations':ct['current_migrations'],'overlap_by_sources':ct['03_match_overlap'],'nations_editions':ct['nations_edition_inventory'],'nations_overlap_groups':len(ct['nations_overlap_pairs']),'nations_overlap_rows':sum(x['rows'] for x in ct['nations_overlap_pairs']),'known_conflicts':ct['conflict_current_binding'],'reserve_exposure':ct['reserve_link_exposure'],'missing_profiles_queue':ct['queue_expected_priority'],'omd_four_pair_rows':len(ct['four_pairs_all_sources'])},
      'baselines':{'authority':olda,'integrity':oldi},'deltas':{'authority':delta(olda,newa),'integrity':delta(oldi,newi),'editions':changed},
      'limits':['same-date/team signatures are candidates, not adjudicated duplicates','foreign-key validation does not establish sports identity correctness','background collector deltas are not automatically attributable to the deployment','counts of final match result fields are not Vega Score coverage','authority baseline15:59 and integrity baseline15:20 are separate transactions']}
 # Supplementary snapshots retain their own times; no false claim of one transaction.
 n,nt=load(B/'nations-current');rs=nt['rosters'];fs=nt['fixtures'];ids={e:{x['id'] for x in rs if x['competition_season_id']==e} for e in (305,308)}
 assert len(fs)==sum(x['matches'] for x in ct['nations_edition_inventory'])
 out['nations_followup']={'at':n['at'],'snapshot':n['snapshot'],'fixtures':len(fs),'all_finished_scored':all(x['status']=='finished' and x['home_score'] is not None and x['away_score'] is not None for x in fs),'teams_by_edition':{str(k):len(v) for k,v in ids.items()},'shared_ids':sorted(ids[305]&ids[308]),'national_teams':sum(x['is_national'] is True for x in rs),'country_null':sum(x['country_code'] is None for x in rs)}
 old,ot=load(B/'baseline-ambiguities');out['known_ambiguity_deltas']={'before_at':old['at'],'after_at':c['at'],'reserve_market_values':{'before':len(ot['reserve_values']),'after':next(x['rows'] for x in ct['reserve_link_exposure'] if x['kind']=='market_value_rows_75142_to_604')},'reserve_transfers':{'before':len(ot['reserve_transfers']),'after':next(x['rows'] for x in ct['reserve_link_exposure'] if x['kind']=='transfer_rows_75142_to_604')}}
 oldkeys={(x['kind'],x['provider']):int(x['provider_keys']) for x in it['02_provider_keys']}
 out['provider_key_deltas']=[{'kind':x['kind'],'provider':x['provider'],'before':oldkeys.get((x['kind'],x['provider']),0),'after':int(x['provider_keys'])} for x in ct['02_provider_keys'] if int(x['provider_keys'])!=oldkeys.get((x['kind'],x['provider']),0)]
 if (B/'national-current').exists():
  from national_analysis import analyze
  d,t=load(B/'national-current');out['national_identity_census']=analyze(d,t)
 return out,ct
if __name__=='__main__':
 ap=argparse.ArgumentParser();ap.add_argument('--write',action='store_true');args=ap.parse_args();out,t=compute()
 if args.write:
  (B/'result.json').write_text(json.dumps(out,ensure_ascii=False,indent=2)+'\n')
  for name,key in [('sources-par-edition','14_competition_source_editions'),('nations-overlap','nations_overlap_pairs'),('omd-four-pairs','four_pairs_all_sources')]:
   if t[key]: (B/(name+'.csv.gz')).write_bytes(gzip.compress(csv_text(t[key]),mtime=0))
 else:
  assert json.loads((B/'result.json').read_bytes())==out
  for name,key in [('sources-par-edition','14_competition_source_editions'),('nations-overlap','nations_overlap_pairs'),('omd-four-pairs','four_pairs_all_sources')]:
   if t[key]:assert gzip.decompress((B/(name+'.csv.gz')).read_bytes())==csv_text(t[key])
 print(json.dumps({'at':out['current']['authority']['at'],'authority':out['current']['authority'],'integrity':out['current']['integrity'],'nations_overlap_groups':out['current']['nations_overlap_groups'],'changed_editions':len(out['deltas']['editions']),'verified':True},ensure_ascii=False,indent=2))
