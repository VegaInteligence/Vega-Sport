# Autorité et intégrité après le déploiement b2e6

**Lecture principale : 18 novembre 2026, 17:11:40.747117 UTC, snapshot 4447904:4447904:.** Les 25 SELECT de la mesure principale partagent une transaction PostgreSQL `REPEATABLE READ READ ONLY`. Aucun échec SQL. Le worker observé est `b2e6dd82d36a2ca0f439ec84bf2e5dbbcd3013d9`. Le diagnostic éphémère a été désactivé après exécution. Aucun déploiement de service, changement de base ou édition de code produit n’a été effectué.

Les dates antérieures ne sont pas interchangeables : l’autorité est comparée au relevé **15:59:30 UTC** et l’intégrité au relevé **15:20:35 UTC**. La liaison réserve est comparée à **15:37:01 UTC**. Deux compléments strictement lus ont leurs propres instantanés : Nations League à **17:14:47 UTC**, toutes les sélections à **17:17:38 UTC**. Ce sont des contrôles d’autorité/identité et de scores finaux de rencontres ; aucune couverture de Vega Scores n’a été recalculée.

## Mesures actuelles et changements

| Mesure | Avant | Après | Différence |
|---|---:|---:|---:|
| Rencontres physiques |588758|588794|+36|
| Rencontres `finished` |576487|577188|+701|
| International Results : rencontres terminées avec score |373|409|+36|
| OpenFootball : rencontres physiques |65926|65926|0|
| OpenFootball : rencontres `finished` |65126|65791|+665|
| OpenFootball : `finished` avec les deux scores |64606|65271|+665|
| Toutes sources : `finished` sans l’un des scores |520|520|0|
| Éditions / compétitions ayant des rencontres |2149/208|2149/208|0|
| Éditions physiques avec plusieurs fournisseurs de rencontres |0|0|0|
| Copies OMD des 35 éditions prioritaires configurées |0|0|0|
| Groupes candidats même jour/deux équipes canoniques |915|915|0|
| Lignes dans ces groupes |1836|1836|0|
| Groupes aux scores complets contradictoires |4|4|0|
| Groupes candidats mélangeant des fournisseurs |287|287|0|
| Lignes dans les groupes mixtes |576|576|0|
| Groupes mixtes aux scores complets contradictoires |0|0|0|

Les 18 éditions d’archives Mondial modifiées gagnent au total 665 lignes classées terminées avec score ; l’édition International Results de Nations League gagne36 rencontres. Les 520 rencontres déjà terminées sans score restent présentes. Le relevé agrégé ne prouve pas, à lui seul, si chaque valeur avait été absente auparavant ou si son statut empêchait seulement de la compter. `result.json` conserve les deltas de chacune des 19 éditions.

| Fournisseur de rencontres | Éditions | Rencontres | Terminées | Terminées avec score |
|---|---:|---:|---:|---:|
| PitchAPI |304|84371|75355|75355|
| OpenFootball |241|65926|65791|65271|
| OpenLigaDB |3|167|159|159|
| International Results |8|409|409|409|
| Open Matchday |30|4682|2576|2576|
| Engsoccerdata |736|179928|179587|179587|
| Worldclub |360|63159|63159|63159|
| Footballcsv |467|190152|190152|190152|

Les 173 scopes de `ops.source_runs` agrégés par cette requête ont le statut `ok`. Ce statut n’établit pas leur complétude métier. Les signatures de doublons restent des **candidats**, pas des autorisations de fusion ou de suppression. Les quatre conflits de scores recensés sont dans Engsoccerdata. Les quatre paires OMD déjà analysées conservent huit lignes OMD ; deux de ces paires comprennent aussi une ligne OpenLigaDB, d’où dix lignes dans le contrôle ciblé toutes sources.

## Nations League : complémentarité mesurée

- Édition305, OpenLigaDB :48 rencontres,16 sélections.
- Édition308, International Results :108 rencontres,38 sélections ;72 rencontres au relevé antérieur.
- Au complément17:14:47 :156 rencontres terminées avec les deux scores,54 identités nationales distinctes, aucun identifiant partagé entre les deux rosters, aucune paire dupliquée détectée par date/identités. Les libellés inspectés correspondent à deux populations complémentaires.
- Les 54codes pays sontNULL. Le premier comptage « même nom et même pays » ne pouvait donc pas les contrôler. Le contrôle élargi ci-dessous supprime cette restriction. Le fichier source garde les 156 rencontres et 54 identités nécessaires pour examiner le rapprochement ; aucun verdict n’est fondé sur les seuls totaux48/108.

## Clés, relations et ambiguïtés

- **252 FK validées**, aucune contrainte non validée. Aucune cible manquante de `provider_ids`, aucune entité portant plusieurs clés actuelles du même fournisseur. Aucune rencontre référant une équipe redirigée, opposant une équipe à elle-même ou liée à une mauvaise édition/saison.
- Les 1783 rencontres terminées avec un côté d’équipe absent restent 1783. C’est un manque de donnée, pas une preuve de FK cassée.
- Les 2297613 lignes joueur/match à minutes positives gardent zéro équipe étrangère au match, zéro équipe inconnue et zéro match manquant dans ce prédicat.
- Les sept groupes d’équipes au même nom/pays et au type non précisé restent sept. Les autres signatures strictes de noms/joueurs/compétitions/saisons restent à zéro ; elles ne constituent pas un certificat de déduplication sémantique.
- Clés fournisseur :211619→211774, soit+155 :36 clés de match International Results,118 clés FIFA d’équipes et une clé Wikidata de joueur.25 groupes entité/fournisseur contre 24.
- Transferts :104326→122457 ;76998mouvements ont au moins une extrémité canonique non résolue, contre 64790. Aucune extrémité brute manquante dans le prédicat, aucune clé source répétée. Les cinq groupes de mêmes faits de transfert restent cinq. Ces progressions de collecte entre deux heures ne sont pas toutes attribuables au déploiement.
-12570 contrats, aucun conflit de clubs contemporains et aucun intervalle négatif ;88239 affiliations fournisseur.106 affiliations restent sans profil fournisseur. Leurs priorités restent 65 × 2,20 × 3,3 × 4,18 × 9 alors que la priorité demandée est 1.
- Deux liens en quarantaine et trois enregistrements de conflit restent présents. Ces trois enregistrements ne sont pas trois défauts actifs équivalents.
- **Estudiantes de Río Cuarto 604→Transfermarkt 75142 (« AA Estudiantes de Río Cuarto II ») reste lié et non mis en quarantaine.** Trois valeurs et **cinq** transferts portent cette association, contre trois et quatre au relevé15:37. Aucun contrat dans le prédicat ciblé. DC United garde sa liaison correcte ; B93 n’a pas cette clé courante. La distinction et les propriétaires de la contre-épreuve antérieure restent applicables.

## Toutes les sélections, sans filtre pays

La lecture17:17:38 contient **235 lignes** `is_national=true` :28 redirigées et 207 nonredirigées. Les 207ont `country_code=NULL`.

Les 207ne sont pas207 sélections sportives éligibles : **54sont des places de tirage Euro 2028** (`A1`, `Winner Group A`, `Winner Match 39`, etc.), avec102 côtés de rencontres futures entre le 9 juin et le 9juillet2028. Il reste **153 identités nommées nonredirigées**, historiques comprises. Ces valeurs ne sont pas un décompte des membres actuels d’une fédération.

La normalisation reproduit l’usage du collecteur : Unicode NFKD, retrait des accents, minuscules et lettres/chiffres. Le contrôle comprend noms principaux, noms courts,139 alias et les clés nominales OpenFootball/International Results ;463 clés fournisseur sont conservées.

-16 groupes de noms identiques existent avant résolution des redirections. Ils ne représentent plus de collision entre identités canoniques distinctes après cette résolution.
- **Zéro collision non résolue** de nom normalisé, d’alias entre IDs canoniques, d’alias par fournisseur, ou de clé fournisseur actuelle vers plusieurs cibles.
- Contrôles linguistiques positifs déjà liés au mêmeID : Ireland/Republic of Ireland/Irlande 1155 ; Czechia/Czech Republic/Tchéquie 5503 ; Turkiye/Turkey/Turquie 5500 ; Ivory Coast/Côte d’Ivoire 5510 ; Curacao/Curaçao 5507 ; DR Congo/Democratic Republic of the Congo 5485 ; Germany/Allemagne 5508. Les clés opaques, alias exacts et dates d’usage figurent dans `national-result.json`.
- Des noms proches correspondent à des sélections distinctes : Northern Ireland 1132/Ireland 1155 ; North Korea 1136/South Korea 5469 ; Guinea 13458/Guinea-Bissau 13467/Equatorial Guinea 13470. Une similarité partielle ne justifie pas un rapprochement.
- Les familles historiques sont exposées pour décision, **sans fusion automatique** : West Germany 1130/East Germany 1140/Germany 5508 ; Soviet Union 1133/Russia 1038 ; Yugoslavia 1117/Serbia and Montenegro 1167/Serbia 6569 ; Czechoslovakia 1126/Czechia 5503 ; Zaire 1142/DR Congo 5485 ; Dutch East Indies 1127/Indonesia 13516. Le nom, le pays actuel ou une continuité de fédération ne suffisent pas à décider comment conserver l’histoire sportive.
- Les 153 identités utilisées dans les scopes nationaux explicitement identifiés sont toutes marquées nationales. Ce contrôle ciblé n’invente pas le type des autres équipes de la base.

**Limites :** l’âge, le genre et le niveau senior/jeunes ne sont pas démontrés par `is_national` ni par une clé de fédération. Une traduction non partagée dans les alias échappe au groupement exact. Le zéro constaté signifie zéro collision selon ces preuves, pas zéro possibilité de confusion dans le monde réel. Les emblèmes restent documentés par le relevé T7 daté ; aucune récupération ou publication n’a été entreprise ici.

## Reproduire et vérifier

Le ZIP est autonome. Après extraction, Python 3.11 ou ultérieur suffit, sans AWS, réseau ou PostgreSQL :

```sh
python3 -B verify.py
```

Le programme contrôle SHA-256 du transport, SHA de la sonde, chaque requête, les états de diagnostic terminé/désactivé et les transactionsREAD ONLY ; il recalcule les totaux, deltas, projectionsCSV et le census national. Les champs SQL homonymes sont conservés dans le transport brut et désambiguïsés par suffixe dans les projections. Il compare les sorties à `result.json`. Le contrôle n’est pas un E2E du produit.

Pour refaire une lecture sur un PostgreSQL autorisé, installer `psycopg 3` et configurer libpq (`PGSERVICE`/variables PG et réseau privé), puis utiliser un répertoire de sortie neuf :

```sh
python3 replay-live.py --dataset current --output nouveau-releve
python3 replay-live.py --dataset nations-current --output nouvelles-nations
python3 replay-live.py --dataset national-current --output nouvelles-identites-nationales
```

Ces commandes imposent `default_transaction_read_only=on`, puis une transaction `REPEATABLE READ READ ONLY`. Elles n’affichent pas les paramètres de connexion. Les requêtes exactes sont dans chaque `queries.json`; les sondes ne contiennent pas de secret. Une nouvelle lecture possède nécessairement sa propre date et ne remplace pas silencieusement les preuves figées. Le lancement ECS original et ses reçus restent dans le dossier de travail ; aucune reproduction autonome ne requiert son chemin Mac.
