import hashlib
queries={'fixtures': 'SELECT m.id,m.competition_season_id,m.source::text,m.status::text,m.match_date,m.kickoff_at,m.home_team_id,m.away_team_id,m.home_score,m.away_score,m.date_unverified,h.name AS home_name,h.country_code AS home_country,h.is_national AS home_national,a.name AS away_name,a.country_code AS away_country,a.is_national AS away_national\nFROM core.matches m LEFT JOIN core.teams h ON h.id=m.home_team_id LEFT JOIN core.teams a ON a.id=m.away_team_id WHERE m.competition_season_id IN (305,308) ORDER BY m.competition_season_id,m.match_date,m.id', 'rosters': 'SELECT DISTINCT m.competition_season_id,t.id,t.name,t.country_code,t.is_national,t.merged_into FROM core.matches m CROSS JOIN LATERAL(VALUES(m.home_team_id),(m.away_team_id)) x(team_id) JOIN core.teams t ON t.id=x.team_id WHERE m.competition_season_id IN(305,308) ORDER BY m.competition_season_id,t.id'}
def collect(db):
 with db.transaction():
  db.execute("SET TRANSACTION ISOLATION LEVEL REPEATABLE READ READ ONLY")
  at,snap,ro=db.execute("SELECT transaction_timestamp(),pg_current_snapshot()::text,current_setting('transaction_read_only')").fetchone();assert ro=='on'
  out={'at':str(at),'snapshot':snap,'read_only':ro,'queries':{}}
  for k,q in queries.items():
   c=db.execute(q);rows=c.fetchall();assert len(rows)<1000
   out['queries'][k]={'columns':[p.name for p in c.description],'rows':rows,'sql_sha256':hashlib.sha256(q.encode()).hexdigest()}
  return out
