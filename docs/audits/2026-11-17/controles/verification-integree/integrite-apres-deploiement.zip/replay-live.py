"""Portable direct PostgreSQL read, using standard libpq PG* environment/service settings.
Requires psycopg3 and an authorized network connection. Never prints credentials.
"""
from pathlib import Path
import argparse,hashlib,json,zlib
import psycopg
from importlib.util import spec_from_file_location,module_from_spec
ap=argparse.ArgumentParser();ap.add_argument('--output',type=Path,required=True);ap.add_argument('--dataset',choices=['current','nations-current','national-current'],default='current');a=ap.parse_args();a.output.mkdir(exist_ok=False,parents=True)
p=Path(__file__).resolve().parent/a.dataset/'probe.py';spec=spec_from_file_location('probe',p);module=module_from_spec(spec);spec.loader.exec_module(module);collect=module.collect
with psycopg.connect(application_name='vega_audit_readonly_integrity',options='-c default_transaction_read_only=on -c statement_timeout=90000 -c lock_timeout=1500 -c max_parallel_workers_per_gather=0',autocommit=True) as db:
 assert db.execute('SHOW transaction_read_only').fetchone()[0]=='on'
 result=collect(db)
blob=zlib.compress(json.dumps(result,default=str,ensure_ascii=True,separators=(',',':')).encode(),6)
(a.output/'inputs.json.zlib').write_bytes(blob)
(a.output/'direct-receipt.json').write_text(json.dumps({'mode':'direct-authorized-libpq','read_only':result['read_only'],'at':result['at'],'snapshot':result['snapshot'],'sha256':hashlib.sha256(blob).hexdigest(),'bytes':len(blob),'errors':result.get('errors',{})},indent=2)+'\n')
print(json.dumps({'at':result['at'],'snapshot':result['snapshot'],'queries':len(result['queries']),'errors':result.get('errors',{})}))
