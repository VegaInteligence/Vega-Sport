# Provenance des rencontres en production

Cette mesure conserve le résultat d’une transaction PostgreSQL en lecture seule. Les six requêtes portent sur les sources enregistrées dans chaque édition, les éditions prioritaires de 2026/27, les statuts des collecteurs, les paires de rencontres à examiner, les saisons françaises et l’ensemble des matchs physiques.

Le champ `match_provider` donne l’origine enregistrée de la rencontre. Les champs complémentaires comme un blason, un classement ou une statistique ont leur propre propriétaire dans la matrice des sources du rapport. Un statut `finished` peut coexister avec un score final absent. Les connexions entre deux éditions et les équipes rapprochées par date sont des indices à examiner. La même rencontre peut avoir plusieurs identifiants physiques.

Après extraction, exécuter `python3 -B verifier.py`. Le programme vérifie les requêtes, le contenu transporté et reproduit le CSV ainsi que ses agrégats. La colonne des scores renseignés exige les deux valeurs et un statut terminé. Les données tabulaires gardent les valeurs inconnues. Les sources et identifiants requis pour répéter la lecture dans Vega sont fournis dans `requetes.json`. Les autres constats de terrain et le journal des requêtes API de 24 heures figurent dans le rapport principal.
