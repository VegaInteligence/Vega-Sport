"""Check the frozen read and reconstruct provider/competition/season attribution without a connection."""
from collections import Counter,defaultdict
from hashlib import sha256
import csv,gzip,io,json,zlib
from pathlib import Path

def digest(b):
    return sha256(b).hexdigest()

def compute(folder):
    receipt=json.loads((folder/'receipt.json').read_bytes())
    capture=(folder/'inputs.json.zlib').read_bytes()
    assert receipt['exit_code']==0 and receipt['definition_end_state']=='INACTIVE'
    assert digest(capture)==receipt['sha256'] and digest((folder/'probe.py').read_bytes())==receipt['probe_sha256']
    data=json.loads(zlib.decompress(capture))
    assert data['readonly']=='on'
    queries=json.loads((folder/'requetes.json').read_bytes())
    assert set(queries)==set(data['tables'])
    for name,sql in queries.items():
        assert digest(sql.encode())==data['tables'][name]['sha256_sql']
    def rows(key):
        t=data['tables'][key]
        return [dict(zip(t['columns'],values)) for values in t['rows']]
    editions=rows('14_competition_source_editions')
    rds,=rows('competition_universe')
    assert sum(r['recorded_matches'] for r in editions)==rds['stored_matches'] and rds['missing_or_wrong_edition']==0
    assert sum(r['recorded_finished'] for r in editions)==rds['paired_finished']
    per_source=defaultdict(Counter)
    per_edition=defaultdict(set)
    for r in editions:
        assert 0<=r['finished_with_score']<=r['recorded_finished']<=r['recorded_matches']
        per_source[r['match_provider']].update(edition_provider_rows=1,matches=r['recorded_matches'],finished=r['recorded_finished'],finished_scored=r['finished_with_score'])
        if r['match_provider']:
            per_edition[r['edition_id']].add(r['match_provider'])
    bindings=rows('15_open_matchday_precedence')
    france=rows('ligue1_matches')
    indexed={r['edition_id']:r for r in editions}
    for r in france:
        stored=indexed[r['edition_id']]
        assert (stored['match_provider'],stored['recorded_matches'],stored['recorded_finished'])==(r['authoritative_match_source'],r['fixtures'],r['finished'])
        r['with_stored_score_all_statuses']=r.pop('with_final_score')
        r['finished_with_score']=stored['finished_with_score']
        assert r['finished_with_score']<=r['with_stored_score_all_statuses']<=r['fixtures']
    current,=[r for r in france if r['season']=='2026/2027']
    old,=[r for r in france if r['season']=='2019/2020']
    assert current['authoritative_match_source']=='pitchapi' and old['finished_with_score']<old['finished']
    groups=rows('03_match_overlap')
    mixed=[r for r in groups if len(r['providers'])>1]
    run_states=Counter()
    for r in rows('06_sources_runtime'):
        run_states[r['status']]+=r['scopes']
    f=io.StringIO(newline='')
    writer=csv.DictWriter(f,fieldnames=list(editions[0]),lineterminator='\n')
    writer.writeheader()
    writer.writerows(editions)
    summary={'at':data['at'],'snapshot':data['snapshot'],'rds':rds,'distinct_editions':len(per_edition),'distinct_competitions':len({r['competition_id'] for r in editions}),
        'multiple_fixture_providers_in_one_physical_edition':sum(len(v)>1 for v in per_edition.values()),'providers':per_source,'scheduled_status_at_capture':run_states,
        'precedences':{'configured':len(bindings),'native_resolved':sum(r['pitch_edition_2026'] is not None for r in bindings),'supplemental_copies':sum(r['supplemental_editions_still_stored'] for r in bindings)},
        'cross_source_same_date_team_groups':sum(r['same_day_team_pair_groups'] for r in mixed),'cross_source_candidate_rows':sum(int(r['candidate_rows']) for r in mixed),
        'cross_source_with_conflicting_complete_scores':sum(r['conflicting_score_groups'] for r in mixed),'mixed_provider_results':mixed,'ligue1_all':france}
    return f.getvalue().encode(),summary

if __name__=='__main__':
    f=Path(__file__).resolve().parent
    grid,summary=compute(f)
    assert gzip.decompress((f/'sources-par-edition.csv.gz').read_bytes())==grid
    assert json.loads((f/'resultat.json').read_bytes())==summary
    print(json.dumps({k:v for k,v in summary.items() if k not in ('ligue1_all','mixed_provider_results')},ensure_ascii=False))
