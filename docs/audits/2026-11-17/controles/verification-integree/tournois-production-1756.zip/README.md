# Tournois sur le site public le 18 novembre, 17 h 56 UTC

Sur ordinateur et iPhone simulé, les quatre équipes de la poule finale de 1950 reçoivent désormais les bons points. La RDA obtient cinq points en 1974, son drapeau est présent et la table tient dans la carte. La version actuellement publiée place cependant la Turquie devant la RFA en 1954 et le Portugal devant l’Allemagne dans le groupe F de l’EURO 2020. L’édition 2028 présente zéro tableau de groupe. La fiche d’Uruguay décrit la campagne victorieuse de 1950 comme « 1er tour ». Le filtre « Italie » omet la finale de 1982 tandis que « Italy » la retrouve. Les dix observations sont identiques sur les deux formats. L’URL nationale utilise la clé renvoyée par l’index public, `t_3ZJD1c`.

Les fichiers `attendus.md`, `final-desktop/lecture.json` et `final-iphone/lecture.json` contiennent les attentes et mesures détaillées. Leurs dossiers contiennent chacun sept captures. Le lecteur de la base et le navigateur ont des révisions distinctes. Le lot courant de la branche a sa propre capsule.

Extraire l’archive puis lancer `python3 -B verifier.py`. Cette commande vérifie les empreintes, les valeurs, les 14 requêtes de navigation et les deux séries de captures hors réseau. Pour recommencer la mesure en ligne avec Node, Playwright Chromium et la clé nationale de l’index inclus, exécuter les deux commandes suivantes. Une publication ultérieure peut changer les résultats.

```sh
node mesurer.mjs "$PLAYWRIGHT_MODULE" "$CHROMIUM" desktop nouvelle-lecture-bureau
node mesurer.mjs "$PLAYWRIGHT_MODULE" "$CHROMIUM" iphone nouvelle-lecture-mobile
```
