"""Contrôler les deux lectures enregistrées et les fichiers de la capsule, hors réseau."""
import hashlib, json
from pathlib import Path
p=Path(__file__).resolve().parent
files=json.loads((p/'empreintes.json').read_text())
for name,digest in files.items():
    assert hashlib.sha256((p/name).read_bytes()).hexdigest()==digest,name
results=[]
for device in ('desktop','iphone'):
    table=json.loads((p/('final-'+device)/'lecture.json').read_bytes())
    assert table['device']==device and len(table['cases'])==7 and not table['errors']
    assert all(c['status']==200 and 'error' not in c for c in table['cases'])
    assert len(table['checks'])==10
    checks={c['name']:c for c in table['checks']}
    assert len(checks)==10
    assert all(c['meets']==(c['expected']==c['actual']) for c in checks.values())
    assert checks['RDA 1974 points']['actual']=='5' and checks['table dans sa carte']['actual']
    assert checks['1954 barragiste qualifié deuxième']['actual']=='Turquie'
    assert checks['EURO 2020 Allemagne devant Portugal']['actual']=='Portugal'
    assert checks['2028 groupes']['actual']==checks['recherche libellé français']['actual']==0
    assert checks['Uruguay champion 1950']['actual'] is None and '1er tour' in table['cases'][-1]['result']['title']
    results.append({'device':device,'finished':table['finished'],'obs':len(checks),'satisfaits':sum(c['meets'] for c in checks.values()),'ecarts':[c['name'] for c in checks.values() if not c['meets']]})
assert results[0]['ecarts']==results[1]['ecarts']
print(json.dumps({'revision_front':'e60e80860e6ad1cfa9f330a4b2c2ce66eb9ef35a','controles':results,'fichiers':len(files)},ensure_ascii=False))
