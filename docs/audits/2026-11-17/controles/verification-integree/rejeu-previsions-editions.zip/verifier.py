import hashlib,json
from pathlib import Path
p=Path(__file__).resolve().parent
d=json.loads((p/'sha256.json').read_bytes())
for name,h in d.items():assert hashlib.sha256((p/name).read_bytes()).hexdigest()==h, name
a=json.loads((p/'global/previsions.json').read_bytes())['rows']
b=json.loads((p/'editions/previsions.json').read_bytes())['rows']
assert sum(row[1] for row in a)==2249 and sum(row[2] for row in a)==2107
for source,n,f,l,_,eds in a:
 z=[x for x in b if x[0]==source]
 assert [sum(x[i] for x in z) for i in (4,5,6)]==[n,f,l] and sum(x[5]>0 for x in z)==eds
z=[x for x in b if x[1] in (332,333,334)]
assert sum(x[4] for x in z)==sum(x[5] for x in z)==361
print('PASS: two snapshots, 2,107 forecast fixtures, 361/361 in the three English editions')
