from pathlib import Path
import json
from psycopg import sql
from psycopg.types.json import Jsonb

ROOT = Path(__file__).resolve().parent

def rows(capture, key):
    return list(map(json.loads, capture["reads"][key]["rows_json"]))


def store(conn, table, records):
    if records:
        fields = sql.SQL(", ").join(sql.Identifier(r[0]) for r in conn.execute(
            """SELECT attname FROM pg_attribute WHERE attrelid=%s::regclass AND attnum>0
               AND NOT attisdropped AND attgenerated='' ORDER BY attnum""", (table,)))
        relation = sql.Identifier(*table.split("."))
        conn.execute(sql.SQL("INSERT INTO {t} ({c}) SELECT {c} FROM jsonb_populate_recordset(NULL::{t},%s)")
                     .format(t=relation,c=fields), (Jsonb(records),))


def prepare(conn, before, after):
    for source, fields in {
        "core.seasons": ("season_id",), "core.teams": ("home_team_id","away_team_id"),
        "core.venues": ("venue_id",), "core.referees": ("referee_id",),
        "core.competition_seasons": ("competition_season_id_season_id",),
        "core.rounds": ("round_id",),
    }.items():
        wanted = {r["id"]:r for field in fields for r in rows(before,"parent.matches_"+field+"_fkey")}
        if source=="core.teams":
            countries = sorted({r["country_code"] for r in wanted.values() if r["country_code"]})
            conn.execute("INSERT INTO core.countries(code) SELECT unnest(%s::text[]) ON CONFLICT DO NOTHING",(countries,))
            assets = json.loads((ROOT/"asset-parent.json").read_text())
            assert {r["crest_asset_id"] for r in wanted.values()}-{None} == {r[0] for r in assets["rows"]}
            for row in assets["rows"]:
                conn.execute("""INSERT INTO core.assets(id,kind,source_url,s3_key,sha256,content_type,width,height)
                                VALUES (%s,%s,%s,%s,decode(%s,'hex'),%s,%s,%s)""", row)
        if source=="core.competition_seasons":
            for edition in wanted.values():
                conn.execute("INSERT INTO core.competitions(id,name) VALUES(%s,%s) ON CONFLICT DO NOTHING",
                             (edition["competition_id"], edition["cup_name"]))
        store(conn,source,list(wanted.values()))
    store(conn,"agg.power_runs",rows(after,"elo_runs"))
    store(conn,"agg.team_elo",rows(after,"table.agg.team_elo"))
    conn.execute("SELECT core.ensure_season_partitions(2026)")
    conn.execute("SELECT setval(pg_get_serial_sequence('core.matches','id'),20000)")


