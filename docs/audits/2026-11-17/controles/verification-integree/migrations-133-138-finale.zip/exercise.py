"""Qualify a committed candidate on PostgreSQL 18 from both production schema histories."""
import argparse
from datetime import datetime, timedelta, timezone
from hashlib import sha256
from io import BytesIO
import csv
import json
import os
from pathlib import Path
import re
import subprocess
import sys
import tarfile
from tempfile import TemporaryDirectory
from urllib.error import HTTPError
from urllib.parse import urlencode
from urllib.request import Request, urlopen
from zipfile import ZipFile
import zlib

import psycopg
from psycopg import sql

from seed_parents import prepare, rows

ROOT=Path(__file__).resolve().parent
BASE="8018e0836ca0f32e8b2eb51fc2847154abff7f13"
MAIN="202f24c09eb4c8fb87d7190939bafbf09cb00393"
HARNESS="0580dfd4ba645461d6c372fbd7b1d73eaaa779a0"
OLD="133_cohort_max_wait.sql"
RESET="134_archive_scores_due.sql"
REPAIR="134_archive_repair_boundary.sql"
LAST="151_snapshot_match_ownership.sql"
PIN_PROBE="150_schema_guard_probe.sql"
SEAL="db35bdf6cc5f7799cb679a8160c096a49c6bd8475130ad3895709c0fd06c0f6b"
ARCHIVE_MEMBERS={
    "rds/avant.zlib":"ed7496ec232d3ef8c93b70439e3ccaa9ae56c0708c4c11cbedb4872012a1f74c",
    "rds/apres.zlib":"e850dd9ebc33dfad5c71b93090fb2d4b3c9c4dfea73296e2278fa13f29f3d71d",
    "rencontres/nouveau.csv":"1f5a545bb3d9f849c6dee8c402545ce07838a8737242985f8c012636bd96dc06",
}
AT=datetime(2026,11,18,16,tzinfo=timezone.utc)
NATIONS={"1982":("t_v0001032",3,1),"1998":("t_2ysHaw",0,3)}
SCOPES={f"open-cups:world-cup-history:{year}" for year in NATIONS}
RUNTIME_PATHS=("backend/vega","backend/sql","backend/api","backend/sources","dashboard/frontend/src/services","dashboard/shared",
               "dashboard/frontend/src/data-url.js","dashboard/frontend/src/model.js")


def digest(body):
    return sha256(body).hexdigest()


def seed_observed(db,before,after,newer,nations):
    prepare(db,before,after)
    countries=sorted({t["country_code"] for t in nations["teams"] if t["country_code"]})
    db.execute("INSERT INTO core.countries(code) SELECT unnest(%s::text[]) ON CONFLICT DO NOTHING",(countries,))
    for team in nations["teams"]:
        db.execute("INSERT INTO core.teams(id,name,country_code,is_national) VALUES(%(id)s,%(name)s,%(country_code)s,%(is_national)s)",team)
    for link in nations["team_bindings"]:
        db.execute("""INSERT INTO core.provider_ids(entity_type,provider,provider_key,entity_id,is_current)
                      VALUES('team',%(provider)s,%(key)s,%(id)s,%(current)s)""",link)
    for row in newer:
        for side in ("home","away"):
            db.execute("INSERT INTO core.teams(id,name) VALUES (%s,%s) ON CONFLICT DO NOTHING",
                       (row[side+"_team_id"],row[side]))
        db.execute("""INSERT INTO core.matches(id,season_id,competition_season_id,match_date,source,status,
           home_team_id,away_team_id,home_team_name,away_team_name,home_score,away_score,archive_position,updated_at)
           VALUES (%(id)s,2026,%(competition_season_id)s,%(match_date)s,'open_matchday','finished',
           %(home_team_id)s,%(away_team_id)s,%(home)s,%(away)s,%(home_score)s,%(away_score)s,10000+%(id)s::int,%(updated_at)s)""",row)
    for table in ("teams","rounds","competitions","competition_seasons"):
        db.execute(sql.SQL("SELECT setval(pg_get_serial_sequence(%s,'id'),(SELECT max(id)+10 FROM {}))")
                   .format(sql.Identifier("core",table)),("core."+table,))


def http(origin,path,etag=None):
    request=Request(origin+path,headers={"If-None-Match":etag} if etag else {})
    try:
        res=urlopen(request,timeout=14)
    except HTTPError as error:
        res=error
    with res:
        body=res.read()
        return {"status":res.status,"etag":res.headers.get("ETag"),"body":json.loads(body) if body else None}


def proof(match_paths,origin,tags=None):
    return {name:http(origin,path,tags[name]["etag"] if tags else None) for name,path in match_paths.items()}


def world_cup(origin):
    receipt={}
    for year,(ident,_,_) in NATIONS.items():
        answer=http(origin,f"/api/nations/{ident}?season=2026%2F2027")
        assert answer["status"]==200,answer
        final_edition,=[r for r in answer["body"]["data"]["tournaments"] if r["year"]==int(year) and r["tournament"]=="world-cup"]
        game=max(final_edition["games"],key=lambda m:m["date"])
        receipt[year]={"score":[game["homeScore"],game["awayScore"]],"status":game["status"],
                       "stage":final_edition["stage"],"games":final_edition["matches"],"etag":answer["etag"]}
    return receipt


def cli(tree,args,env,log,expected=0):
    p=subprocess.run([sys.executable,"-B",*map(str,args)],cwd=tree/"backend",env=env,text=True,capture_output=True,timeout=150)
    log.write_text(p.stdout+p.stderr)
    assert p.returncode==expected,(p.returncode,log.name,p.stderr[-300:])
    return p.stdout


def exercise(case, runtimes, shared):
    name=f"vega_v2_open_matchday_restore_ab{case}{shared['tag']}"
    dsn=shared["db_base"]+name
    out=shared["out"]/case
    out.mkdir()
    with psycopg.connect(shared["db_base"]+"postgres",autocommit=True) as server:
        assert server.info.server_version//10000==18
        server.execute(sql.SQL("CREATE DATABASE {}").format(sql.Identifier(name)))
    before,after=shared["captures"]
    seed,main,candidate=runtimes
    env={**shared["env"],"VEGA_LOCAL_DB":dsn,"V2_MIGRATION_DATABASE_URL":dsn,
         "NODE_OPTIONS":f"--import={shared['preload'].as_uri()}","VEGA_TEST_OPENFOOTBALL":str(shared["fixtures"])}

    def call(tree,argv,log,expected=0):
        return cli(tree,argv,{**env,"PYTHONPATH":str(tree/"backend")},out/(log+".log"),expected)

    def migrate(tree,label):
        call(tree,["-m","vega.migrate"],label)

    def collect(tree,instant,label):
        return json.loads(call(tree,[ROOT/"collect.py",instant.isoformat()],label))

    def restore(label,apply=False,refusal=None,preimage=None,postimage=None):
        pre=preimage or shared["before_path"]
        post=postimage or shared["after_path"]
        argv=["-m","vega.open_matchday_restore","--maintenance",
              "--preimage",pre,"--preimage-sha256",digest(pre.read_bytes()),
              "--postimage",post,"--postimage-sha256",digest(post.read_bytes())]
        output=call(candidate,argv+(["--apply"] if apply else []),label,1 if refusal else 0)
        if refusal:
            assert refusal in (out/(label+".log")).read_text(),label
        return output

    def mondial(tree, mode, label):
        return json.loads(call(tree,[ROOT/"mondial.py",mode,shared["mondial"]],label))
    pre_fjelstul=None

    def runtime_ledger(tree):
        return {p.name:digest(p.read_text(encoding="utf-8").encode()) for p in (tree/"backend/sql").glob("*.sql")
                if "vector_optional" not in p.name}

    def read_ledger():
        return x("SELECT version,encode(checksum,'hex'),applied_at FROM ops.schema_migrations ORDER BY version").fetchall()


    migrate(seed,"migrate-133")
    with psycopg.connect(dsn,autocommit=True) as db:
        with db.transaction():
            seed_observed(db,before,after,shared["newer"],shared["nations"])
        x=db.execute
        ids=[p[0] for p in before["witnesses"]]
        expected_match={m["id"]:m for m in rows(before,"table.core.matches")}
        expected_binding={m["entity_id"]:m for m in rows(before,"table.core.provider_ids")}
        final_fields="id,status::text,home_score,away_score,revision,xmin::text"
        final_query=f"""SELECT m.{final_fields.replace(',',',m.')} FROM core.matches m
          JOIN core.competition_seasons c ON c.id=m.competition_season_id
          WHERE c.cup_key=ANY(%s) AND m.match_date IN ('1982-07-11','1998-07-12') ORDER BY m.match_date"""
        finals=lambda: x(final_query,(list(SCOPES),)).fetchall()
        source_ledger={v:c for v,c,_ in read_ledger()}
        assert max(source_ledger)==OLD and source_ledger==runtime_ledger(seed)
        assert all({v:c for v,c,_ in image["reads"]["migrations"]["rows"]}==source_ledger for image in (before,after))
        assert set(collect(seed,AT,"collect-original")["ran"])==SCOPES
        assert [m[1:4] for m in finals()]==[("not_started",None,None)]*2
        if case=="b":
            migrate(main,"migrate-main-138")
            assert dict((v,c) for v,c,_ in read_ledger())==runtime_ledger(main)
            released_transfers=x("SELECT applied_at FROM ops.schema_migrations WHERE version='135_player_transfers.sql'").fetchone()
            assert released_transfers
            with db.transaction():
                x("SET LOCAL ROLE vega_read")
                x("SELECT from_name, to_id FROM api.player_transfers LIMIT 1").fetchall()
                x("SELECT player_key, read_at FROM api.player_transfer_reads LIMIT 1").fetchall()
            assert x("SELECT count(*) FROM ops.schema_migrations WHERE version=%s",(RESET,)).fetchone()[0]==1
            assert set(collect(main,AT+timedelta(hours=2),"collect-main-134")["ran"])==SCOPES
            assert [m[1:4] for m in finals()]==[("finished",3,1),("finished",0,3)]
            pre_fjelstul=mondial(main,"charge","fjelstul-138-before")
            assert [f[-2:] for f in pre_fjelstul["finales"]]==[[3,1],[0,3]]
            if shared["baseline_only"]:
                item={"status":"baseline-138-confirmed","initial":OLD,"last":read_ledger()[-1][0],"signatures":pre_fjelstul}
                (out/"receipt.json").write_text(json.dumps(item,ensure_ascii=False,indent=2)+"\n")
                return item
        state_before_upgrade=finals()
        read_clock=lambda: dict(x("SELECT scope,last_success_at FROM ops.source_runs WHERE scope=ANY(%s)",(list(SCOPES),)))
        timing_before_upgrade=read_clock()
        main_registered=x("SELECT applied_at FROM ops.schema_migrations WHERE version=%s",(RESET,)).fetchone()
        migrate(candidate,"migrate-candidate")
        post_fjelstul=mondial(candidate, "lecture" if case=="b" else "charge","fjelstul-after-migrate")
        if case=="b":
            assert post_fjelstul["vues_et_tables"]==pre_fjelstul["vues_et_tables"] and post_fjelstul["finales"]==pre_fjelstul["finales"] and post_fjelstul["credit"]==pre_fjelstul["credit"]
        ledger=read_ledger()
        index={v:c for v,c,_ in ledger}
        chronology={v:t for v,_,t in ledger}
        assert index==runtime_ledger(candidate) and ledger[-1][0]==shared["expected_last"]
        assert index[RESET]==shared["main_sha"] and REPAIR in index
        assert all(index[k]==v for k,v in source_ledger.items())
        (out/"verified-ledger.json").write_text(json.dumps({"source":source_ledger,"destination":index},indent=2)+"\n")
        migration_order=[REPAIR,RESET] if case=="a" else [RESET,REPAIR]
        assert chronology[migration_order[0]]<=chronology[migration_order[1]]
        assert read_clock()==({scope:None for scope in SCOPES} if case=="a" else timing_before_upgrade)
        if case=="b":
            assert x("SELECT applied_at FROM ops.schema_migrations WHERE version=%s",(RESET,)).fetchone()==main_registered
            assert x("SELECT applied_at FROM ops.schema_migrations WHERE version='135_player_transfers.sql'").fetchone()==released_transfers
        with db.transaction():
            x("SET LOCAL ROLE vega_read")
            x("SELECT from_name,to_id FROM api.player_transfers LIMIT 1").fetchall()
            x("SELECT player_key,read_at FROM api.player_transfer_reads LIMIT 1").fetchall()
            x("SELECT club_name,club_id,club_image_url FROM api.player_market_values LIMIT 1").fetchall()
            x("SELECT logo_url FROM api.cup_editions LIMIT 1").fetchall()
        ledger_refusals=[]
        for version in dict.fromkeys([REPAIR,RESET,"135_player_transfers.sql","135_cup_competition_logo.sql"]+[n for n in index if n[:4] in ("136_","137_","138_")]+[shared["expected_last"]]):
            old_checksum,old_date=x("SELECT checksum,applied_at FROM ops.schema_migrations WHERE version=%s",(version,)).fetchone()
            for alteration in ("missing","checksum"):
                label=f"refuse-{alteration}-{version[:-4]}"
                if alteration=="missing":
                    x("DELETE FROM ops.schema_migrations WHERE version=%s",(version,))
                else:
                    x("UPDATE ops.schema_migrations SET checksum=%s WHERE version=%s",(bytes(32),version))
                try:
                    restore(label,apply=True,refusal="destination schema mismatch")
                finally:
                    x("INSERT INTO ops.schema_migrations(version,checksum,applied_at) VALUES (%s,%s,%s)"
                      " ON CONFLICT(version) DO UPDATE SET checksum=EXCLUDED.checksum",(version,old_checksum,old_date))
                ledger_refusals.append(label)
        assert read_ledger()==ledger


        def sporting_state():
            identities=dict(x("SELECT id,to_jsonb(m) FROM core.matches m WHERE id=ANY(%s)",(ids,)))
            binding=dict(x("SELECT entity_id,to_jsonb(p) FROM core.provider_ids p WHERE entity_id=ANY(%s) AND entity_type='match'",(ids,)))
            exact=x("""SELECT to_jsonb(e), jsonb_build_object('elo_before',encode(float4send(elo_before),'hex'),
              'elo_after',encode(float4send(elo_after),'hex'),'expected',encode(float4send(expected),'hex'),
              'result',encode(float4send(result),'hex'),'stakes',encode(float4send(stakes),'hex'))
              FROM agg.team_elo e WHERE match_id=ANY(%s) ORDER BY match_id,team_id""",(ids,)).fetchall()
            resources=dict(x("SELECT resource_id,version FROM ops.resource_versions WHERE resource_kind='competition_season' AND resource_id=ANY(%s)",([332,333,334],)))
            sequence=x("SELECT last_value,is_called FROM core.matches_id_seq").fetchone()
            publish=x("SELECT to_jsonb(p) FROM ops.publication p").fetchall()
            return identities,binding,exact,resources,sequence,publish

        match_paths={}
        for stored in rows(before,"parent.matches_competition_season_id_season_id_fkey"):
            folder=stored["cup_key"].split(":")[1]
            match_paths[folder]="/api/cup-table?"+urlencode({"competition":folder,"season":"2026/2027","kind":"results"})
        with (out/"http.log").open("w") as stderr:
            reader=subprocess.Popen(["node",str(ROOT/"serve.mjs"),str(candidate),dsn],stdout=subprocess.PIPE,stderr=stderr,text=True)
            try:
                origin=f"http://127.0.0.1:{int(reader.stdout.readline().strip())}"
                wc_path="/api/worldcup/matches/M-1998-64"
                public_before=http(origin,wc_path)
                assert public_before["status"]==200 and len(public_before["body"]["data"]["lineups"]["home"])==13
                assert public_before["body"]["data"]["score"]==([0,3] if case=="b" else None)
                pre=proof(match_paths,origin)
                assert all(r["status"]==200 for r in pre.values())
                original=sporting_state()
                x("CREATE TABLE core.migration_foreign_text_probe(match_key text)")
                try:
                    restore("refuse-unknown-text-match-key",True,refusal="unreviewed reference type: core.migration_foreign_text_probe.match_key")
                    assert sporting_state()==original
                finally:
                    x("DROP TABLE core.migration_foreign_text_probe")

                assert not original[0] and not original[1] and len(original[2])==70
                dry=json.loads(restore("dry-run"))
                assert dry["would_restore"]==35 and dry["restored"]==0 and sporting_state()==original
                for name,source in (("preimage",before),("postimage",after)):
                    altered=json.loads(json.dumps(source))
                    altered["reads"]["migrations"]["rows"][-1][1]="0"*64
                    tampered=out/(name+"-ledger-tampered.zlib")
                    tampered.write_bytes(zlib.compress(json.dumps(altered).encode()))
                    restore("refuse-"+name+"-ledger",apply=True,refusal="preimage schema mismatch",**{name:tampered})
                assert sporting_state()==original and read_ledger()==ledger
                applied=json.loads(restore("apply",True))
                assert applied["restored"]==35 and applied["preserved_elo"]==70
                restored=sporting_state()
                assert restored[:2]==(expected_match,expected_binding)
                assert restored[2]==original[2] and restored[4:]==original[4:]
                assert set(restored[3])=={332,333,334}
                assert all(restored[3][key]==original[3].get(key,0)+1 for key in restored[3])
                with db.transaction():
                    x("SET LOCAL ROLE vega_read")
                    read_ids=dict(x("SELECT match_id,key FROM api.cup_matches WHERE match_id=ANY(%s)",(ids,)))
                assert read_ids=={id:p["provider_key"] for id,p in expected_binding.items()}
                applied_http=proof(match_paths,origin,pre)
                assert all(r["status"]==200 for r in applied_http.values())
                # A source-owned link on one of these identities appeared since the preimage.
                # Keep it, and refuse the operator mutation even when all 35 parents already exist.
                assert x("UPDATE core.worldcup_matches SET match_id=%s WHERE match_key='M-1930-18' AND match_id IS NULL",(ids[0],)).rowcount==1
                try:
                    restore("refuse-new-worldcup-link",True,refusal="unexpected dependent row in core.worldcup_matches")
                    assert x("SELECT match_id FROM core.worldcup_matches WHERE match_key='M-1930-18'").fetchone()[0]==ids[0]
                    assert sporting_state()==restored
                finally:
                    x("UPDATE core.worldcup_matches SET match_id=NULL WHERE match_key='M-1930-18' AND match_id=%s",(ids[0],))
                again=json.loads(restore("repeat",True))
                assert again["restored"]==again["would_restore"]==0 and sporting_state()==restored
                conditional=proof(match_paths,origin,applied_http)
                assert all(r["status"]==304 for r in conditional.values())

                first=AT+timedelta(hours=4)
                if case=="b":
                    assert not collect(candidate,first,"candidate-not-yet-due")["ran"]
                    first+=timedelta(days=8)
                changed=collect(candidate,first,"candidate-first")
                assert set(changed["ran"])==SCOPES and all(w=="ok" for w in changed["ran"].values())
                recorded=finals()
                assert [m[1:4] for m in recorded]==[("finished",3,1),("finished",0,3)]
                assert [m[0] for m in recorded]==[m[0] for m in state_before_upgrade]
                followup=collect(candidate,first+timedelta(days=8),"candidate-second")
                assert set(followup["ran"])==SCOPES and set(followup["rows_written"].values())=={0} and finals()==recorded
                public_after=http(origin,wc_path)
                assert public_after["status"]==200 and public_after["body"]["data"]["score"]==[0,3]
                assert public_after["body"]["data"]["credit"]==public_before["body"]["data"]["credit"]
                if case=="b":assert public_after==public_before
                else:assert public_after["etag"]!=public_before["etag"]
                fjelstul_http={"avant":{"score":public_before["body"]["data"]["score"],"etag":public_before["etag"]},
                              "apres":{"score":public_after["body"]["data"]["score"],"etag":public_after["etag"]}}
                nations_result=world_cup(origin)
                for year,(_,h,away) in NATIONS.items():
                    assert nations_result[year]["score"]==[h,away] and nations_result[year]["stage"]=="Vainqueur"
                    assert nations_result[year]["games"]==7 and nations_result[year]["status"]=="finished"
                assert sporting_state()[:3]==restored[:3]
            finally:
                reader.terminate()
                reader.wait(timeout=12)
        completed_fjelstul=mondial(candidate,"lecture","fjelstul-after-restore")
        assert [f[-2:] for f in completed_fjelstul["finales"]]==[[3,1],[0,3]]
        if case=="b":
            assert completed_fjelstul["vues_et_tables"]==pre_fjelstul["vues_et_tables"]
        timing=read_clock()
        migrate(candidate,"migrate-repeat")
        assert read_ledger()==ledger
        assert read_clock()==timing
    receipt={"case":case,"initial_schema":OLD if case=="a" else "138_worldcup_match_reads.sql","fjelstul_before":pre_fjelstul,"fjelstul_after_migration":post_fjelstul,"fjelstul_after_restoration":completed_fjelstul,"restoration_cli":applied,"restoration_repeat":again,
             "fjelstul_http":fjelstul_http,"unknown_text_key_rejected":True,"occupied_fjelstul_match_rejected":True,"physical_matches_exact":35,"physical_keys_exact":35,"public_archived_ids":len(read_ids),"elo_rows_and_float_bits_unchanged":70,
             "migration_134_execution_order":migration_order,"schema_pin_refuses_missing_134":True,
             "destination_last_migration":shared["expected_last"],"destination_exact_checksums":len(index),
             "source_exact_checksums":len(source_ledger),"destination_refusals":ledger_refusals,
             "preimage_and_postimage_wrong_133_checksum_refused":True,
             "archive_http_repeat":[r["status"] for r in conditional.values()],
             "finals_before":state_before_upgrade,"finals_after":recorded,"finals_second_zero_writes":True,
             "nations_http":nations_result,"schema_reapply_idempotent":True,"source_success_clocks_stable_on_reapply":True}
    (out/"receipt.json").write_text(json.dumps(receipt,ensure_ascii=False,indent=2)+"\n")
    return receipt


def main():
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--repo",required=True,type=Path)
    parser.add_argument("--revision",required=True)
    parser.add_argument("--evidence",type=Path,help=argparse.SUPPRESS)
    parser.add_argument("--port",type=int,default=55439)
    parser.add_argument("--tag",required=True)
    parser.add_argument("--baseline-only",action="store_true")
    parser.add_argument("--prototype",action="store_true",help="exercise the harness before the merge, without claiming it")
    parser.add_argument("--expected-last",default=LAST,
                        help="source-reviewed destination migration filename; defaults to the candidate A pin")
    args=parser.parse_args()
    repo=args.repo.resolve()
    assert re.fullmatch(r"[a-z0-9]{2,11}",args.tag) and 1<=args.port<=65535
    assert args.expected_last==LAST or re.fullmatch(r"[0-9]{3}_[a-z0-9_]+\.sql",args.expected_last)
    assert not args.prototype or args.expected_last in (LAST,PIN_PROBE)
    def git(*parts):
        return subprocess.check_output(["git","-C",str(repo),*parts])
    revision=git("rev-parse",args.revision+"^{commit}").decode().strip()
    if args.prototype:
        assert revision==HARNESS
    elif not args.baseline_only:
        for required in (MAIN,HARNESS):
            subprocess.run(["git","-C",str(repo),"merge-base","--is-ancestor",required,revision],check=True)
        assert git("show",revision+":backend/sql/"+RESET)==git("show",MAIN+":backend/sql/"+RESET)
    out=ROOT/args.tag
    out.mkdir()
    vault=repo/"docs/audits/2026-11-17/controles/verification-integree/35-matchs-identites-et-elo.zip"
    assert digest(vault.read_bytes())==SEAL
    with ZipFile(vault) as archive:
        contents={k:archive.read(k) for k in ARCHIVE_MEMBERS}
    assert all(digest(v)==ARCHIVE_MEMBERS[key] for key,v in contents.items())
    pre,post=out/"avant.zlib",out/"apres.zlib"
    pre.write_bytes(contents["rds/avant.zlib"])
    post.write_bytes(contents["rds/apres.zlib"])
    archive_source=ROOT/"inputs"
    raw={year:(archive_source/f"world-cup-history-{year}.json").read_bytes() for year in NATIONS}
    fixtures=out/"two-editions.json"
    fixtures.write_text(json.dumps({"editions":{f"world-cup-history:{y}":json.loads(x) for y,x in raw.items()}}))
    preload=out/"openfootball-fetch.mjs"
    preload.write_bytes(git("show",HARNESS+":backend/tests/fake_openfootball_fetch.mjs"))
    nations_path=ROOT/"inputs/rds-target-projection.json"
    deps=repo/"backend/api/node_modules"
    assert (deps/"pg/package.json").exists()
    shared={"baseline_only":args.baseline_only, "mondial":ROOT/"inputs/fjelstul-17.zip", "out":out,"tag":args.tag,"db_base":f"postgresql://postgres@127.0.0.1:{args.port}/",
            "env":{**{k:v for k,v in os.environ.items() if not k.startswith(("V2_","VEGA_","NODE_OPTIONS"))},"PYTHONDONTWRITEBYTECODE":"1"},
            "captures":[json.loads(zlib.decompress(p.read_bytes())) for p in (pre,post)],"before_path":pre,"after_path":post,
            "newer":list(csv.DictReader(contents["rencontres/nouveau.csv"].decode().splitlines())),
            "nations":json.loads(nations_path.read_bytes()),"fixtures":fixtures,"preload":preload,
            "main_sha":digest(git("show",MAIN+":backend/sql/"+RESET)),"expected_last":args.expected_last}
    assert digest(shared["mondial"].read_bytes())=="c46d350337ee9ae4eb8c6172e61e977357179978476cb690c84bd8acb2360255"
    with TemporaryDirectory(prefix="vega-committed-runtime-") as path:
        runtimes=[]
        for label,rev in (("base",BASE),("main",MAIN),("candidate",revision)):
            root=Path(path)/label
            root.mkdir()
            with tarfile.open(fileobj=BytesIO(git("archive",rev,"--",*RUNTIME_PATHS))) as stream:
                stream.extractall(root,filter="data")
            (root/"backend/api/node_modules").symlink_to(deps.resolve(),target_is_directory=True)
            runtimes.append(root)
        if args.prototype:
            (runtimes[-1]/"backend/sql"/RESET).write_bytes(git("show",MAIN+":backend/sql/"+RESET))
            if args.expected_last==PIN_PROBE:
                (runtimes[-1]/"backend/sql"/PIN_PROBE).write_text("-- Isolate the pinned destination version in the RED replay.\nSELECT 1;\n")
        cases={}
        for name in (("b",) if args.baseline_only else ("b","a")):
            try:
                cases[name]=exercise(name,runtimes,shared)
            except Exception as error:
                import traceback
                (out/name/"failure.log").write_text(traceback.format_exc())
                cases[name]={"error":type(error).__name__,"message":str(error)}
        if any("error" in v for v in cases.values()):
            (out/"failures.json").write_text(json.dumps(cases,default=str,indent=2))
            raise RuntimeError(str({name:v for name,v in cases.items() if "error" in v}))
    receipt={"status":"baseline-only" if args.baseline_only else "passed","prototype":args.prototype,"tested_revision":revision,"runtime_mode":"read-only Git archive",
             "base":BASE,"main":MAIN,"expected_last":args.expected_last,"inputs":{**ARCHIVE_MEMBERS,"main_mailbox_migration_sha256":shared["main_sha"],
                     "nation_identity_projection":digest(nations_path.read_bytes()),
                     **{f"world_cup_{year}":digest(body) for year,body in raw.items()}},"cases":cases}
    (out/"receipt.json").write_text(json.dumps(receipt,ensure_ascii=False,indent=2)+"\n")
    print(json.dumps({"passed":True,"prototype":args.prototype,"tested_revision":revision,"receipts":str(out/"receipt.json")}))


if __name__=="__main__":
    main()
