"""Vérifie toutes les pièces scellées et les résultats attendus sans installer de dépendances."""
import collections,hashlib,json,sys
from pathlib import Path
root=Path(__file__).resolve().parent
def check(v,m):
    if not v:sys.exit(m)
def read(p):return json.loads((root/p).read_bytes())
expected=read('manifest-sha256.json')
inventory={p.relative_to(root).as_posix() for p in root.rglob('*') if p.is_file()}
check(inventory==set(expected)|{'manifest-sha256.json'},'inventaire divergent')
for n,h in expected.items():
    check(not (root/n).is_symlink() and hashlib.sha256((root/n).read_bytes()).hexdigest()==h,'fichier altéré : '+n)
r=read('observations/schema-et-2097.json');summary=read('observations/double-publication.json')
check(summary['revision']==r['tested_revision'] and summary['statut']=='PASS','révision divergente')
for case,end in [('a','133'),('b','138')]:
    c=r['cases'][case];p=read('observations/2099-apres-'+end+'.json')['cases']
    check(c['occupied_fjelstul_match_rejected'] and c['unknown_text_key_rejected'] and len(c['destination_refusals'])>=22,'témoins négatifs')
    check(c['physical_matches_exact']==c['physical_keys_exact']==35 and c['elo_rows_and_float_bits_unchanged']==70,'identités et Elo 2097')
    check(c['restoration_repeat']['restored']==0 and c['schema_reapply_idempotent'] and c['archive_http_repeat']==[304,304,304],'idempotence ou ETag')
    check(p['latest-apply']['report']['restored']==35 and p['latest-apply']['report']['elo_pending_sides']==70 and p['latest-repeat']['report']['restored']==0,'état 2099')
    final=c['fjelstul_after_restoration']['vues_et_tables']
    check(sum(v[0] for n,v in final.items() if n.startswith('core.'))==75669 and final['api.worldcup_match_heads'][0]==116,'Fjelstul')
    if case=='b':check(final==c['fjelstul_before']['vues_et_tables'],'signatures Mondial 138')
print('PASS '+r['tested_revision']+' : 133/138, 35 identités, 70 côtés, 2097/2099, cinq vues et témoins négatifs.')
