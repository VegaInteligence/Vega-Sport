"""Charge localement les CSV authentiques ou signe les vues du lecteur sans écriture."""
import datetime,hashlib,json,os,sys,zipfile
from pathlib import Path
from psycopg import sql
from vega.store import connect_local
from vega.sources import worldcup
mode,archive=sys.argv[1:]; assert mode in ('charge','lecture')
def digest(x):return hashlib.sha256(x).hexdigest()
with connect_local(os.environ['VEGA_LOCAL_DB']) as db:
    if mode=='charge':
        with zipfile.ZipFile(archive) as z:
            meta=json.loads(z.read('diff/rejeu/index.json'))
            def get(url,*,as_text):
                k=meta[url];b=z.read('diff/rejeu/'+k['file']);assert as_text and digest(b)==k['sha256'];return b.decode()
            with db.transaction():
                db.execute('SET LOCAL ROLE vega_collect')
                result=worldcup.run(db,get,'worldcup',datetime.datetime(2026,11,18,20,tzinfo=datetime.timezone.utc))
    else:result=None
    counts={}
    with db.transaction():
        tables=['core.worldcup_'+kind for kind in worldcup.TABLES]
        for table in tables:
            rows=db.execute(sql.SQL("SELECT count(*),md5(coalesce(string_agg(to_jsonb(t)::text,E'\\n' ORDER BY to_jsonb(t)::text COLLATE \"C\"),'')) FROM {} t").format(sql.Identifier(*table.split('.')))).fetchone()
            counts[table]=rows
        db.execute('SET LOCAL ROLE vega_read')
        for table in ('worldcup_match_index','worldcup_match_heads','worldcup_match_people','worldcup_match_events','worldcup_match_kicks'):
            rows=db.execute(sql.SQL("SELECT count(*),md5(coalesce(string_agg(to_jsonb(t)::text,E'\\n' ORDER BY to_jsonb(t)::text COLLATE \"C\"),'')) FROM api.{} t").format(sql.Identifier(table))).fetchone()
            counts['api.'+table]=rows
        finals=db.execute("SELECT key, home, away, home_score, away_score FROM api.worldcup_match_heads WHERE key IN ('M-1982-52','M-1998-64') ORDER BY key").fetchall()
        credit=db.execute("SELECT name,url,license FROM api.source_revisions WHERE source='fjelstul-worldcup'").fetchone()
    assert sum(v[0] for k,v in counts.items() if k.startswith('core.'))==75669
    assert counts['api.worldcup_match_index'][0]==counts['api.worldcup_match_heads'][0]==116 and len(finals)==2 and credit
    if mode=='charge':assert result[0] in (0,75669) and result[1]==848,result
print(json.dumps({'role_lectures':'vega_read','vues_et_tables':counts,'finales':finals,'credit':credit,'chargement':result},ensure_ascii=False))
