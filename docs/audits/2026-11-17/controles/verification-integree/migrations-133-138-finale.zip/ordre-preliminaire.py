"""Applique les seules migrations 34ca sur une copie du 138, avant la fusion des programmes."""
import hashlib,io,json,os,pathlib,subprocess,sys,tarfile,tempfile
import psycopg
from psycopg import sql
from pathlib import Path
repo=Path(sys.argv[1]);port=int(sys.argv[2]);template=sys.argv[3];target=sys.argv[4]
assert target.startswith('vega_v2_open_matchday_restore_') and template.startswith('vega_v2_open_matchday_restore_')
dsn='postgresql://postgres@127.0.0.1:'+str(port)+'/'
branch=sys.argv[5] if len(sys.argv)>5 else '34ca3b5b382d7a6a06da9d051170096ba1d700e8'; main='202f24c09eb4c8fb87d7190939bafbf09cb00393'
with psycopg.connect(dsn+'postgres',autocommit=True) as db:
 assert db.info.server_version//10000==18
 db.execute(sql.SQL('CREATE DATABASE {} TEMPLATE {}').format(sql.Identifier(target),sql.Identifier(template)))
with tempfile.TemporaryDirectory() as tmp:
 def src(rev):
  p=Path(tmp)/rev;p.mkdir()
  with tarfile.open(fileobj=io.BytesIO(subprocess.check_output(['git','-C',str(repo),'archive',rev,'--','backend/vega','backend/sql']))) as tf:tf.extractall(p,filter='data')
  return p/'backend'
 a,b=src(main),src(branch)
 def run(path,cmd):
  env={k:v for k,v in os.environ.items() if not k.startswith(('V2_','VEGA_'))}
  env.update(PYTHONPATH=str(path),PYTHONDONTWRITEBYTECODE='1',VEGA_LOCAL_DB=dsn+target,V2_MIGRATION_DATABASE_URL=dsn+target)
  return subprocess.check_output([sys.executable,'-B']+cmd,cwd=path,text=True,env=env)
 def sig():return json.loads(run(a,[str(Path(__file__).resolve().parent/'mondial.py'),'lecture','unused']))
 def ledg():
  with psycopg.connect(dsn+target) as db:return {n:[h,str(t)] for n,h,t in db.execute("SELECT version,encode(checksum,'hex'),applied_at FROM ops.schema_migrations ORDER BY 1")}
 pre,ledger=sig(),ledg();migr=run(b,['-m','vega.migrate']);post,new=sig(),ledg()
 assert pre==post and all(new[n]==v for n,v in ledger.items()) and len(new)>len(ledger)
 hashes={q.name:hashlib.sha256(q.read_bytes()).hexdigest() for path in (a,b) for q in (path/'sql').glob('*.sql') if 'vector_optional' not in q.name}
 assert {n:v[0] for n,v in new.items()}==hashes
 print(json.dumps({'portee':'ordre exact des migrations et signatures de données, identités et HTTP couverts par le reçu du CLI séparé','main':main,'branche':branch,'message_migrateur':migr.strip(),'nombre_fichiers_138':len(ledger),'nombre_fichiers_apres':len(new),'ajoutes':sorted(set(new)-set(ledger)),'doubles_prefixes':[n for n in new if n[:3] in ('136','137','138')],'signatures_avant':pre,'signatures_apres':post,'historique_empreintes_et_dates_conserve':True},ensure_ascii=False,indent=2))
