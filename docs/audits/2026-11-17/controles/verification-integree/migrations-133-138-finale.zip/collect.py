"""Run the shipped collection on the two frozen OpenFootball scopes."""
from datetime import datetime, timedelta
import json
import os
import sys
from unittest.mock import patch

from vega import sources
from vega.sources import cups
from vega.store import connect_local


scopes={f"open-cups:world-cup-history:{year}":timedelta(days=7) for year in (1982,1998)}
with connect_local(os.environ["VEGA_LOCAL_DB"]) as db:
    with db.transaction(), patch.object(cups,"scopes",lambda instant:scopes):
        db.execute("SET LOCAL ROLE vega_collect")
        result=sources.run_due(db,None,datetime.fromisoformat(sys.argv[1]),names={"openfootball"})
    assert all(status=="ok" for status in result.values()), result
    facts=dict(db.execute("SELECT scope,rows_written FROM ops.source_runs WHERE source='openfootball'"))
    print(json.dumps({"ran":{scope:status for (_,scope),status in result.items()},"rows_written":facts}))
