"""E2E for the standard operator configuration and a fully superseded Elo snapshot."""
import argparse
from hashlib import sha256
import json
import os
from pathlib import Path
import re
import subprocess
import sys
import zlib

import psycopg
from psycopg import sql
from psycopg.types.json import Jsonb

q=Path(__file__).resolve().parent
e=q.parents[2]
p=argparse.ArgumentParser()
p.add_argument("tree",type=Path)
p.add_argument("tag")
p.add_argument("--red",action="store_true")
p.add_argument("--template",default="realthree")
p.add_argument("--capture-dir",type=Path,required=True)
a=p.parse_args()
assert all(re.fullmatch(r"[a-z0-9]+",x) for x in (a.tag,a.template))
out=q/a.tag
out.mkdir()
pre=a.capture_dir/"avant.zlib"
post=a.capture_dir/"apres.zlib"
caps=json.loads(zlib.decompress(post.read_bytes()))
ids=[r[0] for r in caps["witnesses"]]
legacy=[json.loads(r) for r in caps["reads"]["table.agg.team_elo"]["rows_json"]]
name="vega_v2_open_matchday_restore_"+a.tag
base=f"postgresql://postgres@127.0.0.1:{int(os.environ.get('OPEN_MATCHDAY_REPLAY_PORT','55439'))}/"
dsn=base+name
env={k:v for k,v in os.environ.items() if not (k.startswith("V2_MIGRATION_") or k.startswith("V2_DB_"))}
env.update(PYTHONPATH=str(a.tree/"backend"),PYTHONDONTWRITEBYTECODE="1")
command=[sys.executable,"-m","vega.open_matchday_restore","--maintenance",
         "--preimage",str(pre),"--preimage-sha256",sha256(pre.read_bytes()).hexdigest(),
         "--postimage",str(post),"--postimage-sha256",sha256(post.read_bytes()).hexdigest()]
results={}
def run(case, connected, apply=False, error=None):
    process=subprocess.run(command+(["--apply"] if apply else []),cwd=a.tree/"backend",
        env={**env,**({"V2_MIGRATION_DATABASE_URL":dsn} if connected else {})},text=True,capture_output=True,timeout=40)
    (out/(case+".stdout")).write_text(process.stdout)
    (out/(case+".stderr")).write_text(process.stderr)
    results[case]={"returncode":process.returncode,"mode":"apply" if apply else "dry-run","operator_configured":connected}
    if error:
        assert process.returncode and error in process.stderr,(case,process.stderr)
        return None
    assert process.returncode==0,(case,process.stderr)
    results[case]["report"]=json.loads(process.stdout)
    return results[case]["report"]

if a.red:
    run("entry",False,error="--dsn")
else:
    run("missing-config",False,error="V2_MIGRATION_DATABASE_URL")
    with psycopg.connect(base+"postgres",autocommit=True) as ctl:
        ctl.execute(sql.SQL("CREATE DATABASE {} TEMPLATE {}").format(sql.Identifier(name),sql.Identifier("vega_v2_open_matchday_restore_"+a.template)))
    with psycopg.connect(dsn,autocommit=True) as db:
        db.execute("DELETE FROM core.provider_ids WHERE entity_type='match' AND entity_id=ANY(%s)",(ids,))
        db.execute("DELETE FROM core.matches WHERE id=ANY(%s)",(ids,))
        assert run("owner-path-dry-run",True)["preserved_elo"]==70
        # Model representation of an atomic publication. No Elo formula or worker
        # is run, and all dummy rows are on an unrelated test fixture.
        with db.transaction():
            db.execute("SET LOCAL ROLE vega_calc")
            db.execute("UPDATE agg.power_runs SET status='superseded' WHERE id=2097")
            db.execute("DELETE FROM agg.team_elo")
            db.execute("INSERT INTO agg.power_runs(id,kind,method_version,status,started_at,finished_at,matches) VALUES (2099,'elo','power-ranking-v8','published','2026-11-18T17:15:34.917412+00','2026-11-18T17:16:04.503585+00',1)")
            db.execute("""INSERT INTO agg.team_elo(match_id,team_id,season_id,elo_before,elo_after,expected,result,run_id)
                SELECT m.id,t,2026,1200,1200,.5,.5,2099 FROM core.matches m CROSS JOIN LATERAL
                unnest(ARRAY[m.home_team_id,m.away_team_id]) t WHERE m.id=8173""")
        db.execute("INSERT INTO agg.team_elo SELECT * FROM jsonb_populate_record(NULL::agg.team_elo,%s)",(Jsonb(legacy[0]),))
        run("mixed-floats",True,apply=True,error="Elo")
        db.execute("DELETE FROM agg.team_elo WHERE run_id=2097")
        db.execute("UPDATE agg.power_runs SET matches=2 WHERE id=2099")
        run("incomplete-published-run",True,apply=True,error="Elo")
        db.execute("UPDATE agg.power_runs SET matches=1 WHERE id=2099")
        assert db.execute("SELECT count(*) FROM core.matches WHERE id=ANY(%s)",(ids,)).fetchone()[0]==0
        pending=run("latest-dry",True)
        assert pending["would_restore"]==35 and pending["elo_pending_sides"]==70 and pending["elo_run"]==2099 and pending["preserved_elo"]==0
        known_elo=db.execute("SELECT row_to_json(e)::text FROM agg.team_elo e ORDER BY match_id,team_id").fetchall()
        applied=run("latest-apply",True,apply=True)
        assert applied["restored"]==35 and applied["elo_pending_sides"]==70 and applied["preserved_elo"]==0
        assert db.execute("SELECT row_to_json(e)::text FROM agg.team_elo e ORDER BY match_id,team_id").fetchall()==known_elo
        assert run("latest-repeat",True,apply=True)["restored"]==0
        assert db.execute("SELECT count(*) FROM core.matches WHERE id=ANY(%s)",(ids,)).fetchone()[0]==35
(out/"receipt.json").write_text(json.dumps({"status":"red" if a.red else "passed","local_database":name,"cases":results},indent=2)+"\n")
print("red" if a.red else "passed")
