# Migration du candidat 4c413029 et restauration de 35 matchs

**PASS sur la copie locale du commit 4c413029c173e96704f4752f843f186526e114cf.** Les deux chemins de migration aboutissent aux 156 noms et empreintes attendus, y compris les six fichiers de préfixes 136–138, jusqu’au fichier 151_snapshot_match_ownership.sql. Sous 2097, les 35 identités et 35 clés sont restaurées avec conservation stricte des 70 côtés Elo existants. Sous le témoin représentatif 2099, les 35 identités sont restaurées, les 70 côtés restent à recalculer, et les lignes Elo de la nouvelle publication restent identiques. [Deux chemins et 2097](observations/schema-et-2097.json) · [2099 après 133](observations/2099-apres-133.json) · [2099 après 138](observations/2099-apres-138.json)

| État initial | Vue de la finale 1998 avant → après | Lectures et contrôles |
|---|---|---|
| Schéma 133, entrée historique OpenFootball | Score absent → 0–3, ETag différent | Les 116 paires des deux éditions sélectionnées et les compositions de la finale restent lisibles. |
| Schéma officiel 138 du commit 202f24c09eb4c8fb87d7190939bafbf09cb00393 | 0–3 → 0–3, même ETag | Les 75 669 lignes typées Fjelstul et les valeurs des cinq vues lisibles sous vega_read ont les mêmes signatures avant/après la migration et la restauration. |

Chaque chemin refuse **22 corruptions du registre de migrations** (ligne absente ou empreinte altérée), les deux captures de restauration lorsque leur historique 133 est falsifié, une nouvelle clé texte inconnue et une FK Fjelstul apparue sur un match restauré. La seconde restauration écrit zéro ligne. Les lectures des trois éditions répondent 304 avec l’ETag de leur état restauré. La copie des 35 matchs reproduit les entrées RDS scellées. Le témoin de publication 2099 reprend le run et ses horodatages sur un autre match, contrôle l’intégrité de la publication et s’assure qu’aucune note n’est fabriquée. Un mélange de deux runs et un run incomplet sont refusés. Ceci ne mesure pas un recalcul de l’Elo en production.

## Vérifier et reproduire

À la racine de l’extraction, cette commande vérifie les pièces scellées.

```sh
python3 -I -B verifier.py
```

Le manifeste contrôle intégralement les scripts, les entrées et les observations. Pour le rejeu intégral, préparer une instance **PostgreSQL 18 jetable** réservée à cet essai, accessible sous l’utilisateur de test postgres sur 127.0.0.1. Les deux scripts refusent les destinations externes. Le rejeu nécessite Python 3.12 ou plus récent avec psycopg 3, Node et Git, une copie autorisée du dépôt contenant la révision auditée et ses ancêtres, et les dépendances du lecteur déjà installées dans backend/api/node_modules. Ces commandes créent une instance Docker locale dédiée.

```sh
docker run --rm -d --name vega-migration-4c413-test -e POSTGRES_HOST_AUTH_METHOD=trust --tmpfs /var/lib/postgresql -p 127.0.0.1::5432 pgvector/pgvector:pg18
docker exec vega-migration-4c413-test pg_isready
VEGA_PORT=$(docker port vega-migration-4c413-test 5432/tcp | cut -d: -f2)
python3 -B candidat.py --repo "$VEGA_REPO" --revision 4c413029c173e96704f4752f843f186526e114cf --port "$VEGA_PORT" --tag rejoue1
docker stop vega-migration-4c413-test
```

VEGA_REPO désigne la copie Git de votre choix. Le seul complément documentaire lu dans ce dépôt est **docs/audits/2026-11-17/controles/verification-integree/35-matchs-identites-et-elo.zip**, SHA-256 db35bdf6cc5f7799cb679a8160c096a49c6bd8475130ad3895709c0fd06c0f6b. L’archive fournit les pré et post-images des identités, et le fichier des nouveaux résultats. Les autres entrées nécessaires figurent ici, notamment les deux éditions OpenFootball, la projection de leurs parents et les 17 CSV Fjelstul. Les programmes exécutés sont lus par git archive sur trois SHA. La restauration cible exclusivement les bases créées par le harnais. Une nouvelle exécution nécessite un tag alphanumérique neuf de 2 à 8 caractères.

La vérification supplémentaire au départ du schéma 138 a comparé les dates d’application et les empreintes des 138 fichiers existants, ainsi que les signatures de toutes les tables et vues Fjelstul. [Reçu chronologique](observations/ordre-138.json)

Pour revalider un correctif d’intégration ultérieur, remplacer **--revision** par son SHA complet et utiliser un tag neuf. Le harnais lit le vrai dernier fichier SQL du commit, exige les ancêtres prévus, compare toutes les empreintes de destination aux fichiers de ce SHA, et rejoue les deux schémas et deux publications, avec les contrôles négatifs. Un nouveau PASS a son propre reçu. Le résultat 4c413029 reste attribué à cette seule révision.

Les observations numériques de table sont des décomptes et des signatures MD5 de la sérialisation JSONB triée de la totalité des lignes, avant/après, en UTF-8. Le manifeste et les empreintes des migrations/fichiers utilisent SHA-256. Les 116 matchs liés sont ceux des seules éditions 1982 et 1998 choisies. Les vues des personnes, événements et tirs au but contiennent des lignes de toute la source. Le détail HTTP requiert une tête effectivement appariée.

Les CSV originaux proviennent de **The Fjelstul World Cup Database, © 2023 Joshua C. Fjelstul, Ph.D.**, au commit 35a8667f518b07469182ae16d35574dd0e7a00fb. Leurs octets sont conservés, puis typés et rapprochés des matchs des deux éditions au cours du rejeu. Les données Fjelstul et tableaux adaptés sont distribués sous CC BY-SA 4.0. Les données d’audit Vega sont destinées aux personnes autorisées à accéder à ce dépôt. [Dépôt Fjelstul épinglé](https://github.com/jfjelstul/worldcup/tree/35a8667f518b07469182ae16d35574dd0e7a00fb) · [Licence](https://creativecommons.org/licenses/by-sa/4.0/legalcode)
