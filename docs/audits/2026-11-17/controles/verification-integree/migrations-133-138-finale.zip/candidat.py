"""Teste le commit exact désigné, migrations historiques et deux publications Elo."""
import argparse,hashlib,io,json,os,re,subprocess,sys,tarfile,tempfile
from pathlib import Path
root=Path(__file__).resolve().parent
p=argparse.ArgumentParser()
p.add_argument('--repo',type=Path,required=True);p.add_argument('--evidence',type=Path,help=argparse.SUPPRESS);p.add_argument('--revision',required=True);p.add_argument('--port',type=int,required=True);p.add_argument('--tag',required=True)
a=p.parse_args(); assert re.fullmatch('[a-z0-9]{2,8}',a.tag)
repo=a.repo.resolve();git=['git','-C',str(repo)];rev=subprocess.check_output(git+['rev-parse',a.revision+'^{commit}'],text=True).strip()
files=subprocess.check_output(git+['ls-tree','-r','--name-only',rev,'backend/sql'],text=True).splitlines();last=Path(max(f for f in files if f.endswith('.sql'))).name
assert re.fullmatch(r'[0-9]{3}_[a-z0-9_]+\.sql',last)
env={**os.environ,'PYTHONDONTWRITEBYTECODE':'1','OPEN_MATCHDAY_REPLAY_PORT':str(a.port)}
call=[sys.executable,'-B',str(root/'exercise.py'),'--repo',str(repo),'--revision',rev,'--port',str(a.port),'--tag',a.tag,'--expected-last',last]
with (root/(a.tag+'.log')).open('w') as f:proc=subprocess.run(call,stdout=f,stderr=subprocess.STDOUT,env=env)
if proc.returncode:sys.exit(proc.returncode)
checks={}
with tempfile.TemporaryDirectory() as tmp:
    with tarfile.open(fileobj=io.BytesIO(subprocess.check_output(git+['archive',rev,'--','backend/vega','backend/sql']))) as tf:tf.extractall(tmp,filter='data')
    for case in 'ab':
        label='n'+case+a.tag; template='ab'+case+a.tag
        with (root/(label+'.log')).open('w') as f:
            subprocess.run([sys.executable,'-B',str(root/'newer-publication.py'),tmp,label,'--template',template,'--capture-dir',str(root/a.tag)],env=env,stdout=f,stderr=subprocess.STDOUT,check=True)
        checks[case]=json.loads((root/label/'receipt.json').read_bytes())
r=json.loads((root/a.tag/'receipt.json').read_bytes())
def hashs(p):return hashlib.sha256(p.read_bytes()).hexdigest()
result={'revision':rev,'schema_cible':last,'historiques':[r['cases'][k]['initial_schema'] for k in ('a','b')],'preuve_2097':hashs(root/a.tag/'receipt.json'),'preuves_2099':{k:hashs(root/('n'+k+a.tag)/'receipt.json') for k in 'ab'},'applications_2099':{k:checks[k]['cases']['latest-apply']['report'] for k in 'ab'},'statut':'PASS'}
(root/a.tag/'double-publication.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result))
