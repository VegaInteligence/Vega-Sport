WITH model AS MATERIALIZED (
  SELECT id,fitted_at FROM agg.xg_models
  ORDER BY fitted_at DESC,id DESC LIMIT 1
), fixture AS MATERIALIZED (
  SELECT m.season_id,m.id,m.source::text,m.status::text,m.kickoff_at,m.match_date,m.first_finished_at,
         m.date_unverified,c.shots::text AS coverage,x.id AS model_id,x.fitted_at
  FROM core.matches m CROSS JOIN model x
  LEFT JOIN core.match_coverage c ON c.season_id=m.season_id AND c.match_id=m.id
  WHERE m.season_id BETWEEN extract(year from x.fitted_at AT TIME ZONE 'UTC')::int-1
                        AND extract(year from transaction_timestamp() AT TIME ZONE 'UTC')::int
    AND m.match_date BETWEEN greatest((x.fitted_at AT TIME ZONE 'UTC')::date-1,(transaction_timestamp() AT TIME ZONE 'UTC')::date-45)
                         AND (transaction_timestamp() AT TIME ZONE 'UTC')::date+1
), per_match AS (
  SELECT f.season_id,f.id,f.source,f.status,
    CASE WHEN f.kickoff_at IS NULL THEN 'kickoff_unknown'
         WHEN f.kickoff_at > transaction_timestamp() THEN 'future_kickoff'
         WHEN f.kickoff_at > f.fitted_at AND f.date_unverified IS NOT TRUE
              AND f.match_date BETWEEN (f.kickoff_at AT TIME ZONE 'UTC')::date-1 AND (f.kickoff_at AT TIME ZONE 'UTC')::date+1 THEN 'after_fit_verified_kickoff'
         WHEN f.kickoff_at > f.fitted_at THEN 'after_fit_unverified_date'
         WHEN f.first_finished_at > f.fitted_at THEN 'older_kickoff_later_finished_record'
         ELSE 'at_or_before_fit' END AS timing,
    coalesce(f.coverage,'missing') AS coverage,
    count(s.shot_no) AS shots,
    count(s.shot_no) FILTER (WHERE s.outcome IS NOT NULL AND s.is_own_goal IS NOT TRUE AND s.x BETWEEN 0 AND 105 AND s.y BETWEEN 0 AND 68) AS eligible,
    count(s.shot_no) FILTER (WHERE s.outcome IS NOT NULL AND s.is_own_goal IS NOT TRUE AND s.x BETWEEN 0 AND 105 AND s.y BETWEEN 0 AND 68 AND s.situation IS DISTINCT FROM 'penalty') AS npxg_eligible,
    count(s.shot_no) FILTER (WHERE s.outcome IS NOT NULL AND s.is_own_goal IS NOT TRUE AND s.x BETWEEN 0 AND 105 AND s.y BETWEEN 0 AND 68 AND s.situation IS DISTINCT FROM 'penalty' AND power(105-s.x,2)+power(34-s.y,2)>=1225) AS npxg_35m,
    count(v.shot_no) FILTER (WHERE v.model_id=f.model_id) AS scores_latest,
    count(v.shot_no) FILTER (WHERE v.model_id<>f.model_id) AS scores_other,
    count(s.shot_no) FILTER (WHERE s.updated_at>f.fitted_at) AS updated_after_fit,
    min(f.kickoff_at) kickoff
  FROM fixture f
  LEFT JOIN core.shots s ON (s.season_id,s.match_id)=(f.season_id,f.id)
  LEFT JOIN agg.shot_xg v ON (v.season_id,v.match_id,v.shot_no)=(s.season_id,s.match_id,s.shot_no)
  GROUP BY 1,2,3,4,5,6
)
SELECT timing,source,status,coverage,count(*) AS fixtures,count(*) FILTER (WHERE shots>0) AS fixtures_with_shots,
    sum(shots)::bigint AS shots,sum(eligible)::bigint AS eligible,sum(npxg_eligible)::bigint AS npxg_eligible,sum(npxg_35m)::bigint AS npxg_35m,
    sum(scores_latest)::bigint AS scores_latest,sum(scores_other)::bigint AS scores_other,
    sum(updated_after_fit)::bigint AS updated_after_fit,min(kickoff) AS first_kickoff,max(kickoff) AS last_kickoff
FROM per_match GROUP BY 1,2,3,4 ORDER BY 1,2,3,4
