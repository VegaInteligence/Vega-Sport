# A16a · Mise à jour pour le rapport

Le xG de production `xg-v2` n°5 est repris exactement par le code du worker observé. Première fenêtre vérifiable après la borne du fit, un match de Saudi First Division. Sur 24 tirs hors penalty, 5 buts contre 3,337 attendus et un Brier de 0,1194. À 35 m et plus, un tir valant 0,00985 xG, aucun but. Ces chiffres ne permettent pas d’estimer la calibration de production avec une incertitude défendable. A16a reste partiel. [Reçu, données et rejeu](RECEIPT.md)
