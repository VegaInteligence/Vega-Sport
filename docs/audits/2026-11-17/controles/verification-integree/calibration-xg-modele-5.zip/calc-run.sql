SELECT id,kind::text,model_version,data_revision,cohort_definition,cutoff_at,started_at,finished_at,status::text
FROM agg.calc_runs WHERE model_version IN (SELECT version FROM agg.xg_models)
ORDER BY started_at DESC,id DESC LIMIT 25
