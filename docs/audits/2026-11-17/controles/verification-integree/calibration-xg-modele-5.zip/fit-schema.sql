SELECT table_schema, table_name, column_name, column_default
FROM information_schema.columns
WHERE (table_schema, table_name) IN (('agg','xg_models'),('agg','shot_xg'),('core','shots'))
ORDER BY 1,2,ordinal_position
