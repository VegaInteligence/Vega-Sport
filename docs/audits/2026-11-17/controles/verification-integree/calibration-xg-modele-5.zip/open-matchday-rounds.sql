SELECT source::text,status::text,count(*) AS rows,count(round_id) AS rounds
FROM core.matches WHERE source='open_matchday'
GROUP BY 1,2 ORDER BY 1,2
