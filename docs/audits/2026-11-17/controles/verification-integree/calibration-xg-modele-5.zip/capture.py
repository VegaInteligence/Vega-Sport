"""Run bounded read-only SQL in the approved temporary ECS audit definition with existing roles."""
import base64,hashlib,json,subprocess,time,zlib
from pathlib import Path

HERE=Path(__file__).resolve().parent
WORKER="vega-v2-worker"
CLUSTER="vega-v2"
PROFILE="statarena"
REGION="us-east-2"
DEFINITION="vega-v2-diagnose"
QUERIES=("model","fit-schema","calc-run","open-matchday-rounds","exposition","coverage","postfit-shots")
def sha(body):return hashlib.sha256(body).hexdigest()
def write(name, obj):(HERE/name).write_text(json.dumps(obj,ensure_ascii=False,indent=2)+"\n")
def aws(*args):
    cmd=['aws','--profile',PROFILE,'--region',REGION,'--no-cli-pager','--output','json',*args]
    p=subprocess.run(cmd,stdout=subprocess.PIPE,stderr=subprocess.PIPE,check=False)
    if p.returncode:
        error=p.stderr.decode(errors='replace')
        # Avoid CLI diagnostics containing command inputs. Retain the AWS error class only.
        category=error.split('An error occurred (',1)[-1].split(')',1)[0] if 'An error occurred (' in error else 'cli error'
        raise RuntimeError(f'{args[0]} {args[1]} failed: {category}')
    return json.loads(p.stdout)

def worker():
    svc=aws('ecs','describe-services','--cluster',CLUSTER,'--services',WORKER)['services'][0]
    ids=aws('ecs','list-tasks','--cluster',CLUSTER,'--service-name',WORKER,'--desired-status','RUNNING')['taskArns']
    tasks=aws('ecs','describe-tasks','--cluster',CLUSTER,'--tasks',*ids)['tasks']
    live,=[t for t in tasks if t['lastStatus']=='RUNNING' and t['taskDefinitionArn']==svc['taskDefinition']]
    runtime=next(c for c in live['containers'] if c['lastStatus']=='RUNNING')
    return svc,{'task':live['taskArn'],'definition':live['taskDefinitionArn'],'started':live['startedAt'],'image':runtime['image'],'image_digest':runtime['imageDigest']}

def main():
    plan={q:(HERE/f'{q}.sql').read_text().strip() for q in QUERIES}
    packed=base64.b64encode(zlib.compress(json.dumps(plan,separators=(',',':')).encode(),9)).decode()
    code=(HERE/'probe-template.py').read_text().replace('PAYLOAD',repr(packed))
    compile(code,'<vega-xg-audit>','exec')
    (HERE/'probe.executed.py').write_text(code)
    service, before=worker()
    diag=aws('ecs','describe-task-definition','--task-definition',DEFINITION)['taskDefinition']
    container,=diag['containerDefinitions']
    assert diag['status']=='ACTIVE' and container.get('entryPoint')==['python','-c']
    assert 'V2_DB_PASSWORD' in {s['name'] for s in container.get('secrets',[])}
    override=json.dumps({'containerOverrides':[{'name':container['name'],'command':[code]}]},separators=(',',':'))
    assert len(override)<8192
    receipt={'worker_before':before,'diagnostic_existing_definition':diag['taskDefinitionArn'],'container_image':container['image'],'query_sha256':{k:sha(v.encode()) for k,v in plan.items()},'probe_sha256':sha(code.encode()),'override_bytes':len(override),'read_only':True}
    write('receipt.json',receipt)
    allowed=('networkMode','taskRoleArn','executionRoleArn','containerDefinitions','volumes','placementConstraints',
             'requiresCompatibilities','cpu','memory','runtimePlatform','ephemeralStorage')
    definition_input={k:diag[k] for k in allowed if k in diag}
    definition_input['family']='vega-audit-readonly-vi27'
    # Force the small audited program to be the only command and pull the running worker's immutable image.
    container['image']=before['image'].rsplit(':',1)[0]+'@'+before['image_digest']
    container['command']=[code]
    assert definition_input.get('taskRoleArn')==diag.get('taskRoleArn') and definition_input['executionRoleArn']==diag['executionRoleArn']
    definition=aws('ecs','register-task-definition','--cli-input-json',json.dumps(definition_input))['taskDefinition']['taskDefinitionArn']
    receipt.update(temporary_definition=definition,container_image=container['image'],existing_roles_preserved=True)
    write('receipt.json',receipt)
    try:
        observe(service,before,definition,container,receipt)
    finally:
        receipt['definition_end_state']=aws('ecs','deregister-task-definition','--task-definition',definition)['taskDefinition']['status']
        write('receipt.json',receipt)

def observe(service,before,definition,container,receipt):
    launched=aws('ecs','run-task','--cluster',CLUSTER,'--task-definition',definition,'--launch-type','FARGATE','--count','1',
                 '--started-by','vega-audit-xg-holdout','--network-configuration',json.dumps(service['networkConfiguration']))
    if launched['failures']: raise RuntimeError('diagnostic task launch failed')
    task,=launched['tasks']
    receipt['task']=task['taskArn']
    write('receipt.json',receipt)
    for _ in range(59):
        state,=aws('ecs','describe-tasks','--cluster',CLUSTER,'--tasks',task['taskArn'])['tasks']
        if state['lastStatus']=='STOPPED':break
        time.sleep(4)
    else: raise RuntimeError('diagnostic task did not reach STOPPED within the read budget')
    actual,=state['containers']
    receipt.update(exit_code=actual.get('exitCode'),diagnostic_digest=actual.get('imageDigest'),stopped=state.get('stoppedAt'))
    write('receipt.json',receipt)
    assert actual.get('imageDigest')==before['image_digest'], 'diagnostic image mismatch'
    options=container['logConfiguration']['options']
    stream='/'.join((options['awslogs-stream-prefix'],container['name'],task['taskArn'].split('/')[-1]))
    token=None
    lines=[]
    for _ in range(45):
        params=['logs','get-log-events','--log-group-name',options['awslogs-group'],'--log-stream-name',stream,'--start-from-head']
        r=aws(*params,*(['--next-token',token] if token else []))
        lines.extend(e['message'] for e in r['events'])
        if 'XG_DONE' in lines or (lines and actual.get('exitCode')!=0):break
        new=r['nextForwardToken']
        if new==token:time.sleep(2)
        token=new
    else:raise RuntimeError('immutable diagnostic result marker unavailable')
    chunks,hashes={},{}
    for msg in lines:
        if msg.startswith('XG '):
            _,name,offset,body=msg.split(' ',3);chunks.setdefault(name,{})[int(offset)]=body
        elif msg.startswith('SHA '):
            _,name,expected=msg.split();hashes[name]=expected
    if actual.get('exitCode')!=0:
        errors=[m.split(':',1)[0] for m in lines if m.startswith('psycopg.errors.')]
        receipt['safe_error_classes']=errors
        raise RuntimeError('read task exited without a full result')
    assert set(chunks)==set(hashes)==set(QUERIES)|{'snapshot'}
    for name,parts in sorted(chunks.items()):
        raw=zlib.decompress(base64.b64decode(''.join(parts[i] for i in sorted(parts))))
        assert sha(raw)==hashes[name]
        (HERE/f'{name}.json').write_bytes(raw)
    receipt.update(result_sha256=hashes,worker_after=worker()[1],snapshot=json.loads((HERE/'snapshot.json').read_bytes()))
    write('receipt.json',receipt)
    print('RDS_READ_OK',receipt['snapshot']['at'],receipt['task'],flush=True)
if __name__=='__main__':main()
