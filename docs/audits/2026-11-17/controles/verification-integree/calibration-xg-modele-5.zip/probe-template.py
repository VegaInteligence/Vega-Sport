import base64,hashlib,json,os,zlib
import psycopg
plan=json.loads(zlib.decompress(base64.b64decode(PAYLOAD)))
def emit(name,obj):
    raw=json.dumps(obj,default=str,ensure_ascii=False,separators=(',',':')).encode()
    block=base64.b64encode(zlib.compress(raw,6)).decode()
    for offset in range(0,len(block),16000):print('XG',name,offset,block[offset:offset+16000],flush=True)
    print('SHA',name,hashlib.sha256(raw).hexdigest(),flush=True)
with psycopg.connect(host=os.environ['V2_DB_HOST'],dbname=os.environ['V2_DB_NAME'],user=os.environ['V2_DB_USER'],password=os.environ['V2_DB_PASSWORD'],sslmode='verify-full',sslrootcert='/app/rds-ca.pem',connect_timeout=10,application_name='vega_audit_xg_holdout',options='-c default_transaction_read_only=on -c statement_timeout=25000 -c lock_timeout=1500 -c max_parallel_workers_per_gather=0',autocommit=True) as db:
    with db.transaction():
        db.execute('SET TRANSACTION ISOLATION LEVEL REPEATABLE READ, READ ONLY')
        at,snapshot,name,readonly,isolation=db.execute("SELECT transaction_timestamp(), pg_current_snapshot()::text,current_database(),current_setting('transaction_read_only'),current_setting('transaction_isolation')").fetchone()
        assert name=='vega_v2' and readonly=='on' and isolation=='repeatable read'
        emit('snapshot',{'at':at,'snapshot':snapshot,'database':name,'read_only':readonly,'isolation':isolation})
        for name,query in plan.items():
            with db.transaction():
                result=db.execute(query)
                emit(name,{'columns':[c.name for c in result.description],'rows':result.fetchall()})
print('XG_DONE',flush=True)
