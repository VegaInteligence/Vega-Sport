WITH officials AS (
  SELECT o.*, (won IS NOT NULL AND drawn IS NOT NULL AND lost IS NOT NULL) complete,
         coalesce(won,0)+coalesce(drawn,0)+coalesce(lost,0) known_outcomes
  FROM core.standings_official o WHERE source='sportscore' AND stage IS NULL
), signatures AS (
  SELECT t.id, t.name canonical, n.name spelling,
      lower(n.name) ~ '(^|[^a-z])(ii|iii|u[- ]?(1[5-9]|2[0-3])|youth|reserves?|primavera|jong|academy)([^a-z]|$)' marked_source,
      lower(t.name) ~ '(^|[^a-z])(ii|iii|u[- ]?(1[5-9]|2[0-3])|youth|reserves?|primavera|jong|academy)([^a-z]|$)' marked_canonical
  FROM core.entity_names n JOIN core.teams t ON t.id=n.entity_id
  WHERE n.entity_type='team' AND n.source='sportscore'
)
SELECT transaction_timestamp() observed_at,
 (SELECT count(*) FROM officials) official_rows,
 (SELECT count(DISTINCT competition_season_id) FROM officials) editions,
 (SELECT count(*) FROM officials WHERE complete) with_full_wdl,
 (SELECT count(*) FROM officials WHERE known_outcomes>played) known_exceeds_played,
 (SELECT count(*) FROM officials WHERE complete AND known_outcomes<played) complete_below_played,
 (SELECT count(*) FROM officials WHERE NOT complete) optional_wdl_unknown,
 (SELECT count(*) FROM signatures) sportscore_spellings,
 (SELECT count(*) FROM signatures WHERE marked_source<>marked_canonical) squad_marker_disagreements,
 (SELECT coalesce(jsonb_agg(to_jsonb(v)), '[]') FROM
    (SELECT id,canonical,spelling FROM signatures WHERE marked_source<>marked_canonical ORDER BY id,spelling LIMIT 50) v) distinct_marker_candidates,
 (SELECT count(*) FROM core.matches WHERE source='open_matchday') omd_matches,
 (SELECT count(round_id) FROM core.matches WHERE source='open_matchday') omd_rounds,
 (SELECT count(*) FROM core.matches WHERE source='open_matchday' AND status='not_started') omd_pending
