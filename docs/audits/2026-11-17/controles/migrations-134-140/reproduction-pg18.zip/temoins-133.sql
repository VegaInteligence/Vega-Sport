INSERT INTO core.seasons(id,label) VALUES (2025,'2025/2026') ON CONFLICT DO NOTHING;
SELECT core.ensure_season_partitions(2025);
INSERT INTO core.assets(id,kind,source_url) VALUES
 (701,'logo','https://example.invalid/competition.png'),(702,'crest','https://example.invalid/home.png'),(703,'crest','https://example.invalid/away.png');
INSERT INTO core.competitions(id,name,logo_asset_id) VALUES(701,'Preflight Cup',701);
INSERT INTO core.competition_seasons(id,competition_id,season_id,native_label,cup_key,cup_name)
 VALUES (701,701,2025,'2025/2026','open-matchday:preflight:2025/2026','Preflight Cup');
INSERT INTO core.competitions(id,name) VALUES(702,'Preflight extra time');
INSERT INTO core.competition_seasons(id,competition_id,season_id,native_label,cup_key,cup_name)
 VALUES (702,702,2025,'2025/2026','open-cups:preflight_et:2025/2026','Preflight extra time');
INSERT INTO core.teams(id,name,crest_asset_id) VALUES(701,'Home',702),(702,'Away',703),(703,'Historical home identity',NULL);
UPDATE core.teams SET merged_into=701 WHERE id=703;
INSERT INTO core.players(id,name) VALUES (701,'Preflight Player');
INSERT INTO core.matches(id,competition_season_id,season_id,match_date,status,home_team_id,away_team_id,home_score,away_score,source,archive_position)
 VALUES (701,701,2025,'2026-01-15','finished',703,702,2,1,'open_matchday',1);
INSERT INTO core.matches(id,competition_season_id,season_id,match_date,status,home_team_id,away_team_id,home_score,away_score,home_score_et,away_score_et,source,archive_position)
 VALUES (702,702,2025,'2026-01-16','finished',701,702,3,2,3,2,'openfootball',1);
INSERT INTO core.player_match_half_stats(season_id,match_id,team_id,player_id,period,minutes_played,accurate_passes)
 VALUES(2025,701,703,701,'first_half',40,13);
INSERT INTO core.player_transfers(id,player_id,transfer_date,from_team_id,to_team_id,source,as_of,source_key)
 VALUES (701,701,'2026-01-10',702,701,'transfermarkt','2026-01-15','preflight-701');
INSERT INTO core.player_contracts(player_id,team_id,start_date,end_date,source,as_of)
 VALUES (701,701,current_date-30,current_date+365,'transfermarkt',current_date-30);
