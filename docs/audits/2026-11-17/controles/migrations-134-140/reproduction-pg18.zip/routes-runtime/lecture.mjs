import { createServer } from 'node:http';
import { once } from 'node:events';
import { createRequire } from 'node:module';
import assert from 'node:assert/strict';
const require = createRequire(import.meta.url);
const { Client } = require(process.env.PREFLIGHT_PG_MODULE);
const db = new Client({ host:'127.0.0.1', port:Number(process.env.PREFLIGHT_PORT), database:'upgrade',
                        user:'postgres', password:process.env.PREFLIGHT_PASSWORD });
await db.connect();
const result={};
try {
  await db.query('SET ROLE vega_read');
  await db.query('SET default_transaction_read_only=on');
  for (const key of ['w','t7','combine']) {
    const { createCupRoute } = await import('./src/routes/cups-'+key+'.mjs');
    const router=createCupRoute(async (q,values=[]) => (await db.query(q,values)).rows);
    const server=createServer(async (incoming,response) => {
      try {
        const url=new URL(incoming.url,'http://127.0.0.1');
        const observed=await router(new Request(url),url.pathname,url.searchParams);
        response.writeHead(observed.status,Object.fromEntries(observed.headers));
        response.end(await observed.text());
      } catch (err) { response.writeHead(500); response.end(String(err)); }
    });
    server.listen(0,'127.0.0.1');await once(server,'listening');
    const urls=['/api/cups/edition?competition=l_v0000702&season=2025%2F2026',
                '/api/cups/edition?competition=l_v0000701&season=2025%2F2026',
                '/api/cup-index?kind=supplemental'];
    try {
      const responses=[];
      for (const url of urls) {
        const res=await fetch('http://127.0.0.1:'+server.address().port+url);
        const text=await res.text();assert.equal(res.status,200,text);
        responses.push({url,status:res.status,body:JSON.parse(text)});
      }
      const score=responses[0].body.matches[0].score;
      const sides=responses[1].body.results[0].sides;
      const catalog=responses[2].body.competitions[0];
      assert.deepEqual(score.et,[3,2]);
      if(key==='t7') assert.deepEqual(score.ft,[3,2]); else assert.equal(score.ft,undefined);
      if(key==='w') {
        assert.equal(sides,undefined);assert.equal(catalog.competition_id,undefined);
      } else {
        assert.equal(sides.home.id,'t_v0000701');assert.equal(sides.away.id,'t_v0000702');
        assert.equal(sides.home.image_url,'https://example.invalid/home.png');
        assert.equal(sides.away.image_url,'https://example.invalid/away.png');
        assert.equal(catalog.competition_id,'l_v0000701');
      }
      assert.equal(catalog.image_url,'https://example.invalid/competition.png');
      result[key]={responses,extra_time:score.et,regulation:score.ft??null,sides:sides??null,
                   catalog_competition_id:catalog.competition_id??null};
    } finally {server.close();await once(server,'close');}
  }
} finally { await db.end(); }
console.log(JSON.stringify(result,null,2));
