# Reproduire la validation des migrations 134–140

Cette capsule utilise le moteur de migration déployé, les 142 fichiers SQL du candidat et des témoins synthétiques. Le reçu indique la révision, les digests des migrations ajoutées et celui de l’image locale. Le registre du gel inclus se limite aux empreintes nécessaires. [Reçu](recu.json) · [Trois variantes des GET](observations-http.json)

Après extraction, fournir Python 3 avec psycopg 3, Node.js, un paquet Node `pg` déjà installé et le contexte Docker local `colima` avec l’image `pgvector/pgvector:pg18` déjà en cache. L’exécution ouvre un conteneur distinct sur la boucle locale et le supprime après le contrôle. Elle doit trouver 142 empreintes identiques en installation neuve et mise à niveau, un refus transactionnel de la migration 139 sur deux transferts de même clé, et neuf GET HTTP 200.

```sh
shasum -a 256 -c SHA256SUMS
python3 -B pg18.py nouveau-rejeu --seed --guard --routes "/chemin/vers/node_modules/pg"
```

Sur le témoin après prolongation à 3–2, la version combinée omet le score à 90 minutes. Sur l’autre compétition, elle renvoie les deux identifiants de clubs et leurs écussons. Toutes les données d’exemple sont créées dans cette instance. Cette capsule ne constitue pas une recette de déploiement.
