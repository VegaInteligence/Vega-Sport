def check(c):
    stored=c.execute("""SELECT id,player_id,source_key,absent_since FROM core.player_transfers
                     WHERE id=701""").fetchone()
    assert stored==(701,701,'preflight-701',None),stored
    row=c.execute("""SELECT logo_url,competition_id FROM api.cup_editions WHERE competition_season_id=701""").fetchone()
    assert row==('https://example.invalid/competition.png','l_v0000701'),row
    match=c.execute("""SELECT match_id,home_team_public_id,home_image_url,away_team_public_id,away_image_url,
                     home_score,away_score FROM api.cup_table_rows WHERE competition_season_id=701""").fetchone()
    assert match==(701,'t_v0000701','https://example.invalid/home.png','t_v0000702','https://example.invalid/away.png',2,1),match
    halves=c.execute("""SELECT matches,excluded_matches,passes_sum,passes_count,passes_minutes FROM api.player_half_coverage
                       WHERE player_key=701 AND period='first_half'""").fetchone()
    assert halves==(1,1,13,1,40),halves
    table=c.execute("SELECT team_id,results FROM core.table_results(701) ORDER BY team_id").fetchall()
    assert table==[(702,[1,0,0,1,1,2]),(703,[1,1,0,0,2,1])],table
    contract=c.execute("SELECT count(*) FROM api.confirmed_player_contracts WHERE player_id=701").fetchone()[0]
    assert contract==1,contract
    profile=c.execute("SELECT count(*) FROM api.player_profiles WHERE player_id=701").fetchone()[0]
    assert profile==1,profile
    import psycopg
    for command in ('DELETE FROM core.player_transfers WHERE id=701','DELETE FROM core.player_contracts WHERE player_id=701'):
        try:
            with c.transaction():c.execute(command)
        except psycopg.errors.RestrictViolation:pass
        else:raise AssertionError(command)
    return dict(transfer=stored,cup=row,sides=match,half_coverage=halves,standings_basis=table,
                contract_rows=contract,profile_rows=profile,both_deletions_refused=True)
