"""Install the frozen chain on two independent local PG18 databases; remove the disposable container."""
import argparse
from datetime import datetime,timezone
import hashlib
import json
import os
from pathlib import Path
import secrets
import shutil
import subprocess
import sys
import tempfile
import time
import uuid
import psycopg
from psycopg import sql

P=Path(__file__).resolve().parent
VIEWS=('api.cup_editions','api.cup_table_rows','api.player_half_coverage','api.standings','api.standing_rows',
       'api.confirmed_player_contracts','api.player_profiles')
def sha(b):return hashlib.sha256(b).hexdigest()
def capture(c):
    def fetch(stmt,*args):return list(c.execute(stmt,args).fetchall())
    views={}
    for name in VIEWS:
        if not c.execute('SELECT to_regclass(%s)',(name,)).fetchone()[0]:continue
        v=c.execute('SELECT pg_get_viewdef(%s::regclass,true),has_table_privilege(\'vega_read\',%s,\'SELECT\')',(name,name)).fetchone()
        cols=fetch('SELECT attname,format_type(atttypid,atttypmod) FROM pg_attribute WHERE attrelid=%s::regclass AND attnum>0 AND NOT attisdropped ORDER BY attnum',name)
        references=fetch("""SELECT DISTINCT ref_ns.nspname,rc.relname FROM pg_rewrite wr JOIN pg_depend d ON d.objid=wr.oid
              AND d.classid='pg_rewrite'::regclass AND d.refclassid='pg_class'::regclass
              JOIN pg_class rc ON rc.oid=d.refobjid JOIN pg_namespace ref_ns ON ref_ns.oid=rc.relnamespace
              WHERE wr.ev_class=%s::regclass AND rc.oid<>wr.ev_class ORDER BY 1,2""",name)
        with c.transaction():
            c.execute('SET LOCAL ROLE vega_read')
            cur=c.execute(sql.SQL('SELECT * FROM {} LIMIT 1').format(sql.Identifier(*name.split('.'))))
            cur.fetchall()
        views[name]=dict(columns=cols,definition_sha256=sha(v[0].encode()),definition=v[0],select_as_reader=v[1],dependencies=references)
    tables={}
    for name in ('core.standings_official','core.player_transfers','core.player_contracts','ops.archive_plans','ops.archive_plan_seasons'):
        if not c.execute('SELECT to_regclass(%s)',(name,)).fetchone()[0]:continue
        tables[name]=dict(columns=fetch('SELECT attname,format_type(atttypid,atttypmod) FROM pg_attribute WHERE attrelid=%s::regclass AND attnum>0 AND NOT attisdropped ORDER BY attnum',name),
              collect_rights=fetch("SELECT has_table_privilege('vega_collect',%s,'SELECT'),has_table_privilege('vega_collect',%s,'INSERT'),has_table_privilege('vega_collect',%s,'UPDATE'),has_table_privilege('vega_collect',%s,'DELETE')",name,name,name,name)[0])
    funcs=fetch("""SELECT n.nspname,p.proname,pg_get_function_identity_arguments(p.oid),p.prosecdef,pg_get_functiondef(p.oid)
                 FROM pg_proc p JOIN pg_namespace n ON p.pronamespace=n.oid
                 WHERE (n.nspname,p.proname) IN (('core','table_results'),('core','keep_transfermarkt_history'),
                 ('ops','archive_match_dependents'),('ops','archive_lock_match_references')) ORDER BY 1,2,3""")
    triggers=fetch("""SELECT tgrelid::regclass::text,tgname,pg_get_triggerdef(oid) FROM pg_trigger WHERE tgname='keep_transfermarkt_history' ORDER BY 1,2""")
    return dict(views=views,tables=tables,functions=funcs,triggers=triggers,
                transfer_index=fetch("SELECT indexdef FROM pg_indexes WHERE schemaname='core' AND indexname='player_transfers_transfermarkt_key'"))
def dump(path,obj):path.write_text(json.dumps(obj,indent=2,ensure_ascii=False,default=str)+'\n')
def main():
    parser=argparse.ArgumentParser();parser.add_argument('output',type=Path);parser.add_argument('--seed',action='store_true');parser.add_argument('--guard',action='store_true');parser.add_argument('--routes',type=Path,help='Path to installed pg package');args=parser.parse_args()
    if args.routes and not args.seed:parser.error('--routes requires --seed')
    if args.guard and not args.seed:parser.error('--guard requires --seed')
    out=args.output.resolve();out.mkdir(parents=True,exist_ok=False)
    pin=json.loads((P/'gel.json').read_bytes())
    migrations={n:sha(f.read_bytes()) for f in sorted((P/'sql').glob('*.sql')) if (n:=f.name)}
    assert migrations==pin['base_sql']|{n:next(iter(d.values())) for n,d in pin['sql_sources'].items()}
    for n,h in pin['runtime_files'].items():assert sha((P/'runtime/backend/vega'/n).read_bytes())==h
    docker=['docker','--context','colima']
    image=subprocess.check_output(docker+['image','inspect','pgvector/pgvector:pg18','--format','{{.Id}}']).decode().strip()
    name='vega-preflight-'+uuid.uuid4().hex[:12];pw=secrets.token_urlsafe(24)
    run=dict(start=datetime.now(timezone.utc).isoformat(),image=image,base=pin['common'],production_runner=pin['production'],steps={})
    created=False
    with tempfile.TemporaryDirectory() as tmp:
        backend=Path(tmp)/'backend';shutil.copytree(P/'runtime/backend',backend);d=backend/'sql';d.mkdir()
        sys.path.insert(0,str(backend));from vega import store
        assert store.__file__==str(backend/'vega/store.py')
        env=dict(os.environ,POSTGRES_PASSWORD=pw)
        try:
            subprocess.run(docker+['run','-d','--pull=never','--rm','--name',name,'--cpus=1.5','--memory=1100m',
              '--tmpfs','/var/lib/postgresql:rw,size=920m','-p','127.0.0.1::5432','-e','POSTGRES_PASSWORD',image],env=env,capture_output=True,check=True)
            created=True
            port=int(subprocess.check_output(docker+['port',name,'5432/tcp']).decode().strip().split(':')[-1])
            def connect(n):return psycopg.connect(host='127.0.0.1',port=port,user='postgres',password=pw,dbname=n,connect_timeout=2,autocommit=True)
            for i in range(75):
                try:
                    with connect('postgres') as admin:
                        for db in ('fresh','upgrade'):admin.execute(sql.SQL('CREATE DATABASE {}').format(sql.Identifier(db)))
                    break
                except psycopg.OperationalError:
                    if i==74:raise
                    time.sleep(0.5)
            def install(n,v):
                # A real isolated path determines the inputs used by the unmodified store.migrate.
                for f in d.iterdir():
                    if int(f.name[:3])>v:f.unlink()
                for f in (P/'sql').glob('*.sql'):
                    if int(f.name[:3])<=v and not (d/f.name).exists():shutil.copyfile(f,d/f.name)
                with connect(n) as c:
                    store.migrate(c,vector=True)
                    applied=c.execute('SELECT version,encode(checksum,\'hex\'),applied_at::text FROM ops.schema_migrations ORDER BY version').fetchall()
                    assert {a[0]:a[1] for a in applied}=={k:h for k,h in migrations.items() if int(k[:3])<=v}
                    state=capture(c)
                    versions=c.execute("SELECT current_setting('server_version'),(SELECT extversion FROM pg_extension WHERE extname='vector')").fetchone()
                    assert versions[0].startswith('18.') and versions[1]
                    return applied,state,versions
            def save(label,n,v):
                applied,state,versions=install(n,v)
                run['steps'][label]={'latest':v,'versions':len(applied),'view_count':len(state['views']),'server':versions}
                dump(out/(label+'-objects.json'),state);dump(out/(label+'-versions.json'),applied)
                dump(out/'receipt.json',run)
                return applied,state
            fresh,first=save('fresh140','fresh',140)
            if args.seed:
                from temoins import check
                with connect('fresh') as c:
                    c.execute((P/'temoins-133.sql').read_text());run['seeded_fresh']=check(c)
            twice,repeated=save('fresh140-again','fresh',140)
            assert first==repeated and fresh==twice
            base,previous=save('upgrade133','upgrade',133)
            if args.seed:
                with connect('upgrade') as c:c.execute((P/'temoins-133.sql').read_text())
            if args.guard:
                with connect('postgres') as c:c.execute('CREATE DATABASE guard TEMPLATE upgrade')
                install('guard',138)
                with connect('guard') as c:
                    c.execute("""INSERT INTO core.player_transfers(player_id,source,as_of,source_key)
                              VALUES(701,'transfermarkt',current_date,'preflight-701')""")
                try:install('guard',139)
                except psycopg.errors.RaiseException as err:
                    message=err.diag.message_primary
                    assert 'TRANSFER_KEYS_NOT_UNIQUE' in message,message
                else:raise AssertionError('139 unexpectedly accepted duplicate source key')
                with connect('guard') as c:
                    preserved=c.execute("""SELECT count(*) FROM core.player_transfers
                                          WHERE player_id=701 AND source_key='preflight-701'""").fetchone()[0]
                    markers=c.execute("SELECT count(*) FROM ops.schema_migrations WHERE version LIKE '139%'").fetchone()[0]
                    col=c.execute("""SELECT count(*) FROM information_schema.columns WHERE table_schema='core'
                               AND table_name='player_transfers' AND column_name='absent_since'""").fetchone()[0]
                    assert (preserved,markers,col)==(2,0,0)
                    run['duplicate_guard_139']=dict(message=message,rows_preserved=preserved,migration_recorded=markers,
                                                     new_column_visible=col)
            for v in range(134,141):
                new,current=save('upgrade'+str(v),'upgrade',v)
                assert [r for r in new if r[0] in {t[0] for t in base}]==base
                base,previous=new,current
            twice_end,end=save('upgrade140-again','upgrade',140)
            assert end==previous==first and twice_end==base
            assert [r[:2] for r in twice_end]==[r[:2] for r in fresh]
            if args.seed:
                with connect('upgrade') as c:run['seeded_upgrade']=check(c)
                assert run['seeded_upgrade']==run['seeded_fresh']
            if args.routes:
                route_env=dict(os.environ,PREFLIGHT_PASSWORD=pw,PREFLIGHT_PORT=str(port),PREFLIGHT_PG_MODULE=str(args.routes.resolve()))
                proc=subprocess.run(['node',str(P/'routes-runtime/lecture.mjs')],env=route_env,capture_output=True,text=True)
                if proc.returncode:raise RuntimeError(proc.stderr)
                values=json.loads(proc.stdout)
                dump(out/'comparaison-http.json',values)
                run['http_200']=sum(len(v['responses']) for v in values.values())
            run.update(status='PASS',fresh_and_upgrade_schema_equal=True,vector=True,
                       checksums_match_frozen_sql=True,second_pass_preserves_timestamps=True)
        finally:
            if created:
                r=subprocess.run(docker+['rm','-f',name],capture_output=True)
                run['own_container_removed']=r.returncode==0
            run['end']=datetime.now(timezone.utc).isoformat();dump(out/'receipt.json',run)
    print(json.dumps({k:run.get(k) for k in ('status','vector','own_container_removed','fresh_and_upgrade_schema_equal')}))

if __name__=='__main__':main()
