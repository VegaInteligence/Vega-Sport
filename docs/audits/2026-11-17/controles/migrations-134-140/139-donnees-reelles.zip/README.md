# VI-31 — Migration 139 sur tous les transferts et contrats actuels

**Rejeu local réussi**, le 18 novembre 2026 à 09:54 UTC. Aucun changement produit, Git ou données de production. Migration figée `139_transfermarkt_history.sql`, SHA-256 `e66951f8f973e4954f800b17bb39d447113c2a7e8fe5a42f4412c49c708846b3`.

## Résultat vérifié

La capture unique en transaction RDS `REPEATABLE READ READ ONLY` date du **18 novembre 2026 à 09:41:37.790 UTC**, snapshot `4425328:4425328:`. Elle contient toutes les lignes et toutes les colonnes des deux tables, sans filtre de fournisseur, sans LIMIT et sans correction préalable.

| Table | Lignes | Fournisseurs | Colonnes antérieures | Résultat après 139, deuxième passage et sondes annulées |
|---|---:|---|---:|---|
| `core.player_transfers` | 46 362 | Transfermarkt : 46 362 | 17 | Identifiants, valeurs et empreintes identiques ; 46 362 `absent_since` NULL |
| `core.player_contracts` | 12 570 | Transfermarkt : 12 568 ; other : 2 | 12 | Clés primaires, valeurs et empreintes identiques ; 12 570 `superseded_on` NULL |

**Aucune paire bloquante** `(player_id, source_key)` Transfermarkt non NULL : 0 groupe, 0 ligne concernée, 0 surnuméraire. Le garde de migration n'a donc pas eu à rejeter ce jeu réel. Son chemin d'échec sur des doublons déjà présents n'est pas démontré par ce rejeu ; la contrainte unique installée a bien rejeté la tentative correspondante, en transaction annulée.

Les 133 checksums de migrations déployées correspondent exactement aux fichiers préflight. Les migrations optionnelles vectorielles 004 et 010 sont absentes de la production et n'ont pas été installées. Les colonnes, types, contraintes et index des deux tables reconstruites en version 133 sont exactement identiques aux métadonnées capturées. Les définitions initiales des deux vues concernées correspondent également.

Le **runner déployé exact `vega.store.migrate`** a installé 133, puis 134–138, puis 139. Le deuxième appel a conservé les données, le schéma et les horodatages des migrations. Aucun SQL139 n'a été réécrit pour le test. Le runner est SHA-256 `497c7c602b9c84146a8ec201839b50dc07e42146887f6324a51526e3d26d70d0`.

## Conservation des faits

L'import réutilise le texte JSONB produit par PostgreSQL, avec `jsonb_populate_recordset` et les types des vraies tables. Les montants entiers ne traversent aucune conversion flottante. Les clés étrangères restent actives ; 16 734 parents joueurs et 1 297 parents équipes conservent leurs vrais identifiants avec des noms synthétiques.

Empreintes SHA-256 de toutes les colonnes antérieures, lignes ordonnées et texte JSONB UTC :

- Transferts : `f28852e1d39aa48cbabf0d942a8c7ee8b6b53dc3699f0fd100bc26f087e1fe0d`.
- Contrats : `7757f4836a3f1b935e351a28feea524712051af711f59c7c0983280155a86202`.

Les empreintes par colonne et par clé sont également comparées à chaque étape dans `run-01/*facts*.json` et `run-01/source-fingerprints.json`. Les quatre dates de transfert inconnues restent NULL. Les 26 450 transferts ayant au moins un côté canonique non raccordé gardent leurs valeurs exactes ; les identifiants fournisseur des deux côtés sont présents pour les 46 362 transferts. La migration ne résout aucune identité et n'invente aucune date.

Les anciennes contraintes et les anciens index restent identiques. Le nouvel index unique partiel est valide, les deux triggers de conservation sont actifs, les vues gardent leurs 5 et 20 colonnes et leur droit SELECT pour `vega_read`. Une lecture réelle sous ce rôle a été exécutée, sans export des résultats individuels.

## Huit sondes locales, toutes annulées

| Sonde | Résultat observé |
|---|---|
| Même joueur et même clé Transfermarkt non NULL | Refus `23505` |
| Même clé, fournisseur `other` | Autorisé |
| Deux nouvelles lignes Transfermarkt à clé NULL | Autorisé |
| Suppression d'un transfert Transfermarkt | Refus `23001` |
| Suppression d'un contrat Transfermarkt | Refus `23001` |
| Suppression d'un contrat `other` | Autorisé |
| Suppression avec `SET LOCAL vega.allow_history_delete='on'` | Autorisé |
| Nouvelle transaction après annulation de cette dérogation | Refus `23001` |

Après ces sondes, les empreintes des 58 932 lignes, les objets et les versions de migration sont encore identiques au résultat du deuxième passage. Les identifiants négatifs synthétiques des sondes étaient absents du jeu réel ; aucune séquence d'identité n'a été consommée par ces sondes.

## Écart avec le relevé de 05:04:55 UTC

| Mesure | 05:04:55 | 09:41:37 | Écart |
|---|---:|---:|---:|
| Transferts Transfermarkt | 7 243 | 46 362 | +39 119 |
| Joueurs avec transferts | 896 | 5 510 | +4 614 |
| Unités de lecture de transferts | 23 321 | 23 321 | 0 |
| Unités déjà lues | 896 | 5 513 | +4 617 |
| Unités jamais lues | 22 425 | 17 808 | −4 617 |
| Deux côtés canoniques raccordés | 3 474 | 19 912 | +16 438 |
| Un seul côté canonique raccordé | 1 760 | 11 720 | +9 960 |
| Aucun côté canonique raccordé | 2 009 | 14 730 | +12 721 |
| Date de transfert absente | 1 | 4 | +3 |

Les **55 témoins** déjà figés à 05h05 sont retrouvés par joueur/clé avec les mêmes IDs et les mêmes valeurs sur leurs **15 champs de base communs**. Les noms, profils et libellés de clubs n'ont pas été recollectés pour cette comparaison. Le relevé antérieur ne contenait ni tous les transferts ni tous les contrats : il ne permet pas d'affirmer la conservation de toutes les histoires entre ces deux instants. Les écarts de volumes sont observés avant le rejeu ; ils ne sont pas attribués à139. Le champ « déjà lu » n'est pas une preuve indépendante du statut HTTP ni de la complétude fournisseur.

## Reproduction locale

Racine de ce dossier :

```text
/Users/lemonnierhugo/.codex/visualizations/2026/11/17/01a1e6f1-9c43-7b81-a52e-3ee15c953578/production-architecture-review/tracks/3-identities/migration-real-preview
```

Le protocole préalable est `SUCCESS_CRITERIA.md`. La commande exacte de capture est `capture-command.json` ; son reçu est `rds-encrypted/receipt.json`. **Ne pas relancer une collecte pour reproduire ce résultat : réutiliser l'entrée privée figée.** La capture s'est exécutée sur l'image déployée `8018e0836ca0f32e8b2eb51fc2847154abff7f13`, digest `sha256:8184f72a335b9b4c126e77ead0e71771b6a4a146ee1b7a026ed2c2c1a6aba352` ; tâche terminée avec code0, définition éphémère désactivée.

Depuis cette racine, avec Python possédant `psycopg` et Docker/Colima disponible :

```sh
python3 -B replay.py run-02
python3 -B compare_0505.py
python3 -B verify_offline.py
```

`run-02` doit être un nouveau nom absent. Le script vérifie les hashes des sources et de l'entrée avant tout rejeu, crée son propre conteneur, importe les lignes privées, exécute le vrai runner et supprime uniquement son conteneur à la fin. La commande réellement exécutée et ses durées sont dans `run-01/receipt.json`. Le rejeu initial a employé PostgreSQL **18.6**, image locale `sha256:c29f30688a9ad961691bdf0ec1650717cc132a5814619d80f80463d6e4c42e47` ; la source RDS était PostgreSQL **18.3**. Même version majeure, versions mineures différentes explicitement conservées dans les preuves.

Le détail privé est `private/inputs.json.zlib`, SHA-256 `fb8ca47c24b83fabeb43b58714a718d42eb5bef9170bcac17a2b466be03fc2b7` (1 769 209 octets). Il reste sur le poste, en répertoire0700 et fichier0600. Le transport a chiffré ce détail avant les journaux ECS avec une clé publique éphémère ; la clé privée n'a jamais quitté le poste. Le paquet partageable exclut le détail, la clé privée et le transport chiffré. Les scripts de reproduction restent dans ce dossier local ; leurs empreintes sont consignées. Le ZIP contient uniquement ce rapport, les critères, SQL, métadonnées, agrégats et empreintes.

## Limites et suite

Ce résultat qualifie la **migration139 sur le snapshot réel capturé**. Il ne qualifie pas le writer d'Opus, les contenus des profils, les quarantaines, les raccordements d'identité, la concurrence ni la durée des verrous en production. Les parents sont simplifiés ; les autres tables de faits et les séquences courantes de production ne sont pas clonées. Les données des deux tables et les droits de lecture des vues sont préservés, mais la nouvelle règle de suppression peut volontairement bloquer un ancien writer qui efface l'historique ; son comportement de redémarrage appartient à la validation du writer.

Le conteneur personnel `vega-139-real-6d7b6da7da26` a été supprimé, code0, absence confirmée. Aucun autre conteneur n'a été modifié. Avant une future application en production, revérifier les doublons sur son état alors courant ; le présent zéro vaut pour09:41:37 UTC uniquement. Aucune autorisation de déploiement n'est déduite du rejeu.
