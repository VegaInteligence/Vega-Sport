"""Quatre lectures publiques ordinaires par paire si disponibles, sans jeton ni donnée personnelle de profil."""
import concurrent.futures,datetime,hashlib,json,sys,gzip
from pathlib import Path
from urllib.parse import urlencode
from urllib.request import Request,urlopen
from urllib.error import HTTPError
d=Path(__file__).resolve().parent
def run(task):
    name,path,params=task
    url='https://vegasport.vercel.app'+path+('?' + urlencode(params) if params else '')
    req=Request(url,headers={'Accept':'application/json','User-Agent':'Vega scientific audit read-only'})
    try: response=urlopen(req,timeout=30)
    except HTTPError as ex:response=ex
    with response as r:
        b=r.read()
        f=target/(name+'.json.gz')
        f.write_bytes(gzip.compress(b,mtime=0))
        result=dict(at=datetime.datetime.now(datetime.timezone.utc).isoformat(),url=url,effective=r.geturl(),status=r.status,bytes=len(b),sha256=hashlib.sha256(b).hexdigest(),headers={k:r.headers[k] for k in ('Date','ETag','Content-Type','Age','Cache-Control') if k in r.headers})
        (target/(name+'.receipt.json')).write_text(json.dumps(result,indent=2)+'\n')
        print(name,result['status'],result['bytes'])
if __name__=='__main__':
    target=Path(sys.argv[1])
    target.mkdir(exist_ok=True)
    if any(target.iterdir()):raise ValueError('Il faut un répertoire de reçus vide.')
    tasks=[]
    for name,year,mid,pid,league in [('2020',2021,'m_1ZaiLN','p_0Aym4b','l_3hvsne'),('distribution',2025,'m_27dufA','p_0rvsP3','l_1pQOHK')]:
        tasks += [(name+'-performance','/api/read/performance',dict(season=f'{year}/{year+1}',league=league,appearance=mid+':'+pid)),(name+'-famille','/api/matches/'+mid+'/players',{}),(name+'-classement','/api/rankings/match',dict(match=mid))]
    with concurrent.futures.ThreadPoolExecutor(max_workers=3) as pool:
        list(pool.map(run,tasks))
