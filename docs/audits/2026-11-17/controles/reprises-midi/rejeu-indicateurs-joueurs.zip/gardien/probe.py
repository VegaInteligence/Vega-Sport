def collect(db):
    # Seeds are the actual per-edition example_match values for partition 2025, one-block.
    ids=[47982, 47994, 48174, 48559, 48574, 48835, 48841, 49333, 50116, 50212, 50497, 50776, 50780, 50956, 51691, 52135, 52296, 52398, 53608, 54135, 54343, 54781, 55001, 55223, 55392, 55546, 56827, 57627, 57819, 57962, 57986, 59373, 59429, 59564, 59669, 60755, 61018, 61176, 61280, 61404, 61506, 62161, 62225, 62696, 62928, 63189, 63380, 63524, 63614, 63731, 63854, 64036, 64460, 64764, 64782, 64958, 65849, 65851, 66041, 66231, 66621, 66765, 67632, 67646, 68082, 68119, 68359, 68559, 68734, 68843, 68951, 69053, 69128, 69248]
    with db.transaction():
        db.execute('SET TRANSACTION ISOLATION LEVEL REPEATABLE READ READ ONLY')
        db.execute("SET LOCAL statement_timeout='45s'")
        stamp=db.execute("SELECT current_database(),transaction_timestamp()::text,pg_current_snapshot()::text,current_setting('transaction_read_only'),current_setting('transaction_isolation')").fetchone()
        assert stamp[0]=='vega_v2' and stamp[3:]==('on','repeatable read')
        c=db.execute("""SELECT g.season_id,m.id AS match_id,g.player_id,g.team_id,m.match_date,m.competition_season_id,cs.competition_id,
          c.name AS competition,lp.position_id,lp.is_starter,g.minutes,g.role,g.z,g.run_id,pm.shot_stopping,pm.aerial,pm.depth,pm.distribution,
          api.public_id('match',m.id) AS match_key,api.public_id('player',g.player_id) AS player_key,api.public_id('competition',cs.competition_id) AS league_key
          FROM core.matches m JOIN core.competition_seasons cs ON cs.id=m.competition_season_id JOIN core.competitions c ON c.id=cs.competition_id
          JOIN agg.player_match_grades g ON (g.season_id,g.match_id)=(m.season_id,m.id)
          JOIN agg.player_power_matches pm ON (pm.season_id,pm.match_id,pm.player_id)=(g.award_season,g.match_id,g.player_id)
          JOIN core.lineup_players lp ON (lp.season_id,lp.match_id,lp.player_id,lp.team_id)=(g.season_id,g.match_id,g.player_id,g.team_id)
          WHERE m.season_id=2025 AND m.id=ANY(%s) AND lp.position_id=11 AND lp.is_starter AND g.minutes>=80 AND g.role='goalkeeper'
          AND pm.shot_stopping IS NULL AND pm.aerial IS NULL AND pm.depth IS NULL AND pm.distribution IS NOT NULL ORDER BY m.id,g.player_id LIMIT 5""",(ids,))
        return dict(snapshot=stamp,match_ids=ids,columns=[v.name for v in c.description],rows=c.fetchall())
