"""Count guaranteed missing inputs at indicator level, after checking they cannot be restored by the deployed method."""
from vega import power as p
import hashlib,inspect

def collect(db):
    module_sha=hashlib.sha256(inspect.getsource(p).encode()).hexdigest()
    assert module_sha=='75d3b2a829b585d8dbadb60d1fb2a6b4233e7f74d220a0f76bab0ebb6fdb93ff'
    protected=set(p.ZERO_IN_MATCH+p.ZERO_IN_EDITION)
    rolespec={'outfield':p.OUTFIELD_BLOCKS,'keeper':p.KEEPER_BLOCKS}
    fields={'progressive_passes':'a','progressive_carries':'a'}
    flags={}
    for role,blocks in rolespec.items():
        for block,items in blocks.items():
            for name,kind,*etc in items:
                columns=[name]+([etc[1]] if kind=='conditional' else [])
                # Any selected NULL is irreversible under restore_zeros. For the remaining
                # indicators our count deliberately leaves the conditional restoration open.
                direct=[c for c in columns if c not in protected]
                if direct:
                    flags[role,block,name]="("+" OR ".join(fields.get(c,'s')+'.'+c+' IS NULL' for c in direct)+")"
    parts=["count(*) AS graded","count(*) FILTER(WHERE s.player_id IS NULL) AS missing_stats"]
    for (role,block,name),expr in flags.items():
        gk="g.role='goalkeeper'" if role=='keeper' else "g.role<>'goalkeeper'"
        parts.append('count(*) FILTER(WHERE '+gk+' AND '+expr+') AS '+role+'_'+name)
    anynull=" OR ".join("("+("g.role='goalkeeper'" if role=='keeper' else "g.role<>'goalkeeper'")+" AND "+expr+")" for (role,_,_),expr in flags.items())
    parts.append('count(*) FILTER(WHERE '+anynull+') AS distinct_incomplete')
    sql="SELECT g.award_season,g.role,"+",".join(parts)+"""
       FROM agg.player_match_grades g
       LEFT JOIN core.player_match_stats s ON (s.season_id,s.match_id,s.player_id)=(g.season_id,g.match_id,g.player_id)
       LEFT JOIN core.player_match_advanced a ON (a.season_id,a.match_id,a.player_id)=(g.season_id,g.match_id,g.player_id)
       WHERE g.season_id=%s GROUP BY 1,2 ORDER BY 1,2"""
    with db.transaction():
        db.execute('SET TRANSACTION ISOLATION LEVEL REPEATABLE READ READ ONLY')
        db.execute("SET LOCAL statement_timeout='100s'")
        snap=db.execute("SELECT current_database(),transaction_timestamp()::text,pg_current_snapshot()::text,current_setting('transaction_read_only'),current_setting('transaction_isolation')").fetchone()
        assert snap[0]=='vega_v2' and snap[3:]==('on','repeatable read')
        partitions={}
        for y in range(2021,2027):
            c=db.execute(sql,(y,))
            partitions[y]=dict(columns=[x.name for x in c.description], rows=c.fetchall())
            print('CHECKPOINT measured',y,flush=True)
    return dict(snapshot=snap,source_sha=module_sha,sql=sql,indicators=[list(k) for k in flags],partitions=partitions)
