"""Lecture du lot autonome Python 3.10+, sans dépôt, réseau ni dépendance tierce."""
from pathlib import Path
import collections,csv,datetime,gzip,hashlib,json,math,re,struct,types,zlib
D=Path(__file__).resolve().parent
def data(p):return (D/p).read_bytes()
def js(p):return json.loads(data(p))
def packed(p):return json.loads(zlib.decompress(data(p)))
def sha(b):return hashlib.sha256(b).hexdigest()
def table(t):return [dict(zip(t['columns'],r,strict=True)) for r in t['rows']]
def csvrows(path):return list(csv.DictReader(data(path).decode().splitlines()))
def iso(v):return datetime.datetime.fromisoformat(v)
def f32(v):return struct.unpack('!f',struct.pack('!f',v))[0]
def sig(v):return sha(json.dumps(v,sort_keys=True,separators=(',',':'),default=str).encode())
if (D/'SHA256SUMS').exists():
 for line in (D/'SHA256SUMS').read_text().splitlines():
  h,n=line.split('  ',1);assert sha(data(n))==h,n
for filename in ['sources/index.json','sources/complements-index.json']:
 for local,src in js(filename).items():
  if 'sha256' in src:assert sha(data('sources/'+local))==src['sha256'],local
for loc in ('','gardien/','indicateurs/'):
 c=js(loc+'rds/recu-public.json')
 assert c['sha256']==sha(data(loc+'rds/inputs.json.zlib')) and c['probe_sha256']==sha(data(loc+'probe.py'))
 assert c['exit_code']==0 and c['definition_end_state']=='INACTIVE'
 j=packed(loc+'rds/inputs.json.zlib');assert j['snapshot'][3:]==['on','repeatable read']
scope=js('sources/statut-revue.json');assert scope['status']=='failed' and scope['verdict_first_line']=='VERDICT: PASS' and [x['name'] for x in scope['refused_tool']]==['Glob']
for p in re.findall(r'\]\(([^)]+)\)',data('ADDENDUM.md').decode()):
 assert not p.startswith(('/','..','http:','https:')) and ((D/p).is_file() or p=='verification.json'),p
result={}
r=[x for x in csvrows('sources/psl-182.csv') if x['backfill_job']]
jobs={q['id']:q for q in table(packed('sources/psl-jobs.zlib')['jobs'])}
assert len(r)==len(set(x['match_id'] for x in r))==132
a=[];b=[]
for x in r:
 j=jobs[int(x['backfill_job'])]
 assert j['entity_id']==int(x['match_id']) and j['priority']==0 and j['last_error_code']==x['initial_parse_code']=='INVALID_REFERENCE'
 assert (j['state'],j['lane'],j['attempts'])==('done','backfill',1) and iso(j['run_after'])==iso(x['backfill_due'])
 a.append((iso(x['backfill_due'])-iso(x['initial_parse_at'])).total_seconds())
 b.append((iso(x['second_at'])-iso(x['backfill_due'])).total_seconds())
assert 86400<min(a)<86401 and 86634<max(a)<86635 and len({x['backfill_due'] for x in r})==97
result['psl']={'jobs':len(r),'distinct_due':97,'seconds_error_to_eligibility':[min(a),max(a)],'seconds_eligibility_to_fetch':[min(b),max(b)],'priority':0}
historical={};award={}
for label in ('2207','0202','0959'):
 c=collections.defaultdict(collections.Counter);hist=[];snaps=set()
 for partition in range(2021,2027):
  d=js(f'sources/{label}/award-role-{partition}.json');rows=table(d);snaps.add(d.get('snapshot',d['at']))
  periods={(x['edition_id'],x['award']):x for x in rows}
  hist.append(sum(x['no_model_role_after_award_history'] for x in rows))
  if label!='2207':
   other=js(f'sources/{label}/player-pending-{partition}.json');assert other['snapshot']==d['snapshot']
   for x in table(other):
    y=periods[x['edition_id'],x['award']]
    assert x['pending_inputs']==y['pending'] and x['definitely_assignable_role']==y['current_assignable']
    for k in ('pending','current_assignable','recovered_by_award_history','no_model_role_after_award_history'):c[x['award']][k]+=y[k]
 historical[label]=hist
 if label!='2207':
  assert len(snaps)==1
  if award:assert award==c
  award=c
assert historical['2207']==[15,113,275,88,1185,58] and historical['0202']==historical['0959']==[30,113,275,88,88,21]
assert (award[2020]['current_assignable'],award[2020]['recovered_by_award_history'])==(14411,7)
ann=csvrows('sources/recalcul-annees.csv')
for q in ann:
 y=int(q['award']);assert award[y]['pending']==int(q['admitted'])-int(q['computable_published'])
 assert award[y]['no_model_role_after_award_history']==int(q['no_role'])
assert sum(int(q['admitted']) for q in ann)==2297613
result['sans_poste_par_partition']=historical;result['ventilation_par_annee']=dict(sorted(award.items()))
z=packed('sources/support-0712.zlib')
gaps=collections.Counter();keepers=collections.Counter();blocks=collections.Counter()
for t in z['support'].values():
 for x in table(t):
  g=x['role']=='goalkeeper';y=x['award_season'];n=x['graded']
  if g:keepers[y]+=n;gaps[y]+=x['no_stopping']
  blocks[g,x['measured_blocks']]+=n
  assert not any(x[k] for k in ('no_stats_row','missing_or_wrong_power','unmeasured_touches'))
assert sum(blocks.values())==2282580 and sum(gaps.values())==104716 and blocks[False,4]==76 and blocks[True,1]==52665
assert sum(x['both_primitives'] for x in js('sources/support-0727.json')['rows'] if x['blocks']==3)==47990
inds=packed('indicateurs/rds/inputs.json.zlib');ic=collections.Counter();ic_year=collections.Counter();ic_byrole=collections.Counter()
for tab in inds['partitions'].values():
 for r in table(tab):
  ic.update({k:n for k,n in r.items() if k not in ('award_season','role')})
  ic_year[r['award_season']]+=r['distinct_incomplete'];ic_byrole[r['role']=='goalkeeper']+=r['distinct_incomplete']
assert len(inds['indicators'])==14 and ic['graded']==2282580 and ic['missing_stats']==0 and ic['distinct_incomplete']==578928
assert ic['outfield_progressive_passes']==ic['outfield_progressive_carries']==ic_byrole[False]==474102
result['gardiens']={y:[gaps[y],n] for y,n in sorted(keepers.items())};result['indicateurs']={'union_par_annee':dict(sorted(ic_year.items())),'union_gardiens':ic_byrole[True],'comptes_non_additifs':ic}
x=packed('rds/inputs.json.zlib')
assert x['calendar']['rows']==[[False,40,10438,10438,'2020-06-16','2021-07-11']] and x['empty']['rows']==[[0,0,0,0]]
assert [q['id'] for q in table(x['levels'])]==[439]
runs=table(x['players'])
assert [q['id'] for q in runs]==[44,1230,1403,1563,1722,1886] and all(q['matches']==q['players']==0 for q in runs)
logs=js('journaux.json');logged=[]
for q,l in zip(runs,logs):
 good=[e for e in l['allowed'] if e['message']==f"player ranking season=2020 method={q['method_version']} players=0"]
 if good:
  assert len(good)==1 and abs((iso(good[0]['at'])-iso(q['finished_at'])).total_seconds())<0.16
  logged.append(q['id'])
 else:assert q['id']==44 and l['returned']==0
assert logged==[1230,1403,1563,1722,1886] and len(logs)==8 and all(e['allowed'] for e in logs[6:])
result['calendrier_2020']=x['calendar']['rows'];result['runs_obsoletes_confirmes']=logged
m=types.ModuleType('methode');src=data('sources/methode.py')
d=packed('sources/2020-inputs.zlib');assert sha(src)==d['module_sha256']
exec(compile(src,'methode', 'exec'),m.__dict__)
rows=[dict(zip(d['columns'],q,strict=True)) for q in d['inputs']]
for r in rows:r['delta']=0. if r['own_elo'] is None or r['opponent_elo'] is None else (r['opponent_elo']-r['own_elo'])/400
m.restore_zeros(rows);assigned=m.assign_roles(rows);ref=m.references(assigned);cs=[m.match_contribution(r,ref)[1] for r in assigned]
gr=m.grade_references([(r['role'],r['competition_id'],r['minutes_played'],c) for r,c in zip(assigned,cs)])
indexes=[m.match_index(r['role'],r['competition_id'],c,gr) for r,c in zip(assigned,cs)]
assert len(rows)==14427 and len(indexes)==14418 and all(v is not None for v in indexes) and d['persisted']==[0,0]
b=next((r,z) for r,z in zip(assigned,indexes) if (r['match_id'],r['player_id'])==(237352,1937));assert b[0]['role']=='winger' and 1.1825<b[1]<1.1826
result['rejeu_2020']={'admis':len(rows),'calculables':len(indexes),'publies':0,'indice_hypothetique_Bulter':b[1]}
samples={}
for n,pk,grade in [('2020','p_0Aym4b',None),('distribution','p_0rvsP3',73.81194135866967),('titulaire','p_3MeIA2',37.91148581311845)]:
 folder='http-titulaire' if n=='titulaire' else 'http';obs={}
 for kind in ('classement','famille','performance'):
  base=f'{folder}/{n}-{kind}'
  meta=js(base+'.receipt.json');raw=gzip.decompress(data(base+'.json.gz'));assert sha(raw)==meta['sha256'] and len(raw)==meta['bytes']
  payload=json.loads(raw);status=meta['status'];assert status==(404 if n=='2020' and kind=='classement' else 200)
  if kind=='performance':q=payload['data']['row'];assert q['playerId']==pk and q['grade']==grade;value=q['grade']
  elif kind=='famille':
   q=next(v for v in payload['data'] if v['player']['id']==pk)
   vals=[a['stat']['value'] for f in q['stats'] for a in f['stats'].values() if a.get('key')=='vega_grade']
   assert (len(vals)==0 if grade is None else len(vals)==1 and abs(vals[0]-grade)<1e-10);value=vals
  elif status==404:assert payload['error']['code']=='RESOURCE_NOT_FOUND';value=payload['error']['code']
  else:q=next(v for v in payload['grades'] if v['playerId']==pk);assert q['grade']==round(grade,1);value=q['grade']
  obs[kind]=dict(status=status,at=meta['at'],value=value,bytes=len(raw),sha256=meta['sha256'])
 samples[n]=obs
keeper=next(q for q in table(packed('gardien/rds/inputs.json.zlib')) if q['player_key']=='p_3MeIA2')
assert keeper['position_id']==11 and keeper['is_starter'] and keeper['minutes']==90 and keeper['distribution'] is not None and all(keeper[k] is None for k in ('shot_stopping','aerial','depth'))
result['http']=samples
top=js('sources/temoins-32.json');ref0=js('sources/reference-0259.json')
assert len(top)==32 and len({x['match'] for x in top})==24 and {x['edition'] for x in top}=={912} and {x['run_id'] for x in top}=={2095}
byedition=csvrows('sources/reference-editions.csv');assert next(q for q in byedition if q['edition']=='912' and q['award']=='2026')['grade_gap_over_0.1']=='541'
assert js('sources/ancienne-grille.json')['known_population']['player']['known_participations_minimum']==2260025
orig={(r[4],r[1],r[2]):r for r in ref0['worst']+list(ref0['worst_by_award'].values())}
for f in ('sources/0554/inputs.json.zlib','sources/0714-inputs.zlib'):
 d=packed(f);assert d['hashes']==ref0['reference_hashes']=={y:sig(ref) for y,ref in d['references'].items()}
 assert len(d['witnesses'])==len(orig)==37
 for year,award,comp,edition,ref,mid,pid,role,p_role,c,z,pz,run,prun in d['witnesses']:
  o=orig[year,mid,pid];assert (f32(c),f32(z),run)==(f32(o[9]),f32(o[10]),o[14])
result['references']={'plus_grands_ecarts':32,'matchs_distincts':24,'edition':912,'temoins_communs':37,'empreintes_annuelles':5}
final=json.dumps(result,ensure_ascii=False,sort_keys=True,indent=2)+'\n'
if (D/'verification.json').exists():assert js('verification.json')==json.loads(final)
print(final,end='')
