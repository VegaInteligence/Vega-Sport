def collect(db):
    def table(sql, args=()):
        c=db.execute(sql,args)
        return dict(columns=[v.name for v in c.description], rows=c.fetchall())
    with db.transaction():
        db.execute("SET TRANSACTION ISOLATION LEVEL REPEATABLE READ READ ONLY")
        db.execute("SET LOCAL statement_timeout='45s'")
        snap=db.execute("SELECT current_database(),transaction_timestamp()::text,pg_current_snapshot()::text,current_setting('transaction_read_only'),current_setting('transaction_isolation')").fetchone()
        assert snap[0]=='vega_v2' and snap[3:]==('on','repeatable read')
        out=dict(snapshot=snap)
        out['calendar']=table("""SELECT cs.archive_key IS NULL AND cs.cup_key IS NULL AS native,
          count(DISTINCT cs.id) AS editions, count(m.id) AS fixtures, count(m.id) FILTER(WHERE m.status='finished') AS finished,
          min(m.match_date) AS first_date,max(m.match_date) AS last_date
          FROM core.competition_seasons cs LEFT JOIN core.matches m ON m.competition_season_id=cs.id AND m.season_id=2020
          WHERE cs.season_id=2020 GROUP BY 1 ORDER BY 1""")
        out['levels']=table("""SELECT id,status,model_version,started_at,finished_at,cohort_definition FROM agg.calc_runs
          WHERE kind='levels' AND cohort_definition='season:2020' ORDER BY id""")
        out['players']=table("""SELECT id,season_id,method_version,status,started_at,finished_at,matches,players FROM agg.power_runs
          WHERE kind='players' AND season_id=2020 ORDER BY id""")
        out['before_1886']=table("""SELECT id,kind,season_id,method_version,status,started_at,finished_at,matches,players FROM agg.power_runs
          WHERE id BETWEEN 1880 AND 1888 ORDER BY id""")
        out['empty']=table("""SELECT (SELECT count(*) FROM core.player_match_stats WHERE season_id=2020) AS stats,
          (SELECT count(*) FROM agg.player_match_grades WHERE award_season=2020) AS grades,
          (SELECT count(*) FROM agg.player_power_matches WHERE season_id=2020) AS intermediates,
          (SELECT count(*) FROM agg.player_power WHERE season_id=2020) AS ranks""")
        out['witnesses']=table("""SELECT m.season_id,m.id AS match_id,m.competition_season_id,cs.competition_id,c.name AS competition,m.match_date,
          s.player_id,s.team_id,s.minutes_played,s.touches,lp.position_id,s.position_id AS stats_position,lp.is_starter,lp.shirt_number,
          g.award_season,g.run_id,g.role,g.z,pm.shot_stopping,pm.aerial,pm.depth,pm.distribution,
          api.public_id('match',m.id) AS match_key,api.public_id('player',s.player_id) AS player_key,api.public_id('competition',c.id) AS league_key,
          api.public_id('team',s.team_id) AS team_key,api.floor_dummy FROM core.matches m
          JOIN core.competition_seasons cs ON cs.id=m.competition_season_id JOIN core.competitions c ON c.id=cs.competition_id
          JOIN core.player_match_stats s ON (s.season_id,s.match_id)=(m.season_id,m.id)
          LEFT JOIN core.lineup_players lp ON (lp.season_id,lp.match_id,lp.player_id)=(s.season_id,s.match_id,s.player_id)
          LEFT JOIN agg.player_match_grades g ON (g.season_id,g.match_id,g.player_id)=(s.season_id,s.match_id,s.player_id)
          LEFT JOIN agg.player_power_matches pm ON (pm.season_id,pm.match_id,pm.player_id)=(g.award_season,g.match_id,g.player_id)
          WHERE (m.season_id,m.id,s.player_id)=(2021,237352,1937) OR ((m.season_id,m.id)=(2025,50956) AND g.role='goalkeeper' AND pm.shot_stopping IS NULL
            AND pm.aerial IS NULL AND pm.depth IS NULL AND pm.distribution IS NOT NULL) ORDER BY 1,2,7""".replace(',api.floor_dummy','').replace(',lp.shirt_number',''))
        return out
