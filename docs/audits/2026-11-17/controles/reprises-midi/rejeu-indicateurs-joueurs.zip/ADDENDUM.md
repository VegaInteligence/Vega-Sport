# Notes joueurs — rectificatif scientifique T5, version 1

**18 novembre 2026, heures UTC.** Sur 2 297 613 entrées admises, 2 282 580 notes sont persistées. Parmi les 15 033 manquantes, le rejeu de la méthode déployée calcule un indice sur 14 418 entrées, toutes de l’année de notation 2020. Les 615 autres restent sans poste pour le moteur. Parmi les notes publiées, au moins 104 792 ont un bloc entier absent. Un nouveau contrôle par indicateur relève **578 928 notes distinctes (25,36 %) avec au moins un indicateur indisponible dans les entrées conservées**. Chaque borne répond à sa propre question. Leur somme compterait des notes deux fois. [Recalcul par année](sources/recalcul-annees.csv) · [Bloc et observations](sources/support-0712.csv) · [Mesure par indicateur](indicateurs/rds/inputs.json.zlib)

Ce texte remplace les formulations signalées dans le rapport T5, ses exigences et son plan. Le résultat textuel « PASS » de Fable porte sur le rapport précédent. Son exécution du 18 novembre à 11:41 a tenté un Glob externe refusé et reste invalide pour la procédure de double revue. La prochaine revue dispose des données référencées ici dans le même dossier. [Reçu de portée](sources/statut-revue.json)

## 1. Mise en attente puis reprise des 132 compositions PSL

Le worker place une tâche en échec définitif pour la tentative courante après `INVALID_REFERENCE`. Son planificateur ordinaire, y compris dans le code du 10 novembre, remet automatiquement en attente après 24 heures les erreurs absentes de sa liste permanente. Il remet les tentatives à zéro, inscrit son heure dans `run_after` et conserve le code. La prise de tâche incrémente les tentatives, l’acquittement préserve le code. La seconde voie de réveil du dépôt, `enqueue_or_revive`, efface le code. [Planificateur](sources/code/planner.py.txt) · [Worker](sources/code/worker.py.txt) · [Transitions de la file](sources/code/jobs.py.txt) · [Version du 10 novembre](sources/code/reveil-historique.txt)

Pour les **132 mêmes cibles** en édition 911, les erreurs de parsing précèdent les 97 valeurs distinctes de `run_after` de **24 h + 0,602 à 234,576 s**. Les 132 tâches conservées sont `backfill/done`, priorité **0**, une tentative et `INVALID_REFERENCE` conservé. Les logs du service backfill nomment les tâches 141722 et 350220 aux deux extrémités de la série d’échecs. Les observations identifient la réactivation automatique parmi les chemins du code examiné. La base conserve l’état terminal, sans journal de chaque UPDATE ou identité de session. [132 horodatages dans les 182 rencontres](sources/psl-182.csv) · [Tâches avec priorité](sources/psl-jobs.zlib) · [Logs bornés](journaux.json)

Distinguer le réveil des 11–13 novembre de **l’exécution le 18 entre 00:36:13 et 00:39:03**. Chaque fetch de composition suit sa propre échéance de **4 j 14 h 17 min à 6 j 1 h 14 min** (397 073 à 522 889 s). L’ordre des claims tient compte de la priorité, de l’échéance et de la clé. L’état des compétiteurs de la file et la capacité de consommation pendant ces jours restent indéterminés. La classe PSL sans poste passe de 1 110 à 14. La contribution marginale d’une tâche à la baisse et au référentiel de 2025 reste sans préimage individuelle. [Chronologie des rencontres](sources/psl-182.csv)

## 2. Dater la ventilation des 15 033 absences

La table initiale des absences vient de la transaction **02:02:22.142267, MVCC 4403005**. À **07:12:11**, le SQL relit les notes, leurs blocs, les quatre tables 2020 et le détail PSL. Le champ des absences par année placé à côté de ce snapshot dans le récapitulatif provient de 02:02. **07:27:24** date le détail gardiens par édition. La grille de **09:59:37.120414, MVCC 4426165**, remesure la même ventilation via ses six partitions et confirme le total des notes. [Table originelle](sources/division-par-annee-0202.json) · [Lecture 07:12](sources/support-0712.zlib) · [Gardiens 07:27](sources/support-0727.json) · [Grille 09:59](sources/grille-0959.txt)

| Année de notation | Admis | Notes | Sans note, rôle direct | Sans note, rôle récupéré | Sans poste |
| --- | ---: | ---: | ---: | ---: | ---: |
| 2020 | 14 427 | 0 | 14 411 | 7 | 9 |
| 2021 | 202 979 | 202 911 | 0 | 0 | 68 |
| 2022 | 265 707 | 265 572 | 0 | 0 | 135 |
| 2023 | 370 490 | 370 276 | 0 | 0 | 214 |
| 2024 | 561 558 | 561 464 | 0 | 0 | 94 |
| 2025 | 652 977 | 652 902 | 0 | 0 | 75 |
| 2026 | 229 475 | 229 455 | 0 | 0 | 20 |
| **Total** | **2 297 613** | **2 282 580** | **14 411** | **7** | **615** |

Le lecteur hors ligne regroupe à nouveau les fichiers des deux transactions par année août–juillet. Les années de partition SQL sont conservées séparément. [Capture 02:02](sources/0202/award-role-2021.json) · [Capture 09:59](sources/0959/award-role-2021.json) · [Sources des six partitions](sources/index.json)

## 3. Remplacer l’explication de la file 2021 par le délai de six heures

Les 14 418 entrées avec poste de la partition SQL 2021 appartiennent au millésime 2020 et précèdent le 1er août 2021. Une nouvelle passe ordinaire sur 2021 les laisse en dehors du calcul lorsque la partition 2020 ne contient aucune statistique joueur. Les deux lectures de la sélection native et le rejeu hors ligne intégral les retrouvent toutes calculables. Les 23 témoins ponctuels examinés avant l’échéance du 18 à 00:03 conservent la portée de cette observation datée. L’explication par un simple délai de six heures doit être retirée pour le stock à poste connu du millésime 2020. [Garde du calcul](sources/code/power.py.txt) · [Rejeu de 14 427 entrées](sources/recalcul-2020.json) · [Contrôle du trajet ordinaire et du changement de version sous PG18](sources/2020-grades-pg18.json)

## 4. Préciser le niveau de support statistique

À 07:12, **au moins 104 792 notes** manquent d’un bloc entier, dont 104 716 gardiens sans bloc arrêts (52 665 avec la distribution seule et 52 051 avec trois blocs), plus 76 joueurs de champ à quatre blocs. Les 2 125 438 joueurs de champ avec cinq blocs ont au moins un indicateur utilisable dans chacun des blocs de trois à neuf. Un bloc présent peut reposer sur un seul indicateur. Les 52 350 autres gardiens ont quatre blocs. À 07:27, 47 990 des 52 051 gardiens à trois blocs ont les deux primitives de `goals_prevented` et la valeur directement lue reste nulle. [Agrégats de blocs](sources/support-0712.csv) · [Primitives du gardien](sources/support-0727.json) · [Règle de mesure](sources/code/power.py.txt)

| Année | Gardiens sans bloc arrêts | Notes de gardiens | Part | Notes tous rôles avec un indicateur directement manquant à 11:58 |
| --- | ---: | ---: | ---: | ---: |
| 2021 | 13 551 | 13 743 | 98,6 % | 142 585 |
| 2022 | 16 791 | 17 711 | 94,8 % | 173 704 |
| 2023 | 23 274 | 24 564 | 94,7 % | 169 982 |
| 2024 | 19 640 | 36 986 | 53,1 % | 41 927 |
| 2025 | 24 567 | 49 039 | 50,1 % | 36 405 |
| 2026 | 6 893 | 15 023 | 45,9 % | 14 325 |
| **Total** | **104 716** | **157 066** | **66,7 %** | **578 928** |

À **11:58:15 UTC**, le contrôle VI-21 examine les 2 282 580 notes des six partitions, avec zéro ligne de statistiques manquante. Il teste 14 indicateurs par type de rôle, huit pour le champ et six pour le gardien, lorsque le numérateur ou le dénominateur obligatoire peut rester définitivement nul après `restore_zeros`. Les 474 102 joueurs–matchs de champ concernés cumulent l’absence des passes et des conduites progressives. Parmi les 104 826 gardiens concernés, 104 716 manquent de buts évités et 4 647 de l’indicateur de passes longues. Les populations d’indicateurs se recoupent. L’union distincte donne la dernière colonne. D’autres indicateurs dépendent du rétablissement des zéros ou de l’existence d’une référence ajustée. La mesure porte sur les entrées relues, avec leur état au 18 novembre. Elle ne reconstitue pas la matière exacte du jour de publication et ne juge pas la validité de chaque note. [Requête et règles d’inclusion](indicateurs/probe.py) · [Résultats par partition, année et rôle](indicateurs/rds/inputs.json.zlib)

## 5. Documenter l’année native 2020 et le préalable du classement 2021

À **11:57:01 UTC**, la partition SQL 2020 compte **40 éditions archives ou coupes et 10 438 matchs terminés, zéro édition et zéro match natifs** selon la double condition `archive_key IS NULL AND cup_key IS NULL`. Les quatre décomptes sont nuls pour les statistiques de partition 2020, les contributions et notes du millésime, et le classement annuel 2020. Le réveil de `due_seasons` par des matchs natifs de cette partition est donc inopérant dans cette population. Un run `levels` portant `season:2020` existe, **439 le 9 novembre à 13:49:33**. [SQL et témoin](probe.py) · [Transaction 11:57](rds/inputs.json.zlib) · [Sélection du planificateur](sources/code/worker.py.txt)

Les six runs joueurs conservés du millésime sont **44/v1, 1230/v4, 1403/v5, 1563/v6, 1722/v7, 1886/v8**, tous à zéro match et zéro joueur. Les logs du worker portent la ligne exclusivement émise par le traitement des classements obsolètes, à moins de 0,16 s de la fin de chacun des cinq derniers. Le prédécesseur direct de 1886 est 1722. Le premier 44 a démarré à 13:49:33 le 9 novembre, dans la même seconde que 439. Le filtre CloudWatch ne trouve aucune ligne correspondante dans les ±5 s de sa fin. Son appelant initial demeure indéterminé. [Journal des six fenêtres](journaux.json) · [Émission du message du worker](sources/code/worker.py.txt)

La garde préserve volontairement le **classement annuel** d’une première demi-saison européenne incomplète. L’exigence de notes de match compte néanmoins les 14 418 notes absentes. Une publication 2020 par le chemin complet établirait aussi sa calibration sur cette partie de saison. Si elle peuple le classement `player_power`, ses indices saisonniers utilisables deviendraient les antécédents lus lors d’un nouveau classement 2021. Le changement de classement individuel qui en résulterait reste à mesurer. VI-21 conserve ces deux décisions distinctes. [Garde, calibration et lecture de l’année précédente](sources/code/power.py.txt) · [Rejeu local premier millésime](sources/2020-grades-pg18.json)

## 6. Mesurer les deux comportements publics

| Clé publique et témoin | Fiche performance | Famille joueurs du match | Classement du match |
| --- | --- | --- | --- |
| Jonas Dakir, `m_3dVygI:p_3MeIA2`, titulaire, 90 min, position 11 | HTTP 200, 37,91148581311845 | HTTP 200, `vega_grade` 37,9114858131185 | HTTP 200, 37,9 |
| Marius Bülter, `m_1ZaiLN:p_0Aym4b`, 90 min, Schalke 04, 23 juillet 2021, millésime 2020 | HTTP 200, `grade=null`, `gradeZ=null` | HTTP 200, joueur présent, champ `vega_grade` absent | HTTP 404, `RESOURCE_NOT_FOUND` |

Chez Dakir, le seul bloc conservé est la distribution (−0,6628181). La fiche affiche une note, le classement l’arrondit à une décimale. Les champs de note des trois réponses omettent le nombre et le nom des blocs utilisés. Le champ statistique `row.blocks=0` compte des actions du joueur. Le témoin Bülter a 35 touches et un poste de titulaire 107. Le rejeu lui attribue le rôle d’ailier et calcule un indice. La fiche utilise la saison publique `2021/2022`, l’année de notation se termine en juillet 2021. Ces GET établissent les deux cas individuels. [Dakir, performance](http-titulaire/titulaire-performance.receipt.json) · [Dakir, famille](http-titulaire/titulaire-famille.receipt.json) · [Dakir, classement](http-titulaire/titulaire-classement.receipt.json) · [Bülter, performance](http/2020-performance.receipt.json) · [Bülter, famille](http/2020-famille.receipt.json) · [Bülter, classement](http/2020-classement.receipt.json) · [Sélection RDS de titulaires](gardien/rds/inputs.json.zlib)

## 7. Journal de chantier

Le WORKLOG modifié dans le checkout de la piste reste un journal de travail local. Il est exclu du paquet de revue et de la fusion documentaire. Le journal partagé et les décisions existantes VI-21 à VI-26 conservent leur propre historique. Les citations du rectificatif utilisent des fichiers relatifs. [Index des pièces](sources/index.json)

## 8. Localiser les 32 écarts de référence

Les 32 plus grands écarts tiennent dans **24 matchs distincts, tous de l’édition PSL 912**, compétition 195, saison de notation 2026, référence 2025, publication 2095. Les IDs vont de 47187 à 47252. Les rôles sont 21 ailiers et 11 défenseurs centraux. La totalité de l’édition compte 2 146 notes, dont **541** dépassent 0,1 point lors du rejeu à contribution conservée, sur 550 au total. La PSL **911** des 132 compositions relève du millésime **2025**. Cette proximité ne mesure pas sa contribution causale aux écarts de 912. À contribution 2026 actuelle fixée, le remplacement de la référence 2025 conservée par son recalcul actuel fait bouger les notes d’au plus 0,00309234 point. L’ancienne référence utilisée à la publication 2095 reste inconnue. [32 clés et bornes](sources/temoins-32.json) · [Table par édition](sources/reference-editions.csv) · [Contraste ultérieur](sources/rejeu-ascendant.json)

## 9. Dater les autres mouvements, corriger « présences » et joindre la capture 05:54

Du 17 novembre vers 22:07 aux mesures du 18 à 02:02 et 09:59, le nombre de clés sans rôle évolue, par **partition SQL** (2021 à 2026), de **15 / 113 / 275 / 88 / 1 185 / 58** à **30 / 113 / 275 / 88 / 88 / 21**. L’ensemble passe de **1 734 à 615**. La PSL explique 1 096 de la diminution nette de 1 119. Hors PSL, le solde de −23 combine +15, −37 et −1. Les premières lectures de partitions ont des heures distinctes. Les deux grilles ultérieures ont chacune un snapshot commun. Ces agrégats ne désignent pas les anciennes personnes. [Relevé initial](sources/2207/award-role-2021.json) · [Relevés atomiques](sources/index.json)

Dans le plan historique, remplacer « 2 260 025 présences » par **« 2 260 025 clés match–joueur portant au moins un indice de participation dans le relevé historique »**. Des erreurs de liaison ou des omissions empêchent d’en déduire un dénominateur de personnes effectivement entrées. Pour le support ou les absences, utiliser les populations datées du présent tableau. [Ancienne grille et nom historique de la colonne](sources/ancienne-grille.json)

La pièce de **05:54:29.964241** est désormais jointe. Les cinq empreintes de référence et les 37 clés ciblées communes gardent leurs contributions, indices publiés en binary32 et identifiants de publication entre 02:59:53, 05:54:29 et 07:14:29. Le dernier passage n’observe pas de nouvelle publication 2026 entre ces relevés. [Entrées 05:54](sources/0554/inputs.json.zlib) · [Comparaison 05:54](sources/0554/comparison.json) · [Comparaison 07:14](sources/0714-comparaison.json)

**Reproduction locale du rectificatif.** Extraire le paquet puis exécuter `python3 -B verifier.py` à sa racine. Le contrôle vérifie les empreintes, les deux tables annuelles, la chronologie PSL, les classements 2020, les réponses HTTP, les 32 clés, les cinq références et les 37 valeurs. VI-21 conserve l’ingestion, le choix d’éligibilité et les effets sur le classement. VI-19 conserve les usages prédictifs. [Résultats du rejeu](verification.json)
