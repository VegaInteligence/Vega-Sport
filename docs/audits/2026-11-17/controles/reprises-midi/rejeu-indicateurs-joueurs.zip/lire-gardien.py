import importlib.util,sys,json,zlib
from pathlib import Path
from concurrent.futures import ThreadPoolExecutor
base=Path(__file__).resolve().parent
spec=importlib.util.spec_from_file_location('http_read',base/'lire-http.py')
module=importlib.util.module_from_spec(spec)
spec.loader.exec_module(module)
module.target=Path(sys.argv[1]);module.target.mkdir(exist_ok=True)
assert not any(module.target.iterdir())
g=json.loads(zlib.decompress((base/'gardien/rds/inputs.json.zlib').read_bytes()))
x=dict(zip(g['columns'],g['rows'][0]));assert x['is_starter'] and x['minutes']==90 and x['position_id']==11
m=x['match_key'];p=x['player_key'];l=x['league_key']
with ThreadPoolExecutor(max_workers=3) as pool:
 list(pool.map(module.run,[('titulaire-performance','/api/read/performance',dict(season='2025/2026',league=l,appearance=m+':'+p)),('titulaire-famille','/api/matches/'+m+'/players',{}),('titulaire-classement','/api/rankings/match',dict(match=m))]))
