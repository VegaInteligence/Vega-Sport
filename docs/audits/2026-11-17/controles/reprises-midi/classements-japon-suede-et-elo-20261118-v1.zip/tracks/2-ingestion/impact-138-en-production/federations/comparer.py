"""Compare chaque ligne publiée avec celle de la fédération, sans faire de rapprochement flou."""
import csv,hashlib,json,re,unicodedata,zlib
from datetime import datetime
from pathlib import Path
from collections import Counter
p=Path(__file__).resolve().parent
db=p.parent/'sur-copie/rds-detail-1217/inputs.json.zlib'
raw=json.loads(zlib.decompress(db.read_bytes()))
def table(k):return [dict(zip(raw[k]['columns'],row)) for row in raw[k]['rows']]
def read(name):return json.loads((p/name).read_bytes())
def normal(v):return ''.join(c for c in unicodedata.normalize('NFKC',v).casefold() if c.isalnum())
aliases={normal(k):normal(v) for k,v in {
    'IK Sirius':'Sirius','BK Häcken':'Häcken','IF Elfsborg':'Elfsborg','BP':'Brommapojkarna',
    'Mjällby AIF':'Mjällby','Degerfors IF':'Degerfors','Örgryte IS':'Örgryte',
    'FC Machida Zelvia':'Machida Zelvia','Urawa Reds':'Urawa Red Diamonds','Fagiano Okayama':'Fagiano Okayama FC',
    'Yokohama F･Marinos':'Yokohama F.Marinos'}.items()}
fields=['position','played','won','drawn','lost','goals_for','goals_against','points']
official={}
swe=read('swe-classement-source.json')['standings']
assert len(swe)==16 and {f['configSeasonStartYear'] for t in swe for f in t['form']}=={2026}
for t in swe:
    st={x['name']:int(x['value']) for x in t['stats']}
    official[15,aliases.get(normal(t['teamName']),normal(t['teamName']))]=(t['teamName'],[t['position'],*[st[k] for k in ('gp','w','t','l','gf','ga','pts')]])
japan=[r for r in read('jpn-classement-navigateur.json')['rows'] if r and r[0].isdigit() and len(r)==12]
assert len(japan)==20
for r in japan:
    name=r[1];key=normal(name)
    official[22,aliases.get(key,key)]=(name,[int(r[i]) for i in (0,4,5,6,7,8,9,3)])
assert len(official)==36
rounds={r['id']:r['stage'] for r in table('rounds')}
def qualified(m):return (rounds.get(m['round_id']) or 'regular') in ('regular','group')
kicks=Counter();completed=Counter();physical=Counter()
at=datetime.fromisoformat(raw['at'])
for m in table('matches'):
    ed=m['competition_season_id']
    if ed not in (15,22):continue
    physical[ed]+=1
    if not qualified(m):continue
    for team in (m['home_team_id'],m['away_team_id']):
        if m['kickoff_at'] and datetime.fromisoformat(m['kickoff_at'])<=at:kicks[ed,team]+=1
        if m['status']=='finished' and m['home_score'] is not None and m['away_score'] is not None:completed[ed,team]+=1
rows=[]
for r in sorted(table('standings'),key=lambda x:(x['competition_season_id'],x['position'])):
    ed=r['competition_season_id']
    if ed not in (15,22):continue
    name,values=official[ed,normal(r['team_name'])]
    nums=[r[f] for f in fields]
    ck=kicks[ed,r['team_id']]
    rows.append(dict(edition=ed,team_id=r['team_id'],nom_vega=r['team_name'],nom_officiel=name,source=r['source'],as_of=r['as_of'],
                     **{f:v for f,v in zip(fields,nums)},matches_commences_qualifies_vega=ck,finis_vega=completed[ed,r['team_id']],
                     champs_divergents=','.join(f for f,a,b in zip(fields,nums,values) if a!=b),
                     officiel='|'.join(map(str,values)),refus_regle_11=r['played']>ck+4))
assert len(rows)==36 and len({(r['edition'],r['team_id']) for r in rows})==36
with (p/'36-clubs.csv').open('w',newline='') as f:
    w=csv.DictWriter(f,list(rows[0]),lineterminator='\n');w.writeheader();w.writerows(rows)
result={'rds':raw['at'],'snapshot':raw['snapshot'],'sha256_rds':hashlib.sha256(db.read_bytes()).hexdigest(),'mesures':{}}
for ed in (15,22):
    selection=[r for r in rows if r['edition']==ed]
    result['mesures'][ed]={'clubs':len(selection),'rencontres_vega_tous_statuts':physical[ed],'commences_qualifies_min':min(r['matches_commences_qualifies_vega'] for r in selection),'commences_qualifies_max':max(r['matches_commences_qualifies_vega'] for r in selection),'joues_officiels':sorted({int(r['officiel'].split('|')[1]) for r in selection}),'numerateurs_regle_11':sum(r['refus_regle_11'] for r in selection),'toutes_statistiques_identiques':sum(not r['champs_divergents'] for r in selection),'differences':{r['nom_vega']:r['champs_divergents'] for r in selection if r['champs_divergents']}}
(p/'comparaison.json').write_text(json.dumps(result,ensure_ascii=False,indent=2)+'\n')
print(json.dumps(result,ensure_ascii=False))
