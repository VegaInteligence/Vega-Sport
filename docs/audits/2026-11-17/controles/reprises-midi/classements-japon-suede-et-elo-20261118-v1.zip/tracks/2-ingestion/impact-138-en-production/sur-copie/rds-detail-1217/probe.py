from time import perf_counter
IDS = [1, 2, 3, 4, 5, 8, 9, 10, 11, 12, 13, 14, 15, 16, 17, 19, 20, 21, 22, 23, 24, 25, 26, 27, 29, 30, 33, 34, 35, 36, 39, 40, 42, 43, 44, 46, 47, 51, 52, 53, 54, 55, 56, 57, 58, 265, 266, 267, 760, 766, 772, 797, 812, 882, 894, 897, 908, 912, 941, 1004]

def collect(db):
    with db.transaction():
        db.execute("SET TRANSACTION ISOLATION LEVEL REPEATABLE READ READ ONLY")
        stamp, snap, ro, ver = db.execute("SELECT transaction_timestamp(),pg_current_snapshot()::text,current_setting('transaction_read_only'),version()").fetchone()
        assert ro == 'on'
        out = {'at': str(stamp), 'snapshot': snap, 'read_only': ro, 'server_version': ver, 'edition_ids': IDS, 'queries': {}}
        def get(name, query, params=()):
            t = perf_counter(); cur = db.execute(query, params)
            out[name] = {'columns': [c.name for c in cur.description], 'rows': cur.fetchall()}
            out['queries'][name] = {'sql': query, 'params': params, 'elapsed_seconds': perf_counter()-t}
        get('official', 'SELECT * FROM core.standings_official WHERE competition_season_id = ANY(%s) ORDER BY id', (IDS,))
        get('aggregate', 'SELECT * FROM agg.standings WHERE competition_season_id = ANY(%s) ORDER BY id', (IDS,))
        get('matches', 'SELECT id,competition_season_id,season_id,round_id,status,home_team_id,away_team_id,home_score,away_score,first_finished_at,kickoff_at,match_date,source,revision,updated_at FROM core.matches WHERE competition_season_id = ANY(%s) ORDER BY season_id,id', (IDS,))
        get('rounds', 'SELECT id,competition_season_id,name,stage FROM core.rounds WHERE competition_season_id = ANY(%s) OR id IN (SELECT round_id FROM core.matches WHERE competition_season_id = ANY(%s)) ORDER BY id', (IDS, IDS))
        get('editions', 'SELECT id,competition_id,season_id,native_label,is_current FROM core.competition_seasons WHERE id = ANY(%s) ORDER BY id', (IDS,))
        comps = sorted({r[1] for r in out['editions']['rows']}); seasons = sorted({r[2] for r in out['editions']['rows']})
        get('competitions', 'SELECT id,name FROM core.competitions WHERE id = ANY(%s) ORDER BY id', (comps,))
        get('seasons', 'SELECT id,label FROM core.seasons WHERE id = ANY(%s) ORDER BY id', (seasons,))
        teamids = set()
        for name in ('official','aggregate'):
            ix = out[name]['columns'].index('team_id'); teamids.update(r[ix] for r in out[name]['rows'])
        for r in out['matches']['rows']: teamids.update((r[5],r[6]))
        teamids = sorted(t for t in teamids if t is not None)
        get('teams', 'SELECT id,name,crest_asset_id FROM core.teams WHERE id = ANY(%s) ORDER BY id', (teamids,))
        assets = sorted({r[2] for r in out['teams']['rows'] if r[2] is not None})
        get('assets', 'SELECT id,kind,source_url,s3_key FROM core.assets WHERE id = ANY(%s) ORDER BY id', (assets,))
        get('provider_ids', "SELECT entity_type,provider,provider_key,entity_id,is_current FROM core.provider_ids WHERE (entity_type='team' AND entity_id = ANY(%s) AND provider IN ('pitchapi','uefa')) OR (entity_type='competition' AND entity_id = ANY(%s) AND provider='pitchapi') ORDER BY entity_type,provider,provider_key", (teamids, comps))
        get('zones', 'SELECT * FROM core.competition_zones WHERE competition_season_id = ANY(%s) ORDER BY competition_season_id,zone', (IDS,))
        get('standings', 'SELECT * FROM api.standings WHERE competition_season_id = ANY(%s) ORDER BY competition_season_id,stage NULLS FIRST,group_name NULLS FIRST,team_id,position,source,zone NULLS FIRST', (IDS,))
        get('standing_rows', 'SELECT * FROM api.standing_rows WHERE competition_season_id = ANY(%s) ORDER BY competition_season_id,stage NULLS FIRST,group_name NULLS FIRST,id,position,source', (IDS,))
        get('definitions', "SELECT 'api.standings' AS object,pg_get_viewdef('api.standings'::regclass,true) AS sql UNION ALL SELECT 'api.standing_rows',pg_get_viewdef('api.standing_rows'::regclass,true) UNION ALL SELECT 'api.public_id',pg_get_functiondef('api.public_id(core.entity_type,integer)'::regprocedure)")
        get('columns', "SELECT n.nspname,c.relname,a.attname,format_type(a.atttypid,a.atttypmod) AS type,a.attnotnull,a.attnum FROM pg_attribute a JOIN pg_class c ON c.oid=a.attrelid JOIN pg_namespace n ON n.oid=c.relnamespace WHERE a.attnum>0 AND NOT a.attisdropped AND (n.nspname||'.'||c.relname) = ANY(%s) ORDER BY n.nspname,c.relname,a.attnum", (['core.standings_official','agg.standings','core.matches','core.rounds','core.teams','core.assets','core.provider_ids','core.competition_zones'],))
        get('indexes', "SELECT schemaname,tablename,indexname,indexdef FROM pg_indexes WHERE (schemaname||'.'||tablename)=ANY(%s) ORDER BY schemaname,tablename,indexname", (['core.standings_official','agg.standings','core.matches','core.rounds','core.teams','core.assets','core.provider_ids','core.competition_zones'],))
        return out
