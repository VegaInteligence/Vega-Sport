"""Vérifie les dates, équipes et sens du calendrier J.League sur deux éditions RDS."""
import csv
from collections import Counter, defaultdict
from datetime import datetime, timezone
import hashlib
from html import unescape
import json
from pathlib import Path
import re
import sys
import unicodedata
from urllib.request import Request, urlopen
import zlib

HERE=Path(__file__).resolve().parent
def sha(raw):return hashlib.sha256(raw).hexdigest()
def norm(s):return ''.join(c for c in unicodedata.normalize('NFKC',s).casefold() if c.isalnum())
def dump(f, obj):f.write_text(json.dumps(obj,ensure_ascii=False,indent=2)+'\n')
def official(name,url):
    target=HERE/'public'/name
    if not target.with_suffix('.raw').exists():
        with urlopen(Request(url,headers={'User-Agent':'Mozilla/5.0'}),timeout=30) as resp:
            raw=resp.read()
            target.with_suffix('.raw').write_bytes(raw)
            dump(target.with_suffix('.json'),{'url':resp.geturl(),'started_at_utc':datetime.now(timezone.utc).isoformat(),'bytes':len(raw),'sha256':sha(raw),'status':resp.status})
    raw=target.with_suffix('.raw').read_bytes()
    assert sha(raw)==json.loads(target.with_suffix('.json').read_bytes())['sha256']
    s=raw.decode()
    cards=re.compile(r' id="(20[0-9]{8})"')
    round_pattern=re.compile(r'>(?:Season Total )?Matchweek ([0-9]+)</span>')
    rounds=list(round_pattern.finditer(s))
    out={}
    for m in cards.finditer(s):
        id_=m[1]
        pc_names=re.findall(r'm-schedule__team-name" data-media="pc">([^<]+)</span>',s[m.start():m.start()+6000])[:2]
        r=next((int(r[1]) for r in reversed(rounds) if r.start()<m.start()),None)
        assert len(pc_names)==2 and r and id_ not in out,(id_,pc_names,r)
        out[id_]={'id_officiel':id_,'date':id_[:4]+'-'+id_[4:6]+'-'+id_[6:8],'journée':r,'domicile':unescape(pc_names[0]),'extérieur':unescape(pc_names[1])}
    return out
def main():
    p=HERE/'public/j1-calendar.json'
    calendar=official('j1-calendar',json.loads(p.read_bytes())['url'])
    extra=official('j1-calendar-printemps','https://www.jleague.jp/en/j1/match/search-list/?category=j1&enddate=2027-06-30&period=custom&startdate=2027-03-01')
    for k,v in extra.items():
        assert calendar.get(k,v)==v,(k,v,calendar.get(k))
        calendar[k]=v
    assert len(calendar)==380 and sorted(Counter(r['journée'] for r in calendar.values()).values())==[10]*38, (len(calendar),Counter(r['journée'] for r in calendar.values()))
    aliases={norm(r['nom_officiel']):int(r['team_id']) for r in csv.DictReader((HERE.parent/'federations/36-clubs.csv').open()) if r['edition']=='22'}
    raw=json.loads(zlib.decompress((HERE/'rds-context/inputs.json.zlib').read_bytes()))
    days=defaultdict(list)
    ties=defaultdict(list)
    batch=raw['calendar']
    for row in batch['rows']:
        m=dict(zip(batch['columns'],row))
        if m['competition_season_id'] not in (22,140) or m['match_date']<'2026-08-01':continue
        days[m['match_date'],m['home_team_id'],m['away_team_id']].append(m)
        ties[m['home_team_id'],m['away_team_id']].append(m)
    output=[]
    for r in sorted(calendar.values(),key=lambda v:v['id_officiel']):
        a,b=(aliases[norm(r[k])] for k in ['domicile','extérieur'])
        exact=days[r['date'],a,b]
        matches=ties[a,b]
        output.append({**r,'id_domicile':a,'id_extérieur':b,'id_vega_exact':'|'.join(str(m['id']) for m in exact),'edition_exacte':'|'.join(str(m['competition_season_id']) for m in exact),'autres_dates_meme_affiche':'|'.join(m['match_date'] for m in matches if m['match_date']!=r['date'])})
    dest=HERE/'calendrier-japon-380.csv'
    with dest.open('w',newline='') as stream:
        w=csv.DictWriter(stream,fieldnames=list(output[0]));w.writeheader();w.writerows(output)
    summary={'source_officielle':json.loads(p.read_bytes()),'complement':json.loads((HERE/'public/j1-calendar-printemps.json').read_bytes()),'rds_utc':raw['at'],'matches_organisateur':len(output),'journées_officielles':dict(sorted(Counter(r['journée'] for r in output).items())),'repartition_par_edition_date_et_adversaires':dict(Counter(r['edition_exacte'] or 'sans correspondance exacte' for r in output)),'journees_par_edition':{ed:sorted({r['journée'] for r in output if r['edition_exacte']==ed}) for ed in ('22','140')},'csv_sha256':sha(dest.read_bytes()),'rejouer':'python3 -B calendrier_japon.py','regle':'Date officielle, mêmes deux équipes canoniques et même sens. Les affiches de date différente restent isolées.'}
    dump(HERE/'calendrier-japon.json',summary)
    print(summary['repartition_par_edition_date_et_adversaires'],summary['journees_par_edition'])
if __name__=='__main__':main()
