from pathlib import Path
import importlib.util
here=Path(__file__).resolve().parent
source=here.parents[2]/'6-teams/capture.py'
spec=importlib.util.spec_from_file_location('capture_worker',source)
module=importlib.util.module_from_spec(spec)
spec.loader.exec_module(module)
module.here=here
module.main()
