"""Rejouer deux vrais widgets sur les données figées de deux lectures RDS, sur PostgreSQL local."""
import argparse
import copy
from datetime import datetime, timedelta, timezone
import hashlib
import json
from pathlib import Path
import re
import sys
import uuid
from urllib.parse import parse_qs, urlparse
import zlib

import psycopg
from psycopg import sql

HERE = Path(__file__).resolve().parent
BASE = HERE.parent / 'sur-copie'
sys.path.insert(0, str(HERE / 'runtime'))
from vega import sources
from vega.sources import sportscore

def digest(data):
    return hashlib.sha256(data).hexdigest()

def snapshot(path):
    data = path.read_bytes()
    receipt = json.loads(path.with_name('receipt.json').read_bytes())
    assert receipt['sha256'] == digest(data) and receipt['exit_code'] == 0
    body = json.loads(zlib.decompress(data))
    assert body['read_only'] == 'on'
    return body

def write_json(path, data):
    path.write_text(json.dumps(data, indent=2, default=str, ensure_ascii=False) + '\n')

def restore(db, table, block):
    schema, name = table.split('.')
    stmt = sql.SQL("COPY {}.{} ({}) FROM STDIN").format(sql.Identifier(schema), sql.Identifier(name), sql.SQL(',').join(map(sql.Identifier, block['columns'])))
    with db.cursor().copy(stmt) as stream:
        for row in block['rows']:
            stream.write_row(row)

def view(db, edition):
    with db.transaction():
        db.execute('SET LOCAL ROLE vega_read')
        rows = db.execute('SELECT r.* FROM api.standing_rows r WHERE competition_season_id=%s ORDER BY position,to_jsonb(r)::text', (edition,)).fetchall()
    stored = db.execute('SELECT id,team_id,position,played,won,drawn,lost,goals_for,goals_against,points,as_of,basis,updated_at FROM core.standings_official WHERE competition_season_id=%s ORDER BY id', (edition,)).fetchall()
    return {'stored': stored, 'read_role': 'vega_read','rows_in_api': len(rows),'api_sha256': digest(json.dumps(rows, default=str).encode())}

def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--port', type=int, default=32802)
    parser.add_argument('--out', type=Path, required=True)
    args = parser.parse_args()
    args.out.mkdir(parents=True,exist_ok=False)
    base = snapshot(BASE / 'rds-detail-1217/inputs.json.zlib')
    context = snapshot(HERE / 'rds-context/inputs.json.zlib')
    keys = {15: ('l_1XsMdH','sweden'), 22: ('l_2ApGa4','japan')}
    report = {'start_utc':datetime.now(timezone.utc),'snapshots':[base['at'],context['at']],'freeze':json.loads((HERE/'freeze.json').read_bytes()),'inputs':{},'scenarios':[],'rerun': 'ci-clean/bin/python tracks/2-ingestion/impact-138-en-production/renouvellement-reel/rejouer.py --port '+str(args.port)+' --out <nouveau-dossier>', 'limits':'Original calendar and standings, preserved as captured. Corrected points are explicitly synthetic. The standings widget does not encode a season.'}
    newer = context['official']['rows']
    oi = base['official']['columns'].index('competition_season_id')
    assert [r for r in base['official']['rows'] if r[oi] in keys] == newer
    # The two snapshots agree on all 36 official rows, including their observation times.
    slug_bodies = {}
    for edition,(key, country) in keys.items():
        p = HERE/'public'/('sportscore-'+country+'.raw')
        rec = json.loads(p.with_suffix('.json').read_bytes())
        assert rec['status']==200 and rec['sha256']==digest(p.read_bytes())
        body=json.loads(p.read_bytes())
        assert body['competition_slug']==sportscore.LEAGUES[key]
        slug_bodies[body['competition_slug']] = body
        report['inputs'][str(edition)] = rec
    target = 'vega_refresh_evidence_'+uuid.uuid4().hex
    addr = 'postgresql://postgres@127.0.0.1:'+str(args.port)
    with psycopg.connect(addr+'/postgres',autocommit=True) as admin:
        admin.execute(sql.SQL('CREATE DATABASE {}').format(sql.Identifier(target)))
        try:
            with psycopg.connect(addr+'/'+target,autocommit=True) as db:
                for page in sorted((BASE/'sql').glob('*.sql')):
                    with db.transaction():
                        db.execute(page.read_text())
                tables = [('assets','core.assets'),('seasons','core.seasons'),('competitions','core.competitions'),('editions','core.competition_seasons'),('teams','core.teams'),('rounds','core.rounds'),('matches','core.matches'),('official','core.standings_official'),('aggregate','agg.standings'),('provider_ids','core.provider_ids'),('zones','core.competition_zones')]
                with db.transaction():
                    db.execute("SET LOCAL session_replication_role='replica'")
                    more = ['core.team_seasons','core.entity_names','ops.source_runs']
                    db.execute('TRUNCATE '+','.join([t for _,t in tables]+more)+' CASCADE')
                    for label,table in tables:
                        restore(db,table,base[label])
                    # Additional editions supply neighbours and their historical memberships.
                    for row in context['editions']['rows']:
                        if row[0] not in base['edition_ids']:
                            db.execute('INSERT INTO core.competition_seasons(id,competition_id,season_id,native_label,is_current) VALUES(%s,%s,%s,%s,%s)',row[:5])
                    for id_,name,short,crest in context['teams']['rows']:
                        db.execute('INSERT INTO core.teams(id,name,short_name,crest_asset_id) VALUES(%s,%s,%s,%s) ON CONFLICT(id) DO UPDATE SET short_name=excluded.short_name',(id_,name,short,crest))
                    for label,table in zip(['membership','names','source_runs'],more):
                        restore(db,table,context[label])
                def state(edition,scope):
                    return {**view(db,edition),'run':db.execute("SELECT last_attempt_at,last_success_at,status,error_code FROM ops.source_runs WHERE source='sportscore' AND scope=%s",(scope,)).fetchone()}
                # Both original successes are >2h old at the replay times, under the adapter's actual clock.
                start = datetime.fromisoformat(context['at'])+timedelta(hours=2)
                for ix, label in enumerate(['identical-authentic','synthetic-one-point-correction']):
                    for edition,(key,country) in keys.items():
                        scope='standings:'+key
                        instant=start+timedelta(hours=3*ix)
                        before=state(edition,scope)
                        calls=[]
                        def getter(url):
                            slug=parse_qs(urlparse(url).query)['slug'][0]
                            assert slug==sportscore.LEAGUES[key]
                            calls.append(url)
                            body=copy.deepcopy(slug_bodies[slug])
                            if ix:
                                max(body['tables'][0]['rows'],key=lambda r:r['pos'])['pts']-=1
                            return body
                        native_scopes=sportscore.scopes
                        try:
                            sportscore.scopes=lambda _: {scope:sportscore.PERIOD}
                            db.execute('SET ROLE vega_collect')
                            result=sources.run_due(db,getter,instant,names={'sportscore'})
                        finally:
                            db.execute('RESET ROLE')
                            sportscore.scopes=native_scopes
                        after=state(edition,scope)
                        item={'case':label,'edition':edition,'now':instant,'worker_role':'vega_collect','calls':calls,'result':result.get(('sportscore',scope)),'before':before,'after':after}
                        report['scenarios'].append(item)
                        assert len(calls)==1 and item['result']=='WRONG_EDITION', (edition,label,item['result'])
                        assert before['stored']==after['stored'] and before['api_sha256']==after['api_sha256'] and after['run'][2:] == ('error','WRONG_EDITION')
                        assert after['run'][1]==before['run'][1]
                report['outcome']='REPRODUCED'
        finally:
            admin.execute(sql.SQL('DROP DATABASE {} WITH (FORCE)').format(sql.Identifier(target)))
            report['finish_utc']=datetime.now(timezone.utc)
            write_json(args.out/'resultat.json',report)
    print([(s['edition'],s['case'],s['result']) for s in report['scenarios']])

if __name__=='__main__':
    main()
