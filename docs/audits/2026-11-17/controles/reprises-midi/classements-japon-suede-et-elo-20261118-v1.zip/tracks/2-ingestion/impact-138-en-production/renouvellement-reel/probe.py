def collect(db):
    with db.transaction():
        db.execute("SET TRANSACTION ISOLATION LEVEL REPEATABLE READ READ ONLY")
        stamp,snap,ro=db.execute("SELECT transaction_timestamp(),pg_current_snapshot()::text,current_setting('transaction_read_only')").fetchone();assert ro=='on'
        out={'at':str(stamp),'snapshot':snap,'read_only':ro,'queries':{}}
        def get(name,q,args=()):
            cur=db.execute(q,args);out[name]={'columns':[c.name for c in cur.description],'rows':cur.fetchall()};out['queries'][name]={'sql':q,'params':args}
        get('editions',"SELECT cs.id,cs.competition_id,cs.season_id,cs.native_label,cs.is_current,se.label FROM core.competition_seasons cs JOIN core.seasons se ON se.id=cs.season_id WHERE cs.competition_id IN (15,22) AND cs.season_id BETWEEN 2025 AND 2028 ORDER BY cs.competition_id,cs.season_id,cs.id")
        ids=[r[0] for r in out['editions']['rows']]
        get('membership',"SELECT team_id,competition_season_id,updated_at FROM core.team_seasons WHERE competition_season_id=ANY(%s) ORDER BY competition_season_id,team_id",(ids,))
        teamids=sorted({r[0] for r in out['membership']['rows']})
        get('teams',"SELECT id,name,short_name,crest_asset_id FROM core.teams WHERE id=ANY(%s) ORDER BY id",(teamids,))
        get('names',"SELECT entity_type,entity_id,name,normalized,kind,source FROM core.entity_names WHERE entity_type='team' AND entity_id=ANY(%s) ORDER BY entity_id,name,kind,source",(teamids,))
        get('calendar',"SELECT m.id,m.competition_season_id,m.season_id,m.match_date,m.kickoff_at,m.status,m.home_team_id,m.away_team_id,h.name AS home,a.name AS away,m.home_score,m.away_score,r.stage::text,r.name AS round_name,m.first_finished_at FROM core.matches m LEFT JOIN core.teams h ON h.id=m.home_team_id LEFT JOIN core.teams a ON a.id=m.away_team_id LEFT JOIN core.rounds r ON r.id=m.round_id WHERE m.competition_season_id=ANY(%s) AND m.match_date BETWEEN DATE '2026-01-01' AND DATE '2027-06-30' ORDER BY m.competition_season_id,m.match_date,m.id",(ids,))
        get('edition_counts',"SELECT m.competition_season_id,count(*) AS matches,min(m.match_date),max(m.match_date),count(*) FILTER(WHERE status='finished') AS finished,count(*) FILTER(WHERE match_date BETWEEN DATE '2026-08-01' AND DATE '2026-12-31') AS august_december_2026 FROM core.matches m WHERE m.competition_season_id=ANY(%s) GROUP BY m.competition_season_id ORDER BY 1",(ids,))
        get('official',"SELECT * FROM core.standings_official WHERE competition_season_id IN (15,22) ORDER BY id")
        get('source_runs',"SELECT * FROM ops.source_runs WHERE source='sportscore' AND scope IN ('standings:l_1XsMdH','standings:l_2ApGa4') ORDER BY scope")
        return out
