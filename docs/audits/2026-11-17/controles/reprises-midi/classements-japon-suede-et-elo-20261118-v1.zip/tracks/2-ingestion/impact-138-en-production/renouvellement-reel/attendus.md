# Renouvellement de deux tableaux réels, avant exécution

Périmètre : Allsvenskan 2026 (édition 15) et J. League édition Vega 22, native 2027. Employer les statistiques réellement observées, membres et graphies RDS, vrais widgets publics si disponibles ; aucune fausse réception de données reconstruites. Conserver les preuves de saison de l’organisateur séparément de ce que le writer actuel sait lire.

Attendus à éprouver : le repeat normal et une modification complète du même tableau ne doivent pas être confondus avec un mauvais millésime en raison d’un calendrier incomplet. Le writer actuel passe qualify avant repeat ; vérifier le refus réel, préservation des lignes/as_of/basis, état error et délai de reprise. Tester un mauvais millésime attesté et une absence de preuve avec provenance explicite. Aucun correctif du produit n’est demandé à ce relecteur.

Les variantes de correction future seront marquées reconstruites, avec delta exact ; elles ne seront jamais présentées comme un flux sportif reçu. La mesure de calendrier borne les éditions et leurs matchs, sans données personnelles. PostgreSQL 18 isolé, code Python gelé, sources et SQL hashés, vrai rôle collect, lectures par vega_read, preuves avant/après et commandes à conserver.
