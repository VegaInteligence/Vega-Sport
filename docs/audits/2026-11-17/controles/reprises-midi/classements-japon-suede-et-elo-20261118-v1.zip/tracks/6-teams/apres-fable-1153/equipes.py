"""Qualify the five peer-review questions on archived, attested inputs."""
from pathlib import Path
from collections import Counter, defaultdict
from datetime import date
import csv,gzip,hashlib,io,json,os,subprocess,sys,zlib
D=Path(__file__).resolve().parent
T=D.parent; E=T.parents[1]
W=Path(os.environ['VEGA_REPO']) if os.environ.get('VEGA_REPO') else Path(json.loads((T/'scope.json').read_bytes())['worktree'])
R=D/'runtime-prod'
prod='8018e0836ca0f32e8b2eb51fc2847154abff7f13'
for name in subprocess.check_output(['git','-C',str(W),'ls-tree','-r','--name-only',prod,'backend/vega/'],text=True).splitlines():
    if name.endswith('.py'):
        target=R/name.removeprefix('backend/')
        target.parent.mkdir(parents=True,exist_ok=True)
        target.write_bytes(subprocess.check_output(['git','-C',str(W),'show',prod+':'+name]))
sys.path.insert(0,str(R))
from vega import power
from vega.sources.open_matchday import COVERED
def sha(x):return hashlib.sha256(x).hexdigest()
def packed(p):return json.loads(zlib.decompress(p.read_bytes()))
def read(p):return json.loads(p.read_bytes())
def flat(t):return [dict(zip(t['columns'],r)) for r in t['rows']]
def writecsv(p,x):
    with (D/p).open('w',newline='') as f:
        w=csv.DictWriter(f,fieldnames=list(x[0]));w.writeheader();w.writerows(x)
def lines(p):return list(csv.DictReader(p.open()))
def bodyof(p):return subprocess.check_output(['git','-C',str(W),'show','8018e0836ca0f32e8b2eb51fc2847154abff7f13:'+p])
def fn(mod):return bodyof('backend/'+mod)
for file in ['vega/power.py','vega/sources/open_matchday.py']:
    assert fn(file)==(R/file).read_bytes()
base=T/'fable-corrections-nov18'
facts=base/'source-facts'
snap=packed(facts/'db/inputs.json.zlib')
elo=snap['elo'];cols=elo['columns'][:]
for i,k in {16:'competition',22:'round_name',25:'home_nat',26:'away_nat',27:'home_ctry',28:'away_ctry'}.items():cols[i]=k
rated={x[1]:dict(zip(cols,x)) for x in elo['rows']}
assert len(rated)==81923
nat={k:v for k,v in rated.items() if v['home_nat'] is True and v['away_nat'] is True}
assert len(nat)==932
venues={int(x['match_id']):x for x in lines(facts/'venues-attested.csv')}
venue_counts=Counter(x['venue_status'] for k,x in venues.items() if k in nat and nat[k]['is_neutral'] is None)
schedule=E/'tracks/2-ingestion/official-calendar-extended/raw/int-results.body.gz'
payload=gzip.decompress(schedule.read_bytes())
src=read(schedule.with_name('int-results.json'));assert sha(payload)==src['hash']
csv_rows=list(csv.DictReader(io.StringIO(payload.decode('utf-8-sig'))))
parser=R/'nations-results.mjs'
parser.write_bytes(bodyof('dashboard/frontend/src/services/nations-results.js'))
script='import {readFileSync} from "node:fs";import {parseNationsResults} from '+json.dumps(parser.as_uri())+'; console.log(JSON.stringify(parseNationsResults(readFileSync(0,"utf8"))));'
projected=json.loads(subprocess.run(['node','--input-type=module','-e',script],input=payload,stdout=subprocess.PIPE,check=True).stdout)
look=defaultdict(list)
for r in csv_rows:
    if r['tournament']=='UEFA Nations League':
        look[(r['date'],r['home_team'],r['away_team'],r['home_score'],r['away_score'])].append(r)
nations=[]
for mid,r in nat.items():
    if r['competition_season_id']!=308:continue
    items=[x for x in projected if (x['date'],x['home'],x['away'],x['score'])==(r['match_date'],r['home_team_name'],r['away_team_name'],[r['home_score'],r['away_score']])]
    assert len(items)==1 and r['is_neutral'] is None
    x=items[0];c=look[(x['date'],x['homeId'],x['awayId'],str(x['score'][0]),str(x['score'][1]))];assert len(c)==1 and 'neutral' not in x
    t=c[0];nations.append({'match_id':mid,'day':x['date'],'home':x['home'],'away':x['away'],'source_home':x['homeId'],'source_away':x['awayId'],'score':str(x['score']),'ground_country':t['country'],'ground_city':t['city'],'neutral_csv':t['neutral'],'neutral_projection':None,'neutral_RDS':r['is_neutral'],'included_in_organizer_venue_proofs':mid in venues})
assert len(nations)==72
writecsv('nations-league-72.csv',nations)
wc=E/'tracks/2-ingestion/world-cup-calendar'
fifaraw=gzip.decompress((wc/'raw/worldcup1934.gz').read_bytes())
assert sha(fifaraw)==read(wc/'raw/worldcup1934.json')['sha256']
fifa={x['IdMatch']:x for x in json.loads(fifaraw)['Results']};assert len(fifa)==17
pairs={int(r['candidate_id']):r for r in lines(wc/'matches.csv') if r['year']=='1934' and r['candidate_id']}
fixtures=[x for x in flat(read(E/'db/worldcup_editions_nov18_verified/fixtures.json')) if x['cup_key'].endswith(':1934')]
published=packed(T/'published-nov18/snapshot/inputs.json.zlib')
merges=dict(published['alias_pairs'])
def row(mid,season,h,a,hs,as_,day,secondary):
    return (mid,season,None,int(h),int(a),hs,as_,None,date.fromisoformat(day),64,secondary,None,None)
raw=[row(r['id'],r['season_id'],r['home_team_id'],r['away_team_id'],r['home_score'],r['away_score'],r['match_date'],True) for r in fixtures]
def retained(rows):
    return {r[0] for r in power.elo_matches(power.merged_rows(sorted(rows,key=lambda x:(x[8],x[0])),merges))}
kept=retained(raw);assert len(kept)==16 and kept=={r['id'] for r in fixtures if r['id'] in rated}
wc34=[]
for r in fixtures:
    m=pairs[r['id']];f=fifa[m['fifa_id']]
    wc34.append({'id':r['id'],'fifa_id':m['fifa_id'],'fifa_timestamp':f['Date'],'home':r['home_team_name'],'away':r['away_team_name'],'score_vega':str([r['home_score'],r['away_score']]),'fifa_score':str([f['HomeTeamScore'],f['AwayTeamScore']]),'elo_replay':r['id'] in kept,'elo_rds':r['id'] in rated})
writecsv('mondial-1934.csv',wc34)
restored=[x for x in lines(base/'scope-check/worldcup-restored-665.csv') if x['year']=='2022']
native=[r for r in flat(read(E/'db/worldcup_copies_nov18_verified/other.json')) if r['edition']==1003 and r['status']=='finished']
assert len(restored)==7 and len(native)==64
nrows=[row(r['id'],r['season_id'],r['home_team_id'],r['away_team_id'],r['home_score'],r['away_score'],r['match_date'],False) for r in native]
rrows=[row(int(r['match_id']),int(r['season_id']),r['home_id'],r['away_id'],int(r['branch_home_score']),int(r['branch_away_score']),r['day'],True) for r in restored]
admitted=retained(nrows+rrows);newids={r[0] for r in rrows}
wc22=[]
for fact,r in zip(restored,power.merged_rows(rrows,merges)):
    cand=[n for n in power.merged_rows(nrows,merges) if abs((n[8]-r[8]).days)<=3 and {n[3],n[4]}=={r[3],r[4]}]
    x=cand[0] if len(cand)==1 else None
    wc22.append({'archive':r[0],'fifa':fact['fifa_id'],'fifa_ordre_inverse':fact['fifa_reversed_orientation'],'home':r[3],'away':r[4],'native':x[0] if x else None,'same_order':r[3:5]==x[3:5] if x else None,'same_score_in_orientation':r[5:7]==(x[5:7] if r[3:5]==x[3:5] else x[5:7][::-1]) if x else None,'contextual_replay_admits_archive':r[0] in admitted,'native_candidates':len(cand)})
writecsv('mondial-2022-sept.csv',wc22)
http=read(D/'http/recus.json');db=packed(D/'rds/inputs.json.zlib'); nc=Counter(r['neutral_csv'] for r in nations)
result={'national_Elo_matches':len(nat),'national_home_terms':dict(venue_counts),'national_by_source':dict(Counter(r['source'] for r in nat.values())),'national_source_grounds':dict(nc),'overlap_of_72_with_venues':sum(r['included_in_organizer_venue_proofs'] for r in nations),'wrong_home_term_at_least':venue_counts['neither_home_association']+venue_counts['nominal_away_hosts']+sum(r['neutral_csv']=='TRUE' and not r['included_in_organizer_venue_proofs'] for r in nations),'saudi_edition_team_rows':len(db['clubs']['rows']),'saudi_with_elo':sum(r[5] is not None for r in db['clubs']['rows']),'http_scores_reproduced':sum(x['same'] and x['score_public'] is not None for y in http for x in y['rows']),'http_explicit_nulls':sum(x['same'] and x['score_public'] is None for y in http for x in y['rows']),'reference':db['reference']['rows'][0], 'female_divisions':db['division']['rows'],'fifa1934_missing':[x for x in wc34 if not x['elo_replay']],'restored2022_admitted_ids':sorted(admitted&newids),'restored2022_matched_same_order':sum(x['same_order'] is True for x in wc22),'restored2022_native_same_score':sum(x['same_score_in_orientation'] is True for x in wc22),'results_source_capture_url':src['url'],'upstream_used_by_product':'same path on moving master; immutable commit verified for this replay only','published_elo_run':2097,'utc_rds_new':db['at']}
(D/'resultats.json').write_text(json.dumps(result,ensure_ascii=False,indent=2)+'\n')
print(result)
