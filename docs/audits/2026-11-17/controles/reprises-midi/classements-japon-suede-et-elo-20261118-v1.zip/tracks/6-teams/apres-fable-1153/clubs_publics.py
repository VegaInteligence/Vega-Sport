"""Compare real read/clubs responses with the same season's stored Elo and scoring reference."""
from concurrent.futures import ThreadPoolExecutor
from datetime import datetime,timezone
from pathlib import Path
import hashlib,json,math,zlib
from urllib.request import Request,urlopen
from urllib.parse import urlencode
D=Path(__file__).resolve().parent
db=json.loads(zlib.decompress((D/'rds/inputs.json.zlib').read_bytes()))
public=D/'http';public.mkdir(exist_ok=True)
def observe(season):
    u='https://dngp6kh9jx2bl.cloudfront.net/api/read/clubs?'+urlencode({'season':season,'league':'l_1SGwQT','limit':'50'})
    with urlopen(Request(u,headers={'User-Agent':'Vega audit'}),timeout=40) as res:
        body=res.read();meta={'url':u,'status':res.status,'sha256':hashlib.sha256(body).hexdigest(),'at':datetime.now(timezone.utc).isoformat()}
    k=season.replace('/','-')
    (public/(k+'.json')).write_bytes(body)
    response=json.loads(body)
    clubs=response.get('clubs',response.get('data',{}).get('clubs',[]))
    source={r[3]:r for r in db['clubs']['rows'] if r[1]==season}
    rows=[]
    ref=db['reference']['rows'][0][1]
    for t in clubs:
        r=source[t['id']];p=t.get('power')
        expected=None if r[5] is None else math.floor(1000/(1+10**(-(r[5]-ref)/400))+.5)/10
        calculated=p.get('score') if p else None
        rows.append({'team_id':t['id'],'name':r[4],'matches':r[7],'elo':r[5],'score_public':calculated,'score_recalcule':expected,'same':expected==calculated})
    meta.update(rows=rows,n_in_roster=len(source),response_keys=list(response))
    return meta
seasons=sorted({r[1] for r in db['clubs']['rows']})
with ThreadPoolExecutor(max_workers=2) as pool:result=list(pool.map(observe,seasons))
(public/'recus.json').write_text(json.dumps(result,ensure_ascii=False,indent=2)+'\n')
print([(r['n_in_roster'],len(r['rows']),sum(x['same'] for x in r['rows'])) for r in result])
