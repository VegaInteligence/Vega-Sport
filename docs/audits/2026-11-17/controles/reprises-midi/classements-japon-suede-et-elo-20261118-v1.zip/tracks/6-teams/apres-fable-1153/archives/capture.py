from pathlib import Path
import importlib.util
here=Path(__file__).resolve().parent
spec=importlib.util.spec_from_file_location('capture_worker',here.parents[1]/'capture.py')
module=importlib.util.module_from_spec(spec)
spec.loader.exec_module(module)
module.here=here
module.main()
