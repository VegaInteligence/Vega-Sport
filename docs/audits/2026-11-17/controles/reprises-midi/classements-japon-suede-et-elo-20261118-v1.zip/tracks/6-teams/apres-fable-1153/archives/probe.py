def collect(db):
    with db.transaction():
        db.execute('SET TRANSACTION ISOLATION LEVEL REPEATABLE READ READ ONLY')
        stamp,snap,ro=db.execute("SELECT transaction_timestamp(),pg_current_snapshot()::text,current_setting('transaction_read_only')").fetchone()
        assert ro=='on'
        query="""WITH a AS (SELECT m.id,m.season_id,m.match_date,m.home_score,m.away_score,m.home_team_id,m.away_team_id,h.is_national hn,v.is_national an
          FROM core.matches m JOIN core.competition_seasons e ON e.id=m.competition_season_id
          LEFT JOIN core.teams h ON h.id=m.home_team_id LEFT JOIN core.teams v ON v.id=m.away_team_id WHERE m.status='finished' AND e.archive_key IS NOT NULL),
        flags AS (SELECT *,((home_team_id IS NOT NULL AND hn IS NOT TRUE)::int+(away_team_id IS NOT NULL AND an IS NOT TRUE)::int) AS club_sides,
          (home_team_id IS NOT NULL AND away_team_id IS NOT NULL AND home_score IS NOT NULL AND away_score IS NOT NULL AND match_date IS NOT NULL) AS complete FROM a)
        SELECT complete,match_date IS NULL AS missing_date,home_score IS NULL OR away_score IS NULL AS missing_score,home_team_id IS NULL OR away_team_id IS NULL AS missing_team,
        count(*) AS matches, sum(club_sides) AS club_sides, count(*) FILTER(WHERE hn IS TRUE OR an IS TRUE) AS with_national_team
        FROM flags GROUP BY 1,2,3,4 ORDER BY 1,2,3,4"""
        cur=db.execute(query);return dict(at=str(stamp),snapshot=snap,read_only=ro,sql=query,columns=[c.name for c in cur.description],rows=cur.fetchall())
