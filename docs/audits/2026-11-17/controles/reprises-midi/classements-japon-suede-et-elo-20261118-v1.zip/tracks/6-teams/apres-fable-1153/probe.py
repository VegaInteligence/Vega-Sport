def collect(db):
    with db.transaction():
        db.execute("SET TRANSACTION ISOLATION LEVEL REPEATABLE READ READ ONLY")
        stamp,snap,ro=db.execute("SELECT transaction_timestamp(),pg_current_snapshot()::text,current_setting('transaction_read_only')").fetchone()
        assert ro=='on'
        out={'at':str(stamp),'snapshot':snap,'read_only':ro,'queries':{}}
        def read(k,q):
            cur=db.execute(q);out[k]={'columns':[c.name for c in cur.description],'rows':cur.fetchall()};out['queries'][k]=q
        read('division',"SELECT competition_id,competition_key,name,level,universe,linked,tier FROM api.league_levels WHERE universe='women' OR competition_key=197 ORDER BY competition_key")
        read('reference',"SELECT count(*) FILTER(WHERE linked AND coalesce(tier,1)=1) AS n_ref, coalesce(avg(level) FILTER(WHERE linked AND coalesce(tier,1)=1),avg(level))::float8 AS ref FROM api.league_levels WHERE universe='men'")
        read('clubs',"""WITH roster AS (SELECT DISTINCT cs.season_id,ts.team_id FROM core.competition_seasons cs JOIN core.team_seasons ts ON ts.competition_season_id=cs.id WHERE cs.competition_id=197)
         SELECT r.season_id,s.label,r.team_id,api.public_id('team',r.team_id),t.name,p.elo,p.rank,p.matches,p.computed_at,
           array(SELECT DISTINCT e.competition_id FROM core.team_seasons t2 JOIN core.competition_seasons e ON e.id=t2.competition_season_id WHERE t2.team_id=r.team_id AND e.season_id=r.season_id ORDER BY 1) AS competition_ids
         FROM roster r JOIN core.seasons s ON s.id=r.season_id JOIN core.teams t ON t.id=r.team_id LEFT JOIN api.power_clubs p ON p.team_key=r.team_id AND p.season_id=r.season_id AND p.scope='clubs' ORDER BY 1,3""")
        read('denominators',"""SELECT count(*) AS finished, count(home_team_id)+count(away_team_id) AS observed_sides,
         count(*) FILTER(WHERE home_team_id IS NOT NULL AND away_team_id IS NOT NULL AND home_score IS NOT NULL AND away_score IS NOT NULL AND match_date IS NOT NULL) AS complete_matches,
         count(*) FILTER(WHERE home_team_id IS NULL OR away_team_id IS NULL) AS missing_team,
         count(*) FILTER(WHERE home_score IS NULL OR away_score IS NULL) AS missing_result, count(*) FILTER(WHERE match_date IS NULL) AS missing_day FROM core.matches WHERE status='finished'""")
        return out
