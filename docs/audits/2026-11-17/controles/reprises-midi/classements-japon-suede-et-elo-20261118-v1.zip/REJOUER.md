# Rejouer les contrôles sur les sélections, les clubs féminins et les classements

La capsule contient deux lectures complémentaires RDS pour SportScore, les widgets effectivement reçus, les deux réponses du calendrier officiel de J1, les tableaux comparés ligne par ligne, les requêtes Elo, les réponses publiques et les entrées sportives utiles au rejeu. Tous les traitements d’écriture ciblent une nouvelle base locale éphémère.

Depuis la racine de la capsule, définir `VEGA_REPO` comme le chemin d’un clone de Vega-Sport contenant le commit AWS `8018e0836ca0f32e8b2eb51fc2847154abff7f13`. Pour les calculs, utiliser Python 3.14, psycopg 3 et Node 24 ou 26. Le chemin Python ci-dessous désigne cet environnement.

```sh
python -B tracks/2-ingestion/impact-138-en-production/renouvellement-reel/calendrier_japon.py
python -B tracks/6-teams/apres-fable-1153/equipes.py
```

Le premier programme recalcule les 380 correspondances par date et clubs. Les deux réponses HTML nécessaires sont incluses. Le second extrait les modules effectivement déployés depuis Git et refait les sélections Elo, les correspondances de rencontres, le contrôle de la neutralité et la lecture des scores et réponses HTTP enregistrées. `clubs_publics.py` refait séparément les trois GET publics à la date d’exécution. Utiliser un autre dossier extrait pour cette nouvelle mesure.

Pour reproduire le refus SportScore antérieur au correctif, fournir une instance PostgreSQL 18 avec pgvector accessible sur la boucle locale, avec création de base pour le compte postgres. Substituer le port publié à 55469. Le programme applique le schéma gelé, restaure les données capturées et passe par le collecteur normal sous son rôle. Les états du lecteur, les dates et les quatre réponses sont enregistrés dans le dossier de sortie. La variante de correction d’un point est synthétique. Les deux autres entrées reproduisent les corps réseau conservés.

```sh
python -B tracks/2-ingestion/impact-138-en-production/renouvellement-reel/rejouer.py --port 55469 --out nouvelle-execution
```

Les résultats de référence sont dans `essai-2/resultat.json`, `calendrier-japon.json` et `tracks/6-teams/apres-fable-1153/resultats.json`. Les deux captures d’archives reposent sur une transaction en lecture seule par fichier. La capture du CSV Nations League épingle une révision publique, le collecteur déployé lit la branche master de cette même source. Les fichiers SHA256SUMS permettent de vérifier les octets inclus.
