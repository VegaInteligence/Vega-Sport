"""Reconcile observed match order and score only after both sides and date match."""
import csv,gzip,hashlib,json,re,unicodedata
from collections import Counter,defaultdict
from pathlib import Path
P=Path(__file__).resolve().parent
Y={2021:31672,2022:31673,2023:31675}
# A fixed edition-only name crosswalk. Each mapping is checked against the team on the
# official sheet, against every opponent/date on this RDS root and the recorded team name.
MAP={467:'Seattle Sounders FC',588:'Al Jazira',637:'Monterrey',695:'Urawa Reds',861:'Chelsea',908:'Club León',1191:'Auckland City FC',1207:'Wydad Athletic Club',4710:'Real Madrid',5111:'Manchester City FC',5153:'Flamengo',5155:'Palmeiras',5162:'Fluminense FC',5282:'Al Ahly FC',5317:'Al Hilal',5325:'Al Ittihad FC',13075:'AS Pirae'}
def sha(b):return hashlib.sha256(b).hexdigest()
def J(p):return json.loads(p.read_bytes())
def raw(p,r):
 b=gzip.decompress(p.read_bytes());ack=J(r);assert sha(b)==ack['sha256'] and ack['status']==200;return json.loads(b),ack
def out(name,rows):
 with (P/name).open('w',newline='') as f:
  w=csv.DictWriter(f,fieldnames=list(rows[0]),lineterminator='\n');w.writeheader();w.writerows(rows)
def jdump(name,j):(P/name).write_text(json.dumps(j,indent=2,ensure_ascii=False)+'\n')
def pair(x):return '-'.join(str(n) for n in x) if all(v is not None for v in x) else ''
def fp(m):return m['TeamName'][0]['Description']
def analyze():
 data=J(P/'inputs/rds.json');grid=J(P/'inputs/grid.json'); profiles={int(r['team_id']):r for r in J(P/'inputs/art-roots.json')};el={r[1]:r for r in J(P/'inputs/elo.json')['rows']};assert set(MAP)==set(profiles)
 games=[];sides=[];registrations=[];subs=[];sources=[];mapping=defaultdict(set);rosters_by_fixture=[];comparisons=defaultdict(Counter)
 for year,edition in Y.items():
  cal,meta=raw(P/'raw'/f'worldcup{year}.gz',P/'raw'/f'worldcup{year}.json');cases=cal['Results'];assert len(cases)==len([r for r in data if r['edition']==edition])
  sources.append(dict(edition=edition,kind='calendar',fifa_match='',url=meta['url'],sha256=meta['sha256'],status=200))
  for ev in sorted(cases,key=lambda r:r['MatchNumber']):
   mid=ev['IdMatch'];sheet,ack=raw(P/'lineups'/(mid+'.json.gz'),P/'lineups'/(mid+'.meta.json'));sources.append(dict(edition=edition,kind='match_sheet',fifa_match=mid,url=ack['url'],sha256=ack['sha256'],status=200))
   assert sheet['IdMatch']==mid and sheet['IdSeason']==ev['IdSeason'] and sheet['MatchStatus']==ev['MatchStatus']==0
   h,a=map(fp,[ev['Home'],ev['Away']]);date=ev['LocalDate'][:10];utc=ev['Date']
   rr=[r for r in data if r['edition']==edition and r['match_date']==date and {MAP[r['home_team_id']],MAP[r['away_team_id']]}=={h,a}];assert len(rr)==1,(year,mid,h,a,date,len(rr));r=rr[0];vega=r['id'];rev=MAP[r['home_team_id']]==a
   assert r['status']=='finished' and r['source']=='openfootball' and len(r['elo_teams'])==2 and set(r['elo_teams'])=={r['home_team_id'],r['away_team_id']}
   previous=el[vega];assert (previous[10],previous[11],previous[12],previous[13],previous[14])==(r['home_team_id'],r['away_team_id'],r['home_score'],r['away_score'],edition)
   sf=[sheet['HomeTeam'],sheet['AwayTeam']]; ft=[s['Score'] for s in sf];assert ft==[ev['HomeTeamScore'],ev['AwayTeamScore']];periods=[]
   for s in sf:periods.append(Counter([g['Period'] for g in (s.get('Goals') or [])]))
   ht=[p[3] for p in periods];reg=[p[3]+p[5] for p in periods];et=[p[7]+p[9] for p in periods];pen=[p[11] for p in periods]
   assert all(f==v+t for f,v,t in zip(ft,reg,et)) and pen==[ev['HomeTeamPenaltyScore'],ev['AwayTeamPenaltyScore']]
   pk=ev['ResultType']==2;extra=ev['ResultType'] in (2,3);assert not (pk and sum(pen)==0)
   def dbscore(suffix):
    k='home_'+suffix;v='away_'+suffix;z=[r[k],r[v]];return z[::-1] if rev else z
   assert ft==dbscore('score'); cov={k:r[k] for k in ('team_sheets','lineups','stats','positive_minutes','halves','advanced','events','shots','player_intermediates','player_grades')}
   g=dict(vega_edition=edition,edition_year=year,storage_season=r['season_id'],vega_match=vega,fifa_season=ev['IdSeason'],fifa_match=mid,fifa_number=ev['MatchNumber'],vega_number=r['match_number'],archive_position=r['archive_position'],day_stadium=date,official_local=ev['LocalDate'],official_utc=utc,vega_kickoff=r['kickoff_at'],official_home=h,official_away=a,vega_home=r['home'],vega_away=r['away'],home_root=r['home_team_id'],away_root=r['away_team_id'],reversed_order=int(rev),official_stage=ev['StageName'][0]['Description'],vega_round=r['registered_round'],vega_stage=r['stage'],vega_status=r['status'],regulation_or_et_or_pk={1:'played_90',2:'played_120_and_shootout',3:'played_120'}[ev['ResultType']],score_fifa=pair(ft),score_vega_native_order=pair([r['home_score'],r['away_score']]),ht_fifa=pair(ht),ht_vega_fifa_order=pair(dbscore('score_ht')),reg_fifa=pair(reg),reg_vega_fifa_order=pair(dbscore('score_90')),after_et_fifa=pair(ft) if extra else '',et_vega_fifa_order=pair(dbscore('score_et')),pk_fifa=pair(pen) if pk else '',pk_vega_fifa_order=pair(dbscore('penalty_score')),elo_sides=len(r['elo_teams']),**cov)
   for i,side in enumerate(sf):
    sside='home' if i==0 else 'away';root=r['home_team_id' if (i==0)!=rev else 'away_team_id'];tid=side['IdTeam'];assert fp(side)==[h,a][i]==MAP[root] and tid==ev[['Home','Away'][i]]['IdTeam'];mapping[root].add(tid)
    players=side['Players'];st={p['IdPlayer'] for p in players if p['Status']==1};on={e['IdPlayerOn'] for e in side['Substitutions']};off={e['IdPlayerOff'] for e in side['Substitutions']};played=st|on;roster={p['IdPlayer'] for p in players};assert len(st)==11 and len(roster)==len(players) and on<=roster and off<=played and not st&on
    sheetrow=dict(vega_edition=edition,vega_match=vega,fifa_match=mid,fifa_side=sside,vega_root=root,fifa_team=tid,team=fp(side),roster=len(roster),starters=len(st),entered=len(on),appeared=len(played),unused=len(roster-played),entrants_later_off=len(on&off),gk_appearances=sum(p.get('Position')==0 and p['IdPlayer'] in played for p in players),sub_changes=len(side['Substitutions']),sub_clock_missing=sum(not v['Minute'] for v in side['Substitutions']),fifa_picture=side['PictureUrl']);sides.append(sheetrow)
    for p in players:
     k=p['IdPlayer'];registrations.append(dict(vega_edition=edition,vega_match=vega,fifa_match=mid,vega_root=root,fifa_team=tid,fifa_player=k,shirt=p.get('ShirtNumber'),fifa_position=p.get('Position'),sheet_role=('starting' if k in st else 'entered' if k in on else 'unused')))
    for v in side['Substitutions']:
     assert v['IdTeam']==tid;subs.append(dict(vega_edition=edition,vega_match=vega,fifa_match=mid,fifa_team=tid,fifa_on=v['IdPlayerOn'],fifa_off=v['IdPlayerOff'],minute_source=v['Minute'],period=v['Period']))
   g.update({k:sum(s[k] for s in sides[-2:]) for k in ['roster','starters','entered','appeared','unused','gk_appearances','sub_clock_missing']});games.append(g)
  gr=next(r for r in grid if int(r['edition_id'])==edition and r['entity_type']=='player')
  assert int(gr['finished'])==len(cases) and int(gr['known_participations_minimum'])==0 and int(gr['positive_minutes'])==0
 assert len(games)==len({g['vega_match'] for g in games})==22 and len(sides)==44 and len(mapping)==len(MAP) and all(len(v)==1 for v in mapping.values())
 assert all(len({n['fifa_team'] for n in sides if n['fifa_match']==r['fifa_match']})==2 for r in games)
 art=[]
 for root,sets in sorted(mapping.items()):
  p=profiles[root];a,s=next(iter(sets)),[r for r in sides if r['vega_root']==root];link=bool(p['production_asset_id']) or p['in_1585_team_entries'];art.append(dict(root=root,core_name=p['name'],fifa_team=a,fifa_name=MAP[root],appearances_in_this_audit=len(s),all_recorded_sides=p['all_recorded_sides'],fixture_ids='|'.join(str(r['vega_match']) for r in s),fifa_matches='|'.join(r['fifa_match'] for r in s),profile_state=p['profile_state'],production_asset_id=p['production_asset_id'],in_1585=p['in_1585_team_entries'],existing=link,provider_keys=p['previous_provider_keys'],url=s[0]['fifa_picture'].replace('{format}','sq').replace('{size}','4')))
 out('fixtures.csv',games);out('sides.csv',sides);out('rosters-by-id.csv',registrations);out('substitutions.csv',subs);out('artwork.csv',art);out('official-sources.csv',sources)
 return games,sides,registrations,art
if __name__=='__main__':analyze()
