"""Validate the frozen 22 rows independently against the compact public projections."""
from pathlib import Path
from datetime import datetime
from zoneinfo import ZoneInfo
from collections import Counter
import csv,json,hashlib,re
P=Path(__file__).resolve().parent
J=lambda n:json.loads((P/n).read_bytes())
rows=lambda n:list(csv.DictReader((P/n).open()))
def sha(b):return hashlib.sha256(b).hexdigest()
def write(name,rows0):
 with (P/name).open('w',newline='') as f:
  w=csv.DictWriter(f,fieldnames=list(rows0[0]),lineterminator='\n');w.writeheader();w.writerows(rows0)
def main():
 r=rows('fixtures.csv');teams=rows('sides.csv');roster=rows('rosters-by-id.csv');subs=rows('substitutions.csv');rds={str(v['id']):v for v in J('inputs/rds.json')};sources=rows('official-sources.csv');pd=J('inputs/inputs-provenance.json');art=rows('artwork.csv');srcparse={(z['year'],z['archive_position']):z for z in J('parser-outcomes.json')}
 count=[];times=[];aux=[];zone={'2021':'Asia/Dubai','2022':'Africa/Casablanca','2023':'Asia/Riyadh'}
 printed={1:'20:30',2:'20:30',3:'20:30',4:'20:30',5:'17:30',6:'20:30',7:'17:00',8:'20:30'}
 for n in ('production','integration'):
  assert sha((P/'parsers'/(n+'.mjs')).read_bytes())==J('parsers/provenance.json')[n]['sha256']
 for f in sorted((P/'corroboration').glob('*.json')):
  rec=J(f);raw=f.with_suffix('')
  if raw.exists():assert sha(raw.read_bytes())==rec['sha256']
  aux.append(dict(name=raw.name,url=rec['url'],retrieved=rec['at'],http=rec.get('status'),bytes=rec.get('bytes'),sha256=rec.get('sha256')))
 for year,expected in [('2021',(8,176,67,243,103)),('2022',(7,154,57,211,105)),('2023',(7,154,67,221,96))]:
  matches=[u for u in r if u['edition_year']==year];ids={v['vega_match'] for v in matches};ps=[v for v in roster if v['vega_match'] in ids];ev=[v for v in subs if v['vega_match'] in ids]
  assert len({(v['vega_match'],v['vega_root'],v['fifa_player'])for v in ps})==len(ps)
  assert len({(v['vega_match'],v['fifa_team'],v['fifa_on'])for v in ev})==len(ev)
  role={q:sum(v['sheet_role']==q for v in ps)for q in ['starting','entered','unused']}
  assert (len(matches),role['starting'],role['entered'],role['starting']+role['entered'],role['unused'])==expected
  assert all(int(v['elo_sides'])==2 and v['vega_status']=='finished' for v in matches)
  for v in matches:
   rootkey=v['vega_match'];db=rds[rootkey];num=int(v['fifa_number']);tm=[k for k in teams if k['vega_match']==rootkey];assert len(tm)==2 and all(k['starters']=='11' for k in tm)
   for d in tm:
    pp=[x for x in ps if x['vega_match']==rootkey and x['fifa_team']==d['fifa_team']];ss=[x for x in ev if x['vega_match']==rootkey and x['fifa_team']==d['fifa_team']];pstat={x['fifa_player']:x['sheet_role'] for x in pp};assert {v['fifa_on'] for v in ss}=={k for k,w in pstat.items() if w=='entered'} and all(pstat[x['fifa_off']] in ('starting','entered') and x['minute_source'] for x in ss)
   assert all(v[k]=='0' and db[k]==0 for k in ['team_sheets','lineups','stats','positive_minutes','halves','advanced','events','shots','player_intermediates','player_grades'])
   assert not db['match_number'] and db['kickoff_at'] is None and db['home_score_ht'] is db['away_score_ht'] is None
   src=(P/'corroboration'/('openfootball-'+year+'.txt')).read_text();line=next(l for l in src.splitlines() if db['home_team_name'] in l and db['away_team_name'] in l)
   openclock=re.search(r'\d{2}:\d{2}',line)[0];stad=datetime.fromisoformat(v['official_utc']).astimezone(ZoneInfo(zone[year]));trueclock=stad.strftime('%H:%M')
   assert trueclock==openclock and str(stad.date())==v['day_stadium']
   ftclock=v['official_local'][11:16];assert (ftclock==trueclock)==(year!='2021')
   if year=='2021':assert trueclock==printed[num]
   p=srcparse[(int(year),int(v['archive_position']))];assert p['home']==db['home_team_name'] and p['away']==db['away_team_name'] and p['day']==db['match_date']
   for source,keys in [('ft',('home_score_90','away_score_90')),('et',('home_score_et','away_score_et')),('p',('home_penalty_score','away_penalty_score'))]:
    if source in p['old'] and (source!='ft' or 'et' in p['old']):assert p['old'][source]==[db[key] for key in keys]
   times.append(dict(edition=year,vega_match=rootkey,fifa_match=v['fifa_match'],number=num,fifa_utc=v['official_utc'],fifa_raw_LocalDate=v['official_local'],stadium_zone=zone[year],stadium_wall_clock=trueclock,printed_fifa_2021=printed[num] if year=='2021' else '',openfootball_txt_wall_clock=openclock,rds_kickoff=v['vega_kickoff']))
  count.append(dict(edition=year,matches=len(matches),sides=2*len(matches),starters=role['starting'],entrants=role['entered'],appearances=role['starting']+role['entered'],unused=role['unused'],distinct_appeared=len({v['fifa_player'] for v in ps if v['sheet_role']!='unused'}),gk_appearances=sum(v['fifa_position']=='0' and v['sheet_role']!='unused' for v in ps),vega_lineups=sum(int(g['lineups']) for g in matches),vega_stats=sum(int(g['stats'])for g in matches),vega_grades=sum(int(g['player_grades'])for g in matches),swapped_sides=sum(int(v['reversed_order']) for v in matches)))
 assert len(sources)==25 and len(r)==22 and len(times)==22 and len(teams)==44 and len(roster)==979 and len(subs)==191 and len(art)==17
 mismatches={k['vega_match'] for k in r if k['reg_vega_fifa_order'] and k['reg_vega_fifa_order']!=k['reg_fifa']};assert mismatches=={'736663'}
 assert {z['vega_match'] for z in r if z['reversed_order']=='1'}=={'736669','736670'} and {z['vega_match']for z in r if z['pk_fifa']}=={'736665'}
 assert all(not z['vega_number'] and not z['vega_kickoff'] and not z['ht_vega_fifa_order'] and z['vega_stage']=='regular' for z in r)
 assert [x['root'] for x in art if x['existing']=='False']==['13075']
 assert all(v['bytes_match_commit'] for v in J('parsers/provenance.json').values())
 assert [(x['year'],x['archive_position']) for x in srcparse.values() if x['old']!=x['candidate']]==[(2021,7)]
 go=Counter(v['sheet_role'] for v in roster);person=len({v['fifa_player'] for v in roster if v['sheet_role']!='unused'})
 receipt=dict(edition_counts=count,official_match_count=22,played=22,awarded=0,official_sources=25,rounds_typed_regular=22,final_score_by_team_agrees=22,correct_final_score_with_changed_order=2,regulation_nonnull=2,regulation_disagreements=sorted(mismatches),full_time_minutes_exposure_not_measured=True,club_appearances=44,stored_team_elo_sides=44,known_participations=go['starting']+go['entered'],unused=go['unused'],distinct_appeared_overall=person,stored_player_sheet_or_stats_or_grades=0,openfootball_local_clocks=22,fifa_calendar_local_mismatches_uae=8,artwork_roots=17,empty_artwork_root=13075,source_reads=pd['rds'],rds_grid_timestamp=J('inputs/grid-snapshot.json')['at'])
 write('per-edition.csv',count);write('kickoffs.csv',times);write('supplemental-sources.csv',aux);(P/'receipt.json').write_text(json.dumps(receipt,ensure_ascii=False,indent=2)+'\n');print('PASS: 22 fixtures, 44 sides, 979 registered, 675 appeared, 304 unused, 1 historical emblem')
if __name__=='__main__':main()
