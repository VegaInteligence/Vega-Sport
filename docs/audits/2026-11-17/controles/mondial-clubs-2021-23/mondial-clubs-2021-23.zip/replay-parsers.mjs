import {readFileSync,writeFileSync} from 'node:fs';
import {parseOpenCupText as deployed} from './parsers/production.mjs';
import {parseOpenCupText as integration} from './parsers/integration.mjs';
const cases = [];
for (const edition of [2021,2022,2023]) {
  const bytes = readFileSync(new URL('./corroboration/openfootball-'+edition+'.txt',import.meta.url),'utf8');
  const old = deployed(bytes,edition), next = integration(bytes,edition);
  if (old.length!==next.length || old.length!==(edition===2021?8:7)) throw Error('unexpected fixture count');
  for (let index=0;index<old.length;index++) {
    const o=old[index],n=next[index];
    if (o.date!==n.date || o.team1!==n.team1 || o.team2!==n.team2) throw Error('fixture mismatch');
    cases.push({year:edition,archive_position:index,day:o.date,home:o.team1,away:o.team2,old:o.score,candidate:n.score});
  }
}
writeFileSync(new URL('./parser-outcomes.json',import.meta.url),JSON.stringify(cases,null,2)+'\n');
console.log('Replayed',cases.length,'fixtures');
