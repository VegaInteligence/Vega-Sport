"""Verify the original bytes and the two independent public read paths."""
import hashlib
import json
from pathlib import Path
import sys

run = Path(sys.argv[1])
receipt = json.loads((run/'mesure.json').read_bytes())
assert receipt['ordinary_requests'] == 32 and len(receipt['conditional']) == 7
seen=set()
for row in [receipt['index'], *receipt['receipts'], *receipt['conditional'].values()]:
    raw = (run/(row['sha256']+'.json')).read_bytes() if row['bytes'] else b''
    assert len(raw) == row['bytes'] and hashlib.sha256(raw).hexdigest() == row['sha256']
    if row['bytes']:
        seen.add(row['sha256'])
assert list(receipt['generic_detail_status']) == [404]*22
assert receipt['final_summary_status'] == 404 and receipt['native_control_status'] == 200 and receipt['missing_control_status'] == 404
assert all(x['status'] == 304 and x['bytes'] == 0 for x in receipt['conditional'].values())
rows={x['path']:x for x in receipt['receipts']}
for path,record in receipt['edition_observations'].items():
    raw=json.loads((run/(rows[path]['sha256']+'.json')).read_bytes())
    assert rows[path]['status'] == 200 and len(raw['matches']) == record['matches'] == (8 if path.endswith('2021') else 7)
    if path.endswith('2021'):
        final,=[m for m in raw['matches'] if 'Chelsea' in m['team1'] and 'Palmeiras' in m['team2']]
        assert final['score']=={'ft':[2,1],'et':[2,1]}
assert seen == {f.stem for f in run.glob('*.json') if f.name!='mesure.json'}
print(f"{len(seen)} corps, 32 lectures et 7 réponses conditionnelles vérifiés")
