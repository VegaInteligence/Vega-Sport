"""Collect read-only Lambda HTTPS responses without persisting authentication material."""
import argparse
import hashlib
import json
import subprocess
import urllib.error
import urllib.parse
import urllib.request
from datetime import datetime, timezone
from pathlib import Path
from concurrent.futures import ThreadPoolExecutor
from botocore.auth import SigV4Auth
from botocore.awsrequest import AWSRequest
from botocore.credentials import Credentials

here = Path(__file__).resolve().parent
root = here.parents[2]

def service(*args):
    cmd = ['aws', '--profile', 'statarena', '--region', 'us-east-2', *args]
    return json.loads(subprocess.check_output(cmd))

def stamp():
    return datetime.now(timezone.utc).isoformat()

if __name__ == '__main__':
    arg = argparse.ArgumentParser()
    arg.add_argument('output', type=Path)
    destination = arg.parse_args().output
    destination.mkdir(exist_ok=False, parents=True)
    release = service('lambda', 'get-function-configuration', '--function-name', 'vega-v2-api', '--query', '{sha:CodeSha256,modified:LastModified}')
    origin = service('lambda', 'get-function-url-config', '--function-name', 'vega-v2-api', '--query', '{url:FunctionUrl,auth:AuthType}')
    assert origin['auth'] == 'AWS_IAM' and urllib.parse.urlsplit(origin['url']).hostname.endswith('.lambda-url.us-east-2.on.aws')
    identity = service('configure', 'export-credentials', '--format', 'process')
    credentials = Credentials(identity['AccessKeyId'], identity['SecretAccessKey'], identity['SessionToken'])
    def get(path, etag=None):
        url = origin['url'].rstrip('/') + path
        headers = {'Accept':'application/json'}
        if etag:
            headers['If-None-Match'] = etag
        request = AWSRequest('GET', url, headers=headers)
        SigV4Auth(credentials, 'lambda', 'us-east-2').add_auth(request)
        try:
            response = urllib.request.urlopen(urllib.request.Request(url, headers=dict(request.headers)), timeout=30)
        except urllib.error.HTTPError as err:
            response = err
        with response:
            raw = response.read()
            proof = dict(path=path, at=stamp(), status=response.status, etag=response.headers.get('ETag'), sha256=hashlib.sha256(raw).hexdigest(), bytes=len(raw))
            if raw:
                (destination/(proof['sha256']+'.json')).write_bytes(raw)
            return proof, json.loads(raw) if raw else None
    index, body = get('/api/cups/index')
    entries = [x for x in body['cups'] if x['key']=='club-world-cup']
    assert len(entries)==1
    cup_id = entries[0]['id']
    keys=json.loads((here/'cles.json').read_bytes())
    matches=list(keys['matches'].values())
    native=keys['native']
    final='/api/matches/'+keys['matches']['736663']
    assert len(set(matches))==22
    editions=['/api/cups/edition?competition='+cup_id+'&season='+s for s in ('2021','2022','2023')]
    snapshots=['/api/cup-snapshot?kind=edition&competition='+cup_id+'&season='+s for s in ('2021','2022','2023')]
    details=['/api/matches/'+x for x in matches]
    paths=[*editions,*snapshots,*details,final+'/summary','/api/matches/'+native,'/api/matches/m_v999999999']
    with ThreadPoolExecutor(max_workers=3) as pool:
        results=dict(zip(paths,pool.map(get,paths),strict=True))
    conditionals={}
    for p in [*editions,*snapshots,'/api/matches/'+native]:
        tag=results[p][0]['etag']
        if tag:conditionals[p]=get(p,tag)[0]
    report={'captured':stamp(), 'release':release, 'index':index, 'club_world_cup':entries[0], 'ordinary_requests':1+len(paths),
            'receipts':[r[0] for r in results.values()],'conditional':conditionals,'edition_observations':{},'generic_detail_status':[results[x][0]['status'] for x in details],
            'final_summary_status':results[final+'/summary'][0]['status'],'native_control_status':results['/api/matches/'+native][0]['status'],'missing_control_status':results['/api/matches/m_v999999999'][0]['status']}
    for p in editions+snapshots:
        response=results[p][1]
        candidate=response
        while isinstance(candidate,dict) and 'matches' not in candidate:
            candidate=next((candidate[k] for k in ('data','payload','body','snapshot') if isinstance(candidate.get(k),dict)),None)
        ms=candidate.get('matches') if isinstance(candidate,dict) else None
        witness=next((m for m in (ms or []) if 'Chelsea' in str(m.get('team1')) and 'Palmeiras' in str(m.get('team2'))),None)
        report['edition_observations'][p]={'status':results[p][0]['status'],'matches':len(ms) if ms is not None else None,
                                           'representation':list(response) if isinstance(response,dict) else None,'chelsea_palmeiras':witness}
    (destination/'mesure.json').write_text(json.dumps(report,indent=2,ensure_ascii=False)+'\n')
    print(report['ordinary_requests'], len(conditionals), report['edition_observations'], 'details',sorted(set(report['generic_detail_status'])), 'controls',report['native_control_status'],report['missing_control_status'])
