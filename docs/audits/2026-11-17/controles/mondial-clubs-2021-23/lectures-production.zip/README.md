# Parcours HTTP du Mondial des clubs

Deux mesures de l’origine Lambda authentifiée du 18 novembre 2026, à 10 h 31 et à 10 h 37 UTC, ont retrouvé les mêmes statuts et valeurs sportives. La seconde mesure est incluse. Le profil AWS `statarena` a permis de lire la configuration et de signer les GET. L’archive contient les corps effectivement reçus et leurs empreintes.

L’index identifie le Mondial des clubs sous la clé publique `l_v0000065`. Les trois éditions et leurs trois snapshots renvoient HTTP 200 et 8, 7 et 7 rencontres. Les deux voies renvoient 2–1 à 90 minutes et 2–1 après prolongation pour Chelsea–Palmeiras. Les 22 lecteurs individuels répondent 404, ainsi que le résumé du match témoin. Le contrôle natif répond 200 et la clé inconnue répond 404. Les sept relectures conditionnelles avec le même ETag répondent 304. Le composant `CupCompetition.jsx` rend les rencontres du lecteur d’édition dans sa liste.

Depuis une extraction neuve, `python3 verifier.py mesure` vérifie les réponses hors ligne. Avec le profil AWS authentifié, les permissions de lecture de la Lambda et Python équipé de botocore, `python3 mesurer.py nouvelle-mesure` reproduit les GET avec leurs identifiants publics. Les réponses peuvent évoluer après déploiement ou correction des données.
