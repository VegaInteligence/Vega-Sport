"""Produit le relevé local avec deux arbres immuables et un PostgreSQL 18 jetable."""
import argparse,contextlib,hashlib,http.client,io,json,os,subprocess,sys,tarfile,tempfile,time,uuid
from pathlib import Path
import psycopg
H=Path(__file__).resolve().parent
VERSIONS={'production':'8018e0836ca0f32e8b2eb51fc2847154abff7f13','integration':'da7506986481e6187fb231aa94ab6c7239663fe7'}
DIRS=['backend/vega','backend/sql','backend/api/src','backend/api/package.json','backend/api/package-lock.json','backend/sources','dashboard/shared','dashboard/package.json','dashboard/frontend/package.json','dashboard/frontend/src']
FILES=['backend/vega/store.py','backend/vega/sources/cups.py','backend/vega/sources/__init__.py','backend/vega/sources/wikidata.py','backend/vega/sources/snapshot.py','backend/vega/worker.py','backend/sources/bridge.mjs','backend/sources/projections/open-cups.mjs','dashboard/frontend/src/services/openfootball-cups.js','backend/api/src/handler.mjs','backend/api/src/routes/cups.mjs','backend/api/src/routes/match-details.mjs','backend/api/src/routes/matches.mjs','backend/api/src/db.mjs','backend/api/package-lock.json']
sha=lambda b:hashlib.sha256(b).hexdigest()
def run(argv,**kw):return subprocess.run(argv,check=True,capture_output=True,**kw)
def dump(p,x):p.write_text(json.dumps(x,indent=2,ensure_ascii=False,default=str)+'\n')
def tuples(conn,sql):
    cur=conn.execute(sql)
    return [dict(zip([s.name for s in cur.description],r,strict=True)) for r in cur]
def norm(x):return json.loads(json.dumps(x,default=str))
def state(conn):
    matches=tuples(conn,"""SELECT m.season_id,m.id,api.public_id('match',m.id) AS public_id,p.provider_key,
              m.competition_season_id AS edition,m.match_date,m.archive_position,m.round_id,m.home_team_id,m.away_team_id,
              m.home_team_name,m.away_team_name,m.status,m.home_score,m.away_score,m.home_score_90,m.away_score_90,m.home_score_et,m.away_score_et,
              m.home_score_ht,m.away_score_ht,m.home_penalty_score,m.away_penalty_score,m.revision,m.updated_at,m.xmin::text AS xmin
              FROM core.matches m JOIN core.provider_ids p ON p.entity_type='match' AND p.provider='openfootball' AND p.entity_id=m.id ORDER BY m.id""")
    editions=tuples(conn,"""SELECT id,cup_key,cup_name,cup_digest,cup_updated_at,cup_checked_at,updated_at,xmin::text FROM core.competition_seasons ORDER BY id""")
    status={}
    for k,t in [('versions','ops.resource_versions'),('dirty','ops.dirty_scopes'),('publication','ops.publication')]:
        status[k]=tuples(conn,'SELECT * FROM '+t+' ORDER BY 1,2')
    others={t:sha(json.dumps(tuples(conn,f'SELECT *,xmin::text AS physical_version FROM {t} ORDER BY 1,2,3'),sort_keys=True,default=str).encode()) for t in ['core.provider_ids','core.rounds','core.teams']}
    views=tuples(conn,"""SELECT id,api.internal_id('match',api.public_id('match',id)) AS recovered_key,
             (SELECT count(*) FROM api.cup_matches c WHERE c.match_id=m.id) AS in_cup_matches,
             (SELECT count(*) FROM api.fixtures f WHERE f.match_id=m.id) AS in_fixtures FROM core.matches m ORDER BY id""")
    return norm(dict(matches=matches,editions=editions,notification=status,other_tables_sha=others,views=views))
def requests(tree,dsn,match_rows,prior):
    proc=subprocess.Popen(['node',str(H/'servir.mjs'),str(tree),dsn],stdout=subprocess.PIPE,stderr=subprocess.PIPE,text=True)
    try:
        ln=proc.stdout.readline()
        if not ln:raise RuntimeError(proc.stderr.read()[:2000])
        port=int(ln);out={}
        paths=[f'/api/cups/edition?competition=l_v0000065&season={year}' for year in [2021,2022,2023]]
        paths += [f'/api/cup-snapshot?kind=edition&competition=l_v0000065&season={year}' for year in [2021,2022,2023]]
        paths+=['/api/matches/'+r['public_id'] for r in match_rows]
        paths+=['/api/dashboard/manifest','/api/health']
        paths+=['/api/matches/'+next(r['public_id'] for r in match_rows if r['id']==736663)+'/summary']
        for p in paths:
            def get(headers):
                c=http.client.HTTPConnection('127.0.0.1',port,timeout=25)
                try:c.request('GET',p,headers=headers);r=c.getresponse();return r.status,r.getheader('ETag'),r.read()
                finally:c.close()
            code,etag,body=get({})
            try:js=json.loads(body)
            except ValueError:js={'response_unreadable':True}
            out[p]=dict(status=code,etag=etag,body_sha=sha(body),body=js,bytes=len(body))
            if prior and p in prior and prior[p]['etag']:
                code,_,_=get({'If-None-Match':prior[p]['etag']})
                out[p]['if_prior_etag_status']=code
        return out
    finally:
        proc.terminate()
        try:proc.wait(5)
        except subprocess.TimeoutExpired:proc.kill();proc.wait()
def main():
    ap=argparse.ArgumentParser();ap.add_argument('checkout',type=Path);ap.add_argument('out',type=Path);ap.add_argument('--candidat-local',action='store_true')
    a=ap.parse_args();W=a.checkout.resolve();out=a.out.resolve();out.mkdir(parents=True,exist_ok=False)
    inputs=json.loads((H/'inputs/facts.json').read_bytes())
    docker=['docker','--context','colima']
    token='cwc-phase-'+uuid.uuid4().hex[:12]
    image=run([*docker,'image','inspect','pgvector/pgvector:pg18','--format','{{.Id}}'],text=True).stdout.strip()
    meta={'code':{},'image_locale':image,'original_snapshot':inputs['at'],'source_ouverte':{},'stages':[]}
    openenv={**os.environ,'GIT_OPTIONAL_LOCKS':'0','PYTHONDONTWRITEBYTECODE':'1'}
    with tempfile.TemporaryDirectory(prefix='arbres-',dir=out) as tmp:
        envs={};trees={}
        for name,rev in VERSIONS.items():
            ws=Path(tmp)/name;ws.mkdir();trees[name]=ws
            archived=run(['git','-C',str(W),'archive',rev,*DIRS],env=openenv).stdout
            with tarfile.open(fileobj=io.BytesIO(archived)) as tar:tar.extractall(ws,filter='data')
            (ws/'backend/api/node_modules').symlink_to(W/'backend/api/node_modules')
            (ws/'dashboard/node_modules').symlink_to(W/'dashboard/node_modules')
            files={f:sha((ws/f).read_bytes()) for f in FILES if (ws/f).exists()}
            meta['code'][name]={'revision':rev,'files':files}
            if name=='integration':meta['code']['ecarts_fichiers_de_travail']={f:{'commit':s,'travail':sha((W/f).read_bytes())} for f,s in files.items() if (W/f).exists() and sha((W/f).read_bytes())!=s}
            if name=='integration' and a.candidat_local:
                manifest=json.loads((H/'candidat-local/empreintes.json').read_bytes())
                for f,pins in manifest.items():
                    assert sha((ws/f).read_bytes())==pins['commit']
                    if pins['working']!=pins['commit']:
                        content=(H/'candidat-local'/f).read_bytes();assert sha(content)==pins['working'];(ws/f).write_bytes(content)
                meta['code']['overlay_local_horodate']=manifest
            envs[name]={**openenv,'NODE_OPTIONS':'--import='+ (H/'frozen-fetch.mjs').as_uri(),'CWC_INPUTS':str(H/'inputs')}
        meta['source_ouverte']={p.name:sha(p.read_bytes()) for p in (H/'inputs').glob('*.txt')}
        run([*docker,'run','--pull=never','--rm','--detach','--name',token,'-p','127.0.0.1::5432',
             '-e','POSTGRES_HOST_AUTH_METHOD=trust','-e','POSTGRES_DB=vega_v2_cwc_replay',image])
        try:
            bound=run([*docker,'port',token,'5432/tcp'],text=True).stdout.strip()
            assert bound.startswith('127.0.0.1:') and '\n' not in bound
            dsn='postgresql://postgres@'+bound+'/vega_v2_cwc_replay'
            for _ in range(100):
                try:conn=psycopg.connect(dsn,connect_timeout=1,autocommit=True);break
                except psycopg.OperationalError:time.sleep(.2)
            else:raise RuntimeError('PostgreSQL local pas prêt')
            with conn:
                meta['pg']=conn.execute('SELECT version()').fetchone()[0];assert 'PostgreSQL 18.' in meta['pg']
                def action(version,mode,at):
                    x=subprocess.run([sys.executable,'-B',str(H/'stage.py'),str(trees[version]),dsn,mode,at],env=envs[version],text=True,capture_output=True)
                    if x.returncode:raise RuntimeError(mode+' '+x.stderr[-2300:])
                    lines=x.stdout.strip().splitlines()
                    if len(lines)>1:(out/(version+'-'+mode+'-'+day[:10]+'.log')).write_text('\n'.join(lines[:-1])+'\n')
                    return json.loads(lines[-1])
                prior=None
                for name,version,day in [('ancienne','production','2026-10-28'),('ancienne-relue','production','2026-11-04'),('integration','integration','2026-11-11'),('integration-relue','integration','2026-11-18')]:
                    if name in ['ancienne','integration']:
                        mig=action(version,'migrate',day);meta['code'][version]['migrations']=mig
                    if name=='ancienne':
                        action(version,'seed',day)
                        conn.execute("INSERT INTO ops.resource_versions(resource_kind,resource_id) VALUES ('home',1)")
                        assert action(version,'publish',day)['generation']==1
                    
                    s=action(version,'run',day);snap=state(conn)
                    if set(s['results'].values())!={'ok'}:raise RuntimeError(json.dumps(s))
                    pub=action(version,'publish',day);http=requests(trees[version],dsn,snap['matches'],prior);prior=http
                    dump(out/(name+'.json'),dict(run=s,db=snap,publication_forcee=pub,http=http))
                    print(name,len(snap['matches']),s['runs'],[(k,x['status']) for k,x in list(http.items())[:1]],flush=True)
                    meta['stages'].append(name);dump(out/'provenance.json',meta)
                immediate=action('integration','run','2026-11-18T00:01:00');dump(out/'immediat.json',immediate)
                conn.execute("UPDATE ops.resource_versions SET version=version+1 WHERE resource_kind='home' AND resource_id=1")
                ctrl=action('integration','publish','2026-11-18T00:02:00')
                checks=requests(trees['integration'],dsn,snap['matches'],prior)
                ctrl.update({k:v for k,v in checks.items() if k in ('/api/dashboard/manifest','/api/health')})
                dump(out/'temoin-publication.json',ctrl)
        finally:
            run([*docker,'rm','-f','-v',token]);meta['conteneur_detruit']=True;dump(out/'provenance.json',meta)
if __name__=='__main__':main()
