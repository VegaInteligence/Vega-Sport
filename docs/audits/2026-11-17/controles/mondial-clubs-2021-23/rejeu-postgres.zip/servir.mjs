import {createServer} from 'node:http';
import {pathToFileURL} from 'node:url';
import {resolve} from 'node:path';
const [tree,dsn] = process.argv.slice(2);
const {createReader}=await import(pathToFileURL(resolve(tree,'backend/api/src/db.mjs')));
const {createHandler}=await import(pathToFileURL(resolve(tree,'backend/api/src/handler.mjs')));
const db=createReader(dsn,{role:'vega_read'});
const handler=createHandler({read:db.read});
const server=createServer(async(req,res)=>{
  try {
    const reply=await handler(new Request('http://127.0.0.1'+req.url,{headers:req.headers,method:req.method}));
    res.writeHead(reply.status,Object.fromEntries(reply.headers.entries()));
    res.end(Buffer.from(await reply.arrayBuffer()));
  } catch(e) { res.writeHead(500);res.end(JSON.stringify({error:String(e)})); }
});
server.listen(0,'127.0.0.1',()=>console.log(server.address().port));
process.on('SIGTERM',()=>server.close(async()=>{await db.end();process.exit(0);}));
