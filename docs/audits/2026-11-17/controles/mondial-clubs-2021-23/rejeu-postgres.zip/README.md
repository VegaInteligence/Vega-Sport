# Mise à niveau des 22 rencontres de Coupe du monde des clubs 2021–2023

**Le commit `da7506986481e6187fb231aa94ab6c7239663fe7` corrige le score à 90 minutes de Chelsea–Palmeiras et préserve les 22 identifiants de match.** Sur PostgreSQL 18 local, la réponse HTTP de l’édition 2021 passe de `{"ft":[2,1],"et":[2,1]}` à `{"ft":[1,1],"et":[2,1]}`. Les deux périodes sont lues dans les lignes persistées. Seule la rencontre **736663** reçoit une nouvelle révision. Les 22 mi-temps présentes dans OpenFootball demeurent absentes du stockage et des réponses de coupe, y compris les six vrais 0–0. [Résultats](resultats.json)

| Passage du writer | Édition 2021 | 2022 | 2023 | État observable |
|---|---:|---:|---:|---|
| Déployé `8018e08`, initialisation | 8 | 7 | 7 | 22 insertions et trois digests identiques à ceux du snapshot RDS |
| Même version, semaine suivante | 0 | 0 | 0 | Les 22 tuples de match restent physiquement identiques |
| Passage à `da75069864` | **1** | 0 | 0 | Chelsea–Palmeiras passe de la révision locale 1 à 2 |
| Même version, semaine suivante | 0 | 0 | 0 | Aucun tuple de match réécrit. Un nouvel appel une minute plus tard ne sélectionne aucune édition |

## Clés, empreintes et lecteurs HTTP

Les 22 identifiants **736656 à 736677**, les 17 clubs, les tours, les trois éditions **31672, 31673 et 31675**, la famille **65** et les saisons sont ceux des captures sources. Le match témoin conserve `m_v0736663` et sa clé OpenFootball `club-world-cup:2021:2022-02-12|Chelsea FC (ENG)|Palmeiras (BRA)|`. Les 22 clés de match sont reconstruites par le writer déployé à partir du texte original. Pour le Real Madrid et Manchester City, la table de correspondance contient bien l’alias OpenFootball avec le suffixe de pays, marqué ancien. Les clés actuelles sans suffixe sont conservées sur les mêmes clubs. [Entrées et empreintes](inputs/receipts.json) · [Clés de club gelées](inputs/team-bindings.json)

Le nouveau writer interprète le digest sur les lignes persistées avec la version `cup-rows-v2`. Au premier passage, les **trois digests changent**, même pour les deux éditions dont aucune rencontre n’a changé. La date de modification sportive `cup_updated_at` avance seulement pour 2021. À la relecture identique de la semaine suivante, le writer met à jour `cup_checked_at` et le tuple de chacune des trois éditions, et le planificateur consigne le succès de lecture. Les 22 matchs, leurs révisions, leurs versions physiques, les tours, les équipes et les clés fournisseur demeurent stables. [Valeurs de digest](resultats.json)

- **Éditions et snapshots.** Les trois GET `/api/cups/edition?competition=l_v0000065&season=…` et les trois GET `/api/cup-snapshot?kind=edition&competition=l_v0000065&season=…` répondent 200 avec les 22 matchs attendus. L’ancien ETag de l’édition 2021 déclenche bien une réponse 200 après la correction, puis 304 à la relecture identique. Les éditions 2022 et 2023 restent à 304 sur leurs anciens ETag. Les snapshots datent la dernière vérification et renvoient 200 après chaque lecture hebdomadaire, même quand les matchs n’ont pas changé.
- **Routes individuelles.** Sur ces mêmes données locales, les 22 GET `/api/matches/m_v…` et le résumé `/api/matches/m_v0736663/summary` renvoient 404. Le SQL restitue les 22 clés via `api.internal_id` et les 22 lignes via `api.cup_matches`. La vue `api.fixtures` exige `cs.cup_key IS NULL`, ce qui écarte ces éditions du lecteur individuel. Le passage au nouveau writer ne change pas cette portée.
- **Notification globale.** L’ETag du manifeste de tableau de bord ne change pas lors de la correction, et un GET muni de l’ancien ETag reçoit 304. Aucune version de ressource ni aucun périmètre de recalcul n’est ajouté par ce chemin de coupe dans la base isolée. Un appel explicite au véritable `worker.publish(force=True)` garde la génération 1. Un contrôle indépendant qui avance une ressource témoin permet à la même publication de passer de 1 à 2, puis obtient 200 avec l’ancien ETag du manifeste. Le cache de l’édition sait reconnaître la correction par le contenu. Un consommateur qui n’observe que la génération globale ne reçoit pas ce signal lors de l’essai. [Reçu du témoin global](verification/temoin-publication.json)

## Phases encore manquantes et portée

Les trois textes fournissent la mi-temps pour **22 matchs sur 22**. Leur dernière paire entre parenthèses est identique au registre FIFA gelé une fois appliquée l’orientation des équipes, inversée pour deux matchs de 2022. Les 22 paires de mi-temps attestées restent `NULL/NULL` dans les deux états PostgreSQL et le membre `ht` est absent dans les corps HTTP. Pour Wydad–Al Hilal en 2022, les deux versions préservent 1–1 à 90 minutes, 1–1 après prolongation et 3–5 aux tirs au but. Les étapes, calendriers, notes, Elo et navigation en production ne sont pas mesurés par cet essai. Les constats de phases manquantes et de notification sont remis aux propriétaires T4 et VI-21.

Le premier essai de référence utilise exclusivement les blobs Git des deux révisions pour le parseur, le writer, les migrations et l’API. Un second essai local a appliqué à la version d’intégration les **deux fichiers appelés de la copie de travail** dont les octets différaient, le lecteur des coupes et la fonction partagée OpenFootball. Le parseur des trois textes, sa projection et le writer correspondent au commit gelé. Les résultats mesurés sont identiques sur ces 22 matchs. La copie de travail retire le repli vers le score final en présence d’une prolongation dont le score à 90 minutes manque. Aucun des deux matchs à prolongation de cet échantillon n’est dans cet état après l’upgrade. [Provenance du commit](verification/provenance.json) · [Empreintes du candidat local](candidat-local/empreintes.json)

La base est construite par les migrations réelles. Le chargeur exécute `sources.run_due` puis `cups.For.run → cups.run → cups.save` avec le rôle `vega_collect`. Le vrai bridge Node appelle la projection du commit. Seul le transport des trois URL OpenFootball est remplacé par la lecture des octets scellés. Le serveur HTTP ouvre une vraie socket en boucle locale, exécute `createHandler` et `createReader` avec le rôle `vega_read`. Les GET ont lieu après la validation de la transaction. Les révisions initiales 1, les temps de vérification hebdomadaires, le tuple physique, les ressources initiales et les dates système PostgreSQL sont des valeurs de test. Les matchs, scores et digests de départ sont comparés directement au snapshot RDS du **18 novembre 2026 à 10 h 12 min 07 s UTC**. Les identités des joueurs, les assets, les Elo et les autres données d’exploitation n’ont pas été répliqués.

## Vérifier ou reproduire

Le rejeu des preuves à partir de l’archive extraite demande seulement Python 3.10 ou ultérieur.

```sh
shasum -a 256 -c SHA256SUMS
python3 -B verifier.py
```

Pour répéter l’expérience PostgreSQL, fournir un checkout possédant les deux commits, les dépendances Node déjà installées dans `backend/api` et `dashboard`, Python 3.12 ou supérieur avec psycopg 3, Node ≥20 et Docker local (contexte `colima`) avec l’image préinstallée `pgvector/pgvector:pg18`. L’empreinte d’image utilisée figure dans le reçu. La commande lit les blobs par `git archive` et ne modifie pas le checkout. Elle exige un dossier de résultats neuf, crée le conteneur sur une adresse de boucle locale à port éphémère et le détruit en fin d’essai.

```sh
python3 -B essai.py "$CHECKOUT" reproduction-locale
python3 -B verifier.py reproduction-locale
python3 -B essai.py "$CHECKOUT" reproduction-candidat --candidat-local
python3 -B verifier.py reproduction-candidat
```

Les essais préparatoires incomplets restent dans le dossier opérateur. Le périmètre de la capsule comprend les deux passages terminés, leurs données et leur commande. Les trois textes OpenFootball et les chiffres du registre sportif fournissent les entrées de l’essai. Les sites HTML des tiers et les accès de production en sont absents.
