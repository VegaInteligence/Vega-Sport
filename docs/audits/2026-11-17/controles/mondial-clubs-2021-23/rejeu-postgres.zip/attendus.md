# Attendus avant exécution

Isoler une base PostgreSQL 18 locale, une famille de compétition et les trois éditions scellées. Rétablir les clés d’équipe, de saison, d’édition, de tour et de match d’après les observations disponibles. Les horaires de lecture, métadonnées absentes et numéros initiaux de révision sont des témoins locaux. La même lecture des trois textes doit reconstruire le digest ancien et les phases enregistrées avant toute comparaison.

Comparer les corps réellement servis par GET pour les trois éditions, les snapshots de coupe et la rencontre témoin avant, après et après rejeu. L’attendu sportif est Chelsea–Palmeiras 0–0 à la pause, 1–1 après 90 minutes, 2–1 après prolongation. Mesurer quelles valeurs le produit restitue. Ne jamais remplacer une mi-temps manquante par zéro.

Un nouveau digest peut être dû à la version du writer sans modification de match. Vérifier chaque tuple match, ses IDs, clés externes, révision et version physique ; séparer le suivi de lecture des modifications sportives. Relever les signaux de publication, les codes HTTP et les ETag conditionnels. Une erreur, un endpoint sans phase ou une publication restée inchangée sera rapporté tel quel. Aucun appel source en ligne.
