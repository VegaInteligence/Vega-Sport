import {readFileSync} from 'node:fs';
import {createHash} from 'node:crypto';
import {join} from 'node:path';
globalThis.fetch = async (input) => {
  const url = typeof input === 'string' ? input : input.url;
  const m = /^https:\/\/raw\.githubusercontent\.com\/openfootball\/club-worldcup\/master\/(2021|2022|2023)\/clubworldcup\.txt$/.exec(url);
  if (!m) throw Error('Source hors des trois éditions autorisées');
  const bytes=readFileSync(join(process.env.CWC_INPUTS,'openfootball-'+m[1]+'.txt'));
  const receipt=JSON.parse(readFileSync(join(process.env.CWC_INPUTS,'receipts.json')))[`openfootball-${m[1]}.txt`];
  if (receipt.url!==url || createHash('sha256').update(bytes).digest('hex')!==receipt.sha256) throw Error('Source modifiée');
  return new Response(bytes,{status:200,headers:{'Content-Type':'text/plain; charset=utf-8'}});
};
