"""Assemble la liste scellée et valide les preuves après une extraction neuve."""
import hashlib
import io
import json
from pathlib import Path
import subprocess
import sys
import tempfile
import zipfile

ROOT = Path(__file__).resolve().parent
NAME = 'rejeu-coupes-du-monde-des-clubs-2021-2023.zip'
SOURCE = ['README.md', 'attendus.md', 'resultats.json', 'verifier.py', 'essai.py',
          'stage.py', 'servir.mjs', 'frozen-fetch.mjs', 'emballer.py',
          'verification.log', 'verification-candidat-local.log',
          'candidat-local/empreintes.json', 'candidat-local/backend/api/src/routes/cups.mjs',
          'candidat-local/dashboard/shared/openfootball-history.js']
FILES = ['facts.json', 'receipts.json', 'team-bindings.json', 'phases-attestees.json',
         'openfootball-2021.txt', 'openfootball-2022.txt', 'openfootball-2023.txt']
STAGES = ['ancienne', 'ancienne-relue', 'integration', 'integration-relue', 'immediat',
          'provenance', 'temoin-publication']
MEMBERS = sorted(SOURCE + ['inputs/' + f for f in FILES] +
                 [d + '/' + stage + '.json' for d in ['verification', 'verification-candidat-local'] for stage in STAGES])


def sha(data):
    return hashlib.sha256(data).hexdigest()


def assemble():
    contents = {name: (ROOT / name).read_bytes() for name in MEMBERS}
    contents['SHA256SUMS'] = ''.join(f'{sha(value)}  {name}\n' for name, value in contents.items()).encode()
    buffer = io.BytesIO()
    with zipfile.ZipFile(buffer, 'w') as archive:
        for name, value in sorted(contents.items()):
            entry = zipfile.ZipInfo(name, (2025, 1, 1, 0, 0, 0))
            entry.create_system = 3
            entry.external_attr = 0o100644 << 16
            archive.writestr(entry, value, zipfile.ZIP_DEFLATED, compresslevel=9)
    return buffer.getvalue(), sha(contents['SHA256SUMS'])


def main():
    blob, manifest = assemble()
    assert assemble() == (blob, manifest)
    with tempfile.TemporaryDirectory(dir=ROOT) as tmp:
        dest = Path(tmp)
        with zipfile.ZipFile(io.BytesIO(blob)) as archive:
            assert archive.testzip() is None and set(archive.namelist()) == set(MEMBERS) | {'SHA256SUMS'}
            archive.extractall(dest)
        for entry in MEMBERS:
            if entry.endswith('.py'):
                compile((dest / entry).read_bytes(), entry, 'exec')
            if entry.endswith(('.mjs', '.js')):
                subprocess.run(['node', '--check', entry], cwd=dest, check=True, capture_output=True)
        cmd = ['shasum', '-a', '256', '-c', 'SHA256SUMS']
        checked = subprocess.run(cmd, cwd=dest, check=True, capture_output=True).stdout.splitlines()
        assert len(checked) == len(MEMBERS) and all(line.endswith(b': OK') for line in checked)
        result = subprocess.run([sys.executable, '-I', '-B', 'verifier.py'], cwd=dest,
                                check=True, capture_output=True).stdout
        assert result == (dest / 'resultats.json').read_bytes()
    (ROOT / NAME).write_bytes(blob)
    print(json.dumps(dict(zip=NAME, sha256=sha(blob), octets=len(blob), membres=len(MEMBERS)+1,
                          fichiers_scelles=len(MEMBERS), sha256_liste=manifest,
                          constructions_identiques=2, extraction_neuve=True,
                          sources_python_javascript_verifiees=True, relectures_postgresql=2,
                          sortie_verificateur_sha256=sha(result)), indent=2))


if __name__ == '__main__':
    main()
