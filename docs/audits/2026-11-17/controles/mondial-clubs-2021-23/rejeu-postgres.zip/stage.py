"""Un processus par révision évite de partager des modules entre versions."""
import sys,os,json,hashlib
from datetime import datetime,timezone
from pathlib import Path
folder,dsn,action,day= sys.argv[1:]
sys.path.insert(0,str(Path(folder)/'backend'))
from vega import store,sources,worker
from vega.sources import cups
HERE=Path(__file__).resolve().parent
freeze=json.loads((HERE/'inputs/facts.json').read_bytes());editions=sorted({(g['season_id'],g['edition']) for g in freeze['games']})
when=datetime.fromisoformat(day).replace(tzinfo=timezone.utc)
db=store.connect_local(dsn)
try:
    if action=='migrate':
        store.migrate(db)
        print(json.dumps(db.execute('select version from ops.schema_migrations order by 1').fetchall()));sys.exit(0)
    if action=='seed':
        with db.transaction():
            db.execute("INSERT INTO core.competitions(id,name) VALUES (65,'Club World Cup 2025')")
            for t in freeze['team_aliases']:
                db.execute('INSERT INTO core.teams(id,name) VALUES (%s,%s)',(t['team_id'],t['name']))
            for kind,provider,key,tid,current in json.loads((HERE/'inputs/team-bindings.json').read_bytes())['provider_keys']:
                db.execute("INSERT INTO core.provider_ids(entity_type,provider,provider_key,entity_id,is_current) VALUES (%s,%s,%s,%s,%s)",(kind,provider,key,tid,current))
            for g in freeze['games']:
                for side in ('home','away'):
                    k='name:'+g[side+'_team_name']
                    r=db.execute("SELECT entity_id FROM core.provider_ids WHERE provider='openfootball' AND entity_type='team' AND provider_key=%s",(k,)).fetchone()
                    assert r and r[0]==g[side+'_team_id'],(k,r,g[side+'_team_id'])
            for y,edition in editions:
                store.Store(db).season(f'{y}/{y+1}')
                db.execute("INSERT INTO core.competition_seasons(id,competition_id,season_id,native_label,cup_key) VALUES (%s,65,%s,%s,%s)",(edition,y,str(y),f'open-cups:club-world-cup:{y}'))
            for rid,edition,name in sorted({(r['round_id'],r['edition'],r['registered_round']) for r in freeze['games']}):
                db.execute("INSERT INTO core.rounds(id,competition_season_id,name) VALUES (%s,%s,%s)",(rid,edition,name))
            db.execute("SELECT setval(pg_get_serial_sequence('core.matches','id'),736656,false)")
        print('{}');sys.exit(0)
    if action=='publish':
        print(json.dumps({'generation':worker.publish(db,when,force=True)}));sys.exit(0)
    scopes={f'open-cups:club-world-cup:{year}' for year,_ in editions}
    # Les autres éditions sont déclarées lues pour ce passage, de façon à laisser due() choisir normalement les trois cibles.
    with db.transaction():
        for sc in sorted(set(cups.For('open-cups').scopes(when))-scopes):
            sources.record_run(db,'openfootball',sc,when,None,0,0)
    db.execute('SET ROLE vega_collect')
    pre=sources.due(db,when,'openfootball',cups.For('open-cups'))
    result=sources.run_due(db,None,when,names={'openfootball'})
    db.execute('RESET ROLE')
    checks=db.execute("SELECT scope,status,rows_written,error_code FROM ops.source_runs WHERE scope=ANY(%s) ORDER BY scope",(sorted(scopes),)).fetchall()
    print(json.dumps({'selection':pre,'results':{k[1]:v for k,v in result.items()},'runs':checks}))
finally:db.close()
