"""Vérification hors ligne des lectures HTTP et des résultats PostgreSQL capturés."""
import argparse,csv,hashlib,json,re
from pathlib import Path

P=Path(__file__).resolve().parent
read=lambda p:json.loads(p.read_bytes())
def check(folder):
    data=[read(folder/(s+'.json')) for s in ('ancienne','ancienne-relue','integration','integration-relue')]
    rds={g['id']:g for g in read(P/'inputs/facts.json')['games']}
    facts={int(g['vega_match']):g for g in read(P/'inputs/phases-attestees.json')['matchs']}
    texts={}
    for y in (2021,2022,2023):
        f=P/'inputs'/f'openfootball-{y}.txt';b=f.read_bytes()
        assert hashlib.sha256(b).hexdigest()==read(P/'inputs/receipts.json')[f.name]['sha256']
        raw=[re.findall(r'(\d+)-(\d+)',g.group(1))[-1] for line in b.decode().splitlines() if ' v ' in line for g in [re.search(r'\(([^()]*)\)\s*$',line)] if g]
        texts[y]=[list(map(int,x)) for x in raw]
    all_ids=sorted(rds);assert len(all_ids)==22==len(facts)
    scores=['home_score','away_score','home_score_90','away_score_90','home_score_et','away_score_et','home_score_ht','away_score_ht','home_penalty_score','away_penalty_score']
    physical=[];digests=[];notification=[];header=None
    for n,stage in enumerate(data):
        db=stage['db'];games=db['matches'];assert [r['id'] for r in games]==all_ids
        assumed=[8,7,7] if n==0 else [1,0,0] if n==2 else [0,0,0]
        assert [x[2] for x in stage['run']['runs']]==assumed and len(stage['run']['selection'])==3
        assert all(x[1]=='ok' for x in stage['run']['runs'])
        assert all(v['id']==v['recovered_key'] and v['in_fixtures']==0 and v['in_cup_matches']==1 for v in db['views'])
        editions={v['id']:v for v in db['editions']}
        physical.append({g['id']:g['xmin'] for g in games});digests.append({eid:r['cup_digest'] for eid,r in editions.items()})
        for g in games:
            rid=g['id'];yr=g['season_id'];c=rds[rid];official=facts[rid]
            for key in ['id','season_id','edition','status','archive_position','home_team_id','away_team_id','home_team_name','away_team_name','round_id','match_date',*scores]:
                expect=1 if n>=2 and rid==736663 and key=='home_score_90' else c[key]
                assert g[key]==expect,(rid,key,g[key],expect)
            assert g['revision']==(2 if n>=2 and rid==736663 else 1)
            assert g['provider_key']==f"club-world-cup:{yr}:{g['match_date']}|{g['home_team_name']}|{g['away_team_name']}|"
            if n<2:assert editions[g['edition']]['cup_digest']==c['cup_digest']
            zone=stage['http'][f'/api/cups/edition?competition=l_v0000065&season={yr}']
            snap=stage['http'][f'/api/cup-snapshot?kind=edition&competition=l_v0000065&season={yr}']
            assert zone['status']==snap['status']==200 and zone['body']['matches']==snap['body']['matches']
            wire=zone['body']['matches'][g['archive_position']];ht=list(map(int,official['ht_fifa'].split('-')))
            if official['reversed_order']=='1':ht=ht[::-1]
            assert texts[yr][g['archive_position']]==ht
            assert wire['date']==g['match_date'] and wire['team1']==g['home_team_name'] and wire['team2']==g['away_team_name']
            pair=list(map(int,official['reg_fifa'].split('-')))
            if official['reversed_order']=='1':pair=pair[::-1]
            assert wire['score']['ft']==([2,1] if n<2 and rid==736663 else pair)
            assert ('ht' not in wire['score']) and g['home_score_ht'] is None and g['away_score_ht'] is None
            for field,official_field in [('et','after_et_fifa'),('p','pk_fifa')]:
                expected=official[official_field]
                if expected:
                    pair=list(map(int,expected.split('-')))
                    assert wire['score'][field]==(pair[::-1] if official['reversed_order']=='1' else pair)
                else:assert field not in wire['score']
            assert stage['http']['/api/matches/'+g['public_id']]['status']==404
            if n>0:
                assert zone['if_prior_etag_status']==(200 if yr==2021 and n==2 else 304)
                assert snap['if_prior_etag_status']==200
        assert stage['http']['/api/matches/m_v0736663/summary']['status']==404
        manifest=stage['http']['/api/dashboard/manifest']
        assert manifest['status']==200 and str(manifest['body']['publicationVersion'])=='1'
        if n:assert manifest['if_prior_etag_status']==304 and header==manifest['etag']
        header=manifest['etag'];assert stage['publication_forcee']['generation'] is None
        notification.append(db['notification'])
    assert all(v==notification[0] for v in notification)
    assert physical[0]==physical[1] and physical[2]==physical[3] and [k for k in all_ids if physical[1][k]!=physical[2][k]]==[736663]
    assert digests[0]==digests[1] and digests[2]==digests[3] and all(digests[1][k]!=digests[2][k] for k in digests[1])
    assert all(s['db']['other_tables_sha']==data[0]['db']['other_tables_sha'] for s in data)
    for eid in (31672,31673,31675):
        a,b,c,d=(next(x for x in s['db']['editions'] if x['id']==eid) for s in data)
        assert len({x['cup_checked_at'] for x in [a,b,c,d]})==4 and len({x['xmin'] for x in [a,b,c,d]})==4
        assert a['cup_updated_at']==b['cup_updated_at'] and c['cup_updated_at']==d['cup_updated_at']
        assert (c['cup_updated_at']!=b['cup_updated_at'])==(eid==31672)
    assert not read(folder/'immediat.json')['selection']
    ctl=read(folder/'temoin-publication.json')
    assert ctl['generation']==2 and ctl['/api/dashboard/manifest']['if_prior_etag_status']==200
    provenance=read(folder/'provenance.json')
    assert provenance['conteneur_detruit'] and 'PostgreSQL 18.' in provenance['pg']
    return dict(matchs=22,editions=3,id_revise=736663,cles_match_inchangees=22,anciennes_empreintes_RDS=3,
        nouvelles_empreintes=3,changements_de_match_par_etape=[[g[2] for g in s['run']['runs']] for s in data],
        mi_temps_source_connues=22,mi_temps_0_0_sources=sum(x['ht_fifa']=='0-0' for x in facts.values()),mi_temps_stockees=0,
        editions_http_200=3,snapshots_http_200=3,matchs_individuels_404=22,resume_temoin_http=404,rejeu_immediat_scopes=0,
        tuples_editions_ecrits_chaque_relecture=3,signal_global_apres_correction=1,signal_global_controle_positif=2,
        sha_digest_par_edition_avant_apres=[digests[0],digests[2]])
if __name__=='__main__':
    ap=argparse.ArgumentParser();ap.add_argument('dossier',nargs='?',type=Path);ap.add_argument('--produire',action='store_true');a=ap.parse_args()
    directories=[a.dossier] if a.dossier else [P/'verification',P/'verification-candidat-local']
    results=[check(d) for d in directories];assert all(x==results[0] for x in results)
    content=json.dumps(results[0],ensure_ascii=False,indent=2)+'\n'
    if a.produire:(P/'resultats.json').write_text(content)
    elif (P/'resultats.json').exists():assert (P/'resultats.json').read_text()==content
    print(content,end='')
