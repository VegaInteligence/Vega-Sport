"""Contrôle complet des agrégats, des fichiers SQL et des témoins après extraction."""
import ast,hashlib,json,os,subprocess,sys
from pathlib import Path
from initial import initial,get,q
D=Path(__file__).resolve().parent
def main():
 public=json.loads((D/'recu-rds.json').read_bytes())
 assert hashlib.sha256((D/'probe.py').read_bytes()).hexdigest()==public['probe_sha256']
 qs=ast.literal_eval(ast.parse((D/'probe.py').read_text()).body[0].value)
 assert qs=={p.stem:p.read_text() for p in (D/'sql').glob('*.sql')}
 fresh=initial();assert json.loads(json.dumps(fresh))==json.loads((D/'verification-initiale.json').read_bytes())
 j=get();pos={(r['match'],r['team_id'],r['player_id']) for r in q(j,'stats') if (r['minutes_played'] or 0)>0};g={(r['match'],r['team_id'],r['player_id']) for r in q(j,'grades')};assert pos==g and len(g)==4118
 for file in ('analyser.py','temoins.py','tests-negatifs.py'):
    subprocess.run([sys.executable,'-B',str(D/file)],cwd=D,env={**os.environ,'PYTHONPATH':''},check=True)
 s=json.loads((D/'synthese.json').read_bytes());w=s['editions']['0']
 assert [w[k] for k in ('notes_saff_joue_strict','notes_saff_banc_strict','place_part_sans_confirmation_identite','place_banc_sans_confirmation_identite','sans_place_saff')]==[378,0,3721,19,0]
 assert [w[k] for k in ('saff_place_part_sans_note','saff_place_banc_avec_note','compensation_entre_maillots','rds_part_sans_indice_du_cote_attribue')]==[26,19,3,1]
 print('146 matchs, 292 côtés, 4 118 notes, 378 correspondances situées, 2 côtés contradictoires vérifiés.')
if __name__=='__main__':main()
