import collections,hashlib,json,zlib
from pathlib import Path
D=Path(__file__).resolve().parent
def get():
 source=D/'rds/receipt.json';rec=json.loads((source if source.exists() else D/'recu-rds.json').read_bytes());b=(D/'rds/inputs.json.zlib').read_bytes();assert hashlib.sha256(b).hexdigest()==rec['sha256'] and rec['definition_end_state']=='INACTIVE' and rec['exit_code']==0
 j=json.loads(zlib.decompress(b));assert j['snapshot'][3:]==['on','repeatable read'];return j
def q(j,k):return [dict(zip(j[k]['columns'],r)) for r in j[k]['rows']]
def initial():
 j=get();fs={r['match']:r for r in q(j,'matches')};ext=json.loads((D/'matchs-attendus.json').read_bytes());assert {r['match'] for r in ext}==fs.keys() and len(fs)==146
 med={r['match']:r['edition'] for r in ext}
 grade=q(j,'grades');assert len(grade)==len({(x['match'],x['player_id']) for x in grade})
 gg=collections.Counter((r['match'],r['team_id']) for r in grade);sql=q(j,'notes_independantes');assert gg=={(v['match'],v['team_id']):v['notes'] for v in sql} and all(v['notes']==v['personnes'] for v in sql)
 aff=collections.Counter((i,side) for i,side,num,pid,nm,role in json.loads((D/'feuilles-min.json').read_bytes()) if role!='banc')
 rds_sides={};out={}
 for r in ext:
    m=fs[r['match']];assert r['edition']==m['edition'] and m['match_date']==r['date'] and r['score']==f"{m['home_score']}-{m['away_score']}"
    for s,k in [('home','home_team_id'),('away','away_team_id')]:rds_sides[r['match'],s]=gg[r['match'],m[k]]
 assert sum(rds_sides.values())==len(grade) and set(rds_sides)==set(aff)
 for ed in (1000,1001,0):
    kk=[k for k in rds_sides if not ed or med[k[0]]==ed];deltas={k:aff[k]-rds_sides[k] for k in kk}
    ids={k[0] for k in kk};by={i:deltas[i,'home']+deltas[i,'away'] for i in ids}
    opp={i:min(abs(deltas[i,'home']),abs(deltas[i,'away'])) for i in ids if deltas[i,'home']*deltas[i,'away']<0}
    out[ed]={'cotes':len(kk),'saff':sum(aff[k] for k in kk),'notes':sum(rds_sides[k] for k in kk),'deficits_cotes':sum(max(0,v) for v in deltas.values()),'excedents_cotes':sum(max(0,-v) for v in deltas.values()),'cotes_egaux':sum(v==0 for v in deltas.values()),'deficits_matchs':sum(max(0,v) for v in by.values()),'excedents_matchs':sum(max(0,-v) for v in by.values()),'matchs_compensation':len(opp),'matchs_egalite_compensee':sum(by[i]==0 for i in opp),'volume_compense_par_sens':sum(opp.values())}
 return {'utc':j['snapshot'][0],'snapshot':j['snapshot'][2],'editions':out}
if __name__=='__main__':print(json.dumps(initial(),indent=2))
