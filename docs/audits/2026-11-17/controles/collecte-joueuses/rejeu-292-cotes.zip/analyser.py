"""Réconciliation hors ligne, bornée à la feuille, au match et à son côté sportif."""
from collections import Counter,defaultdict
from pathlib import Path
import argparse,csv,hashlib,io,json,zlib
D=Path(__file__).resolve().parent
def read(n):return json.loads((D/n).read_bytes())
def rows(j,k):return [dict(zip(j[k]['columns'],r)) for r in j[k]['rows']]
def csvb(rr):
 s=io.StringIO(newline='');w=csv.DictWriter(s,fieldnames=list(rr[0]));w.writeheader();w.writerows(rr);return s.getvalue().encode()
def jsonb(o):return (json.dumps(o,ensure_ascii=False,indent=2)+'\n').encode()
def add_origin(cues,i,pid,team,code):
 if pid is not None:cues[i,pid].add((team,code))
def facts(data):
 fs={r['match']:r for r in rows(data,'matches')};up={};stat={};grades={};anch=defaultdict(set);cues=defaultdict(set)
 for k,rs,vals in [('lineups',up,('team_id','shirt_number','is_starter')),('stats',stat,('team_id','minutes_played')),('grades',grades,('team_id',))]:
    for r in rows(data,k):
        key=r['match'],r['player_id'];assert key not in rs
        rs[key]=tuple(r[v] for v in vals)
        if k!='grades':anch[key].add(r['team_id'])
        if k=='lineups' and r['is_starter']:add_origin(cues,*key,r['team_id'],'titulaire')
        if k=='stats' and (r['minutes_played'] or 0)>0:add_origin(cues,*key,r['team_id'],'minutes')
 for e in rows(data,'events'):
    typ=e['event_type'];assert typ in ('substitution','goal');team=e['team_id']
    for p in [e['player_id'],e['related_player_id']]:
        add_origin(cues,e['match'],p,None if e['is_own_goal'] and typ=='goal' else team,'remplacement' if typ=='substitution' else ('but_contre_son_camp' if e['is_own_goal'] else 'but'))
 for r in rows(data,'shots'):
    i=r['match'];t=r['team_id'];f=fs[i];op={f['home_team_id']:f['away_team_id'],f['away_team_id']:f['home_team_id']}.get(t)
    add_origin(cues,i,r['player_id'],None if r['is_own_goal'] else t,'tir')
    add_origin(cues,i,r['keeper_id'],None if r['is_own_goal'] else op,'gardienne')
 return fs,up,stat,grades,anch,cues
def analyse(data,saff,fx):
 fs,up,stat,grades,anch,cues=facts(data)
 names={r['player_id']:set(r['noms_multicomposants_sha256']) for r in rows(data,'noms_prives')}
 keys=set(up)|set(stat)|set(grades)|set(cues)
 assert set(p for i,p in keys)==set(names)
 side_of={i:{r['home_team_id']:'home',r['away_team_id']:'away'} for i,r in fs.items()}
 saff_by=defaultdict(dict);sn=defaultdict(set);rn=defaultdict(set);sa_by_id={}
 for i,s,num,pid,n,role in saff:
    assert num not in saff_by[i,s];saff_by[i,s][num]=(pid,set(n),role)
    assert (i,pid) not in sa_by_id;sa_by_id[i,pid]=(s,num,role)
    for a in n:sn[i,a].add(pid)
 for i,p in keys:
    for a in names[p]:rn[i,a].add(p)
 shirt_dups=Counter((i,side_of[i].get(t),num) for (i,p),(t,num,st) in up.items())
 rt=defaultdict(Counter);info=[];globalcnt=Counter();strictmap=defaultdict(set);reverse=defaultdict(set);special=[]
 per=defaultdict(list);resolved_participants={};graded_keys=set(grades)
 for i,p in sorted(keys):
    sx=side_of[i]; l=up.get((i,p)); st=stat.get((i,p)); g=grades.get((i,p)); ref=anch[i,p];cc=cues[i,p]
    anchor_sides={sx.get(t) for t in ref};evt_sides={sx.get(t) for t,_ in cc if t is not None};played=bool(cc);gside=sx.get(g[0]) if g else None
    if l:rt[i,sx.get(l[0])]['compo']+=1;rt[i,sx.get(l[0])]['titulaires']+=int(l[2] is True)
    if st:rt[i,sx.get(st[0])]['stat']+=1;rt[i,sx.get(st[0])]['positives']+=int((st[1] or 0)>0)
    if g:rt[i,gside]['notes']+=1
    if played:
        if len(anchor_sides)==1 and None not in anchor_sides:pside=next(iter(anchor_sides))
        elif not anchor_sides and len(evt_sides)==1 and None not in evt_sides:pside=next(iter(evt_sides))
        else:pside=None
        resolved_participants[i,p]=pside;rt[i,pside]['part']+=1
        if l and l[2] is False:rt[i,pside]['part_non_titulaire_inscrite']+=1
        if (i,p) not in grades:rt[i,pside]['part_sans_note']+=1
    else:pside=None
    s_l=sx.get(l[0]) if l else None;listed_side_discord=len(anchor_sides)>1;event_discord=bool(anchor_sides and evt_sides-anchor_sides)
    grade_contra=bool(g and ((anchor_sides and gside not in anchor_sides) or (played and pside and pside!=gside)))
    if listed_side_discord:globalcnt['compo_stat_cote_contradictoire']+=1
    if event_discord:
        globalcnt['acteur_match_indice_evenement_contredit_cote_structure']+=1
        if pside is not None:rt[i,pside]['indice_adverse']+=1
        if pside is not None and pside not in evt_sides:
            globalcnt['jeu_uniquement_atteste_par_indice_adverse']+=1
            rt[i,pside]['aucun_indice_meme_cote']+=1
    if grade_contra:globalcnt['note_cote_contredit_cote_structure_ou_participation']+=1
    if g and not played:rt[i,gside]['note_sans_indice_jeu_rds']+=1
    if played and pside is None:globalcnt['part_rds_cote_indetermine']+=1
    if not g and not l:continue
    scope=gside if g else s_l
    slot=saff_by[i,scope].get(l[1]) if l and scope==s_l else None
    spid,nm,role=slot if slot else (None,set(),None)
    fnames=names[p];candidates=set().union(*(sn[i,a] for a in fnames))
    shared=fnames&nm
    # Une variante de nom doit être exacte et unique dans l'ensemble des deux listes de ce match.
    unique_aliases={a for a in shared if sn[i,a]=={spid} and rn[i,a]=={p}}
    strict=bool(l and slot and unique_aliases and candidates=={spid} and shirt_dups[i,s_l,l[1]]==1 and not (listed_side_discord or grade_contra))
    if strict:strictmap[p].add(spid);reverse[spid].add(p)
    located_other=bool(candidates and all(sa_by_id[i,k][0]!=scope for k in candidates))
    other_number=bool(candidates and scope and any(sa_by_id[i,k][0]==scope and (not l or sa_by_id[i,k][1]!=l[1]) for k in candidates))
    if strict:association='nom_unique_cote_maillot'
    elif not l:association='sans_ligne_composition'
    elif g and s_l!=gside:association='cote_note_composition_divergent'
    elif not slot:association='maillot_absent_feuille'
    elif not shared:association='maillot_sans_nom_exact'
    else:association='maillot_nom_ambigu'
    saff_state=role if strict else None
    bench_confirmed=saff_state=='banc';role_confirmed=saff_state in ('titulaire','entree')
    if g:
        r=rt[i,gside]
        r['conf_part']+=int(role_confirmed);r['conf_banc']+=int(bench_confirmed)
        r['sans_identite_situee']+=int(not strict)
        r['candidate_part']+=int(not strict and role in ('titulaire','entree'));r['candidate_banc']+=int(not strict and role=='banc')
        r['sans_place']+=int(slot is None);r['nom_autre_cote']+=int(located_other);r['nom_autre_numero']+=int(other_number)
        r['note_sans_indice_local_cote']+=int(not played or gside!=pside)
    if g or strict or event_discord or grade_contra:
        actor=dict(match=i,pid=p,avec_note=bool(g),cote_note=gside,cote_compo=s_l,maillot=l[1] if l else None,
                 compo_titulaire=l[2] if l else None,part_rds=played,cote_part_rds=pside,origine=sorted(o for o in {z for _,z in cc}),
                 cote_evenement_divergent=event_discord,cote_note_divergent=grade_contra,appariement=association,strict=strict,saff_place=spid,saff_declare=role,
                 nom_uniquement_autre_cote=located_other,nom_autre_numero_meme_cote=other_number,nb_noms_candidats=len(candidates))
        info.append(actor)
    if event_discord or grade_contra or (played and not pside):special.append(dict(match=i,pid=p,jeu=played,cote_jeu=pside,cote_note=gside,cotes_structure=sorted(str(x) for x in anchor_sides),indices=sorted([(str(sx.get(t)),o) for t,o in cc]),conflit_note=grade_contra))
 for i,p in keys:
    if (i,p) not in up or (i,p) in grades:continue
    t,_,starter=up[i,p];side=side_of[i].get(t)
    if not starter and (i,p) not in resolved_participants:rt[i,side]['banc_non_confirme_rds']+=1
 slot_grade=Counter((r['match'],r['cote_note'],r['maillot']) for r in info if r['avec_note'])
 assert len(slot_grade)==len(grades) and all(n==1 for n in slot_grade.values()) and all(g is not None for i,s,g in slot_grade)
 assert set(fs)=={r['match'] for r in fx}
 sides=[];games=[];sh=Counter();sg=Counter()
 for f in sorted(fx,key=lambda f:(f['edition'],f['date'],f['match'])):
    i=f['match'];v=fs[i];assert (v['edition'],v['match_date'],f"{v['home_score']}-{v['away_score']}")==(f['edition'],f['date'],f['score'])
    batch=[]
    for side,label,tkey in [('home','dom','home_team_id'),('away','ext','away_team_id')]:
        a=Counter(role for _,_,role in saff_by[i,side].values());n=rt[i,side]
        row=dict(edition=f['edition'],match=i,wpl=f['wpl'],saff=f['saff'],jour=f['date'],cote=side,equipe=f[label],vega_equipe=v[tkey],saff_titulaires=a['titulaire'],saff_entrees=a['entree'],saff_part=a['titulaire']+a['entree'],saff_banc=a['banc'],rds_composition=n['compo'],rds_titulaires=n['titulaires'],rds_non_titulaire_avec_indice=n['part_non_titulaire_inscrite'],rds_banc_sans_indice=n['banc_non_confirme_rds'],rds_part=n['part'],rds_minutes_positives=n['positives'],rds_notes=n['notes'],saff_moins_notes=a['titulaire']+a['entree']-n['notes'],
                 rds_part_sans_note=n['part_sans_note'],rds_note_sans_preuve_jeu=n['note_sans_indice_jeu_rds'],rds_note_sans_preuve_jeu_meme_cote=n['note_sans_indice_local_cote'],notes_saff_joue_strict=n['conf_part'],notes_saff_banc_strict=n['conf_banc'],notes_identite_non_etablie=n['sans_identite_situee'],place_part_sans_confirmation_identite=n['candidate_part'],place_banc_sans_confirmation_identite=n['candidate_banc'],sans_place_saff=n['sans_place'],nom_uniquement_adverse=n['nom_autre_cote'],nom_autre_maillot=n['nom_autre_numero'])
        no_grade=sum(role!='banc' and (i,side,nr) not in slot_grade for nr,(pid,na,role) in saff_by[i,side].items())
        bench_grade=sum(role=='banc' and (i,side,nr) in slot_grade for nr,(pid,na,role) in saff_by[i,side].items())
        row.update(saff_place_part_sans_note=no_grade,saff_place_banc_avec_note=bench_grade,compensation_entre_maillots=min(no_grade,bench_grade),rds_part_avec_indice_du_cote_adverse=n['indice_adverse'],rds_part_sans_indice_du_cote_attribue=n['aucun_indice_meme_cote'])
        assert no_grade-bench_grade==row['saff_moins_notes']
        assert row['notes_saff_joue_strict']+row['notes_saff_banc_strict']+row['notes_identite_non_etablie']==n['notes']
        sides.append(row);batch.append(row)
    h,a=batch;df=h['saff_moins_notes'];da=a['saff_moins_notes'];gg=h['rds_notes']+a['rds_notes'];assert f['notes']==gg
    games.append(dict(edition=f['edition'],match=i,wpl=f['wpl'],jour=f['date'],dom=f['dom'],ext=f['ext'],saff=h['saff_part']+a['saff_part'],notes=gg,delta_dom=df,delta_ext=da,delta_match=df+da,volume_compense=min(abs(df),abs(da)) if df*da<0 else 0,saff_place_part_sans_note=h['saff_place_part_sans_note']+a['saff_place_part_sans_note'],saff_place_banc_avec_note=h['saff_place_banc_avec_note']+a['saff_place_banc_avec_note'],compensation_entre_maillots=h['compensation_entre_maillots']+a['compensation_entre_maillots']))
 agg={}
 for ed in (1000,1001,0):
    sel=[r for r in sides if not ed or r['edition']==ed];games_el=[r for r in games if not ed or r['edition']==ed]
    if not sel:continue
    cols=list(sel[0])[8:];agg[str(ed)]={c:sum(r[c] for r in sel) for c in cols}
    agg[str(ed)].update(cotes=len(sel),cotes_deficit=sum(r['saff_moins_notes']>0 for r in sel),cotes_excedent=sum(r['saff_moins_notes']<0 for r in sel),cotes_egalite=sum(r['saff_moins_notes']==0 for r in sel),deficits_cotes=sum(max(0,r['saff_moins_notes']) for r in sel),excedents_cotes=sum(max(0,-r['saff_moins_notes']) for r in sel),matchs_avec_compensation=sum(x['volume_compense']>0 for x in games_el),volume_compense=sum(x['volume_compense'] for x in games_el))
 strict_rows=[r for r in info if r['strict']]
 globalcnt['appariement_depuis_autre_match_seul']=sum(r['saff_place'] in strictmap.get(r['pid'],set()) for r in info if r['avec_note'] and not r['strict'])
 return sides,games,info,special,dict(editions=agg,conflits=dict(globalcnt),forts=dict(toutes_occurrences=len(strict_rows),vega_distinctes=len(strictmap),saff_distinctes=len(reverse),vega_plusieurs_saff=sum(len(v)>1 for v in strictmap.values()),saff_plusieurs_vega=sum(len(v)>1 for v in reverse.values())),associations_notes=dict(Counter(r['appariement'] for r in info if r['avec_note'])))
def run():
 b=(D/'rds/inputs.json.zlib').read_bytes();j=json.loads(zlib.decompress(b));assert j['snapshot'][3:]==['on','repeatable read']
 sides,games,individual,special,summary=analyse(j,read('feuilles-min.json'),read('matchs-attendus.json'))
 initial=read('verification-initiale.json');ng=summary['editions']['0'];assert ng['rds_notes']==4118 and ng['saff_part']==4125
 assert all(summary['editions'][ed][k]==initial['editions'][ed]['volume_compense_par_sens' if k=='volume_compense' else k] for ed in initial['editions'] for k in ('cotes','deficits_cotes','excedents_cotes','volume_compense'))
 assert len(sides)==len(rows(j,'notes_independantes'))==292
 ix={(r['match'],r['team_id']):r['notes'] for r in rows(j,'notes_independantes')};assert all(ix[r['match'],r['vega_equipe']]==r['rds_notes'] for r in sides)
 return {'cotes-292.csv':csvb(sides),'matchs-146.csv':csvb(games),'associations.json.zlib':zlib.compress(json.dumps(individual,separators=(',',':')).encode(),9),'exceptions.json':jsonb(special),'synthese.json':jsonb(summary)}
if __name__=='__main__':
 ap=argparse.ArgumentParser();ap.add_argument('--generer',action='store_true');a=ap.parse_args()
 for n,b in run().items():
    if a.generer:(D/n).write_bytes(b)
    else:assert (D/n).read_bytes()==b,n
    print(n,hashlib.sha256(b).hexdigest())
