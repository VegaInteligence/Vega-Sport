"""Vérifie les refus en faisant varier une seule composante sur un match observé."""
import copy,json,zlib
from pathlib import Path
from analyser import rows,analyse,read,jsonb
D=Path(__file__).resolve().parent
def tests():
 j=json.loads(zlib.decompress((D/'rds/inputs.json.zlib').read_bytes()));ss=read('feuilles-min.json')
 # Garder deux côtés, tous les candidats, les remplacements et les alias du match observé.
 i=87580; f=[r for r in read('matchs-attendus.json') if r['match']==i];ss=[r for r in ss if r[0]==i]
 for k,t in j.items():
    if k not in ('snapshot','noms_prives'):
        pos=t['columns'].index('match');t['rows']=[r for r in t['rows'] if r[pos]==i]
 pn={r['player_id'] for k in ('grades','lineups','stats','events','shots') for r in rows(j,k)}|{r['related_player_id'] for r in rows(j,'events')}|{r['keeper_id'] for r in rows(j,'shots')}
 j['noms_prives']['rows']=[r for r in j['noms_prives']['rows'] if r[0] in pn]
 def record(data,sf):
    acts=analyse(data,sf,f)[2]
    return next(a for a in acts if a['pid']==40646)
 initial=record(j,ss);assert initial['strict'] and initial['maillot']==14 and initial['cote_note']=='home'
 unique=next(r for r in ss if r[1]=='home' and r[2]==14);matches=next(r[1] for r in j['noms_prives']['rows'] if r[0]==40646); nm=set(matches)&set(unique[4]);assert nm
 alt=copy.deepcopy(ss);next(r for r in alt if r[1]=='home' and r[2]==14)[4]=[];assert not record(j,alt)['strict']
 alt=copy.deepcopy(ss);next(r for r in alt if r[1]=='away' and r[2]!=14)[4].extend(nm);assert not record(j,alt)['strict']
 alt=copy.deepcopy(j);next(r for r in alt['noms_prives']['rows'] if r[0]!=40646)[1].extend(nm);assert not record(alt,ss)['strict']
 # Remplacer les numéros de deux titulaires pour conserver les totaux et les maillots uniques.
 alt=copy.deepcopy(ss);u=next(r for r in alt if r[1]=='home' and r[2]==14);v=next(r for r in alt if r[1]=='home' and r[2]!=14 and r[5]==u[5]);u[2],v[2]=v[2],u[2]
 assert not record(j,alt)['strict']
 return {'temoin':i,'pid_vega':40646,'exact_independant':True,'sans_nom_refuse':True,'homonyme_adverse_refuse':True,'alias_rds_en_double_refuse':True,'maillots_intervertis_refuses':True}
if __name__=='__main__':
 import sys
 b=jsonb(tests());p=D/'tests-negatifs.json'
 if '--generer' in sys.argv:p.write_bytes(b)
 else:assert p.read_bytes()==b
