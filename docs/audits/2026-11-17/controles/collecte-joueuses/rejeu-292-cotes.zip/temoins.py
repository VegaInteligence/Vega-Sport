from pathlib import Path
import json,zlib
from analyser import read,rows,jsonb
D=Path(__file__).resolve().parent
def verifier():
 c=read('changements-temoins.json');ss=read('feuilles-min.json');stock=json.loads(zlib.decompress((D/'rds/inputs.json.zlib').read_bytes()))
 l={(r['match'],r['player_id']):r for r in rows(stock,'lineups')};fs={r['match']:r for r in rows(stock,'matches')};ev=rows(stock,'events');g={(r['match'],r['player_id']) for r in rows(stock,'grades')}
 slot={(i,s,num):(p,typ) for i,s,num,p,names,typ in ss}
 res=[]
 for i,a,b,ts in [(69327,7,99,'46'),(69353,11,20,'71')]:
    h=fs[i]['home_team_id'];away=fs[i]['away_team_id'];lp=l[i,2258]
    assert lp['team_id']==h and (i,2258) not in g
    links=[r for r in ev if r['match']==i and r['event_type']=='substitution' and r['related_player_id']==2258];assert len(links)==1
    link=links[0];other=l[i,link['player_id']];assert link['team_id']==other['team_id']==away and other['shirt_number']==a
    sw=[r for r in c if r['match']==i and r['cote']=='away' and r['entrant']==b and r['sortant']==a];assert len(sw)==1 and sw[0]['minute']==ts
    primary_slot=slot[i,'home',lp['shirt_number']];other_slot=slot[i,'away',b]
    res.append(dict(match=i,id_vega=2258,maillot_domicile_dans_vega=lp['shirt_number'],presence_saff_maillot_domicile=primary_slot[1],saff_domicile=primary_slot[0],note_vega=False,remplacement_vega_equipe='away',maillot_coacteur=a,entrant_saff=b,sortant_saff=a,minute_saff=ts,saff_adverse=other_slot[0]))
 assert res[0]['saff_domicile']==res[1]['saff_adverse'] and res[0]['saff_adverse']==res[1]['saff_domicile'] and res[0]['saff_domicile']!=res[0]['saff_adverse']
 return res
if __name__=='__main__':
 import sys
 blob=jsonb(verifier());p=D/'deux-cotes-contradictoires.json'
 if '--generer' in sys.argv:p.write_bytes(blob)
 else:assert p.read_bytes()==blob
