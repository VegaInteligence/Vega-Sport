# Première division féminine saoudienne · trois éditions
     
Au 18 novembre 2026, Vega conserve les **146 résultats confirmés** des deux saisons terminées, aux bons jours, horaires et côtés. Pour 2026/27, la fédération publie **28 résultats sur 56 matchs**. Vega possède les 56 affiches orientées mais seulement les **8 résultats** des journées 1 et 2. Il manque les 20 scores des journées 3 à 7. [Registre des 202 affiches](matches-202.csv) · [Calendrier SAFF 2026/27](https://www.saff.com.sa/en/championship.php?id=428&type=all)

| Saison et édition | Matchs joués SAFF / inscrits | Résultats Vega concordants | Participations minimales connues de la grille | Notes en base / affichables selon la règle | Côtés avec Elo |
|---|---:|---:|---:|---:|---:|
| 2024/25 · 1000 | 90 / 90 | 90 | 2 552 | 2 547 / 2 232 | 180 |
| 2025/26 · 1001 | 56 / 56 | 56 | 1 589 | 1 571 / 1 362 | 112 |
| 2026/27 · 1002 | 28 / 56 | 8 | 0 | 0 / 0 | 16 |

Les trois comptages sont corroborés en reconstruisant les matchs, victoires, nuls, défaites et buts de chaque club du classement fédéral. La compétition actuelle est à mi-saison. Les résultats vont jusqu’au 7 novembre. La prochaine rencontre est prévue le 10 décembre. Les 28 matchs à venir se distinguent donc des 20 résultats déjà connus qui manquent à Vega. Les mesures de notes indiquent ce que la grille attribue à ces éditions. L’audit antérieur des erreurs d’identité reste distinct. [Saison 2024/25](https://www.saff.com.sa/en/championship.php?id=263&type=all) · [Saison 2025/26](https://www.saff.com.sa/en/championship.php?id=345&type=all) · [Grille extraite](vega-grille.json)

**Deux manches interverties.** Le 31 octobre, Al Taraji a reçu Al Nassr et perdu 2–3. Dans Vega, le match avec ces deux côtés orientés est enregistré le 6 mai 2027 sous l’ID 47976. La rencontre retour, 47949, porte la date du 31 octobre et le statut reporté. En rapprochant les côtés, 19 des 20 résultats manquants sont classés reportés et le dernier est libellé à venir. En rapprochant le seul jour, les deux manches auraient été confondues. Parmi les 56 matchs, 54 dates et 51 heures locales concordent. Les huit résultats présents ont tous la bonne date, le bon horaire, le bon sens et le bon score. [Détail match par match](matches-202.csv)

## Huit résultats enregistrés en 2026/27

Les feuilles officielles et leurs remplacements attestent **176 titulaires et 64 entrantes**, soit **240 participations de 135 joueuses distinctes** sous identifiant SAFF. Parmi les 139 inscriptions sur le banc, 75 sont restées sans entrée enregistrée. Chaque entrée et chaque sortie a été vérifiée dans la bonne équipe par nom et numéro de maillot. La séquence des remplacements conserve 11 joueuses sur le terrain. Le registre portable utilise des numéros de maillot propres à chaque côté et des empreintes d’identifiants SAFF. [Seize côtés](feuilles-16-cotes.csv) · [Exemple de la ligue](https://wpl.saff.com.sa/match/48595?season=2026/2027)

| Résultat Vega | Date de septembre 2026 | Affiche | Titulaires | Entrées | Banc sans entrée | Lignes avec minutes strictement positives BEPRO |
|---|---:|---|---:|---:|---:|---:|
| 47926 | 10 | Al Nassr – NEOM 3–0 | 22 | 8 | 9 | 29 |
| 47927 | 11 | Al Taraji – Al Ahli 1–5 | 22 | 8 | 9 | indisponibles |
| 47928 | 11 | Al Hilal – Al Ittihad 1–3 | 22 | 7 | 11 | 28 |
| 47929 | 12 | Al Ula – Al Qadsiah 0–1 | 22 | 7 | 11 | indisponibles |
| 47930 | 17 | NEOM – Al Ula 0–4 | 22 | 8 | 10 | 30 |
| 47931 | 18 | Al Qadsiah – Al Taraji 14–0 | 22 | 10 | 8 | indisponibles |
| 47932 | 18 | Al Ahli – Al Hilal 0–9 | 22 | 10 | 8 | indisponibles |
| 47933 | 19 | Al Ittihad – Al Nassr 4–2 | 22 | 6 | 9 | 27 |

Le centre de match sert une feuille SAFF et deux présentations des événements. La requête par identifiant de fixture expose 47 buts et 19 cartons jaunes dans les huit réponses. La requête par code de match expose les entrées et sorties horodatées des deux équipes. Sur quatre matchs, le service de statistiques fournit **117 lignes individuelles BEPRO**, exactement les joueuses attestées de ces quatre rencontres par équipe et maillot. Il enregistre **114 temps de jeu strictement positifs**. Les entrantes Al Nassr n°15 (90e), Al Ittihad n°99 (90e) et n°77 (89e) ont chacune une ligne enregistrant zéro minute et respectivement une, une et deux passes. Pour les 123 autres participations, les quatre réponses de statistiques renvoient HTTP 502 lors de deux lectures par identifiant. La variante par code de match ne fournit pas davantage de données individuelles. Les 240 participations restent attestées par les feuilles. Les touches ne figurent pas dans les 117 lignes individuelles analysées. [Mesures disponibles](mesures.json) · [Reçus du site](sources-web.json)

À 09:59:37 UTC, la grille ne trouvait aucune joueuse mesurable ni aucun index publié sur ces huit matchs. À 10:46:07 UTC, un SELECT en lecture seule retrouve, pour chacun, deux côtés Elo et zéro ligne de composition individuelle, d’événement, de tir, de statistiques individuelles ou de note. La preuve extérieure n’établit ni les clés joueuse Vega, ni l’admission par le modèle, ni une note de remplacement. Cette capsule couvre les huit feuilles parallèlement aux calendriers complets des trois saisons. [Source SQL](matchs.sql) · [Reçus Vega](sources-vega.json)

## Rejouer la capsule

La commande suivante vérifie depuis une extraction neuve les sommes, les 202 jointures, les classements et les feuilles. Elle demande seulement Python 3.10 ou ultérieur et un outil SHA-256.

```sh
shasum -a 256 -c SHA256SUMS
python3 -B verifier.py
```

Les entrées sont des extraits factuels. Les 202 lignes de Vega sont conservées avec leur identifiant, saison, date, score, statut et compteurs. Les extraits SAFF omettent noms de personnes, dates de naissance, photos et coordonnées. Les fichiers de preuve bruts et les dates/empreintes permettent un contrôle supplémentaire dans le dossier opérateur. La grille et le SELECT proviennent de deux instantanés en lecture seule. Le premier essai de transport SQL n’a pu lancer une image de diagnostic périmée. Le relevé réussi a employé l’image déployée `8018e08`. [Provenance des deux lectures](sources-vega.json)
