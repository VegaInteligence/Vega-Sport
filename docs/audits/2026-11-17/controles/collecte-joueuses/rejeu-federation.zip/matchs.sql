SELECT cs.id AS edition,cs.season_id,m.id,m.match_date,m.kickoff_at,m.status::text,
       m.home_team_id,h.name AS home,m.away_team_id,a.name AS away,m.home_score,m.away_score,
       (SELECT p.provider_key FROM core.provider_ids p WHERE p.entity_type='match' AND p.provider='pitchapi' AND p.entity_id=m.id ORDER BY p.is_current DESC LIMIT 1) AS pitchapi,
       (SELECT count(*) FROM core.lineup_players s WHERE (s.match_id,s.season_id)=(m.id,m.season_id)) AS lineup_listed,
       (SELECT count(*) FROM core.lineup_players s WHERE (s.match_id,s.season_id)=(m.id,m.season_id) AND s.is_starter IS TRUE) AS lineup_starters,
       (SELECT count(*) FROM core.match_events s WHERE (s.match_id,s.season_id)=(m.id,m.season_id)) AS events,
       (SELECT count(*) FROM core.shots s WHERE (s.match_id,s.season_id)=(m.id,m.season_id)) AS shots,
       (SELECT count(*) FROM core.player_match_stats s WHERE (s.match_id,s.season_id)=(m.id,m.season_id)) AS stats,
       (SELECT count(*) FROM core.player_match_stats s WHERE (s.match_id,s.season_id)=(m.id,m.season_id) AND s.minutes_played>0) AS positive_minutes,
       (SELECT count(*) FROM agg.player_match_grades s WHERE (s.match_id,s.season_id)=(m.id,m.season_id)) AS grades,
       (SELECT count(*) FROM agg.team_elo s WHERE (s.match_id,s.season_id)=(m.id,m.season_id) AND s.team_id IN (m.home_team_id,m.away_team_id)) AS elo
FROM core.competition_seasons cs JOIN core.matches m ON (m.competition_season_id,m.season_id)=(cs.id,cs.season_id)
JOIN core.teams h ON h.id=m.home_team_id JOIN core.teams a ON a.id=m.away_team_id
WHERE cs.competition_id=197 AND cs.id IN (1000,1001,1002)
ORDER BY cs.id,m.match_date,m.id
