"""Vérifie le rapprochement des calendriers, les minutes et les unités de couverture."""
import argparse
from collections import Counter,defaultdict
from datetime import datetime,timedelta
from pathlib import Path
import csv,hashlib,io,json
D=Path(__file__).resolve().parent
SAFF={'Al Qadisiyah':'Al Qadsiah','AlUla':'Al Ula','NEOM':'Neom SC'}
WPL={'Al-Nassr FC':'Al Nassr','NEOM':'Neom SC','Al-Taraji Club':'Al Taraji','Al-Ahli Saudi FC':'Al Ahli','Al-Hilal SFC':'Al Hilal','Al-Ittihad Club':'Al Ittihad','Al-ula Club':'Al Ula','Al-Qadsiah FC':'Al Qadsiah'}
def read(n):return json.loads((D/n).read_bytes())
def serialize_json(x):return (json.dumps(x,indent=2,ensure_ascii=False)+'\n').encode()
def serialize_csv(x):
    s=io.StringIO(newline='');w=csv.DictWriter(s,fieldnames=list(x[0]));w.writeheader();w.writerows(x);return s.getvalue().encode()
def count(rows,k):return sum(r[k] for r in rows)
def keymap(rows,key):
    m={key(r):r for r in rows};assert len(m)==len(rows);return m
def independent():
    fed=read('saff-calendriers.json');standings=read('saff-classements.json');vg=read('vega-matchs.json');wpl=read('wpl-calendrier.json');grid=read('vega-grille.json')
    assert {r['edition'] for r in fed}=={1000,1001,1002} and all(r['competition_id']=='197' for r in grid)
    wmap=keymap(wpl,lambda r:(WPL[r['home']],WPL[r['away']]))
    vmap=keymap(vg,lambda r:(r['edition'],r['home'],r['away']))
    keymap(fed,lambda r:(r['edition'],r['home'],r['away']));assert len(fed)==len(vg)==202
    lines=read('inscriptions.json');enter=read('remplacements.json');stats=read('mesures.json')
    keymap(lines,lambda r:(r['wpl_id'],r['side'],r['shirt']));keymap(lines,lambda r:(r['wpl_id'],r['saff_id_hash']))
    keymap(stats,lambda r:(r['wpl_id'],r['side'],r['shirt']))
    per=[];sheets=[];ledger=[];source_receipts=keymap(read('sources-web.json'),lambda r:r['piece'])
    for ed in (1000,1001,1002):
        rows=[r for r in fed if r['edition']==ed];nclubs=len({r['home'] for r in rows})
        assert len(rows)==nclubs*(nclubs-1) and all(r['home']!=r['away'] for r in rows)
        played=[r for r in rows if r['home_goals'] is not None]
        reconstructed=defaultdict(Counter)
        for r in played:
            for n,g,a in [(r['home'],r['home_goals'],r['away_goals']),(r['away'],r['away_goals'],r['home_goals'])]:
                reconstructed[n].update(dict(p=1,w=int(g>a),d=int(g==a),l=int(g<a),gf=g,ga=a))
        tt=[r for r in standings if r['edition']==ed];assert len(tt)==nclubs
        assert all(r[k]==reconstructed[r['team']][k] for r in tt for k in ('p','w','d','l','gf','ga'))
        assert sum(r['p'] for r in tt)==2*len(played)
        roster_grid={r['entity_type']:r for r in grid if int(r['edition_id'])==ed};gp=roster_grid['player'];gc=roster_grid['club']
        for r in rows:
            h=SAFF.get(r['home'],r['home']);a=SAFF.get(r['away'],r['away']);v=vmap[ed,h,a]
            assert v['home_team_id']!=v['away_team_id'] and v['pitchapi']
            score=r['home_goals'] is not None; assert (r['away_goals'] is not None)==score
            completed=v['status']=='finished';assert completed==(v['home_score'] is not None and v['away_score'] is not None)
            exact=score and completed and (r['home_goals'],r['away_goals'])==(v['home_score'],v['away_score'])
            dt=datetime.fromisoformat(v['kickoff_at'])+timedelta(hours=3)
            row=dict(edition=ed,semaine=r['week'],saff_fixture=r['saff_fixture'],vega_match=v['id'],pitchapi=v['pitchapi'],domicile=h,exterieur=a,
                date_saff=r['date'],heure_saff=r['time'],date_vega=v['match_date'],heure_vega_arabie=dt.strftime('%H:%M'),date_identique=r['date']==v['match_date'],
                heure_identique=r['time']==dt.strftime('%H:%M'),score_saff=f"{r['home_goals']}-{r['away_goals']}" if score else '',statut_vega=v['status'],score_vega=f"{v['home_score']}-{v['away_score']}" if completed else '',
                resultat_manquant=score and not completed,resultat_identique=exact,elo_cotes=v['elo'],notes_vega=v['grades'])
            ledger.append(row)
            if ed!=1002:continue
            w=wmap[h,a]; assert w['date']==r['date'] and w['time']==r['time'] and w['round']==r['week']
            assert (w['home_score'],w['away_score'])==((str(r['home_goals']),str(r['away_goals'])) if score else (None,None))
            assert not r['code'] or w['code']==r['code']
            if not completed:continue
            assert r['date']==v['match_date'] and exact and v['elo']==2
            assert all(v[k]==0 for k in ('lineup_listed','lineup_starters','events','shots','stats','positive_minutes','grades'))
            i=w['wpl_id']
            for side in ('home','away'):
                roster=[o for o in lines if (o['wpl_id'],o['side'])==(i,side)]
                indexed={o['shirt']:o for o in roster};starters={p for p,o in indexed.items() if o['role']=='MAIN'};benches={p for p,o in indexed.items() if o['role']=='SUBSTITUTES'}
                assert len(starters)==11 and not starters&benches and len(starters|benches)==len(roster)
                changes=[t for t in enter if (t['wpl_id'],t['side'])==(i,side)]
                field=starters.copy();entrants=set()
                for t in changes:
                    inc,left=t['entered'],t['left']
                    assert left in field and inc in benches and inc not in field|entrants and t['names_match_sheet'] and t['minute']
                    field.remove(left);field.add(inc);entrants.add(inc)
                participated=starters|entrants;assert len(field)==11
                measured=[o for o in stats if (o['wpl_id'],o['side'])==(i,side)]
                assert source_receipts[f'MatchStats-{i}']['status']==(200 if measured else 502)
                if measured:
                    assert {o['shirt'] for o in measured}==participated and all(o['minutes']>=0 for o in measured)
                    assert all(o['shirt'] in entrants and o['passes']>0 for o in measured if o['minutes']==0)
                sheets.append(dict(vega_match=v['id'],wpl_id=i,saff_fixture=r['saff_fixture'],date=r['date'],cote=side,equipe=h if side=='home' else a,titulaires=len(starters),
                      banc_inscrites=len(benches),entrees=len(entrants),participations=len(participated),banc_sans_entree=len(benches-entrants),lignes_bepro=len(measured),
                      bepro_minutes_positives=sum(o['minutes']>0 for o in measured),bepro_zero_avec_entree=sum(o['minutes']==0 for o in measured),elo_vega=1,notes_vega=0))
        scoped=[r for r in ledger if r['edition']==ed];assert int(gp['finished'])==sum(r['statut_vega']=='finished' for r in scoped) and int(gp['actual_valid'])==count(scoped,'notes_vega')
        assert int(gc['stored_matched_sides'])==count(scoped,'elo_cotes')
        per.append(dict(edition=ed,saison=gp['season'],clubs=nclubs,calendrier=len(rows),joues_saff=len(played),a_venir_saff=len(rows)-len(played),termines_vega=int(gp['finished']),
                        scores_confirmes=sum(r['resultat_identique'] for r in scoped),resultats_manquants=count(scoped,'resultat_manquant'),
                        discordance_date=sum(not r['date_identique'] for r in scoped),discordance_heure_locale=sum(not r['heure_identique'] for r in scoped),
                        participations_min_grille=int(gp['known_participations_minimum']),entrees_moteur_grille=int(gp['expected_proven']),notes_grille=int(gp['actual_valid']),
                        notes_affichables_grille=int(gp['displayed_under_current_rule']),elo_cotes_vega=count(scoped,'elo_cotes')))
    assert [r['resultats_manquants'] for r in per]==[0,0,20] and len(sheets)==16
    current=[r for r in ledger if r['edition']==1002]
    lost=[r for r in current if r['resultat_manquant']]
    assert Counter(r['statut_vega'] for r in lost)=={'postponed':19,'not_started':1} and {r['semaine'] for r in lost}=={3,4,5,6,7}
    swapped=[r for r in current if not r['date_identique']];assert {r['vega_match'] for r in swapped}=={47949,47976}
    for l,r in (swapped,swapped[::-1]):
        assert (l['domicile'],l['exterieur'],l['date_saff'])==(r['exterieur'],r['domicile'],r['date_vega'])
    sums={k:count(sheets,k) for k in ('titulaires','banc_inscrites','entrees','participations','banc_sans_entree','lignes_bepro','bepro_minutes_positives','bepro_zero_avec_entree','elo_vega','notes_vega')}
    assert list(sums.values())==[176,139,64,240,75,117,114,3,16,0]
    assert read('types-evenements.json')=={'Goal':47,'Yellow card':19}
    assert sum(r['date_identique'] and r['heure_identique'] for r in ledger if r['statut_vega']=='finished')==154
    ids_entrantes={(c['wpl_id'],c['side'],c['entered']) for c in enter}
    ids_joueuses={r['saff_id_hash'] for r in lines if r['role']=='MAIN' or (r['wpl_id'],r['side'],r['shirt']) in ids_entrantes}
    assert len(ids_joueuses)==135 and len({r['saff_id_hash'] for r in lines})==165
    summary=dict(identifiants_saff_distincts_ayant_joue=135,identifiants_saff_distincts_inscrits=165,editions=per,courante_huit_matchs=sums,resultats_manquants_par_statut=dict(Counter(r['statut_vega'] for r in lost)),
                 huit_matchs_preuves_minutes=len({r['wpl_id'] for r in sheets if r['lignes_bepro']}),negatifs={'banc_non_entre':75,'minutes_arrondies_zero_avec_entree_et_passes':3,'retours_intervertis':2,'scores_futurs_absents':28,'niveaux_match_competition_distincts':True})
    return {'synthese.json':serialize_json(summary),'matches-202.csv':serialize_csv(ledger),'feuilles-16-cotes.csv':serialize_csv(sheets),'editions.csv':serialize_csv(per)}
if __name__=='__main__':
    ap=argparse.ArgumentParser();ap.add_argument('--generer',action='store_true');args=ap.parse_args()
    for name,blob in independent().items():
        if args.generer:(D/name).write_bytes(blob)
        else:assert (D/name).read_bytes()==blob,name
        print(name,hashlib.sha256(blob).hexdigest())
