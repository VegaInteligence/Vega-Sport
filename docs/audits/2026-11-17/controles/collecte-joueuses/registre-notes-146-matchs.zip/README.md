# Participations SAFF et notes Vega sur 146 matchs

Sur les deux éditions historiques, **22 matchs comptent au total 23 participations attestées de plus que de notes**, et **10 matchs comptent 16 notes de plus que de participations attestées**. Les 114 autres ont des totaux égaux. La différence nette de sept entre 4 125 participations et 4 118 notes masque ces écarts de sens opposé. [Registre par match](comparaison-146.csv)

| Saison | Matchs | Participations SAFF | Notes en base | Déficits de notes en volume | Excédents de notes en volume | Matchs à compte égal |
|---|---:|---:|---:|---:|---:|---:|
| 2024/25 | 90 | 2 541 | 2 547 | 5 sur 5 matchs | 11 sur 6 matchs | 79 |
| 2025/26 | 56 | 1 584 | 1 571 | 18 sur 17 matchs | 5 sur 4 matchs | 35 |
| Ensemble | 146 | 4 125 | 4 118 | 23 sur 22 matchs | 16 sur 10 matchs | 114 |

Chaque total SAFF comprend les identifiants de titulaires et de remplaçantes dont l’entrée est documentée, dédoublonnés par rencontre et par côté. Les deux équipes d’un même match ont des ensembles d’identifiants disjoints. La jointure vérifie l’édition, le match, les côtés, la date et le score. Le relevé RDS du 18 novembre à 10:46 UTC compte les lignes de notes présentes en base. Le contrôle utilise une seule fois le total de chaque match. Une note masquée à l’affichage reste comptée. Les mesures concernent les écarts entre deux dénominateurs. L’éligibilité de chaque participante à une note, les erreurs éventuelles du journal sportif et les notes attribuées à une autre personne demandent une preuve individuelle. [Résultats et empreintes des captures](synthese.json)

## Rencontres témoins

| Date | Rencontre et ID Vega | Participations | Notes | Fait observable |
|---|---|---:|---:|---|
| 16 novembre 2024 | Eastern Flames – Al Taraji · 87552 | 25 | 28 | Trois notes en excédent |
| 14 mars 2025 | Al Ula – Eastern Flames · 87606 | 28 | 31 | Trois notes en excédent |
| 19 février 2026 | Al Qadsiah – NEOM · 69348 | 22 | 24 | Deux onzes, aucune entrée enregistrée dans le journal fédéral |
| 27 mars 2026 | Al Ula – Al Ahli · 69353 | 28 | 26 | Deux participations de plus que de notes |

Les deux plus grands excédents et le plus grand déficit figurent dans le registre complet avec les identifiants de la fédération et de la ligue. [Eastern Flames – Al Taraji](https://wpl.saff.com.sa/match/14638?season=2024/2025) · [Al Ula – Eastern Flames](https://wpl.saff.com.sa/match/14693?season=2024/2025) · [Al Qadsiah – NEOM](https://wpl.saff.com.sa/match/32064?season=2025/2026) · [Al Ula – Al Ahli](https://wpl.saff.com.sa/match/32068?season=2025/2026)

## Ventilation par côté et appariement des personnes

La SAFF identifie les **292 côtés**. Le relevé RDS principal compte les notes par match. Un second fichier gelé, lu le 17 novembre à 23:34 UTC, conserve les lignes individuelles avec équipe pour deux de ces matchs, soit quatre côtés. Ses **55 notes** rejoignent exactement les totaux des deux rencontres à 10:46 le lendemain. La stabilité de leur répartition entre les deux instantanés reste inconnue. La colonne des notes par côté est vide pour les **288 autres côtés**. [Registre des 292 côtés](comparaison-292-cotes.csv)

| Date | ID Vega | Domicile · SAFF / notes | Extérieur · SAFF / notes |
|---|---:|---|---|
| 10 janvier 2025 | 87575 | Al Ahli · 15 / 15 | Al Amal · 15 / 15 |
| 17 janvier 2025 | 87580 | Al Nassr · 12 / 12 | Al Qadsiah · 13 / 13 |

Les deux compositions RDS contiennent 80 inscriptions avec maillot. Les 80 numéros existent sur la feuille SAFF du bon côté. Les 55 notes occupent toutes un numéro correspondant à une participante attestée. Après vérification du nom multicomposant exact et unique dans les deux effectifs du même côté, **deux correspondances locales** subsistent. Il s’agit du n°14 d’Al Nassr (Vega 40646) et du n°27 d’Al Qadsiah (40773) au match 87580. Aucune date de naissance n’est renseignée pour les 80 lignes RDS de ces deux matchs. Les 53 autres notes ont une concordance de maillot sans confirmation nominale selon cette règle. [Détail des deux matchs](detail-deux-matchs.json)

Les deux éditions officielles comptent **275 identifiants SAFF distincts ayant joué**. Chacun a une date de naissance cohérente dans les feuilles locales. Les clés individuelles Vega du relevé détaillé sont des clés PitchAPI. Le registre général disponible à 03:45 UTC comprend 64 972 racines Vega avec leurs noms et alias, et 22 540 lignes fournisseur datées dans l’espace Transfermarkt. Les éléments gelés ne contiennent aucune correspondance native typée entre ces espaces et celui de la SAFF. Sur les 275 personnes, 20 ont au moins un nom multicomposant exact dans le registre Vega, et 244 ont une date de naissance présente sur au moins une racine Vega. **Aucune n’a simultanément un de ses noms multicomposants et sa date sur une même racine**, même avant les gardes d’unicité. Le test normalise casse, ponctuation et espaces, conserve les signes diacritiques et utilise les formes nominales publiées. Aucun rapprochement approximatif ni aucun simple numéro porté sur plusieurs dates n’alimente le résultat. [Indices agrégés par identifiant fédéral haché](indices-bio.json) · [Provenance](provenance.json)

## Rejeu

Depuis une extraction neuve, deux commandes suffisent avec Python 3.10 ou ultérieur. La capsule utilise les faits sportifs et les empreintes d’identifiants fédéraux. Aucune requête en ligne ni donnée nominative brute n’est nécessaire.

```sh
shasum -a 256 -c SHA256SUMS
python3 -B verifier.py
```

Le script opérateur `preparer.py` conservé dans le dossier de contrôle permet en plus de réextraire les entrées depuis les feuilles et les quatre captures gelées. Les inspections des données personnelles originales s’effectuent localement. Le premier ZIP et l’extension de 174 matchs conservent leurs empreintes d’origine.
