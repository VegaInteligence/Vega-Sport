"""Rejoue les écarts de volumes, les témoins par côté et les tests de clé sans données civiles."""
from collections import defaultdict,Counter
from pathlib import Path
import argparse,csv,hashlib,io,json
D=Path(__file__).resolve().parent
def read(f):return json.loads((D/f).read_bytes())
def csvbytes(rows):
    buf=io.StringIO(newline='');w=csv.DictWriter(buf,fieldnames=list(rows[0]));w.writeheader();w.writerows(rows);return buf.getvalue().encode()
def jb(x):return (json.dumps(x,ensure_ascii=False,indent=2)+'\n').encode()
def summary(rr):
    return dict(matchs=len(rr),participations=sum(r['participations_saff'] for r in rr),notes=sum(r['notes_rds'] for r in rr),deficit_brut=sum(r['deficit'] for r in rr),excedent_brut=sum(r['excedent'] for r in rr),net_participations_moins_notes=sum(r['delta'] for r in rr),matchs_deficit=sum(r['delta']>0 for r in rr),matchs_excedent=sum(r['delta']<0 for r in rr),matchs_egaux=sum(r['delta']==0 for r in rr),distribution=dict(sorted(Counter(r['delta'] for r in rr).items())))
def run():
    inputs=read('entrees-292-cotes.json');detail=read('detail-deux-matchs.json');keys=read('indices-bio.json');pr=read('provenance.json')
    by=defaultdict(dict);allids=set();cotes=[];games=[]
    assert len({(r['vega_match'],r['joueur_vega']) for r in detail})==len(detail)==80
    for r in inputs:
        key=r['edition'],r['match']
        assert r['cote'] not in by[key] and r['date_saff']==r['date_rds'] and r['score_saff']==r['score_rds']
        assert len(r['jouees'])==len(set(r['jouees'])) and len(r['jouees'])>=11
        by[key][r['cote']]=r;allids.update(r['jouees'])
    assert len(by)==146 and len(inputs)==292
    known=set(r['vega_match'] for r in detail)
    for (ed,i),both in sorted(by.items()):
        h,a=both['home'],both['away'];assert h['team_id']!=a['team_id'] and not set(h['jouees'])&set(a['jouees'])
        assert h['wpl']==a['wpl'] and h['saff']==a['saff'] and h['notes_match']==a['notes_match']
        p=len(h['jouees'])+len(a['jouees']);g=h['notes_match']
        games.append(dict(edition=ed,vega=i,wpl=h['wpl'],saff=h['saff'],date=h['date_saff'],domicile=h['equipe'],exterieur=a['equipe'],score=h['score_saff'],saff_dom=len(h['jouees']),saff_ext=len(a['jouees']),participations_saff=p,notes_rds=g,delta=p-g,deficit=max(0,p-g),excedent=max(0,g-p),detail_notes_par_cote='capture_anterieure' if i in known else 'indisponible'))
        for side,r in both.items():
            graded=[o for o in detail if o['vega_match']==i and o['cote_note']==side and o['note']]
            ng=len(graded) if i in known else None
            cotes.append(dict(edition=ed,vega=i,wpl=r['wpl'],saff=r['saff'],date=r['date_saff'],cote=side,equipe=r['equipe'],id_equipe_vega=r['team_id'],participations_saff=len(r['jouees']),notes_rds=ng,delta=len(r['jouees'])-ng if ng is not None else None,
                 statut='compte_complet_au_snapshot_anterieur' if i in known else 'notes_par_cote_non_observees'))
        if i in known:assert g==sum(r['note'] for r in detail if r['vega_match']==i)
    assert all(r['cote_note'] in ('home','away') and r['cote_note']==r['cote_composition'] for r in detail if r['note'])
    assert all((r['notes_rds']==r['participations_saff']) for r in cotes if r['vega'] in known)
    assert all(r['notes_rds'] is None for r in cotes if r['vega'] not in known)
    sums={str(ed):summary([r for r in games if r['edition']==ed]) for ed in (1000,1001)}
    sums['ensemble']=summary(games)
    assert [sums[ed][k] for ed in ('1000','1001','ensemble') for k in ('deficit_brut','excedent_brut','matchs_egaux')]==[5,11,79,18,5,35,23,16,114]
    assert sums['ensemble']['participations']==4125 and sums['ensemble']['notes']==4118
    assert set(o['saff'] for o in keys)==allids and sum(r['participations'] for r in keys)==4125 and len(keys)==275
    assert all(r['dates_distinctes']==1 for r in keys) and not any(r['candidats'] for r in keys)
    matched=[r for r in detail if r['note'] and r['nom_unique_dans_les_deux_effectifs'] and r['pres_saff_si_numero']]
    assert len(matched)==2 and {r['vega_match'] for r in matched}=={87580}
    somme=dict(editions=sums,cotes_ventiles=4,cotes_non_ventiles=288,ancien_detail_notes=55,
     ids_saff_ayant_joue=len(keys),ids_saudi_avec_date_jour=275,dates_avec_candidat_dans_registre=sum(r['vega_meme_date']>0 for r in keys),noms_multicomposants_avec_candidat=sum(r['vega_homonymes_multicomposants']>0 for r in keys),nom_et_date_candidats_sans_filtre=sum(r['nom_et_date_sans_filtre']>0 for r in keys),
     cle_bio_unique=sum(r['injectif'] for r in keys),identifiants_saff_presents_chez_fournisseurs_observes=False,compositions_avec_maillot_correspondant=sum(r['numero_saff_present'] for r in detail),
     notes_avec_numero_sur_participante=sum(r['note'] and r['pres_saff_si_numero'] for r in detail),notes_avec_numero_et_nom_multicomposant_exacts_et_uniques=len(matched),
     observations_situees=[dict(vega_match=r['vega_match'],equipe=r['cote_note'],maillot=r['numero'],joueur_vega=r['joueur_vega']) for r in matched],recu=pr)
    assert somme['notes_avec_numero_sur_participante']==55 and somme['compositions_avec_maillot_correspondant']==80
    # Une compensation nette masquerait les deux directions. Le dédoublement des colonnes par côté devient un total faux.
    assert abs(sums['ensemble']['net_participations_moins_notes'])!=sums['ensemble']['deficit_brut']+sums['ensemble']['excedent_brut']
    assert sum(r['notes_match'] for r in inputs)==2*sums['ensemble']['notes']
    return {'comparaison-146.csv':csvbytes(games),'comparaison-292-cotes.csv':csvbytes(cotes),'synthese.json':jb(somme)}
if __name__=='__main__':
    ap=argparse.ArgumentParser();ap.add_argument('--generer',action='store_true');arg=ap.parse_args()
    for f,b in run().items():
        if arg.generer:(D/f).write_bytes(b)
        else:assert b==(D/f).read_bytes(),f
        print(hashlib.sha256(b).hexdigest(),f)
