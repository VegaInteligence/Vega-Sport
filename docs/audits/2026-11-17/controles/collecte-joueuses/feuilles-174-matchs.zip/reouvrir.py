"""Rouvre les seuls formulaires publics d'un match et compare leurs empreintes."""
import argparse,hashlib,json,time
from datetime import datetime,timezone
from pathlib import Path
from urllib.error import HTTPError
from urllib.parse import urlencode
from urllib.request import Request,urlopen
D=Path(__file__).resolve().parent
p=argparse.ArgumentParser();p.add_argument('--match',type=int,required=True);p.add_argument('--sortie',type=Path,required=True)
a=p.parse_args()
sources=[s for s in json.loads((D/'sources.json').read_bytes()) if s['wpl']==a.match]
assert len(sources) in (2,3),'identifiant WPL absent du corpus'
a.sortie.mkdir(exist_ok=False,parents=True)
out=[]
for s in sources:
    assert s['url'].startswith('https://saff-ti.com/womensFootballWebsite/Live/')
    request=Request(s['url'],data=urlencode(s['requete']).encode(),headers={'User-Agent':'Mozilla/5.0','Origin':'https://wpl.saff.com.sa','Referer':'https://wpl.saff.com.sa/'})
    try:response=urlopen(request,timeout=40)
    except HTTPError as err:response=err
    with response:b=response.read();status=response.status
    (a.sortie/(s['type']+'.data')).write_bytes(b)
    digest=hashlib.sha256(b).hexdigest()
    out.append(dict(type=s['type'],utc=datetime.now(timezone.utc).isoformat(),status=status,same_bytes=digest==s['sha256'],original_sha256=s['sha256'],current_sha256=digest))
    time.sleep(.5)
(a.sortie/'observation.json').write_text(json.dumps(out,indent=2)+'\n')
for s in out:print(s['type'],s['status'],s['current_sha256'],s['same_bytes'])
