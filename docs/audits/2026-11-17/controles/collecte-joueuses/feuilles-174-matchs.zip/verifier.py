"""Réconcilie les présences natives avec les changements et les durées publiées."""
from collections import Counter, defaultdict
from pathlib import Path
import argparse,csv,hashlib,io,json
D=Path(__file__).resolve().parent
CLUBS={'Al Nassr Women':'Al Nassr','NEOM Women':'Neom SC','Al Hilal Women (SAFF)':'Al Hilal','Al Ittihad Women (SAFF)':'Al Ittihad','Al Ula FC Women':'Al Ula','Al Taraji Women':'Al Taraji','Al-Ahli Saudi Women':'Al Ahli','Al Qadsiah FC Women':'Al Qadsiah'}
def read(p):return json.loads((D/p).read_bytes())
def group(rows):
    by=defaultdict(list)
    for r in rows:by[r['wpl'],r['cote']].append(r)
    return by
def csvbytes(rows):
    buf=io.StringIO(newline='');w=csv.DictWriter(buf,fieldnames=list(rows[0]));w.writeheader();w.writerows(rows);return buf.getvalue().encode()
def jsonbytes(x):return (json.dumps(x,indent=2,ensure_ascii=False)+'\n').encode()
def evaluate(fxs,lineups,changes,measured,sources,strict=True):
    l,c,m=map(group,(lineups,changes,measured));src={(r['wpl'],r['type']):r for r in sources};allrows=[];conflicts=[];seen=defaultdict(set);hrs=Counter();byclub=defaultdict(set)
    for f in fxs:
        ed,idx=f['edition'],f['wpl']
        played_sides=set()
        for k,side in enumerate(('home','away')):
            key=idx,side;sheet=l[key];events=c[key];stats=m[key];team=f[('domicile','exterieur')[k]]
            shirts=defaultdict(list);names=defaultdict(list)
            for row in sheet:
                shirts[row['maillot']].append(row)
                for nam in row['noms']:names[nam].append(row)
            starters=[r for r in sheet if r['role']=='MAIN']; bench=[r for r in sheet if r['role']=='SUBSTITUTES']
            issues=[];early=[];rows_affected=False
            if len(starters)!=11:issues.append('effectif_titulaire_'+str(len(starters)))
            if '' in shirts or len(shirts)!=len(sheet):issues.append('maillot_non_unique')
            identifiers={r['personne'] for r in sheet};missing=sum(not r['personne'] for r in sheet)
            if missing or len(identifiers)!=len(sheet):issues.append('identifiant_manquant_ou_duplique')
            if played_sides & (identifiers-{None}):issues.append('meme_identifiant_sur_deux_cotes')
            played_sides.update(identifiers-{None})
            field={r['personne'] for r in starters if r['personne']};played=field.copy()
            switches=0
            for event in events:
                matched=[]
                for role,alias in [('entrant','nom_entrant'),('sortant','nom_sortant')]:
                    candidates=[r for r in shirts[event[role]] if event[alias] in r['noms']]
                    if len(candidates)==1 and candidates[0]['personne']:matched.append(candidates[0]);continue
                    nm=names[event[alias]]
                    issues.append('remplacement_'+role+'_maillot_nom_incertains')
                    conflicts.append(dict(edition=ed,wpl=idx,cote=side,probleme='remplacement_'+role,maillot=event[role],minute=event['minute'],maillots_meme_nom=','.join(sorted(r['maillot'] for r in nm))))
                    matched.append(None)
                inc,out=matched
                if inc and inc['role']=='SUBSTITUTES' and inc['personne'] not in played:
                    played.add(inc['personne']);switches+=1
                else:issues.append('entrante_inclassable_ou_deja_jouee')
                if not out or not inc or out['personne'] not in field or inc['personne'] in field:
                    issues.append('sequence_non_resolue')
                    conflicts.append(dict(edition=ed,wpl=idx,cote=side,probleme='sequence_non_resolue',maillot=event['entrant'],minute=event['minute'],maillots_meme_nom='',sortante=event['sortant'],sortante_sur_terrain=bool(out and out['personne'] in field)))
                else:
                    field.remove(out['personne']);field.add(inc['personne'])
            seen[ed].update(played)
            incertitudes_feuille=bool(issues)
            same_signals=sum(1 for s in stats if s['minutes']>0);zeros=[s for s in stats if s['minutes']==0]
            assert len({s['maillot'] for s in stats})==len(stats)
            if len(field)!=11:issues.append('effectif_final_'+str(len(field)))
            played_shirts={r['maillot'] for r in sheet if r['personne'] in played}
            if stats:
                for s in stats:
                    byclub[s['equipe_bepro']].add(team)
                    if s.get('champ_touches'):issues.append('champ_touches_present')
                sm={str(s['maillot']) for s in stats}
                if sm!=played_shirts:
                    issues.append('couverture_BEPRO_divergente')
                    conflicts.append(dict(edition=ed,wpl=idx,cote=side,probleme='couverture_BEPRO',maillots_BEPRO_seuls=','.join(sorted(sm-played_shirts)),maillots_SAFF_seuls=','.join(sorted(played_shirts-sm))))
                for s in zeros:
                    ev=[t for t in events if t['entrant']==str(s['maillot'])]
                    early.append(str(s['maillot'])+'@'+(','.join(t['minute'] for t in ev) if ev else '?')+':'+str(s['passes'])+'p')
            issues=sorted(set(issues))
            current=ed==1002;res=src.get((idx,'mesures'),{})
            if ed!=1002:qual='non_sonde'
            elif stats:qual='BEPRO'
            elif f.get('statistiques_reponse')=='200:pending':qual='analyse_BEPRO_en_attente'
            elif res.get('http')==502:qual='HTTP_502'
            else:qual='sans_mesures_HTTP_'+str(res.get('http'))
            allrows.append(dict(edition=ed,wpl=idx,saff=f['saff'],vega=f['vega'],jour=f['date'],semaine=f['semaine'],cote=side,equipe=team,statut_vega=f['statut_vega'],elo_cotes_match=f['elo_cotes_vega'],notes_match=f['notes_vega'],
              feuille=f['format_feuille'],journal=f['format_changements'],tit=len(starters),banc=len(bench),remplacements_lignes=len(events),entrees_sures=switches,participations_attestees=len(played),
              banc_sans_entree=len(bench)-switches if f['format_changements']=='SAFF_changes' and not incertitudes_feuille else None,
              minutes_source=qual,mesures=len(stats),minutes_positives=same_signals,zero=len(zeros),zeros_avec_actions=sum(bool(z['actions_positives']) for z in zeros),
              temoin_zero_minute='|'.join(early),part_sans_minute_positive=len(played_shirts-{str(s['maillot']) for s in stats if s['minutes']>0}) if current else None,anomalies='|'.join(issues)))
    if strict:
        assert len(fxs)==174 and len(allrows)==348 and all(len(v)==1 for v in byclub.values()),byclub
        for bn,n in byclub.items():assert CLUBS[bn]==next(iter(n)),(bn,n)
    def sums(rows):
        return {k:sum(r[k] for r in rows if r[k] is not None) for k in ('tit','banc','remplacements_lignes','entrees_sures','participations_attestees','banc_sans_entree','mesures','minutes_positives','zero','zeros_avec_actions','part_sans_minute_positive')}
    def count_group(rows):
        return dict(matchs=len(rows)//2,**sums(rows),cotes_avec_onze_titulaires=sum(r['tit']==11 for r in rows),cotes_feuille_et_journal=sum(r['feuille']=='SAFF_MAIN_SUBSTITUTES' and r['journal']=='SAFF_changes' for r in rows),cotes_avec_anomalie=sum(bool(r['anomalies']) for r in rows),cotes_banc_non_concluant=sum(r['banc_sans_entree'] is None for r in rows),nombre_matchs_mesures=sum(bool(r['mesures']) for r in rows)//2)
    def category(rows):
        metrics=count_group(rows)
        keys={(r['wpl'],r['cote']) for r in rows}
        safe=set()
        qualified_subs={(e['wpl'],e['cote'],e['entrant']) for e in changes if (e['wpl'],e['cote']) in keys}
        for row in lineups:
            if (row['wpl'],row['cote']) in keys and (row['role']=='MAIN' or (row['wpl'],row['cote'],row['maillot']) in qualified_subs):
                safe.add(row['personne'])
        assert None not in safe
        metrics['identifiants_distincts_ayant_joue']=len(safe)
        metrics['disponibilite_minutes_par_match']=dict(Counter(r['minutes_source'] for r in rows if r['cote']=='home'))
        return metrics
    categories={'huit_termines':[r for r in allrows if r['edition']==1002 and r['statut_vega']=='finished'],'vingt_autres_resultats':[r for r in allrows if r['edition']==1002 and r['statut_vega']!='finished']}
    summary={'editions':{str(ed):dict(**count_group([r for r in allrows if r['edition']==ed]),ids_saff_participants=len(seen[ed])) for ed in (1000,1001,1002)},'actuelle':{k:category(v) for k,v in categories.items()},'qualite':dict(Counter(r['anomalies'] for r in allrows if r['anomalies'])),'noms_clubs_statistiques':{k:sorted(v) for k,v in byclub.items()}}
    for ed in (1000,1001,1002):
        summary['editions'][str(ed)]['remplacements_sans_horodatage']=sum(not str(x['minute']).strip() for x in changes if x['edition']==ed)
    for ed in ('1000','1001'):
        for field in ('mesures','minutes_positives','zero','zeros_avec_actions','part_sans_minute_positive','nombre_matchs_mesures'):
            summary['editions'][ed][field]=None
    return allrows,conflicts,summary
def run():
    rows,c,s=evaluate(*[read(n+'.json') for n in ['rencontres','inscriptions','changements','mesures','sources']])
    assert s['actuelle']['huit_termines']['participations_attestees']==240 and s['actuelle']['huit_termines']['minutes_positives']==114
    assert [s['editions'][str(e)]['matchs'] for e in (1000,1001,1002)]==[90,56,28]
    all_current=[r for r in rows if r['edition']==1002]
    by_match=defaultdict(list)
    for r in all_current:by_match[r['wpl']].append(r)
    games=[]
    for idx,ss in by_match.items():
        h,a=ss;assert h['cote']=='home' and a['cote']=='away' and h['minutes_source']==a['minutes_source']
        g=dict(vega=h['vega'],wpl=idx,saff=h['saff'],date=h['jour'],semaine=h['semaine'],domicile=h['equipe'],exterieur=a['equipe'],etat_vega=h['statut_vega'],elo_cotes_vega=h['elo_cotes_match'],notes_vega=h['notes_match'],source_minutes=h['minutes_source'])
        for k in ('tit','entrees_sures','participations_attestees','banc_sans_entree','mesures','minutes_positives','zero','zeros_avec_actions','part_sans_minute_positive'):g[k]=sum(o[k] for o in ss)
        g['temoins']=' | '.join(o['cote']+' '+o['temoin_zero_minute'] for o in ss if o['temoin_zero_minute'])
        g['ecarts']=' | '.join(o['cote']+' '+o['anomalies'] for o in ss if o['anomalies'])
        games.append(g)
    current_ids={g['wpl'] for g in games}
    l=[r for r in read('inscriptions.json') if r['wpl'] in current_ids]
    cnow=[r for r in read('changements.json') if r['wpl'] in current_ids]
    mnow=read('mesures.json');red=read('expulsions-28.json')
    assert len(red)==2 and {r['wpl'] for r in red}=={48603,48606}
    byshirt={(r['wpl'],r['cote'],r['maillot']):r for r in l};numbers={ (r['wpl'],r['cote'],str(r['maillot'])):r for r in mnow }
    for e in red:
        k=(e['wpl'],e['cote'],e['maillot']);assert byshirt[k]['personne']==e['personne'] and byshirt[k]['role']=='MAIN'
        assert not any(r['wpl']==k[0] and r['cote']==k[1] and (r['sortant']==k[2] or r['entrant']==k[2]) for r in cnow)
    all_part={(r['wpl'],r['cote'],r['maillot']) for r in l if r['role']=='MAIN'}|{(r['wpl'],r['cote'],r['entrant']) for r in cnow}
    assert len(all_part)==831
    marker_keys={(r['wpl'],r['cote'],r['sortant']) for r in cnow}|{(r['wpl'],r['cote'],r['entrant']) for r in cnow}|{(r['wpl'],r['cote'],r['maillot']) for r in red}
    no_positive={k for k in all_part if k not in numbers or numbers[k]['minutes']<=0}
    s['durees_actuelles']={'horodatage_des_215_remplacements':dict(Counter('mi_temps' if 'halftime' in x['minute'] else 'arrets' if '+' in x['minute'] else 'minute' for x in cnow)),
      'minutes_superieures_a_90':sum(r['minutes']>90 for r in mnow),'maximum_minutes_individuelles':max(r['minutes'] for r in mnow),'sans_duree_positive_avec_changement_ou_expulsion':len(no_positive&marker_keys),'sans_duree_positive_sans_changement_ni_expulsion':len(no_positive-marker_keys),
      'expulsions':[{**e,'minutes_bepro':numbers[e['wpl'],e['cote'],e['maillot']]['minutes']} for e in red]}
    for g in games:
        i=g['wpl'];g['expulsions']='|'.join(r['cote']+' '+r['maillot']+'@'+r['minute'] for r in red if r['wpl']==i)
        keys={k for k in no_positive if k[0]==i};g['sans_duree_positive_avec_changement_ou_expulsion']=len(keys&marker_keys)
        g['sans_duree_positive_sans_changement_ni_expulsion']=len(keys-marker_keys)
    assert len(games)==28 and sum(x['entrees_sures'] for x in games)==215
    assert sum(x['participations_attestees'] for x in games)==831 and sum(x['minutes_positives'] for x in games)==406
    assert sum(x['part_sans_minute_positive'] for x in games)==425 and sum(x['elo_cotes_vega'] for x in games)==16
    assert [e['maillots_SAFF_seuls'] for e in c if e['edition']==1002 and e['wpl']==48617 and e['probleme']=='couverture_BEPRO']==['14']
    probes=[r for r in read('autres-sources.json') if r['piece'].endswith('mesures-sonde')]
    assert len(probes)==6 and all(r['http']==502 for r in probes)
    negative=negative_controls()
    return {'cotes-348.csv':csvbytes(rows),'matchs-28.csv':csvbytes(games),'ecarts-traces.json':jsonbytes(c),'synthese.json':jsonbytes(s),'tests-negatifs.json':jsonbytes(negative)}

def negative_controls():
    match=[f for f in read('rencontres.json') if f['wpl']==48595]
    def filt(file):return [r for r in read(file+'.json') if r['wpl']==48595]
    ls,ev,st,ps=[filt(f) for f in ('inscriptions','changements','mesures','sources')]
    original=evaluate(match,ls,ev,st,ps,False)[0]
    assert sum(r['participations_attestees'] for r in original)==30
    assert sum(r['minutes_positives'] for r in original)==29
    from copy import deepcopy
    wrong=deepcopy(ev);wrong[0]['nom_entrant']='identite absente de la feuille'
    rejected=evaluate(match,ls,wrong,st,ps,False)[0]
    assert sum(r['participations_attestees'] for r in rejected)==29 and any('nom_incertains' in r['anomalies'] for r in rejected)
    empty=evaluate(match,ls,[],[],ps,False)[0]
    assert sum(r['participations_attestees'] for r in empty)==22
    wrongnumber=deepcopy(ev);wrongnumber[0]['entrant']='999'
    unmatched=evaluate(match,ls,wrongnumber,st,ps,False)[0]
    assert sum(r['participations_attestees'] for r in unmatched)==29
    return {'registre_sans_remplacements':22,'maillot_incompatible':29,'nom_incompatible':29,'feuille_et_changements':30,'ne_pas_supprimer_entree_a_zero_minute':{'minutes_positives':29,'attestees':30}}
if __name__=='__main__':
    p=argparse.ArgumentParser();p.add_argument('--generer',action='store_true');flag=p.parse_args()
    for n,blob in run().items():
        if flag.generer:(D/n).write_bytes(blob)
        else:assert (D/n).read_bytes()==blob,n
        print(hashlib.sha256(blob).hexdigest(),n)
