# Registre officiel des présences · 174 matchs joués

Au 18 novembre 2026, les **28 résultats** de la saison saoudienne en cours disposent de compositions et de changements nominatifs sur le site de la ligue. La fédération atteste **831 participations** de **155 joueuses distinctes**. Vega conserve huit résultats, seize côtés avec Elo et aucune note de joueuse sur ces 28 rencontres. [Détail des 28 matchs](matchs-28.csv) · [Calendrier fédéral](https://www.saff.com.sa/en/championship.php?id=428&type=all)

| Résultats officiels 2026/27 | Joueuses SAFF distinctes | Titulaires | Entrées | Participations | Banc sans entrée | Minutes BEPRO positives | Sans durée positive BEPRO |
|---|---:|---:|---:|---:|---:|---:|---:|
| 8 résultats terminés dans Vega | 135 | 176 | 64 | 240 | 75 | 114 | 126 |
| 20 autres rencontres déjà jouées | 153 | 440 | 151 | 591 | 185 | 292 | 299 |
| Ensemble des 28 | 155 | 616 | 215 | 831 | 260 | 406 | 425 |

Les seize compositions des deux premières journées figurent aussi dans la première capsule, incluse à l’identique. Des joueuses participent aux deux groupes de matchs. Les 135 et 153 identifiants distincts se recoupent. [Première capsule](premiere-capsule.zip) · [Sources primaires des rencontres](sources.json)

## Minutes mesurées et lacunes des statistiques

Les 56 côtés ont chacun onze titulaires. Les 215 remplaçantes entrées sont retrouvées sur le banc de la bonne équipe par maillot et par nom. Chaque sortante était sur le terrain au moment où le journal la remplace. Sur 14 matchs, le service de statistiques de la ligue livre 413 lignes individuelles BEPRO. **406 affichent des minutes positives**. Sept entrantes portent zéro minute malgré une action positive enregistrée dans leurs statistiques. Sur les quatorze autres matchs, treize appels renvoient HTTP 502 et le quatorzième renvoie HTTP 200 avec analyse en attente (Al Ittihad–Al Ula, identifiant WPL 48613). [Registre des 28 matchs](matchs-28.csv) · [Exemple en attente](https://wpl.saff.com.sa/match/48613?season=2026/2027)

Le 30 octobre, dans Al Ittihad–NEOM 3–3, la n°14 d’Al Ittihad entre à la 84e minute. Le journal et la feuille sont concordants. Les statistiques BEPRO couvrent quatorze des quinze participantes de son équipe et omettent la n°14. Pour les 425 apparitions sans durée strictement positive, le registre garde le statut source, le numéro de maillot et les changements disponibles. Les minutes de remplacement ne sont pas converties en temps de jeu mesuré. Le test ne relie aucune identité fédérale à une identité Vega. [Match officiel](https://wpl.saff.com.sa/match/48617?season=2026/2027) · [Écarts détaillés](ecarts-traces.json)

Le journal indique la mi-temps pour 30 remplacements, les arrêts de jeu pour 5 et une minute de jeu pour 180. Parmi les 425 apparitions sans minutes BEPRO positives, 225 ont une borne explicite d’entrée, de sortie ou d’expulsion, et 200 n’ont aucun de ces repères. Quatre durées publiées dépassent 90 minutes. Deux titulaires sont expulsées hors remplacement. La n°29 d’Al Ula reçoit un rouge à 90+4 (94 minutes BEPRO), et la n°3 d’Al Taraji à la 19e (18 minutes BEPRO). [Événements d’expulsion](expulsions-28.json) · [Rencontre Al Hilal–Al Taraji](https://wpl.saff.com.sa/match/48606?season=2026/2027)

## Registre des deux saisons terminées

L’opération a relu le calendrier, la feuille et le journal de remplacement de chacune des 90 rencontres de 2024/25 et des 56 rencontres de 2025/26. Les deux millésimes ont des identifiants de compétition WPL distincts, 183 et 270. Ils correspondent aux éditions Vega 1000 et 1001, et aux calendriers SAFF 263 et 345. Les 202 affiches des trois saisons ont été rapprochées par édition et côtés dans la première capsule. Les 174 jouées y ont une date et un score officiels. [Calendrier 2024/25](https://www.saff.com.sa/en/championship.php?id=263&type=all) · [Calendrier 2025/26](https://www.saff.com.sa/en/championship.php?id=345&type=all)

| Saison | Matchs | Côtés avec feuille et journal / attendus | Titulaires | Entrées attestées | Participations attestées | IDs participants distincts | Côtés avec anomalie |
|---|---:|---:|---:|---:|---:|---:|---:|
| 2024/25 | 90 | 180 / 180 | 1980 | 561 | 2541 | 231 | 1 |
| 2025/26 | 56 | 112 / 112 | 1232 | 352 | 1584 | 170 | 1 |

Une entrante est retenue lorsque le journal nomme sa personne avec le maillot d’une remplaçante inscrite sur ce côté. Un désaccord sur la sortante est conservé dans le registre. Une entrée ambiguë reste en dehors du minimum attesté. Les identifiants distincts se rapportent au registre SAFF. Les mesures internes des éditions (2 547 et 1 571 notes) se lisent dans la première capsule. La comparaison ne permet pas, seule, d’attribuer l’écart à des personnes nommées. [348 côtés vérifiés](cotes-348.csv)

Les durées anciennes ont fait l’objet d’un sondage séparé de trois matchs par édition, au début, au milieu et à la fin du calendrier. Les six requêtes de statistiques par identifiant de fixture ont retourné HTTP 502. La couverture des minutes individuelles historiques demeure indéterminée au-delà de ces six lectures. Les journaux indiquent une heure ou une minute pour 556 des 561 entrées de 2024/25 et 350 des 352 de 2025/26. Les sept autres entrantes sont nommées sur leur feuille et leur journal, sans heure de remplacement. [Reçus du sondage et des calendriers](autres-sources.json)

## Rejeu et provenance

Les sources publiques ont été relues le 18 novembre 2026. Le registre utilise séparément l’ID du calendrier fédéral, le code WPL du journal, l’ID WPL de la feuille et l’ID de match Vega. Le client web de la WPL configure ces saisons en mode fixture_id. Le formulaire public MatchEvents.php appelé avec le code natif du match donne les changements nominatifs. La mesure porte sur les réponses HTTP de ces sources. Le collecteur compare la saison, l’heure locale, la date, l’ordre des équipes et le score des deux calendriers avant de joindre les feuilles. Les réponses brutes sont conservées dans le dossier opérateur. La capsule livre les champs sportifs minimaux et les empreintes des sources, sans noms civils, dates de naissance ni images personnelles.

Après extraction, les deux commandes suivantes vérifient les sommes et refont les comptes avec Python 3.10 ou ultérieur.

```sh
shasum -a 256 -c SHA256SUMS
python3 -B verifier.py
```

Avec un accès Internet, la commande suivante relit les trois formulaires du match témoin et compare les nouvelles empreintes aux reçus datés. Elle place les réponses originales dans un nouveau dossier local.

```sh
python3 -B reouvrir.py --match 48617 --sortie controle-prive-48617
```

Les contrôles négatifs changent un nom ou un maillot, retirent les remplacements et conservent le témoin à zéro minute. Le décompte suit exactement la preuve disponible. [Tests rejouables](tests-negatifs.json)

### Côtés historiques à lire avec réserve

- 2024-09-28 · Al Qadsiah. La n°15 est désignée sortante à la mi-temps puis à la 66e minute. Le journal nomme deux entrantes différentes, n°34 et n°17. [Feuille officielle](https://wpl.saff.com.sa/match/14617?season=2024/2025)
- 2026-04-03 · Al Qadsiah. La n°3 est désignée sortante à la 78e puis à la 79e minute. Le journal nomme les entrantes n°19 et n°8. [Feuille officielle](https://wpl.saff.com.sa/match/32073?season=2025/2026)
