"""Reconstitue les sources exactes du test à partir des objets Git de Vega-Sport."""
from pathlib import Path
import argparse
import hashlib
import json
import subprocess

def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('repo',type=Path)
    args = parser.parse_args()
    root = Path(__file__).resolve().parent
    receipt = json.loads((root / 'source-receipt.json').read_bytes())
    sources = receipt['files']
    destination = root / 'runtime'
    for name, expected in sources.items():
        path = Path(name)
        if path.is_absolute() or '..' in path.parts:
            raise ValueError(name)
        data = subprocess.check_output(['git','-C',str(args.repo),'cat-file','blob',receipt['commit']+':'+name])
        if hashlib.sha256(data).hexdigest() != expected:
            raise ValueError('Empreinte source divergente '+name)
        target = destination / path
        target.parent.mkdir(parents=True,exist_ok=True)
        if target.exists() and target.read_bytes() != data:
            raise ValueError('Fichier local divergent '+name)
        target.write_bytes(data)
    print(len(sources),'sources vérifiées',receipt['commit'])

if __name__=='__main__':
    main()
