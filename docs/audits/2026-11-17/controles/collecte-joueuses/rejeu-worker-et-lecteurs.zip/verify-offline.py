from pathlib import Path
import json,hashlib,csv
Q=Path(__file__).resolve().parent
s=json.loads((Q/'states.json').read_text());r=json.loads((Q/'result.json').read_text());t=json.loads((Q/'transport-evidence.json').read_text());e=json.loads((Q/'execution-receipt.json').read_text())
checks=[]
def check(label,condition):
    assert condition,label
    checks.append(label)
check('replay passed; disposable container destroyed',r['status']=='PASS' and e['exit_code']==0 and e['stopped'])
check('source exact integrity',all(hashlib.sha256((Q/'runtime'/p).read_bytes()).hexdigest()==sha for p,sha in json.loads((Q/'source-receipt.json').read_text())['files'].items()))
check('all 11 fetches genuinely leased at transport',len(t)==11 and all(x['lease_at_fetch']['state']=='leased' and x['lease_at_fetch']['has_token'] and x['lease_at_fetch']['unexpired'] for x in t))
for variant in ['partial_columns','partial_rows','empty']:
    before=s[variant+'_before_graded'];f=s[variant+'_fetch'];c=s[variant+'_calculate'];g=s[variant+'_regraded']
    check(variant+': actual calculated prior stored',len(before['target_power'])==1 and before['target_power'][0]['contribution']>0 and len(before['target_grade'])==1)
    check(variant+': coverage and collector OK',f['coverage'][0]['player_stats']=='ok' and f['family'][0]['status']=='ok')
    check(variant+': removed player explicitly dirtied',any(x['scope_kind']=='player_season' and x['player_id']==900001 for x in f['dirty']))
    check(variant+': ordinary dirty queue fully drained',c['dirty']==[])
    check(variant+': real stored grade untouched by ingestion and ordinary calculation',before['target_grade']==f['target_grade']==c['target_grade'])
    check(variant+': independent API reads expose 75 minutes and 77.4 after ordinary calculation',c['readers']['/api/rankings/match?match=m_syn001']['status']==200 and c['readers']['/api/rankings/match?match=m_syn001']['body']['grades'][0]['minutes']==75 and c['readers']['/api/rankings/match?match=m_syn001']['body']['grades'][0]['grade']==77.4)
    check(variant+': real grade refresh clears grade API',not g['target_grade'] and g['readers']['/api/rankings/match?match=m_syn001']['status']==404)
    if variant=='partial_columns':
        check(variant+': row retained but absent metrics lost',f['raw'][0]['minutes_played']==75 and f['raw'][0]['tackles'] is None and f['raw'][0]['touches'] is None and f['raw'][0]['assists'] is None)
        check(variant+': recalculated contribution becomes unknown',len(g['target_power'])==1 and g['target_power'][0]['contribution'] is None and g['target_power'][0]['match_index'] is None)
    else:
        check(variant+': target raw deleted',not any(x['player_id']==900001 for x in f['raw']))
        a=c['readers']['sql']['appearances'][0];l=c['readers']['sql']['list'][0]
        check(variant+': lineup surviving appearance has zero minutes but stale grade',a['minutes']==0 and not a['has_stats'] and a['grade']>77)
        check(variant+': list combines zero matches with old graded minutes',l['matches']==0 and l['total_minutes']==0 and l['grade_count']==1 and l['grade_minutes']==75)
        check(variant+': normal aggregate removed',not c['target_aggregate'])
        check(variant+': source power removed only by grade pass',not g['target_power'])
check('empty players route returns empty data',s['empty_calculate']['readers']['/api/matches/m_syn001/players']['body']=={'data':[]})
check('summary counts no graded/played player',s['empty_calculate']['readers']['/api/matches/m_syn001/summary']['body']['data']['match']['coverage']['gradedPlayers']==0 and s['empty_calculate']['readers']['/api/matches/m_syn001/summary']['body']['data']['match']['coverage']['playedPlayers']==0)
check('every observed API session is read only vega_read',all(x['readers']['sql']['session']==[{'current_user':'vega_read','read_only':'on'}] for x in s.values()))
check('empty data identical to previously attested canonical bytes',all(x['data_canonical_sha256']=='4f53cda18c2baa0c0354bb5f9a3ecbe5ed12ab4d8e11ba873c2f11161202b945' for x in t if x['stage'] in ('empty_fetch','empty_repeat','expired_lease_fetch')))
check('invalid parsing is preserving counterexample',s['invalid_before_graded']['raw']==s['invalid_fetch']['raw'] and s['invalid_fetch']['family'][0]['status']=='error')
check('lost lease is preserving counterexample',s['lease_before_graded']['raw']==s['expired_lease_fetch']['raw'] and s['lease_before_graded']['target_grade']==s['expired_lease_fetch']['target_grade'])
rows=[]
for key,x in s.items():
    a=x['readers']['sql']['appearances'];rank=x['readers']['/api/rankings/match?match=m_syn001'];gs=rank['body'].get('grades',[])
    rows.append({'state':key,'raw_target':sum(i['player_id']==900001 for i in x['raw']),'raw_family_rows':len(x['raw']),'coverage':x['coverage'][0]['player_stats'],'family':x['family'][0]['status'],'dirty_scopes':len(x['dirty']),'aggregate':len(x['target_aggregate']),'power_rows':len(x['target_power']),'grade_rows':len(x['target_grade']),'appearance_minutes':a[0]['minutes'] if a else None,'appearance_grade':a[0]['grade'] if a else None,'ranking_status':rank['status'],'ranking_minutes':gs[0]['minutes'] if gs else None,'ranking_grade':gs[0]['grade'] if gs else None})
with (Q/'timeline.csv').open('w') as f:
    w=csv.DictWriter(f,fieldnames=list(rows[0]));w.writeheader();w.writerows(rows)
(Q/'offline-verification.json').write_text(json.dumps({'status':'PASS','checks':len(checks),'passed':checks,'states':len(s),'route_responses':len(s)*3},indent=2))
print(json.dumps({'status':'PASS','checks':len(checks),'states':len(s),'route_responses':len(s)*3}))
