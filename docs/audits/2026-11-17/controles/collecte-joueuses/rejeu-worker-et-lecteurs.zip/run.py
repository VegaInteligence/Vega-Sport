from pathlib import Path
import subprocess,uuid,time,os,json,sys,hashlib
Q=Path(__file__).resolve().parent
python=sys.argv[1] if len(sys.argv)>1 else str(Q/'.venv/bin/python')
D=['docker','--context','colima'];name='vi21-counterread-'+uuid.uuid4().hex[:10]
image=subprocess.check_output(D+['image','inspect','pgvector/pgvector:pg18','--format','{{.Id}}'],text=True).strip()
receipt={'container':name,'image':image,'network':'127.0.0.1 only; synthetic PitchClient transport, no upstream network','started':time.time()}
try:
    subprocess.run(D+['run','--rm','-d','--name',name,'-p','127.0.0.1::5432','-e','POSTGRES_HOST_AUTH_METHOD=trust','-e','POSTGRES_DB=vega_v2_worker_counterread',image],check=True,capture_output=True)
    for _ in range(60):
        if subprocess.run(D+['exec',name,'pg_isready','-U','postgres'],capture_output=True).returncode==0:break
        time.sleep(.5)
    else:raise RuntimeError('PG18 not ready')
    port=subprocess.check_output(D+['port',name,'5432/tcp'],text=True).strip().rsplit(':',1)[1]
    dsn='postgresql://postgres@127.0.0.1:'+port+'/vega_v2_worker_counterread'
    env=dict(os.environ,PYTHONPATH=str(Q/'runtime/backend'),PYTHONDONTWRITEBYTECODE='1')
    p=subprocess.run([python,str(Q/'replay.py'),dsn],env=env,text=True,capture_output=True)
    (Q/'replay.log').write_text(p.stdout+p.stderr);receipt['exit_code']=p.returncode
    print(p.stdout+p.stderr)
finally:
    cleanup=subprocess.run(D+['stop',name],capture_output=True,text=True)
    receipt.update(stopped=cleanup.returncode==0,cleanup_output=cleanup.stdout.strip(),finished=time.time())
    (Q/'execution-receipt.json').write_text(json.dumps(receipt,indent=2))
sys.exit(receipt.get('exit_code',1))
