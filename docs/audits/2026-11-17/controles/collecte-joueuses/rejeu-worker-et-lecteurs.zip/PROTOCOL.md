# Protocole avant exécution — une apparition, Worker.details

## Objet et frontière
Code exact du commit déployé `8018e0836ca0f32e8b2eb51fc2847154abff7f13`, archive locale immuable; aucune modification produit. PostgreSQL 18 jetable dans une ressource Docker personnelle. Aucune connexion RDS, aucun appel fournisseur, aucune recherche de calendrier/composition/blason. `[]` est la forme de données déjà attestée par le relevé Saudi existant; **tous les identifiants, matchs, observations antérieures et notes de ce nouvel essai sont synthétiques**. Cela ne démontre pas qu’une note antérieure existait pour un vrai match Saudi.

La cible est une seule apparition de 75 minutes. Trente apparitions de référence fixes (un autre joueur, trente matchs synthétiques) sont nécessaires au seuil MIN_REFERENCE=30 du vrai calcul, afin de produire et stocker une vraie note calculée sans insérer une note arbitraire. Une seconde ligne de contrôle, non analysée, permet une réponse partielle qui omet la cible. Une composition synthétique fixe conserve l’identité de la cible après disparition des statistiques.

## Chemin exercé
`jobs.enqueue → Worker.step → claim_next/claim → Worker.details → PitchClient.fetch → normalize_family → hydrate → Store.save_family → jobs.ack`.
Le seul point remplacé est le transport HTTP injecté dans PitchClient: statut, en-tête et corps JSON contrôlés, sans réseau. La vraie normalisation, la vraie transaction PostgreSQL, le vrai verrou/lease et le vrai ack restent actifs. Le transport relit la tâche et conserve la preuve qu’elle est effectivement leased, token non nul et échéance future à l’instant du fetch.

Pour chaque état: statistiques core, couverture, family_state, révision, dirty_scopes, resource_versions, agrégats saison, player_power_matches, player_match_grades, player_grade_editions, vues API et réponses des routes réelles. Les lectures utilisent vega_read et une connexion read-only. Le calcul appelle Worker.calculate (agrégats/cohortes), puis séparément power.refresh_players (sous-étape effective du passage journalier); le passage journalier complet, ses autres modèles, la cadence réelle, le cache/CDN et le navigateur ne sont pas prétendus testés.

## Cas et résultats à vérifier (hypothèses avant test)
1. Réponse complète HTTP200: tâche done avec lease libéré; observation 75 minutes stockée. Calcul ordinaire puis refresh_players doivent produire une contribution et une note persistées non nulles pour la cible.
2. Réponse partielle en colonnes: cible conservée mais ses métriques absentes deviennent nulles. Examiner si ancien intermédiaire/note survit avant et après Worker.calculate, puis disparaît/recalcule après refresh_players.
3. Réponse partielle en lignes: seul le témoin reste; cible supprimée, famille ok et tâche done. Vérifier que son ancien scope player_season est marqué, malgré sa disparition.
4. Réponse vide HTTP200: zéro statistique sur le match, famille ok et tâche done. Vérifier la même invalidation et distinguer lecteur de statistiques, lecteur d’apparitions et lecteur de notes. Une composition survivante peut induire minutes=0 tout en joignant une ancienne note; c’est une hypothèse à mesurer.
5. Réponse vide identique répétée: ack normal; pas de nouvelle révision/invalidation si empreinte identique.
6. Contrôle négatif de parse: HTTP200 avec une ligne invalide; la dernière observation validée doit être conservée, tâche en échec et family_state error (couverture core antérieure distincte).
7. Contrôle négatif de lease: expiration réelle du lease au moment du transport; aucune mutation de la famille ni ack autorisé.

Restaurer la réponse complète par le même chemin avant chaque variante indépendante. Aucun changement de seuil, de coefficient, de méthode de calcul ou de code normalisateur. Toute erreur de harnais sera conservée et corrigée uniquement dans ce dossier, avec distinction entre essai infructueux et verdict final.

## Critères d’acceptation de la preuve
- Les observations et notes antérieures sont réellement en base et relues avant altération.
- Les preuves avant/après séparent l’ingestion, le calcul ordinaire et le rafraîchissement des notes.
- Un résultat contraire à l’hypothèse de suppression est rapporté intégralement.
- Le replay est reproductible depuis l’archive source, les entrées, les scripts et les hashes; aucun secret ni donnée personnelle réelle.
- La ressource Docker personnelle est détruite même en cas d’échec; zéro écriture production.
