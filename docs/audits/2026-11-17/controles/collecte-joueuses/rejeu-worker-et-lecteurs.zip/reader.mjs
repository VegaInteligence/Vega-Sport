import { createReader } from './runtime/backend/api/src/db.mjs';
import { createHandler } from './runtime/backend/api/src/handler.mjs';
const reader=createReader(process.argv[2],{role:'vega_read'});
const handler=createHandler({read:reader.read});
const out={};
try{
  for(const path of ['/api/matches/m_syn001/players','/api/matches/m_syn001/summary','/api/rankings/match?match=m_syn001']){
    const response=await handler(new Request('http://evidence.invalid'+path));
    out[path]={status:response.status,headers:Object.fromEntries(response.headers),body:await response.json()};
  }
  out.sql={session:await reader.read('SELECT current_user,current_setting(\'transaction_read_only\') AS read_only'),
    appearances:await reader.read('SELECT player_id,minutes,has_stats,grade,grade_z,goals,assists,tackles FROM api.player_appearances WHERE match_id=900001 AND player_id=900001'),
    grades:await reader.read('SELECT * FROM api.match_grades WHERE match_key=900001'),
    list:await reader.read('SELECT player_id,matches,total_minutes,grade_count,grade_minutes,grade_zm FROM api.player_list_editions WHERE player_id=900001')};
  console.log(JSON.stringify(out));
}finally{await reader.end();}
