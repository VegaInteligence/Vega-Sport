# VI-21 — contre-lecture de Worker.details sur une apparition

**Conclusion : le chemin complet ne protège pas l’observation antérieure d’un tableau HTTP 200 partiel ou vide.** Sur le code déployé `8018e0836ca0f32e8b2eb51fc2847154abff7f13`, le vrai worker loue la tâche, remplace la famille, marque les dépendances puis l’acquitte. Une ancienne contribution et une ancienne note réellement calculées et stockées survivent à cette ingestion **et au calcul ordinaire**. Les lecteurs peuvent les exposer jusqu’au rafraîchissement des notes.

Le contrôle porte sur **une apparition cible entièrement synthétique**, dans une base PostgreSQL 18 jetable. Il ne prouve aucune disparition passée ni aucune note antérieure réelle pour les huit matchs Saudi. Leur seule preuve réelle réutilisée est la réponse vide déjà attestée dans le dossier parent ; aucune nouvelle collecte RDS, fournisseur, calendrier, composition ou média n’a été faite.

## Résultats observés

La cible avait 75 minutes, 12 tacles, 50 touches et 1 passe décisive. Le vrai `power.refresh_players` a calculé et écrit `contribution=4.504123`, `z=2.1411982`, soit une note lue `77.42685467200741` et rendue `77.4` par la route des notes. Trente apparitions de référence fixes et un témoin de ligne sont synthétiques ; ils permettent le calcul natif avec `MIN_REFERENCE=30`, sans abaisser les seuils ni insérer une note arbitraire. La cible est la seule apparition dont l’impact est analysé.

| Réponse contrôlée | Après Worker.details / ack | Après Worker.calculate | Après power.refresh_players |
|---|---|---|---|
| Cible présente, mais métriques absentes | Ligne présente, minutes 75 ; tacles/touches/PD devenus null ; ancienne note conservée | Agrégats recalculés, file dirty vidée, ancienne contribution/note toujours stockée et lue | Contribution et indice deviennent null ; ancienne note supprimée |
| Tableau partiel omettant la cible, témoin seul | Ligne cible supprimée ; famille `ok` ; tâche `done` | Agrégat cible supprimé ; ancienne contribution/note encore stockée et lue | Ancienne contribution et note supprimées |
| Tableau `[]` | Toutes les lignes player_stats du match supprimées ; famille `ok` ; tâche `done` | Même retrait de l’agrégat cible, mais anciennes contribution/note encore présentes | Ancienne contribution et note supprimées |
| Même `[]` répété | Tâche acquittée ; pas de nouvelle révision ni de nouveau scope | État inchangé | Non requis |
| Ligne invalide, HTTP 200 | Parsing `INVALID_ID`, tâche `failed` ; données et note antérieures conservées ; `family_state=error`, couverture core antérieure `ok` | Non requis | Non requis |
| Lease réellement expiré pendant le transport | `LEASE_LOST` ; aucune mutation de famille, aucun ack ; observations et note conservées | Non requis | Non requis |

**Contre-exemples de conservation :** erreur de parsing et perte de lease protègent effectivement le précédent état. Ils ne contredisent pas la suppression quand le tableau partiel/vide est syntaxiquement accepté avec couverture `ok`.

## Les lecteurs ne présentent pas tous le même état

Après `[]` puis `Worker.calculate`, les requêtes sous `vega_read`, transaction read-only, donnent simultanément :

- `GET /api/matches/m_syn001/players` : HTTP 200, `{"data":[]}`.
- `api.player_appearances` : l’identité reste grâce à la composition synthétique ; `minutes=0`, `has_stats=false`, mais `grade=77.42685467200741` et ancien `grade_z`.
- `GET /api/rankings/match?match=m_syn001` : HTTP 200, cible encore rendue avec **75 minutes et note 77.4**.
- `GET /api/matches/m_syn001/summary` : HTTP 200, `playedPlayers=0`, `gradedPlayers=0`, aucun leader ; les métriques de couverture du résumé ne reprennent donc pas aveuglément la vieille note.
- `api.player_list_editions` : `matches=0`, `total_minutes=0`, mais `grade_count=1`, `grade_minutes=75` et l’ancien numérateur de note.

Après le vrai `power.refresh_players`, la note et ses sommes disparaissent, la route des notes répond 404 et la vue d’apparition conserve `minutes=0` avec `grade=null`. La ligne de contribution est également supprimée quand la cible n’a plus de statistiques. Le cas partiel en colonnes conserve une ligne de contribution avec valeurs de calcul nulles.

Ce sont des réponses exécutées par les routes de production et le vrai lecteur PostgreSQL, via les objets Request/Response du handler. Aucun serveur HTTP public ni CDN n’est impliqué. Les en-têtes observés sont conservés ; la durée réelle d’un cache et le rendu navigateur n’ont pas été mesurés.

## Dépendances et temporalité

L’ancien scope joueur **est correctement conservé avant DELETE et marqué**. Dans le cas vide, cinq scopes directs sont en attente : édition, deux équipes, cible et témoin. Les versions match, édition, accueil, joueurs et équipes sont incrémentées ; la révision du match passe de 6 à 7 dans le scénario figé. `Worker.calculate` traite les cinq scopes puis cinq cohortes, retire l’agrégat cible et laisse la file entièrement vide.

Cependant, aucun scope traité par ce drain ne rafraîchit `agg.player_power_matches`, `agg.player_match_grades` ou `agg.player_grade_editions`. Ce n’est donc **pas une omission de l’ancien identifiant dans dirty_scopes** : c’est un décalage entre les dépendances immédiatement recalculées et celles du passage de modèles. La révision et `updated_at` sont modifiées, et `due_seasons` sait détecter une saison modifiée. Le code prévoit un délai depuis le dernier passage (1 h, ou 6 h sans match récent), mais l’essai n’a pas fait attendre l’ordonnanceur ni exécuté tous les modèles. Aucune durée maximale de péremption en production n’est affirmée ; une panne ou une attente de traitement peut la prolonger.

La séparation entre réponse vide authentique et collecte incomplète reste un contrat source à établir pour VI-21. Le test prouve le comportement actuel ; il ne justifie pas à lui seul de fusionner les réponses ou de conserver systématiquement toutes les anciennes valeurs, car une vraie correction peut retirer un joueur ou une statistique.

## Localisation du mécanisme dans la source gelée

Tous les chemins ci-dessous sont dans `runtime/`, vérifiés contre `source-receipt.json`.

- `backend/vega/worker.py:313` : `step` et claim réels ; `:848` : `details`, fetch, normalisation, hydrate puis `save_family` avec le lease.
- `backend/vega/pitchapi.py:324` : une enveloppe valide HTTP 2xx retourne ses données avec couverture `ok`.
- `backend/vega/normalize.py:827` : les lignes présentes sont normalisées ; le tableau vide n’ajoute aucune ligne et n’est pas rejeté.
- `backend/vega/store.py:728` : vérification du lease ; `:764` : anciens scopes avant suppression ; `:768` : DELETE de la famille ; `:787` : couverture, révision, dirty ; `:805` : ack dans la transaction.
- `backend/vega/store.py:491` : scopes et versions marqués ; `:809` : échec de parsing conservant les faits précédents.
- `backend/vega/calculator.py:395` et `:423` : agrégats, rollups et scopes ; `backend/vega/worker.py:382` : calcul ordinaire puis cohortes.
- `backend/vega/power.py:1486` : recalcul joueur ; `:1574` : remplacement des contributions ; `:1707` et `:1730` : écriture puis retrait des anciennes notes absentes du nouveau calcul.
- `backend/sql/107_vega_match_grades.sql` et définitions ultérieures gelées : tables de notes, jointures et vues ; le schéma est réellement migré jusqu’à `133_cohort_max_wait.sql` (133 migrations, option vector non requise pour ce chemin).
- `backend/api/src/routes/rankings.mjs:642` : lecture des notes indépendante de la présence de statistiques ; `backend/api/src/routes/match-details.mjs:67` : route des statistiques ; `backend/api/src/routes/matches.mjs:207` : résumé filtrant les joueurs effectivement joués.
- `backend/vega/worker.py:61` et `:93` : délais et sélection des saisons ; `backend/vega/models.py:780` : le passage de modèles appelle le recalcul joueur.

## Validation, environnement et limites

**6 scénarios, 28 états, 84 réponses de routes et 42 vérifications offline : PASS.** Onze fetches ont une preuve du vrai lease actif au moment du transport : neuf succès, un parsing invalide attendu, une perte de lease attendue. Les notes initiales et leur numérateur sont relus depuis les tables persistées ; aucune note n’a été fabriquée par INSERT.

Dernière exécution : PostgreSQL **18.6** aarch64, Python **3.14.6**, psycopg/psycopg-binary **3.3.9**, boto3 **1.44.4**, Node **26.4.0**, pg Node **8.23.1**. Les dépendances Python sont celles du requirements déployé. Il s’agit du code déployé extrait de Git et exécuté localement, **pas d’une affirmation que le conteneur ECS déployé a été exécuté ici**. Un premier passage complet Python 3.12.11/psycopg 3.2.12 a été conservé ; les 28 états ont les mêmes observations, valeurs calculées et corps de réponses après répétition avec les dépendances déployées (0 différence sémantique).

Les quatre premiers essais de harnais incomplets sont conservés dans `attempts/` : colonne source obligatoire dans le seed ; tâches de profil supplémentaires créées par hydrate ; besoin de réarmer explicitement la tâche failed du contrôle négatif ; run_after local/horloge PG. Ils ne sont pas présentés comme des passes. Le seul réarmement contrôlé est documenté dans `result.json`, sans prétendre à une relance automatique en production.

Le transport remplace uniquement le réseau par un statut/en-tête/corps contrôlé. La clé `pk_test_synthetic_counterread` est une chaîne de test sans accès fournisseur. Trente références fixes et la composition sont du setup synthétique, pas une vérification de leur ingestion. Les voies `summary`, autres familles, un scénario sans composition, les archives, les modèles quotidiens complets, la concurrence inter-processus et une panne réelle du calcul ne sont pas revendiqués. Le test de lease est une expiration contrôlée en base, pas une preuve de tous les cas de concurrence.

**Zéro écriture produit, Git, RDS ou Linear.** Tous les conteneurs PostgreSQL personnels ont été arrêtés et supprimés ; le reçu de la dernière exécution le confirme.

## Reproduction

Le paquet contient les scripts, les sources gelées (et leurs deux archives Git), les entrées synthétiques, la preuve antérieure minimale, les résultats et les essais incomplets. Installer seulement les dépendances locales ; Docker doit disposer du contexte `colima` et de l’image PG18 indiquée dans `execution-receipt.json`.

Depuis le dossier extrait :

```sh
python3.14 -m venv .venv
.venv/bin/python -m pip install -r requirements.txt
npm ci --prefix runtime/backend/api --ignore-scripts --no-audit --no-fund
docker --context colima pull pgvector/pgvector:pg18
python3 run.py
python3 verify-offline.py
```

Commande réellement exécutée sur le poste : `python3 run.py`, puis `python3 verify-offline.py`, dans ce dossier. `run.py` ne se connecte qu’à sa propre base `vega_v2_worker_counterread`, publiée sur `127.0.0.1` à un port aléatoire, et la détruit dans un `finally`. On peut fournir explicitement un autre Python : `python3 run.py /chemin/venv/bin/python`. Une mise à jour du tag PG18 doit être distinguée de l’image exacte du reçu (`sha256:c29f30688a9ad961691bdf0ec1650717cc132a5814619d80f80463d6e4c42e47`).

Attendu : code de sortie 0, `result.json.status=PASS`, `offline-verification.json.checks=42`, les mêmes valeurs sémantiques de `timeline.csv`. Les dates, durées, noms de conteneurs, tokens de lease, en-têtes de timing et ports locaux varient normalement.

Fichiers de lecture prioritaires : `timeline.csv` (28 points), `result.json` (6 scénarios), `states.json` (tables et réponses complètes), `transport-evidence.json` (11 leases), `PROTOCOL.md` (attendus avant exécution), `offline-verification.json` (42 assertions), `execution-receipt.json` (cleanup), `environment-comparison.json` (répétition), `SHA256SUMS` (intégrité du paquet).
