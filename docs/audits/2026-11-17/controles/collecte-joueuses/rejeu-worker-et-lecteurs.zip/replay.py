"""Controlled evidence replay, never a production collector. See PROTOCOL.md first."""
from pathlib import Path
from datetime import datetime, timezone, timedelta, date
import json,sys,hashlib,subprocess,copy,platform,importlib.metadata
from vega import store,jobs,power
from vega.worker import Worker
from vega.pitchapi import PitchClient

Q=Path(__file__).resolve().parent
DSN=sys.argv[1]
assert DSN.startswith('postgresql://postgres@127.0.0.1:') and DSN.endswith('/vega_v2_worker_counterread')
conn=store.connect_local(DSN)
store.migrate(conn)
s=store.Store(conn)
sid=s.season('2026/2027');s.season('2025/2026')
MID=900001;PID=900001;PEER=900002;SENTINEL=900003;HOME=900001;AWAY=900002;CS=900001

def binding(kind,key,ident):
    conn.execute('INSERT INTO core.provider_ids(entity_type,provider,provider_key,entity_id) VALUES(%s,\'pitchapi\',%s,%s)',(kind,key,ident))
conn.execute("INSERT INTO core.competitions(id,name,kind) VALUES(900001,'Synthetic women control league','league')")
conn.execute("INSERT INTO core.competition_seasons(id,competition_id,season_id,native_label,is_current) VALUES(900001,900001,2026,'2026/2027',true)")
binding('competition','l_syn001',CS)
for tid,key,name in [(HOME,'t_syn001','Synthetic home'),(AWAY,'t_syn002','Synthetic away')]:
    conn.execute('INSERT INTO core.teams(id,name,is_national) VALUES(%s,%s,false)',(tid,name));binding('team',key,tid)
    conn.execute('INSERT INTO core.team_seasons(team_id,competition_season_id) VALUES(%s,%s)',(tid,CS))
for pid,key,name in [(PID,'p_syn001','Synthetic target'),(PEER,'p_syn002','Synthetic fixed reference'),(SENTINEL,'p_syn003','Synthetic row sentinel')]:
    conn.execute('INSERT INTO core.players(id,name) VALUES(%s,%s)',(pid,name));binding('player',key,pid)

def fixture(mid,day,key=None):
    conn.execute("INSERT INTO core.matches(id,season_id,competition_season_id,match_date,kickoff_at,status,home_team_id,away_team_id,home_score,away_score,source) VALUES(%s,2026,%s,%s,%s,'finished',%s,%s,0,0,'pitchapi')",(mid,CS,day,datetime.combine(day,datetime.min.time(),timezone.utc),HOME,AWAY))
    conn.execute('INSERT INTO core.match_coverage(season_id,match_id) VALUES(2026,%s)',(mid,))
    if key:binding('match',key,mid)
fixture(MID,date(2026,10,1),'m_syn001')
conn.execute("INSERT INTO core.lineups(season_id,match_id,team_id,side,formation,confirmed) VALUES(2026,%s,%s,'home','4-3-3',true)",(MID,HOME))
conn.execute('INSERT INTO core.lineup_players(season_id,match_id,player_id,team_id,is_starter,position_id) VALUES(2026,%s,%s,%s,true,75)',(MID,PID,HOME))
conn.execute("UPDATE core.match_coverage SET lineups='ok' WHERE match_id=%s",(MID,))
# Immutable synthetic support for MIN_REFERENCE=30; only the target is modified by the scenarios.
for i in range(30):
    mid=910001+i;fixture(mid,date(2026,9,1)+timedelta(days=i))
    conn.execute('INSERT INTO core.player_match_stats(season_id,match_id,player_id,team_id,position_id,minutes_played,tackles,touches) VALUES(2026,%s,%s,%s,75,90,%s,50)',(mid,PEER,HOME,1+i%10))
    conn.execute("UPDATE core.match_coverage SET player_stats='ok' WHERE match_id=%s",(mid,))

def entry(pid,tid,**stats):
    return {'player':{'id':pid,'name':{'p_syn001':'Synthetic target','p_syn003':'Synthetic row sentinel'}[pid]},'team_id':tid,'stats':[{'stats':{k:{'key':k,'stat':{'type':'integer','value':v}} for k,v in stats.items()}}]}
full=[entry('p_syn001','t_syn001',position_id=75,minutes_played=75,tackles=12,touches=50,assists=1),entry('p_syn003','t_syn002',position_id=11,minutes_played=90)]
inputs={'complete':full,'partial_columns':[entry('p_syn001','t_syn001',position_id=75,minutes_played=75),full[1]],'partial_rows':[full[1]],'empty':[],'invalid':[{'player':{'id':'bad'},'team_id':'t_syn001','stats':[]}]}
(Q/'inputs.json').write_text(json.dumps({'synthetic':True,'target':{'match_id':MID,'player_id':PID,'minutes':75},'reference_matches':30,'fixed_reference_tackles':[1+i%10 for i in range(30)],'payload_data':inputs},indent=2))

transports=[];responses={};state={};queue_resets=[]
def transport(request,timeout):
    assert request.full_url=='https://api.pitchapi.dev/v1/matches/m_syn001/players'
    leased=rows("SELECT id,state::text,attempts,lease_token IS NOT NULL AS has_token,lease_until>clock_timestamp() AS unexpired FROM ops.fetch_jobs WHERE id=%s",(state['job'],))[0]
    assert leased['state']=='leased' and leased['has_token'] and leased['unexpired']
    if state.get('expire'):
        conn.execute("UPDATE ops.fetch_jobs SET lease_until=clock_timestamp()-interval '1 second' WHERE id=%s",(state['job'],))
    data=inputs[state['payload']]
    raw=json.dumps({'data':data},separators=(',',':')).encode()
    transports.append({'stage':state['stage'],'endpoint':request.full_url,'lease_at_fetch':leased,'controlled_http_status':200,'raw_sha256':hashlib.sha256(raw).hexdigest(),'data_canonical_sha256':hashlib.sha256(json.dumps(data,separators=(',',':')).encode()).hexdigest(),'expired_during_transport':state.get('expire',False)})
    return 200,{'Content-Type':'application/json','X-Request-ID':'synthetic-counterread'},raw
client=PitchClient('pk_test_synthetic_counterread',transport=transport,interval=0,retries=0)
worker=Worker(s,client,lanes=('details',),cohort_delay=0)

def rows(query,args=()):
    cur=conn.execute(query,args);return [dict(zip([x.name for x in cur.description],r)) for r in cur.fetchall()]

def snapshot(label):
    out={
      'label':label,'at':datetime.now(timezone.utc).isoformat(),
      'raw':rows('SELECT player_id,team_id,minutes_played,tackles,touches,assists FROM core.player_match_stats WHERE match_id=%s ORDER BY player_id',(MID,)),
      'coverage':rows('SELECT player_stats::text FROM core.match_coverage WHERE match_id=%s',(MID,)),
      'family':rows("SELECT status::text,encode(fingerprint,'hex') AS fingerprint,last_success_at,last_attempt_at FROM ops.family_state WHERE match_id=%s AND family='player_stats'",(MID,)),
      'match':rows('SELECT revision FROM core.matches WHERE id=%s',(MID,)),
      'dirty':rows('SELECT scope_kind::text,player_id,team_id,competition_season_id,cohort_id,revision FROM ops.dirty_scopes ORDER BY id'),
      'versions':rows('SELECT resource_kind::text,resource_id,version FROM ops.resource_versions ORDER BY resource_kind,resource_id'),
      'target_aggregate':rows('SELECT to_jsonb(p) AS row FROM agg.player_season_stats p WHERE player_id=%s',(PID,)),
      'target_power':rows('SELECT match_id,player_id,minutes,contribution,match_index,run_id FROM agg.player_power_matches WHERE player_id=%s',(PID,)),
      'target_grade':rows('SELECT match_id,player_id,minutes,z,first_z,run_id,graded_at,changed_at FROM agg.player_match_grades WHERE player_id=%s',(PID,)),
      'target_grade_edition':rows('SELECT * FROM agg.player_grade_editions WHERE player_id=%s',(PID,)),
      'jobs':rows('SELECT id,state::text,attempts,last_error_code,lease_token IS NOT NULL AS has_token FROM ops.fetch_jobs ORDER BY id'),
    }
    r=subprocess.run(['node',str(Q/'reader.mjs'),DSN],text=True,capture_output=True)
    (Q/'reader-stderr.log').open('a').write(label+'\n'+r.stderr)
    if r.returncode:raise RuntimeError('reader failed: '+r.stderr)
    out['readers']=json.loads(r.stdout)
    responses[label]=out
    (Q/'states.json').write_text(json.dumps(responses,indent=2,default=str))
    return out

def fetch(label,payload,expire=False):
    ident=jobs.enqueue(conn,'details','player_stats',entity_type='match',entity_id=MID)
    if ident is None:
        prior=rows("SELECT id,state::text FROM ops.fetch_jobs WHERE family='player_stats' AND entity_id=%s AND state='failed' ORDER BY id DESC LIMIT 1",(MID,))
        assert len(prior)==1, 'only a failed synthetic job may be rearmed'
        ident=prior[0]['id']
        conn.execute("UPDATE ops.fetch_jobs SET state='pending',run_after=clock_timestamp()-interval '1 second' WHERE id=%s AND state='failed'",(ident,))
        queue_resets.append({'stage':label,'job':ident,'reason':'controlled rearm after negative parsing test; no claim this retry is automatic'})
    state.update(job=ident,stage=label,payload=payload,expire=expire)
    assert worker.step()
    out=snapshot(label)
    job_state=next(r for r in out['jobs'] if r['id']==ident)
    expected='leased' if expire else 'failed' if payload=='invalid' else 'done'
    assert job_state['state']==expected,(label,job_state)
    return out

def calc(label):
    count=worker.calculate()
    out=snapshot(label);out['calculate_processed']=count
    assert not [r for r in out['dirty'] if r['scope_kind'] in ('player_season','team_season','competition_season')],label
    return out

def grades(label):
    count=power.refresh_players(conn,2026)
    out=snapshot(label);out['refresh_players_count']=count
    return out

def baseline(prefix):
    fetch(prefix+'_fetch','complete');calc(prefix+'_calculate');out=grades(prefix+'_graded')
    assert len(out['target_power'])==1 and out['target_power'][0]['contribution'] is not None
    assert len(out['target_grade'])==1 and out['target_grade'][0]['z'] is not None
    assert out['raw'][0]['minutes_played']==75 and out['raw'][0]['tackles']==12
    return out

report={'python':platform.python_version(),'dependencies':{p:importlib.metadata.version(p) for p in ('psycopg','psycopg-binary','boto3')},'postgres':rows('SELECT version() AS version')[0]['version'],'baseline_release':'8018e0836ca0f32e8b2eb51fc2847154abff7f13','nature':'controlled synthetic data, real production code and PostgreSQL; no production data writes','scenarios':{}}
try:
    for variant in ('partial_columns','partial_rows','empty'):
        baseline(variant+'_before')
        after=fetch(variant+'_fetch',variant)
        assert any(r['scope_kind']=='player_season' and r['player_id']==PID for r in after['dirty'])
        assert after['target_grade'] and after['target_power']
        after_calc=calc(variant+'_calculate')
        assert after_calc['target_grade'] and after_calc['target_power']
        after_grade=grades(variant+'_regraded')
        assert not after_grade['target_grade']
        if variant!='partial_columns':assert not after_grade['target_power']
        report['scenarios'][variant]={'ingestion_ack':True,'old_player_scope_marked':True,'old_grade_survives_ingestion':True,'old_grade_survives_ordinary_calculate':True,'grade_removed_after_refresh_players':True}
    before=snapshot('empty_before_repeat');again=fetch('empty_repeat','empty')
    assert before['match']==again['match'] and before['dirty']==again['dirty']
    report['scenarios']['identical_empty']={'ack':True,'revision_unchanged':True,'dirty_unchanged':True}
    before=baseline('invalid_before');failed=fetch('invalid_fetch','invalid')
    assert before['raw']==failed['raw'] and before['target_grade']==failed['target_grade']
    assert failed['family'][0]['status']=='error' and failed['coverage'][0]['player_stats']=='ok'
    report['scenarios']['invalid']={'preserves_raw':True,'preserves_grade':True,'job_failed':True,'family_error_core_coverage_ok':True}
    before=baseline('lease_before');expired=fetch('expired_lease_fetch','empty',expire=True)
    assert before['raw']==expired['raw'] and before['target_grade']==expired['target_grade'] and before['match']==expired['match']
    report['scenarios']['expired_lease']={'preserves_raw':True,'preserves_grade':True,'no_ack':True,'worker_results':{str(k):v for k,v in worker.results.items()}}
    report['controlled_queue_resets']=queue_resets
    report['fetch_log']=rows('SELECT family::text,http_status,error_code,request_id FROM ops.fetch_log ORDER BY fetched_at')
    report['schema_migrations']=rows("SELECT version,encode(checksum,'hex') checksum FROM ops.schema_migrations ORDER BY version")
    report['status']='PASS'
finally:
    (Q/'transport-evidence.json').write_text(json.dumps(transports,indent=2,default=str))
    (Q/'states.json').write_text(json.dumps(responses,indent=2,default=str))
    (Q/'result.json').write_text(json.dumps(report,indent=2,default=str))
    conn.close()
print(json.dumps({'status':report.get('status'),'scenarios':report['scenarios'],'snapshots':len(responses)},indent=2))
