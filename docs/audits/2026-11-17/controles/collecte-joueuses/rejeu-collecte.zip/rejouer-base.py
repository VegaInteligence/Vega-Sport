"""Run deployed ingestion and planning against the frozen edition on a fresh local PostgreSQL."""
from collections import Counter
from datetime import datetime, timedelta, timezone
import hashlib,json,sys,time
from pathlib import Path
import psycopg
from vega import store,planner
from vega.normalize import NormalizedFamily,normalize_family

here=Path(__file__).resolve().parent
inputs=json.loads((here/'entrees-rejeu.json').read_bytes())
dsn=sys.argv[1]
assert dsn.startswith('postgresql://postgres@127.0.0.1:') and dsn.endswith('/vega_v2_wpl_audit')
for n in range(100):
    try:db=store.connect_local(dsn);break
    except psycopg.OperationalError:time.sleep(.25)
else:raise RuntimeError('PostgreSQL ne répond pas')
now=datetime.fromisoformat(inputs['at'])
rows=inputs['games'];data=inputs['native'];edition=1002
engine=store.Store
with db:
    store.migrate(db)
    s=engine(db)
    with db.transaction():
        s.season('2026/2027')
        db.execute("INSERT INTO core.competitions(id,name) VALUES (197,%s)",("Women's Premier League",))
        db.execute("INSERT INTO core.competition_seasons(id,competition_id,season_id,native_label,is_current) VALUES(1002,197,2026,'2026/2027',true)")
        def binding(kind,pid,ident):
            db.execute("INSERT INTO core.provider_ids(entity_type,provider,provider_key,entity_id) VALUES(%s,'pitchapi',%s,%s)",(kind,pid,ident))
        binding('competition',inputs['provider_league'],197)
        teams={}
        for m in rows:
            for idx,(id_key,n_key) in enumerate((('home_team_id','home'),('away_team_id','away'))):
                k=m[id_key];pk=data[m['pitchapi']][idx+1]
                assert k not in teams or teams[k]==pk
                if k not in teams:
                    db.execute("INSERT INTO core.teams(id,name) VALUES(%s,%s)",(k,m[n_key]));binding('team',pk,k);teams[k]=pk
            db.execute("""INSERT INTO core.matches(id,competition_season_id,season_id,match_date,kickoff_at,status,home_team_id,away_team_id,home_score,away_score,source)
                    VALUES(%s,1002,2026,%s,%s,%s,%s,%s,%s,%s,'pitchapi')""",(m['id'],m['match_date'],m['kickoff_at'],m['status'],m['home_team_id'],m['away_team_id'],m['home_score'],m['away_score']))
            binding('match',m['pitchapi'],m['id'])
            db.execute("INSERT INTO core.match_coverage(season_id,match_id) VALUES(2026,%s)",(m['id'],))
        db.execute("INSERT INTO ops.collection_progress(source,competition_season_id,family,expected,done,last_success_at) VALUES('pitchapi',1002,'league_matches',1,1,%s)",(inputs['calendar_success'],))
    empty_states=[]
    def states():
        return list(db.execute("""SELECT m.id,m.revision, f.status::text,(SELECT count(*) FROM core.player_match_stats s WHERE s.match_id=m.id AND s.season_id=2026)
         FROM core.matches m JOIN ops.family_state f ON f.match_id=m.id AND f.family='player_stats' WHERE m.competition_season_id=1002 ORDER BY m.id"""))
    for turn in range(2):
        for m in rows:
            if m['status']=='finished':
                actual=inputs['players_empty_sha'][m['pitchapi']]
                assert actual==hashlib.sha256(b'[]').hexdigest()
                s.save_family(m['id'],'player_stats',normalize_family('players',[],match_id=m['pitchapi']))
        empty_states.append(states())
    assert empty_states[0]==empty_states[1] and len(empty_states[0])==8 and all(x[2:]==('ok',0) for x in empty_states[0])
    with db.transaction(force_rollback=True):
        jobs=planner.plan_backfill(db,now=now,first_season=2026,last_season=2026,competitions=[inputs['provider_league']])
        ordinary=db.execute("SELECT family::text,count(*) FROM ops.fetch_jobs GROUP BY 1 ORDER BY 1").fetchall()
        assert not any(x[0] in ('player_stats','league_matches') for x in ordinary)
        mid=next(m['id'] for m in rows if m['status']=='finished')
        db.execute("DELETE FROM ops.family_state WHERE match_id=%s AND family='player_stats'",(mid,))
        planner.plan_backfill(db,now=now,first_season=2026,last_season=2026,competitions=[inputs['provider_league']])
        requested=db.execute("SELECT entity_id FROM ops.fetch_jobs WHERE family='player_stats'").fetchall()
        assert requested==[(mid,)]
    with db.transaction(force_rollback=True):
        assert planner._overdue(db,now)==0
        db.execute("UPDATE core.matches SET status='not_started' WHERE id=47934")
        positive=planner._overdue(db,now)
        assert positive==1 and db.execute("SELECT entity_id FROM ops.fetch_jobs WHERE family='summary'").fetchall()==[(47934,)]
    with db.transaction(force_rollback=True):
        planner._weekly(db,now)
        initial_weekly=db.execute("SELECT competition_season_id FROM ops.fetch_jobs WHERE family='league_matches'").fetchall()
        assert initial_weekly==[]
        planner.observe(db,47949,kickoff_at=now+timedelta(days=2),status='not_started',now=now)
        planner._weekly(db,now)
        watched=db.execute("SELECT competition_season_id FROM ops.fetch_jobs WHERE family='league_matches'").fetchall()
        assert watched==[(edition,)]
    with db.transaction(force_rollback=True):
        m=next(x for x in rows if x['status']=='finished')
        # A single synthetic prior observation for a player with no real-world identity claim.
        db.execute("INSERT INTO core.players(id,name) VALUES(999001,'Contrôle Vega')")
        binding('player','p_zz0001',999001)
        previous=NormalizedFamily(rows={'core.player_match_stats':[{'player_id':'p_zz0001','team_id':teams[m['home_team_id']],'minutes_played':75}]})
        s.save_family(m['id'],'player_stats',previous)
        def represented():return db.execute("SELECT minutes_played FROM core.player_match_stats WHERE match_id=%s AND season_id=2026",(m['id'],)).fetchall()
        before=represented();s.save_family(m['id'],'player_stats',normalize_family('players',[],match_id=m['pitchapi']));after=represented()
        assert before==[(75,)] and after==[] and db.execute("SELECT status::text FROM ops.family_state WHERE match_id=%s AND family='player_stats'",(m['id'],)).fetchone()==('ok',)
    result={'postgres':db.execute('SHOW server_version').fetchone()[0],'source_statuses_56':dict(Counter(m['status'] for m in rows)),'observed_empty_sha':hashlib.sha256(b'[]').hexdigest(),
            'empty_first_and_second':empty_states,'normal_backfill_jobs':ordinary,'positive_control_missing_family_requested':requested,
            'overdue_actual_postponed_selected':0,'overdue_counterexample_selected':positive,
            'weekly_without_watch':initial_weekly,'weekly_with_one_in_window':watched,
            'synthetic_prior_then_real_empty':{'fixture':m['id'],'prior_minutes':75,'rows_after':len(after),'collector_status_after':'ok'},'production_writes':0}
    print(json.dumps(result,ensure_ascii=False,indent=2))
