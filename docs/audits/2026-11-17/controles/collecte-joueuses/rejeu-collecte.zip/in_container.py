from datetime import datetime,timezone
import json,os,hashlib
from collections import Counter
from vega.pitchapi import PitchClient,PitchError
from vega.normalize import normalize_family,NormalizationError
specs=CONFIGURATION_PLACEHOLDER
attempts=[]
client=PitchClient(os.environ['PITCHAPI_API_KEY'],interval=1.2,timeout=20,retries=0,on_attempt=lambda e:attempts.append({'http':e['status'],'code':e.get('error_code')}))
data=[]
for family,endpoint,params,key in specs:
    start=len(attempts);rec={'at':datetime.now(timezone.utc).isoformat(),'family':family,'endpoint':endpoint,'params':params,'target':key}
    try:
        response=client.fetch(endpoint,params)
        rec['coverage']=response.coverage
        raw=response.data;rec['empty']=raw is None
        if raw is not None:
            rec['sha256']=hashlib.sha256(json.dumps(raw,sort_keys=True,separators=(',',':'),ensure_ascii=False).encode()).hexdigest()
            rec['input_shape']={'type':type(raw).__name__,'count':len(raw) if isinstance(raw,(dict,list)) else None}
            if family=='league_matches':
                rec['identity']={k:raw.get('league',{}).get(k) for k in ('id','name','season')}
            out=normalize_family(family,raw,match_id=key if family!='league_matches' else None)
            if family in ('league_matches','summary'):
                cols=('id','home_team_id','away_team_id','match_date','kickoff_at','status','home_score','away_score')
                rec['matches']=[[r.get(c) for c in cols] for r in out.rows.get('core.matches',[])]
            elif family=='players':
                rows=out.rows.get('core.player_match_stats',[])
                rec['stats_count']=len(rows);rec['minutes_known']=sum(r.get('minutes_played') is not None for r in rows)
                rec['positive_minutes']=sum((r.get('minutes_played') or 0)>0 for r in rows)
                rec['players_with_team']=sum(bool(r.get('player_id') and r.get('team_id')) for r in rows)
                rec['non_null_fields']=dict(Counter(k for r in rows for k,v in r.items() if v is not None))
            else:
                rows=out.rows.get('core.lineup_players',[]);rec['lineup_listed']=len(rows)
                rec['starters']=sum(r.get('is_starter') is True for r in rows)
    except (PitchError,NormalizationError) as exc:
        rec['failure']=getattr(exc,'code',type(exc).__name__)
    rec['transport']=attempts[start:];data.append(rec)
    if any(x['http'] in (401,403,429) for x in attempts[start:]):break
print('AUDIT_VI21 '+json.dumps({'provider_requests':len(attempts),'observations':data},default=str,separators=(',',':')),flush=True)
