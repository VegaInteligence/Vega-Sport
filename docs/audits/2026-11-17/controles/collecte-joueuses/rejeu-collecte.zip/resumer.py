"""Verify the current provider, operational state and two independent PostgreSQL counts."""
import csv,json,hashlib,sys,zlib
from collections import Counter
from pathlib import Path
here=Path(__file__).resolve().parent
def read(name):
    b=(here/name).read_bytes()
    return json.loads(zlib.decompress(b) if name.endswith('zlib') else b)
def save(name, data):
    (here/name).write_text(json.dumps(data,ensure_ascii=False,indent=2)+'\n')
def table(name, src):
    with (here/name).open('w',newline='') as out:
        w=csv.writer(out,lineterminator='\n');w.writerow(src['columns']);w.writerows(src['rows'])
v=read('suites/rds/inputs.json.zlib');impact=read('impact/rds/inputs.json.zlib')
ledger=v['etats-joueurs-par-edition'];expected=impact['impact']
data=[dict(zip(ledger['columns'],r)) for r in ledger['rows']]
rows=[dict(zip(expected['columns'],r)) for r in expected['rows']]
assert len(data)==len({r['edition_id'] for r in data})==304 and len(rows)==len({r['id'] for r in rows})==487
assert all(r['family_ok']==r['ok_no_player_rows']+r['ok_rows_without_positive_minutes']+r['ok_with_positive_minutes']==r['finished'] for r in data)
for r in data:
    samples=[v for v in rows if v['edition']==r['edition_id']]
    assert len(samples)==r['no_positive_minutes'] and sum(not x['stats_present'] for x in samples)==r['ok_no_player_rows']
table('collecte-par-edition.csv',ledger);table('487-rencontres.csv',expected)
totals={k:sum(v[k] for v in data) for k in ledger['columns'][3:]}
pop={}
for test,key in ((False,'sans_ligne'),(True,'sans_minute_positive')):
    x=[r for r in rows if r['stats_present']==test]
    pop[key]={'matchs':len(x),'matchs_avec_titulaires':sum(bool(r['starter_rows']) for r in x),'editions':len({r['edition'] for r in x}),**{k:sum(r[k] for r in x) for k in expected['columns'][5:]}}
first=read('observed.json')['observations'];extra=read('sommaires-restants/observed.json')['observations']
assert len(first)==22 and len(extra)==18 and all(r['transport']==[{'http':200,'code':None}] and 'failure' not in r for r in first+extra)
targets={(r['endpoint'],tuple(sorted(r['params'].items()))) for r in first+extra};assert len(targets)==40
idx=read('rds/inputs.json.zlib')
current=next(r for r in first if r['family']=='league_matches' and r['target']==1002)
db_matches={r[1]:r for r in idx['queries']['summary_attempts']['rows']};games={r[0]:r for r in current['matches']}
assert games.keys()==db_matches.keys() and all((g[3],g[5],g[6],g[7])==(db_matches[k][2],db_matches[k][4],db_matches[k][5],db_matches[k][6]) for k,g in games.items())
postponed={k for k,g in games.items() if g[5]=='postponed'}
p1=next(r for r in first if r['family']=='league_matches' and r['target']==1000)
p2=next(r for r in first if r['family']=='league_matches' and r['target']==1001)
details={r['target']:r['matches'][0] for r in first+extra if r['family']=='summary'}
assert postponed<=details.keys() and len(details)==21 and all(details[k]==games[k] for k in details)
assert all(r['input_shape']=={'type':'list','count':0} and r['stats_count']==0 for r in first if r['family']=='players')
assert all(r['lineup_listed']==0 for r in first if r['family']=='lineups')
assert all(r[-1]==r[-2]==0 and r[2]=='absent' for r in v['veilles']['rows']) and sum(r[3] for r in v['veilles']['rows'])==56
replay=read('rejeu-complet.json')
assert replay['weekly_without_watch']==[] and replay['weekly_with_one_in_window']==[[1002]] and replay['synthetic_prior_then_real_empty']['rows_after']==0
result={'operations_rds':idx['snapshot'], 'mesures_par_edition_rds':v['snapshot'],'contre_comptage_rds':impact['snapshot'],'edition_native':1002,'competition_native':current['identity'],
        'classes_natives':dict(Counter(g[5] for g in games.values())),'anciens_calendriers':[[p['params']['season'],len(p['matches']),sum(v[5]=='finished' for v in p['matches'])] for p in (p1,p2)],
        'lectures_pitchapi_200_distinctes':len(targets),'resumes_reportes_sans_score_qui_concordent':len(postponed),
        'retour_inverse_encore_futur':details['m_2N1YBP'],'listes_joueurs_vides':8,'compositions_vides':8,'veilles':v['veilles'],
        'editions':len(data),'totaux_nat_if':totals,'sous_populations':pop}
save('resultats.json',result)
print(len(targets),'requêtes distinctes',len(data),'éditions',len(rows),'matchs',totals['finished'],'terminés')
