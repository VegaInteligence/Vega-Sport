WITH per_fixture AS MATERIALIZED (
  SELECT cs.id AS edition_id, cs.competition_id, cs.season_id, m.id AS match_id, m.status AS match_status,
         m.kickoff_at < statement_timestamp() AS elapsed, f.status::text AS stats_family,
         (CASE WHEN m.status='finished' THEN EXISTS (SELECT 1 FROM core.player_match_stats s WHERE s.season_id=m.season_id AND s.match_id=m.id) END) AS any_stats,
         (CASE WHEN m.status='finished' THEN EXISTS (SELECT 1 FROM core.player_match_stats s WHERE s.season_id=m.season_id AND s.match_id=m.id AND s.minutes_played>0) END) AS positive_minutes
  FROM core.competition_seasons cs JOIN core.matches m ON m.competition_season_id=cs.id AND m.season_id=cs.season_id
  LEFT JOIN ops.family_state f ON f.match_id=m.id AND f.family='player_stats'
  WHERE cs.archive_key IS NULL AND cs.cup_key IS NULL AND m.source='pitchapi'
)
SELECT edition_id, competition_id, season_id, count(*) AS matches, count(*) FILTER(WHERE match_status='finished') AS finished,
       count(*) FILTER(WHERE match_status='postponed' AND elapsed) AS elapsed_postponed,
       count(*) FILTER(WHERE match_status='finished' AND stats_family='ok') AS family_ok,
       count(*) FILTER(WHERE match_status='finished' AND stats_family='ok' AND NOT any_stats) AS ok_no_player_rows,
       count(*) FILTER(WHERE match_status='finished' AND stats_family='ok' AND any_stats AND NOT positive_minutes) AS ok_rows_without_positive_minutes,
       count(*) FILTER(WHERE match_status='finished' AND stats_family='ok' AND positive_minutes) AS ok_with_positive_minutes,
       count(*) FILTER(WHERE match_status='finished' AND stats_family IS DISTINCT FROM 'ok' AND positive_minutes) AS other_state_with_positive_minutes,
       count(*) FILTER(WHERE match_status='finished' AND NOT positive_minutes) AS no_positive_minutes
FROM per_fixture GROUP BY edition_id,competition_id,season_id ORDER BY competition_id,season_id,edition_id
