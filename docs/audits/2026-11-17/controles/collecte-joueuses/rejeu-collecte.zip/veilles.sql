SELECT m.status::text AS status, m.kickoff_at < statement_timestamp() AS past, coalesce(w.state::text,'absent') AS watch,
       count(*) AS matches, min(w.kickoff_at) AS first_watch_kickoff, max(w.kickoff_at) AS last_watch_kickoff,
       count(*) FILTER(WHERE w.kickoff_at>statement_timestamp()-interval '30 days' AND w.kickoff_at<statement_timestamp()+interval '30 days') AS matches_matching_weekly_scope,
       count(*) FILTER(WHERE m.status='not_started' AND m.kickoff_at<statement_timestamp()-interval '6 hours' AND m.kickoff_at>=statement_timestamp()-interval '365 days' AND (w.match_id IS NULL OR w.state='stopped')) AS matches_matching_overdue_scope
FROM core.matches m LEFT JOIN ops.match_watch w ON w.match_id=m.id
WHERE m.competition_season_id=1002 GROUP BY 1,2,3 ORDER BY 1,2,3
