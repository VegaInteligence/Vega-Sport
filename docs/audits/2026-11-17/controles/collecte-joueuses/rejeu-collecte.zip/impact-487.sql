WITH uncovered AS MATERIALIZED (
  SELECT cs.id AS edition,cs.competition_id, m.season_id,m.id,
    EXISTS(SELECT 1 FROM core.player_match_stats z WHERE z.season_id=m.season_id AND z.match_id=m.id) AS stats_present
  FROM core.competition_seasons cs JOIN core.matches m ON m.competition_season_id=cs.id AND m.season_id=cs.season_id
  JOIN ops.family_state f ON f.match_id=m.id AND f.family='player_stats' AND f.status='ok'
  WHERE cs.archive_key IS NULL AND cs.cup_key IS NULL AND m.source='pitchapi' AND m.status='finished'
    AND NOT EXISTS (SELECT 1 FROM core.player_match_stats s WHERE s.season_id=m.season_id AND s.match_id=m.id AND s.minutes_played>0)
)
SELECT u.edition,u.competition_id,u.season_id,u.id,u.stats_present,
   (SELECT count(*) FROM core.lineup_players s WHERE s.season_id=u.season_id AND s.match_id=u.id AND s.is_starter IS TRUE) AS starter_rows,
   (SELECT count(*) FROM core.player_match_stats s WHERE s.season_id=u.season_id AND s.match_id=u.id) AS stats_rows,
   (SELECT count(*) FROM agg.player_match_grades s WHERE s.season_id=u.season_id AND s.match_id=u.id) AS player_grades,
   (SELECT count(*) FROM agg.player_power_matches s WHERE s.match_id=u.id) AS intermediate_rows,
   (SELECT count(*) FROM agg.team_elo t WHERE t.season_id=u.season_id AND t.match_id=u.id) AS team_elo_sides
FROM uncovered u ORDER BY u.edition,u.id
