def collect(db):
    queries={
        'editions':"""SELECT cs.id, cs.season_id, cs.native_label, cs.is_current, cs.start_date, cs.end_date,
            (SELECT provider_key FROM core.provider_ids p WHERE p.entity_type='competition' AND p.entity_id=cs.competition_id AND p.provider='pitchapi' AND p.is_current LIMIT 1) AS provider_league
            FROM core.competition_seasons cs WHERE cs.id IN(1000,1001,1002) ORDER BY cs.id""",
        'progress':"""SELECT competition_season_id, family::text, expected, done, empty, failed, last_success_at, updated_at FROM ops.collection_progress WHERE source='pitchapi' AND competition_season_id IN(1000,1001,1002) ORDER BY competition_season_id,family""",
        'jobs':"""SELECT id,lane::text,family::text,competition_season_id,state::text,last_http,last_error_code,run_after,updated_at FROM ops.fetch_jobs WHERE competition_season_id IN(1000,1001,1002) AND family='league_matches' ORDER BY competition_season_id,updated_at""",
        'recent_calendar_requests':"""SELECT fetched_at,family::text,competition_season_id,entity_type::text,entity_id,http_status,error_code,duration_ms FROM ops.fetch_log WHERE fetched_at >= now()-interval '30 days' AND (competition_season_id IN (1000,1001,1002) OR (entity_type='competition' AND entity_id=197)) ORDER BY fetched_at""",
        'family_states':"""SELECT m.status::text, (m.kickoff_at < now()) AS past, f.family::text,f.status::text, count(*) AS records,min(f.last_attempt_at),max(f.last_attempt_at),max(f.last_success_at)
            FROM core.matches m LEFT JOIN ops.family_state f ON f.match_id=m.id WHERE m.competition_season_id=1002 GROUP BY 1,2,3,4 ORDER BY 1,2,3,4""",
        'summary_attempts':"""SELECT m.id,p.provider_key,m.match_date,m.kickoff_at,m.status::text,m.home_score,m.away_score,m.updated_at,j.state::text AS job_state,j.last_http,j.last_error_code,j.run_after,j.updated_at AS job_update
            FROM core.matches m LEFT JOIN core.provider_ids p ON p.provider='pitchapi' AND p.entity_type='match' AND p.entity_id=m.id AND p.is_current LEFT JOIN ops.fetch_jobs j ON j.entity_type='match' AND j.entity_id=m.id AND j.family='summary'
            WHERE m.competition_season_id=1002 ORDER BY m.match_date,m.id,j.updated_at""",
        'public_log_detail':"""SELECT m.status::text,l.family::text,l.http_status,l.error_code,count(*),count(DISTINCT m.id),min(l.fetched_at),max(l.fetched_at)
            FROM core.matches m JOIN ops.fetch_log l ON l.entity_type='match' AND l.entity_id=m.id AND l.fetched_at>=now()-interval '30 days'
            WHERE m.competition_season_id=1002 GROUP BY 1,2,3,4 ORDER BY 1,2,3,4""",
    }
    with db.transaction():
        db.execute('SET TRANSACTION ISOLATION LEVEL REPEATABLE READ, READ ONLY')
        out={'snapshot':db.execute("SELECT current_database(),statement_timestamp(),pg_current_snapshot()::text,current_setting('transaction_read_only')").fetchone(),'queries':{}}
        for name,query in queries.items():
            cur=db.execute(query)
            out['queries'][name]={'sql':query,'columns':[c.name for c in cur.description],'rows':cur.fetchall()}
        return out
