"""Start a disposable PG18 instance, load the deployed commit and run the bounded reproduction."""
import argparse,hashlib,io,json,os,subprocess,sys,tarfile,tempfile,uuid
from pathlib import Path
here=Path(__file__).resolve().parent
a=argparse.ArgumentParser()
a.add_argument('repo',type=Path)
a.add_argument('output',type=Path)
args=a.parse_args()
cmd=['docker','--context','colima']
release='8018e0836ca0f32e8b2eb51fc2847154abff7f13'
def run(parts,**kw):return subprocess.check_output(parts,**kw)
image=run([*cmd,'image','inspect','pgvector/pgvector:pg18','--format','{{.Id}}'],text=True).strip()
name='wpl-audit-'+uuid.uuid4().hex[:10]
with tempfile.TemporaryDirectory() as tmp:
    raw=run(['git','-C',str(args.repo),'archive',release,'backend/sql','backend/vega'])
    with tarfile.open(fileobj=io.BytesIO(raw)) as t:t.extractall(tmp,filter='data')
    run([*cmd,'run','--rm','-d','--name',name,'-p','127.0.0.1::5432','-e','POSTGRES_HOST_AUTH_METHOD=trust','-e','POSTGRES_DB=vega_v2_wpl_audit',image])
    try:
        host=run([*cmd,'port',name,'5432/tcp'],text=True).strip()
        assert host.startswith('127.0.0.1:') and '\n' not in host
        output=run([sys.executable,str(here/'rejouer-base.py'),'postgresql://postgres@'+host+'/vega_v2_wpl_audit'],env={**os.environ,'PYTHONPATH':tmp+'/backend','PYTHONDONTWRITEBYTECODE':'1'})
        record=json.loads(output);record['release']=release;record['docker_image']=image;record['source_sha']=hashlib.sha256(raw).hexdigest()
        args.output.write_text(json.dumps(record,ensure_ascii=False,indent=2)+'\n')
        print('Rejeu vérifié',record['postgres'],record['source_statuses_56'])
    finally:
        subprocess.run([*cmd,'stop',name],check=True,stdout=subprocess.DEVNULL)
