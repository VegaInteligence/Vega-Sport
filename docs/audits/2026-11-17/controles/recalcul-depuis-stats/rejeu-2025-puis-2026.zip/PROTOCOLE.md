# Diagnostic ascendant 2025 → 2026, avant exécution

## Question et frontière

Mesurer uniquement les notes ponctuelles 2026 qui résulteraient d'une publication préalable des nouvelles références 2025. La contribution C de chaque participation 2026 est recalculée une seule fois avec les entrées actuelles, puis conservée identique dans tous les scénarios. Ne pas attribuer à ce changement de référence des changements d'Elo, de statistiques ou de rôle. Ne pas prétendre recalculer la chaîne historique complète, les classements annuels, leur prior de saison précédente ou les six années antérieures : la référence ponctuelle 2025 achevée se construit directement sur ses propres contributions.

## Collecte autorisée et mémoire

1. Exiger le fichier terminé `../elo-counterfactual/rds/inputs.json.zlib` et son reçu valide avant tout lancement. Épingler son SHA et ceux des anciens résultats `../2025/rds` et `../2026/rds`.
2. Réutiliser le lanceur de diagnostic existant, une seule tâche séquentielle, image déployée `8018e0836ca0f32e8b2eb51fc2847154abff7f13`. Le probe vérifie le module exact `power.py` : SHA-256 `75d3b2a829b585d8dbadb60d1fb2a6b4233e7f74d220a0f76bab0ebb6fdb93ff`. Aucun changement de service, de secret, de branche ou de générateur existant.
3. Ouvrir **une seule transaction REPEATABLE READ READ ONLY** et récupérer, avant le moindre ajustement lourd : les entrées normalisées du SELECT déployé pour 2025 et 2026, la référence 2025 effectivement publiée, les notes 2026 et leurs champs d'identité, les runs publiés pertinents, les types SQL effectifs des tables de référence et de `z`. Lire les lignes par curseurs serveur, les écrire en fichiers temporaires internes éphémères (spool pickle), puis terminer la transaction.
4. Pour chaque année : compte, ordre de colonnes et empreinte multiensemble reproduisant exactement l'ancien probe. Comparer aux empreintes historiques ; une différence est rapportée comme dérive du snapshot, sans la masquer. La transaction commune nouvelle suffit à la comparaison interne, même si les anciennes empreintes diffèrent.
5. Charger une seule année à la fois après fermeture de la transaction. Libérer les dictionnaires dès leur contribution calculée. Conserver seulement les références numériques 2025 et les entrées condensées nécessaires au contraste 2026. Mesurer durée, taille des spools et pic RSS du processus. Les spools sont détruits à la fin ; aucune table temporaire RDS ni publication.

## Calcul et stockage

6. Appliquer les fonctions déployées `restore_zeros`, `assign_roles`, `references`, `match_contribution`, puis `grade_references` à 2025. Les défauts connus de ces fonctions sont conservés : ceci mesure le comportement déployé, sans le corriger.
7. Contrôler le schéma vivant : les moyennes, dispersions et quantiles doivent être `real`. Simuler **le texte produit par le dumper psycopg réellement utilisé dans COPY, puis sa lecture float4**. Valider l'équivalence du convertisseur sur des valeurs ordinaires et des frontières binary32 par des casts SQL `text::real` pendant la transaction de lecture. Garder la référence en double avant stockage et celle après round-trip ; ne pas arrondir seulement les quantiles ni oublier les dispersions.
8. Comparer la référence 2025 recalculée puis stockable à celle publiée : clés de rôle/compétition, effectifs, moyennes, dispersions et les 2 001 quantiles de chaque rôle ; différences binary32, écarts absolus et relatifs, maxima et monotonie. Conserver les deux références complètes et les valeurs avant stockage.
9. Recalculer C pour 2026 avec les fonctions déployées et évaluer trois références sur ces **mêmes C** : A = 2025 publiée, B = 2025 recalculée avec round-trip de stockage, U = 2025 recalculée non arrondie (contrôle de l'effet de stockage uniquement).
10. Mesurer B−A (effet isolé de propagation), A−notes publiées et B−notes publiées, ainsi que U−B. Compter les écarts strictement **>0,01 ; >0,1 ; >1 point**, les valeurs NULL, clés/identités manquantes, maxima, quantiles d'écart et entiers modifiés. Fournir les résultats sur les indices calculés et sur leurs candidats binary32. Ne pas annoncer le nombre exact d'UPDATE de production : le writer conserve certaines notes dans la tolérance d'indice 1e-4 et n'est pas exécuté.

## Contrôle qualité et arrêt

- Une clé brute doublonnée, un schéma non attendu, une référence 2025 absente, un échec du contrôle de cast, des quantiles non monotones ou un résultat non fini interrompent le diagnostic avec sa preuve d'échec.
- Réconcilier admises = sans rôle + attribuées ; attribuées = C connues + inconnues ; mêmes contributions/identités pour A/B/U. Distinguer les notes calculables sans publication et les notes persistées hors sélection admise.
- Ne jamais recalculer ni lire une entrée métier après fermeture de la transaction. Tous les calculs se font sur les spools ou objets déjà récupérés.
- Préserver le code exact, l'image effective, le reçu de tâche, les empreintes des entrées, les références complètes et les lignes condensées 2026. Le rejeu local indépendant refait les transformations `match_index`/`score_of` et leurs compteurs depuis ces valeurs ; il ne sera pas présenté comme un rejeu de l'ajustement brut 2025 si les statistiques complètes n'ont pas été exportées.
- Un seul lancement de collecte ; pas de second essai automatique en cas d'échec. Le compte rendu sépare validation du diagnostic et convergence des données publiées.

## Précision ajoutée pendant le diagnostic unique

Le contrôle local montre une étape supplémentaire nécessaire : un SELECT ordinaire de `real` est chargé par psycopg depuis le décimal court émis par PostgreSQL. Par exemple, `0.1::real` est relu en Python comme `0.1`, alors que `0.1::real::float8` expose `0.10000000149011612`. La seule valeur binary32 promue en double ne reproduit donc pas tout le chemin du lecteur.

Le probe déjà lancé conserve les références doubles et binary32 intégrales. Ses contrastes utilisant directement cette dernière représentation sont **préliminaires**. Après réception, effectuer exclusivement sur PostgreSQL local et en lecture seule le chemin `texte COPY psycopg → text::real → lecture psycopg ordinaire`, pour chaque cellule numérique de la nouvelle référence. Contrôler la valeur binary32 par rapport au probe et l'idempotence du même aller-retour sur toute la référence publiée. Conserver les cellules et la version/configuration PostgreSQL locale ; recalculer ensuite les contrastes finaux avec les références réellement relues. Aucune nouvelle tâche RDS ni modification du probe figé. Le contrôle local et les limites de cette relecture seront explicités dans le rapport final.
