"""Verify the condensed evidence in a disposable local directory; no network or DB."""
from pathlib import Path
from datetime import datetime,timezone
import hashlib,json,shutil,subprocess,sys,tempfile,time
Q=Path(__file__).resolve().parent
FILES=['replay.py','power-8018e0836c.py','probe.py','prior-inputs.json','rds/receipt.json','rds/inputs.json.zlib','storage-roundtrip-receipt.json','reference-2025-after-copy-and-read.json']
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
expected=json.loads((Q/'replay-receipt.json').read_text());start=datetime.now(timezone.utc).isoformat();tick=time.monotonic()
with tempfile.TemporaryDirectory(prefix='offline-replay-',dir=Q)as name:
    target=Path(name)
    for rel in FILES:
        dest=target/rel;dest.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(Q/rel,dest)
    argv=[sys.executable,'-B',str(target/'replay.py')]
    proc=subprocess.run(argv,cwd=target,capture_output=True,text=True)
    (Q/'portable-replay.log').write_text(proc.stdout+proc.stderr)
    assert proc.returncode==0,proc.stderr
    actual=json.loads((target/'replay-receipt.json').read_text())
    normalized=lambda x:{k:v for k,v in x.items()if k not in ['seconds','python']}
    assert normalized(actual)==normalized(expected),'Independent condensed replay differs from preserved result'
    csvs=['reference-role-changes.csv','reference-competition-spread-changes.csv']
    assert all(sha(target/n)==sha(Q/n)for n in csvs)
    receipt={'status':'passed','started':start,'ended':datetime.now(timezone.utc).isoformat(),'seconds':round(time.monotonic()-tick,3),'argv':argv,'cwd':str(target),'exit_code':proc.returncode,'python':sys.version,'input_hashes':{n:sha(Q/n)for n in FILES},'all_substantive_receipt_fields_identical':True,'both_reference_csvs_byte_identical':True,'rows_replayed':actual['population']['assigned'],'network_used':False,'database_used':False,'ephemeral_directory_removed_on_exit':True}
(Q/'portable-replay-receipt.json').write_text(json.dumps(receipt,indent=2)+'\n')
print(json.dumps(receipt,indent=2))
