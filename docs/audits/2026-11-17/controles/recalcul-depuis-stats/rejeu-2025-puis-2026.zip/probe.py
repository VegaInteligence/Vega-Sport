"""One read-only snapshot, then a sequential 2025 reference / fixed-C 2026 diagnostic."""
from collections import Counter,defaultdict
import ctypes,gc,hashlib,heapq,inspect,json,math,pickle,resource,struct,tempfile,time
from pathlib import Path
import psycopg
from psycopg.adapt import Transformer,PyFormat
from vega import power as p

SOURCE='75d3b2a829b585d8dbadb60d1fb2a6b4233e7f74d220a0f76bab0ebb6fdb93ff'
def sha(b):return hashlib.sha256(b).hexdigest()
def encoded(v):return json.dumps(v,ensure_ascii=True,separators=(',',':'),allow_nan=False).encode()
def refs_out(r):
    return {'roles':[[k,*v]for k,v in sorted(r['roles'].items())],'spreads':[[*k,*v]for k,v in sorted(r['spreads'].items())],'quantiles':dict(sorted(r['quantiles'].items()))}
def references_from(r):
    return {'roles':{x[0]:tuple(x[1:])for x in r['roles']},'spreads':{tuple(x[:2]):tuple(x[2:])for x in r['spreads']},'quantiles':r['quantiles']}
def f32(x):return None if x is None else struct.unpack('!f',struct.pack('!f',x))[0]
def real_converter():
    lib=ctypes.CDLL(None);fun=lib.strtof;fun.argtypes=[ctypes.c_char_p,ctypes.POINTER(ctypes.c_char_p)];fun.restype=ctypes.c_float
    transform=Transformer()
    def text(x):return bytes(transform.get_dumper(float(x),PyFormat.TEXT).dump(float(x)))
    def real(x):
        end=ctypes.c_char_p();v=float(fun(text(x),ctypes.byref(end)))
        assert end.value==b''and math.isfinite(v)
        return v
    return real,text
def round_refs(r,real):
    return {'roles':{k:(n,real(m),real(s))for k,(n,m,s)in r['roles'].items()},'spreads':{k:(n,real(s))for k,(n,s)in r['spreads'].items()},'quantiles':{k:[real(v)for v in q]for k,q in r['quantiles'].items()}}
def validate_refs(r):
    for role,(n,m,s)in r['roles'].items():
        assert n>1 and math.isfinite(m)and math.isfinite(s)and s>0
        q=r['quantiles'][role];assert len(q)==p.GRADE_QUANTILES+1 and all(math.isfinite(v)for v in q)and q==sorted(q)
    assert all(n>0 and math.isfinite(s)and s>0 for n,s in r['spreads'].values())
def ref_diff(a,b):
    out={}
    for kind in ['roles','spreads','quantiles']:
        x,y=a[kind],b[kind];common=x.keys()&y.keys();diff=[];counts=Counter()
        for key in common:
            xx,yy=x[key],y[key]
            if kind!='quantiles':counts['different_counts']+=int(xx[0]!=yy[0]);xx,yy=xx[1:],yy[1:]
            assert len(xx)==len(yy)
            for u,v in zip(xx,yy):
                counts['values']+=1;counts['different_binary32']+=int(f32(u)!=f32(v));counts['different_double']+=int(u!=v);diff.append(abs(u-v))
        out[kind]={'common_keys':len(common),'only_left':[str(k)for k in sorted(x.keys()-y.keys())],'only_right':[str(k)for k in sorted(y.keys()-x.keys())],'counts':dict(counts),'max_absolute':max(diff,default=0.0),'mean_absolute':sum(diff)/len(diff)if diff else None}
    return out

def collect(db):
    started=time.monotonic();checkpoints=[]
    def log(stage):
        rec={'stage':stage,'seconds':round(time.monotonic()-started,3),'rss_peak_kib':resource.getrusage(resource.RUSAGE_SELF).ru_maxrss};checkpoints.append(rec);print('CHECKPOINT',json.dumps(rec),flush=True)
    module=inspect.getsource(p);assert sha(module.encode())==SOURCE
    real,text=real_converter();raw_meta={};spools={};real_schema={}
    with tempfile.TemporaryDirectory(prefix='vega-ascending-reference-')as temp:
        temp=Path(temp)
        with db.transaction():
            db.execute('SET TRANSACTION ISOLATION LEVEL REPEATABLE READ READ ONLY')
            db.execute("SET LOCAL statement_timeout='300s'")
            meta=db.execute("SELECT current_database(),transaction_timestamp()::text,pg_current_snapshot()::text,current_setting('transaction_read_only'),current_setting('transaction_isolation'),current_date").fetchone()
            assert meta[0]=='vega_v2'and meta[3:5]==('on','repeatable read')
            assert p.grade_reference_year(2025,meta[-1])==2025 and p.grade_reference_year(2026,meta[-1])==2025
            columns=db.execute("""SELECT c.relname,a.attname,format_type(a.atttypid,a.atttypmod) FROM pg_attribute a JOIN pg_class c ON c.oid=a.attrelid JOIN pg_namespace n ON n.oid=c.relnamespace WHERE n.nspname='agg' AND c.relname IN ('match_grade_roles','match_grade_spreads','match_grade_quantiles','player_match_grades') AND a.attnum>0 AND NOT a.attisdropped ORDER BY c.relname,a.attnum""").fetchall()
            real_schema={(table,column):typ for table,column,typ in columns}
            for key in [('match_grade_roles','mean'),('match_grade_roles','spread'),('match_grade_spreads','spread'),('match_grade_quantiles','value'),('player_match_grades','z')]:assert real_schema[key]=='real',(key,real_schema[key])
            values=[0.0,-0.0,.1,-.1,1.0,-1.0,1e-35,-1e-35,2**-126]
            for sign in [-1,1]:
                for n in [0,1,2,7,100,1000]:
                    mid=sign*(1+(n+.5)*2**-23)
                    values.extend([mid,math.nextafter(mid,-math.inf),math.nextafter(mid,math.inf)])
            values.extend([math.sqrt(2)*k/19 for k in range(-10,11)])
            texts=[text(v).decode()for v in values]
            casts=db.execute('SELECT x, x::real::float8 FROM unnest(%s::text[]) WITH ORDINALITY AS t(x,n) ORDER BY n',(texts,)).fetchall()
            assert len(casts)==len(values)
            oracle=[{'input':v,'copy_text':s,'postgres_float4':pg,'simulated_float4':real(v)}for v,(s,pg)in zip(values,casts)]
            assert all(r['postgres_float4']==r['simulated_float4']for r in oracle)
            published=p.read_grade_references(db,2025);assert published;validate_refs(published)
            runs=db.execute("SELECT id,kind,season_id,method_version,started_at::text,finished_at::text,matches,players FROM agg.power_runs WHERE kind='players' AND season_id IN (2025,2026) AND status='published' ORDER BY season_id,id").fetchall()
            for year in [2025,2026]:
                file=temp/f'raw-{year}.pickle';hashes=[];keys=set();count=0;examples=[]
                ordered=hashlib.sha256()
                with file.open('wb')as out,db.cursor(name=f'ascending_raw_{year}')as cur:
                    cur.itersize=3000;cur.execute(p.PLAYER_MATCHES,([year,year+1],*p.award_year(year)));names=[c.name for c in cur.description]
                    for record in cur:
                        row=[v if k in p._KEPT else p._num(v)for k,v in zip(names,record)];match=row[names.index('match_id')];player=row[names.index('player_id')];key=(match,player)
                        assert key not in keys;keys.add(key);digest=hashlib.sha256(encoded(row)).digest();hashes.append(digest);ordered.update(digest);pickle.dump(row,out,protocol=5);count+=1
                        if len(examples)<3:examples.append(row)
                raw_meta[year]={'admitted':count,'raw_column_order':names,'raw_multiset_sha256':sha(b''.join(sorted(hashes))),'raw_ordered_sha256':ordered.hexdigest(),'spool_bytes':file.stat().st_size,'examples':examples};spools[year]=file
                del hashes,keys;log(f'read-raw-{year}')
            file=temp/'published-2026.pickle';stored_n=0;stored_hash=hashlib.sha256()
            with file.open('wb')as out,db.cursor(name='ascending_published_2026')as cur:
                cur.itersize=4000;cur.execute('SELECT match_id,player_id,team_id,role,minutes,season_id,z,ref_season,award_season FROM agg.player_match_grades WHERE award_season=2026 ORDER BY match_id,player_id')
                for r in cur:pickle.dump(r,out,protocol=5);stored_hash.update(encoded(r));stored_n+=1
            stored_file=file;stored_bytes=file.stat().st_size
        # No database access from this point onward, including after the 2025 fit.
        log('closed-one-read-transaction')
        def fit(year):
            names=raw_meta[year]['raw_column_order'];rows=[]
            with spools[year].open('rb')as src:
                while True:
                    try:vals=pickle.load(src)
                    except EOFError:break
                    r=dict(zip(names,vals));r['delta']=0.0 if r['own_elo']is None or r['opponent_elo']is None else(r['opponent_elo']-r['own_elo'])/400;rows.append(r)
            raw_meta[year]['restored_values']=p.restore_zeros(rows);assigned=p.assign_roles(rows);raw_meta[year]['no_role']=len(rows)-len(assigned);del rows;gc.collect();log(f'fit-start-{year}')
            primitive=p.references(assigned);out=[];counts=Counter()
            for i,r in enumerate(assigned):
                _,c=p.match_contribution(r,primitive);assert c is None or math.isfinite(c);counts['assigned']+=1;counts['contribution_known'if c is not None else 'contribution_null']+=1
                if year==2025:out.append((r['role'],r['competition_id'],r['minutes_played'],c))
                else:out.append([r['match_id'],r['player_id'],r['edition'],r['competition_season_id'],r['team_id'],r['role'],r['competition_id'],int(r['minutes_played']),c])
                assigned[i]=None
            del assigned,primitive;gc.collect();raw_meta[year]['computed_counts']=dict(counts);assert raw_meta[year]['admitted']==counts['assigned']+raw_meta[year]['no_role'];log(f'fit-end-{year}');return out
        graded=fit(2025);fresh=p.grade_references(graded);del graded;gc.collect();validate_refs(fresh)
        rounded=round_refs(fresh,real);validate_refs(rounded);log('2025-reference-rounded-as-copy-real')
        current=fit(2026);stored={}
        with stored_file.open('rb')as src:
            while True:
                try:row=pickle.load(src)
                except EOFError:break
                key=row[:2];assert key not in stored;stored[key]=row[2:]
        summary=defaultdict(Counter);by_role=defaultdict(lambda:defaultdict(Counter));gaps=defaultdict(list);extremes=defaultdict(list);keys=set();compact=[]
        def compare(label,za,zb,row):
            t=summary[label];r=by_role[row[5]][label]
            for ctr in [t,r]:
                ctr['rows']+=1;ctr['left_null']+=int(za is None);ctr['right_null']+=int(zb is None);ctr['null_disagreement']+=int((za is None)!=(zb is None))
            if za is None or zb is None:return
            assert math.isfinite(za)and math.isfinite(zb)
            sa,sb=p.score_of(za),p.score_of(zb);gap=abs(sa-sb);gaps[label].append(gap)
            for ctr in [t,r]:
                ctr['comparable']+=1;ctr['index_abs_gt_1e-4']+=int(abs(za-zb)>1e-4);ctr['index_diff_f32']+=int(f32(za)!=f32(zb))
                ctr['score_gap_gt_001']+=int(gap>.01);ctr['score_gap_gt_01']+=int(gap>.1);ctr['score_gap_gt_1']+=int(gap>1);ctr['changed_rounded_score']+=int(math.floor(sa+.5)!=math.floor(sb+.5))
            item=(gap,row[0],row[1],row[3],row[5],sa,sb)
            heap=extremes[label]
            if len(heap)<12:heapq.heappush(heap,item)
            elif item>heap[0]:heapq.heapreplace(heap,item)
        population=Counter()
        for row in current:
            key=tuple(row[:2]);assert key not in keys;keys.add(key);role,comp,c=row[5],row[6],row[8]
            a=p.match_index(role,comp,c,published);b=p.match_index(role,comp,c,rounded);u=p.match_index(role,comp,c,fresh)
            old=stored.get(key);population['assigned']+=1
            if old:
                team,old_role,minutes,partition,z,ref,award=old;population['published']+=1;population['identity_disagreement']+=int((team,old_role,minutes,partition)!=(row[4],role,row[7],row[2]));population['published_reference_not2025']+=int(ref!=2025)
            else:z=None;population['not_published']+=1
            compare('ascending_vs_independent',b,a,row);compare('unrounded_vs_roundtrip',u,b,row)
            compare('ascending_vs_independent_candidate_f32',f32(b),f32(a),row)
            if old:
                compare('independent_vs_published',a,z,row);compare('ascending_vs_published',b,z,row);compare('ascending_candidate_f32_vs_published',f32(b),z,row)
            compact.append(row+([*old]if old else [None]*7))
        population['stored_outside_assigned']=len(stored.keys()-keys);population['stored_total']=stored_n;assert len(stored)==stored_n and population['published']+population['not_published']==population['assigned']
        del current,stored,keys;gc.collect()
        distributions={}
        for name,values in gaps.items():
            values.sort();n=len(values);distributions[name]={'n':n,'mean':sum(values)/n if n else None,'p50':values[int(.5*(n-1))]if n else None,'p95':values[int(.95*(n-1))]if n else None,'p99':values[int(.99*(n-1))]if n else None,'max':values[-1]if n else None}
        del gaps;log('finished')
        return {'snapshot':meta,'source_sha256':SOURCE,'player_sql_sha256':sha(p.PLAYER_MATCHES.encode()),'raw':raw_meta,'reference_years':{'2025':2025,'2026':2025},'schema':columns,'runs':runs,'roundtrip':{'method':'Actual psycopg text float dumper then libc strtof; checked against PostgreSQL text::real::float8 before fitting','psycopg_version':psycopg.__version__,'oracle':oracle,'all_oracle_equal':True},'references':{'published_2025':refs_out(published),'refit_2025_double':refs_out(fresh),'refit_2025_storage':refs_out(rounded)},'reference_comparisons':{'refit_storage_vs_published':ref_diff(rounded,published),'double_vs_storage':ref_diff(fresh,rounded)},'population_2026':population,'comparisons':summary,'by_role':by_role,'gap_distributions':distributions,'extremes':{k:sorted(v,reverse=True)for k,v in extremes.items()},'condensed_columns':['match','player','partition','edition','team','role','competition','minutes','current_contribution','published_team','published_role','published_minutes','published_partition','published_z','published_ref','published_award'],'condensed_2026':compact,'condensed_sha256':sha(encoded(compact)),'stored_2026_ordered_sha256':stored_hash.hexdigest(),'stored_spool_bytes':stored_bytes,'checkpoints':checkpoints,'wall_seconds':round(time.monotonic()-started,3),'rss_peak_kib':resource.getrusage(resource.RUSAGE_SELF).ru_maxrss,'production_writes':0,'scope':'Match-grade reference propagation only; full 2025 raw statistics are not exported; no seasonal ranking, six-year chain or production writer execution.'}
