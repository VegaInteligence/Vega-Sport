"""Exact text-COPY input / ordinary psycopg real output, using only local read-only SELECTs."""
from pathlib import Path
from datetime import datetime,timezone
from copy import deepcopy
import hashlib,json,struct,zlib
import psycopg
from psycopg.adapt import Transformer,PyFormat
Q=Path(__file__).resolve().parent
def enc(x):return json.dumps(x,ensure_ascii=True,separators=(',',':'),allow_nan=False).encode()
def sha(b):return hashlib.sha256(b).hexdigest()
blob=(Q/'rds/inputs.json.zlib').read_bytes();receipt=json.loads((Q/'rds/receipt.json').read_bytes());assert receipt['exit_code']==0 and sha(blob)==receipt['sha256']
d=json.loads(zlib.decompress(blob));transform=Transformer()
def cells(ref):
    out=[]
    for group,positions in [('roles',(2,3)),('spreads',(3,))]:
        for i,row in enumerate(ref[group]):
            for pos in positions:out.append((group,i,pos,row[pos]))
    for role,values in ref['quantiles'].items():
        out.extend(('quantiles',role,i,v)for i,v in enumerate(values))
    return out
out={};details={}
with psycopg.connect('postgresql://postgres@127.0.0.1:55439/postgres')as con:
    con.execute('SET TRANSACTION READ ONLY')
    config=con.execute("SELECT version(),current_setting('extra_float_digits'),current_setting('transaction_read_only')").fetchone();assert config[2]=='on'and int(config[1])>0
    for source in ['published_2025','refit_2025_double']:
        ref=d['references'][source];values=cells(ref);texts=[bytes(transform.get_dumper(float(v),PyFormat.TEXT).dump(float(v))).decode()for _,_,_,v in values]
        result=con.execute('SELECT value::real,value::real::float8 FROM unnest(%s::text[]) WITH ORDINALITY AS t(value,n) ORDER BY n',(texts,)).fetchall();assert len(result)==len(values)
        actual=deepcopy(ref);evidence=[]
        for cell,text,(readback,binary32)in zip(values,texts,result):
            group,key,pos,original=cell;actual[group][key][pos]=readback
            evidence.append([group,key,pos,original,text,binary32,readback])
        if source=='published_2025':assert actual==ref,'Published RDS reference does not round-trip identically through the local text reader'
        else:
            binary_ref=deepcopy(ref)
            for (group,key,pos,_),(_,binary32)in zip(values,result):binary_ref[group][key][pos]=binary32
            assert binary_ref==d['references']['refit_2025_storage'],'Remote float4 simulation differs from actual PostgreSQL storage conversion'
        out[source]=actual;details[source]=evidence
new=out['refit_2025_double'];out_path=Q/'reference-2025-after-copy-and-read.json';out_path.write_text(json.dumps(new,indent=2)+'\n')
packed=zlib.compress(enc(details),9);(Q/'roundtrip-cells.json.zlib').write_bytes(packed)
summary={'at':datetime.now(timezone.utc).isoformat(),'input_sha256':sha(blob),'local_postgres':config[0],'extra_float_digits':config[1],'transaction_read_only':config[2],'psycopg_version':psycopg.__version__,'published_reference_idempotent':True,'all_remote_binary32_values_equal_actual_pg_storage':True,'cells':{k:len(v)for k,v in details.items()},'readback_double_differs_from_promoted_binary32':sum(r[5]!=r[6]for r in details['refit_2025_double']),'max_readback_difference':max(abs(r[5]-r[6])for r in details['refit_2025_double']),'roundtrip_cells_sha256':sha(packed),'actual_reference_sha256':sha(out_path.read_bytes()),'database_writes':0,'production_writes':0,'scope':'Real storage and text-reader serialization only. No table INSERT, COPY, UPDATE, DELETE or schema mutation; no RDS connection.'}
(Q/'storage-roundtrip-receipt.json').write_text(json.dumps(summary,indent=2)+'\n');print(json.dumps(summary,indent=2))
