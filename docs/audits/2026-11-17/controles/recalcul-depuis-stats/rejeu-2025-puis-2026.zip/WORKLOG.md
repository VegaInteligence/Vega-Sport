Objectif : isoler la propagation des références ponctuelles de notes lors d'un rattrapage 2025 puis 2026, à C actuel 2026 fixe.

Contraintes : image déployée 8018e08 ; une seule collecte séquentielle, une transaction RDS READ ONLY / REPEATABLE READ pour les deux années et les références ; aucune écriture produit ou production ; sorties uniquement ici. Pas de chaîne historique complète ni de classement annuel revendiqué.

Terminé : protocole préalable ; diagnostic :160 réussi, snapshot commun 4423081, empreintes brutes identiques aux deux collectes antérieures. Tout lu avant fit, spools éphémères supprimés. Références passées par texte COPY → real → lecteur ordinaire PostgreSQL local ; idempotence des 14 560 cellules publiées et égalité du stockage vérifiées. Rejeu intégral des 229 455 C condensés réussi.

Résultat : B−A max 0,003092337354 point, aucun >0,01 ; 15 arrondis entiers diffèrent. B−publié : 7 684 >0,01 ; 551 >0,1 ; aucun >1. Ne pas présenter ces compteurs comme UPDATE réels, ni le rejeu condensé comme fit brut 2025.

Validation portable indépendante terminée : 229 455 lignes rejouées en 13,676 s, résultats substantiels identiques ; aucun réseau ni base. Archive et manifeste figés à transmettre au coordinateur. Aucun nouveau diagnostic RDS nécessaire.
