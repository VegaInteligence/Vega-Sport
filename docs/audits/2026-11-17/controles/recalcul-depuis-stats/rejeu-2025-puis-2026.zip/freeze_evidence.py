"""Freeze only this diagnostic evidence directory and verify the archive byte for byte."""
from pathlib import Path
from datetime import datetime,timezone
import hashlib,json,zipfile
Q=Path(__file__).resolve().parent
excluded={'SHA256SUMS','ascending-reference-evidence.zip','archive-receipt.json'}
files=sorted(p for p in Q.rglob('*')if p.is_file()and p.name not in excluded)
assert not any(p.is_symlink()for p in files)
def sha(b):return hashlib.sha256(b).hexdigest()
entries=[{'path':p.relative_to(Q).as_posix(),'bytes':p.stat().st_size,'sha256':sha(p.read_bytes())}for p in files]
ledger=''.join(f"{r['sha256']}  {r['path']}\n"for r in entries)
(Q/'SHA256SUMS').write_text(ledger)
archive=Q/'ascending-reference-evidence.zip'
with zipfile.ZipFile(archive,'w',compression=zipfile.ZIP_DEFLATED,compresslevel=9)as z:
    for p in files+[Q/'SHA256SUMS']:z.write(p,p.relative_to(Q).as_posix())
with zipfile.ZipFile(archive)as z:
    assert z.testzip()is None
    assert z.read('SHA256SUMS').decode()==ledger
    assert set(z.namelist())=={r['path']for r in entries}|{'SHA256SUMS'}
    for r in entries:
        b=z.read(r['path']);assert len(b)==r['bytes']and sha(b)==r['sha256']
receipt={'status':'passed','at':datetime.now(timezone.utc).isoformat(),'archive':archive.name,'archive_sha256':sha(archive.read_bytes()),'archive_bytes':archive.stat().st_size,'members':len(entries)+1,'uncompressed_member_bytes':sum(r['bytes']for r in entries)+len(ledger.encode()),'sha256sums_sha256':sha(ledger.encode()),'every_member_verified':True,'source_entries':entries,'production_writes':0}
(Q/'archive-receipt.json').write_text(json.dumps(receipt,indent=2)+'\n')
print(json.dumps({k:v for k,v in receipt.items()if k!='source_entries'},indent=2))
