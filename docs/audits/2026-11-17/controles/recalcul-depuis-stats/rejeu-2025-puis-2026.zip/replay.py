"""Offline replay of every fixed-C 2026 contrast, from complete condensed observations."""
from pathlib import Path
from collections import Counter,defaultdict
import csv,hashlib,heapq,json,math,runpy,struct,sys,time,zlib
Q=Path(__file__).resolve().parent;start=time.monotonic()
def sha(b):return hashlib.sha256(b).hexdigest()
def enc(v):return json.dumps(v,ensure_ascii=True,separators=(',',':'),allow_nan=False).encode()
source=(Q/'power-8018e0836c.py').read_bytes();assert sha(source)=='75d3b2a829b585d8dbadb60d1fb2a6b4233e7f74d220a0f76bab0ebb6fdb93ff'
p=runpy.run_path(str(Q/'power-8018e0836c.py'))
blob=(Q/'rds/inputs.json.zlib').read_bytes();r=json.loads((Q/'rds/receipt.json').read_bytes());assert r['exit_code']==0 and r['definition_end_state']=='INACTIVE'and sha(blob)==r['sha256']
assert r['actual_image_digest']=='sha256:8184f72a335b9b4c126e77ead0e71771b6a4a146ee1b7a026ed2c2c1a6aba352'
assert sha((Q/'probe.py').read_bytes())==r['probe_sha256']
d=json.loads(zlib.decompress(blob));assert d['source_sha256']==sha(source)and d['snapshot'][3:5]==['on','repeatable read']
stored=json.loads((Q/'storage-roundtrip-receipt.json').read_bytes());reader=(Q/'reference-2025-after-copy-and-read.json').read_bytes();assert stored['actual_reference_sha256']==sha(reader)and stored['published_reference_idempotent']and stored['all_remote_binary32_values_equal_actual_pg_storage']
def refs(v):return {'roles':{x[0]:tuple(x[1:])for x in v['roles']},'spreads':{tuple(x[:2]):tuple(x[2:])for x in v['spreads']},'quantiles':v['quantiles']}
a=refs(d['references']['published_2025']);b=refs(json.loads(reader));u=refs(d['references']['refit_2025_double']);remote=refs(d['references']['refit_2025_storage'])
for ref in [a,b,u,remote]:
    assert all(len(q)==2001 and q==sorted(q)and all(math.isfinite(v)for v in q)for q in ref['quantiles'].values())
rows=d['condensed_2026'];assert sha(enc(rows))==d['condensed_sha256']
def f32(x):return None if x is None else struct.unpack('!f',struct.pack('!f',x))[0]
summary=defaultdict(Counter);per_role=defaultdict(lambda:defaultdict(Counter));gaps=defaultdict(list);worst=defaultdict(list);pop=Counter();seen=set()
def record(label,left,right,row):
    for c in [summary[label],per_role[row[5]][label]]:
        c['rows']+=1;c['left_null']+=int(left is None);c['right_null']+=int(right is None);c['null_disagreement']+=int((left is None)!=(right is None))
    if left is None or right is None:return
    assert math.isfinite(left)and math.isfinite(right)
    x,y=p['score_of'](left),p['score_of'](right);delta=abs(x-y);gaps[label].append(delta)
    for c in [summary[label],per_role[row[5]][label]]:
        c['comparable']+=1;c['index_abs_gt_1e-4']+=int(abs(left-right)>1e-4);c['index_diff_f32']+=int(f32(left)!=f32(right));c['score_gap_gt_001']+=int(delta>.01);c['score_gap_gt_01']+=int(delta>.1);c['score_gap_gt_1']+=int(delta>1);c['changed_rounded_score']+=int(math.floor(x+.5)!=math.floor(y+.5))
    item=(delta,row[0],row[1],row[3],row[5],x,y);heap=worst[label]
    if len(heap)<12:heapq.heappush(heap,item)
    elif item>heap[0]:heapq.heapreplace(heap,item)
for row in rows:
    key=tuple(row[:2]);assert key not in seen;seen.add(key);pop['assigned']+=1
    za,zb,zu,zr=[p['match_index'](row[5],row[6],row[8],ref)for ref in [a,b,u,remote]]
    z=row[13];published=row[10]is not None
    pop['published'if published else 'not_published']+=1
    if published:
        pop['identity_disagreement']+=int((row[9],row[10],row[11],row[12])!=(row[4],row[5],row[7],row[2]));pop['published_reference_not2025']+=int(row[14]!=2025)
    comparisons={'ascending_vs_independent':(zb,za),'unrounded_vs_exact_roundtrip':(zu,zb),'exact_reader_vs_promoted_binary32':(zb,zr),'ascending_vs_independent_candidate_f32':(f32(zb),f32(za)),
                 'remote:ascending_vs_independent':(zr,za),'remote:unrounded_vs_roundtrip':(zu,zr),'remote:ascending_vs_independent_candidate_f32':(f32(zr),f32(za))}
    if published:comparisons.update({'independent_vs_published':(za,z),'ascending_vs_published':(zb,z),'ascending_candidate_f32_vs_published':(f32(zb),z),'remote:independent_vs_published':(za,z),'remote:ascending_vs_published':(zr,z),'remote:ascending_candidate_f32_vs_published':(f32(zr),z)})
    for name,(left,right)in comparisons.items():record(name,left,right,row)
for name,expected in d['comparisons'].items():assert dict(summary['remote:'+name])==expected,(name,summary['remote:'+name],expected)
distributions={}
for name,values in gaps.items():
    values.sort();n=len(values);distributions[name]={'n':n,'mean':sum(values)/n if n else None,'p50':values[int(.5*(n-1))]if n else None,'p95':values[int(.95*(n-1))]if n else None,'p99':values[int(.99*(n-1))]if n else None,'max':values[-1]if n else None}
for name,expect in d['gap_distributions'].items():
    assert all(abs(distributions['remote:'+name][key]-expect[key])<1e-10 for key in ['mean','p50','p95','p99','max'])
assert pop['assigned']==len(rows)==d['population_2026']['assigned']and pop['published']==d['population_2026']['published']and pop['identity_disagreement']==0
prior=json.loads((Q/'prior-inputs.json').read_bytes());agreement={}
for year in ['2025','2026']:
    now,old=d['raw'][year],prior['years'][year];agreement[year]={'prior_snapshot':old['snapshot'],'common_snapshot':d['snapshot'],'same_raw_multiset':now['raw_multiset_sha256']==old['raw_multiset_sha256'],'raw_multiset_sha256':now['raw_multiset_sha256'],'same_source':d['source_sha256']==old['source_sha256'],'same_sql':d['player_sql_sha256']==old['player_sql_sha256'],'admitted_now':now['admitted'],'admitted_before':old['counts']['admitted']}
    assert now['admitted']==now['no_role']+now['computed_counts']['assigned']
refrows=[]
for role in sorted(a['roles'].keys()&b['roles'].keys()):
    old,new=a['roles'][role],b['roles'][role];diff=[abs(x-y)for x,y in zip(a['quantiles'][role],b['quantiles'][role])]
    refrows.append({'role':role,'published_matches':old[0],'recalculated_matches':new[0],'published_mean':old[1],'recalculated_mean':new[1],'mean_difference':new[1]-old[1],'published_spread':old[2],'recalculated_spread':new[2],'spread_difference':new[2]-old[2],'spread_relative_difference':(new[2]-old[2])/old[2],'quantiles':len(diff),'quantiles_different':sum(x!=y for x,y in zip(a['quantiles'][role],b['quantiles'][role])),'quantile_max_abs':max(diff),'quantile_mean_abs':sum(diff)/len(diff)})
spreadrows=[]
for key in sorted(a['spreads'].keys()&b['spreads'].keys()):
    old,new=a['spreads'][key],b['spreads'][key];spreadrows.append({'role':key[0],'competition':key[1],'published_matches':old[0],'recalculated_matches':new[0],'published_spread':old[1],'recalculated_spread':new[1],'absolute_difference':abs(new[1]-old[1]),'relative_difference':(new[1]-old[1])/old[1]})
for filename,entries in [('reference-role-changes.csv',refrows),('reference-competition-spread-changes.csv',spreadrows)]:
    with(Q/filename).open('w',newline='')as f:w=csv.DictWriter(f,fieldnames=list(entries[0]));w.writeheader();w.writerows(entries)
output={'status':'passed','scope':'Offline exact-reader fixed-C 2026 contrast, not a refit of exported full raw 2025 inputs','data_sha256':sha(blob),'source_sha256':sha(source),'actual_reference_sha256':sha(reader),'common_snapshot':d['snapshot'],'agreement_with_prior':agreement,'population':dict(pop),'comparisons':{k:dict(v)for k,v in summary.items()if not k.startswith('remote:')},'gap_distributions':{k:v for k,v in distributions.items()if not k.startswith('remote:')},'by_role':{role:{k:dict(v)for k,v in comps.items()if not k.startswith('remote:')}for role,comps in per_role.items()},'worst':{k:sorted(v,reverse=True)for k,v in worst.items()if not k.startswith('remote:')},'reference_summary':{'roles':len(refrows),'competition_role_spreads':len(spreadrows),'role_match_counts_unchanged':all(r['published_matches']==r['recalculated_matches']for r in refrows),'competition_counts_unchanged':all(r['published_matches']==r['recalculated_matches']for r in spreadrows),'quantiles_different':sum(r['quantiles_different']for r in refrows),'quantiles_total':sum(r['quantiles']for r in refrows),'quantile_max_abs':max(r['quantile_max_abs']for r in refrows),'spread_max_abs':max(r['absolute_difference']for r in spreadrows),'spread_max_relative_abs':max(abs(r['relative_difference'])for r in spreadrows),'mean_max_abs':max(abs(r['mean_difference'])for r in refrows)},'remote_comparisons_reproduced':list(d['comparisons']),'seconds':round(time.monotonic()-start,3),'python':sys.version,'network_used':False,'production_writes':0}
(Q/'replay-receipt.json').write_text(json.dumps(output,indent=2,ensure_ascii=False)+'\n');print(json.dumps({k:output[k]for k in ['status','population','comparisons','gap_distributions','reference_summary','seconds']},indent=2))
