# Référence ascendante 2025 → 2026 — diagnostic terminé

**Sur les 229 455 participations 2026 calculables et publiées, remplacer la référence publiée de 2025 par celle recalculée change chaque note de moins de 0,01 point.** Le maximum est **0,003092337354 point**, à contribution actuelle strictement identique. Le changement reste observable à certaines frontières : 15 notes calculées changent d'arrondi entier. Ce résultat ne signifie donc pas une égalité bit à bit ou un affichage nécessairement identique.

Le recalcul 2026 après ce rattrapage conserve, par rapport aux notes actuellement publiées, **7 684 écarts > 0,01 point**, **551 > 0,1**, **aucun > 1**, maximum **0,457006129576**. La propagation de référence ne résout pas l'essentiel de cet écart. Le diagnostic ne détermine pas à lui seul l'origine de chaque différence.

Aucune écriture de données de production, de branche ou de code produit. Un seul diagnostic ECS, une seule transaction RDS métier. Le protocole est dans `PROTOCOLE.md`, écrit avant collecte ; son amendement de sérialisation est explicitement daté par la chronologie des reçus et identifié comme ajouté pendant le diagnostic.

## Contraste effectivement mesuré

Toutes les transformations de calcul proviennent du module déployé figé `power-8018e0836c.py`. Les deux années suivent `restore_zeros → assign_roles → references → match_contribution`. Les éventuels défauts du code déployé sont conservés. C 2026 est recalculé une seule fois sur ses entrées actuelles, puis gardé fixe pour les quatre scénarios :

- **P** : indice `z` actuellement publié pour chaque participation 2026, relu par psycopg.
- **A** : C actuel 2026 évalué avec la référence 2025 actuellement publiée.
- **B** : même C, avec la référence 2025 reconstruite sur les observations brutes actuelles de 2025, passée par le chemin d'écriture/lecture des valeurs `real`.
- **U** : même C, même référence reconstruite avant toute réduction de précision de stockage ; contrôle de B uniquement.

Les seuils portent sur `abs(score_of(z_left) − score_of(z_right))`, strictement supérieurs aux valeurs indiquées. Le `z` n'est pas la note sur 100. L'arrondi entier est `floor(score + 0.5)`.

| Contraste | > 0,01 | > 0,1 | > 1 | Maximum en points | Arrondis entiers différents |
| --- | ---: | ---: | ---: | ---: | ---: |
| B − A : effet de la seule référence recalculée | 0 | 0 | 0 | 0.00309233735421 | 15 |
| A − P : référence publiée, C actuel | 7,681 | 550 | 0 | 0.456568155338 | 782 |
| B − P : ordre 2025 puis 2026, C actuel | 7,684 | 551 | 0 | 0.457006129576 | 775 |
| U − B : effet du stockage/lecteur de la référence | 0 | 0 | 0 | 5.24877420638e-06 | 0 |

Pour B−A, l'écart moyen vaut 0,000031154684 ; p95 0,000122143276 ; p99 0,000387416681. Le maximum correspond à `(match_id=10, player_id=424)`, rôle `centre_forward` : A=26,594730878842 et B=26,591638541487. Pour B−P, le maximum est `(47188, 28945)` : P=25,629711439952 et B=25,172705310376.

Une vue secondaire arrondit aussi les indices candidats `z` en binary32 : B−A conserve les mêmes trois seuils nuls et donne 16 arrondis entiers différents ; B−P conserve 7 684/551/0 et donne 776 arrondis différents. **Ces candidats ne sont pas un comptage exact des lignes qu'un writer publierait.** `write_match_grades` (ligne 1707 du module figé) conserve le `z` existant lorsque sa différence reste dans 1e-4 et que les autres champs de décision sont identiques ; les opérations SQL de publication, `first_z`, `changed_at`, agrégats d'édition et classements saisonniers ne sont pas exécutés ni simulés entièrement. La vue principale B emploie en revanche le round-trip exact de la *référence* 2025 demandé pour la lecture 2026.

## Référence 2025 : valeurs et support

Les 7 rôles, 539 paires rôle/compétition et leurs effectifs sont identiques avant/après ; aucune clé ajoutée ou supprimée. Le sous-ensemble de référence contient 426 620 participations d'au moins 60 minutes, conformément à `GRADE_FULL_MINUTES`. Il est distinct des 652 902 participations 2025 dont C a été calculé.

Après le chemin effectif de stockage puis lecture :

| Famille de cellules | Cellules modifiées | Total | Plus grand écart absolu |
| --- | ---: | ---: | ---: |
| Moyenne par rôle | 6 | 7 | 1,2e-8 |
| Dispersion globale par rôle | 4 | 7 | 9e-8 |
| Dispersion rôle/compétition | 309 | 539 | 8,01e-6 |
| Quantiles | 12 550 | 14 007 | 0,0002399 |

Le maximum relatif de dispersion rôle/compétition vaut 2,0887991e-5, soit environ 0,00209 %. Les références intégrales avant stockage, stockables et publiées sont dans l'artefact RDS ; celle effectivement relue est `reference-2025-after-copy-and-read.json`. Les deux CSV détaillent chaque rôle et chaque dispersion. Les quantiles restent finis, ordonnés et de longueur 2 001 pour chaque rôle.

## Une collecte atomique, avant calcul lourd

Le garde-fou `../elo-counterfactual/rds/inputs.json.zlib` et son reçu réussi ont été vérifiés avant lancement ; son SHA est enregistré dans `prior-inputs.json`. La tâche `vega-audit-readonly-vi27:160` a utilisé :

- image `361769570630.dkr.ecr.us-east-2.amazonaws.com/vega-v2-worker:8018e0836ca0f32e8b2eb51fc2847154abff7f13` ;
- digest réellement exécuté `sha256:8184f72a335b9b4c126e77ead0e71771b6a4a146ee1b7a026ed2c2c1a6aba352` ;
- SHA du module `75d3b2a829b585d8dbadb60d1fb2a6b4233e7f74d220a0f76bab0ebb6fdb93ff` ;
- SHA de `PLAYER_MATCHES` `ec8dd276bd174ad0ca943a46c87db1ef958ca76c87705dab80377875370429a3` ;
- snapshot PostgreSQL `4423081:4423081:`, transaction commencée le **18 novembre 2026 à 08:56:44.101054 UTC**, `REPEATABLE READ`, `transaction_read_only=on`, base `vega_v2`.

Les observations 2025/2026, les notes publiées 2026, les références publiées 2025, les types de colonnes et les runs ont tous été lus dans cette transaction. Elle est fermée à +78,076 s, avant le premier ajustement lourd. Les curseurs serveur écrivent trois spools internes éphémères, supprimés avant retour du diagnostic ; aucune table temporaire RDS.

| Année | Lignes admises | Sans rôle | C attribuées et connues | SHA-256 du multiensemble d'entrées |
| --- | ---: | ---: | ---: | --- |
| 2025 | 652 977 | 75 | 652 902 | `cd7a665c40108c1cb34068686f8373aafa135110281f98bd397b35a24655810f` |
| 2026 | 229 475 | 20 | 229 455 | `4c263ebc14e9535b74e57e3b61017a62fe2aa4885db43382f0eaf061198b135c` |

Ces deux empreintes, comptes, source et SQL concordent exactement avec les collectes antérieures `../2025/rds` (08:40:52 UTC) et `../2026/rds` (08:44:06 UTC). C'est une égalité du multiensemble normalisé, pas une garantie d'ordre des lignes : le SELECT déployé n'a pas d'`ORDER BY`. Les nouveaux hashes ordonnés sont conservés dans le résultat. Les anciens diagnostics n'avaient pas exporté toutes les références numériques ; aucune égalité de l'intégralité de leurs états de référence n'est revendiquée. Le contraste principal repose sur la nouvelle transaction commune.

Réconciliation 2026 : 229 455 attribuées = 229 455 publiées, zéro identité divergente (équipe, rôle, minutes, partition), zéro publiée hors sélection, zéro référence autre que 2025, aucune note nulle ou non finie dans les contrastes. Les runs publiés observés sont 2095 (2026, terminé 01:07:35 UTC), puis 2096 (2025, commencé 01:07:37 UTC, terminé 01:15:32 UTC). Cet ordre est un constat du snapshot ; il ne prouve pas à lui seul la cause des écarts numériques.

Les spools occupaient 190 753 449 + 66 845 833 + 13 464 365 = **271 063 647 octets**. Durée interne 191,381 s ; pic RSS observé pendant `collect` **1 849 304 KiB**, environ 1,764 GiB, sur une allocation de 8 GiB / 2 vCPU. Ce pic ne mesure pas nécessairement le maximum ultérieur de sérialisation du runtime. Reçu ECS : exit 0, définition désactivée (`INACTIVE`), 275 blocs de résultat réassemblés, 6 589 618 octets compressés.

## Passage exact par `real` et lecteur psycopg

Le schéma vivant confirme `real` pour les moyennes, dispersions, quantiles et `z`. Les références 2025 sont construites avec C en double en mémoire ; elles ne sont pas construites depuis des C déjà stockés en `real`. Les notes 2025 de `refresh_players` sont calculées avant l'écriture de leur référence, tandis que la prochaine lecture 2026 relit les tables `real` (`refresh_players`, lignes 1486–1568 ; writers/readers, lignes 1756–1781 du module conservé).

Le probe RDS vérifie 66 valeurs de contrôle, dont des frontières binary32, avec le dumper texte psycopg réellement installé puis `text::real::float8`. Il conserve toute la référence double et sa valeur binary32. **Cette dernière représentation seule n'est pas la valeur Python renvoyée par le lecteur ordinaire** : PostgreSQL émet un décimal court pour `real`. Ainsi `0.1::real` se relit comme `0.1`, tandis que `0.1::real::float8` expose `0.10000000149011612`.

Après collecte, `storage_roundtrip.py` exécute uniquement des SELECT locaux READ ONLY sur PostgreSQL 18.6 ARM64, psycopg 3.3.9, `extra_float_digits=1`. Pour les **14 560 cellules** de la nouvelle référence, il applique le texte COPY psycopg → `text::real` → lecteur ordinaire et conserve chaque valeur intermédiaire. Il vérifie également :

1. les 14 560 valeurs de stockage binary32 sont exactement identiques à la simulation du probe ;
2. les 14 560 cellules de référence publiée capturées sur RDS sont identiques après le même passage local ;
3. les types, clés, comptes et monotonie restent valides.

Aucun INSERT/COPY de table/UPDATE/DELETE local ou RDS, aucune nouvelle connexion RDS. Le round-trip est celui des valeurs qui passeraient par les colonnes, sans exécuter les effets transactionnels du writer. La version serveur RDS n'a pas été capturée ; la concordance de stockage est contrôlée par l'oracle distant et la concordance du lecteur par l'idempotence de toute la référence publiée. La variante finale B exploite les cellules réellement relues localement. Les résultats B stockés initialement dans `rds/inputs.json.zlib` emploient la promotion binary32 et sont donc **préliminaires** ; `replay-receipt.json` est la source des résultats finaux de ce rapport. L'écart maximal entre ces deux représentations est 0,000004304008 point, sans changement d'arrondi entier sur ce jeu.

## Preuve hors ligne, commandes et limites

`rds/inputs.json.zlib` conserve les 229 455 contributions 2026 et identités/indices publiés condensés, ainsi que toutes les références nécessaires. Il est suffisant pour refaire entièrement les contrastes de notes, sans réseau et sans base. `replay.py` importe la copie exacte du module, contrôle les hashes et recalcule les comparaisons sur toutes les lignes. Il reproduit aussi les six contrastes préliminaires distants comme contrôle d'intégrité. `verify_portable.py` répète ce rejeu dans une copie temporaire sous ce dossier, vérifie l'identité des résultats substantiels et des deux CSV puis supprime la copie. Son reçu et son journal sont préservés.

Commandes hors ligne, à exécuter sur une copie du dossier extrait si l'on souhaite conserver intacts les reçus originaux :

```sh
python3 -B replay.py
python3 -B verify_portable.py
```

L'environnement constaté pour le rejeu est Python 3.14.6 ; le code de rejeu utilise seulement la bibliothèque standard. Le premier rejeu a pris 13,226 s ; la reproduction portable indépendante, 13,676 s, exit 0, avec tous les résultats substantiels et les deux CSV identiques. Le reçu du rejeu portable contient son argv exact, le répertoire temporaire, les hashes et le résultat.

Commande de collecte historique, **consignée pour reproduction contrôlée, non relancée** :

```sh
'/Users/lemonnierhugo/.codex/visualizations/2026/11/17/01a1e6f1-9c43-7b81-a52e-3ee15c953578/production-architecture-review/ci-clean/bin/python' -B '/Users/lemonnierhugo/.codex/visualizations/2026/11/17/01a1e6f1-9c43-7b81-a52e-3ee15c953578/production-architecture-review/tracks/5-players/raw-refit/ascending-reference/collect.py' '/Users/lemonnierhugo/.codex/visualizations/2026/11/17/01a1e6f1-9c43-7b81-a52e-3ee15c953578/production-architecture-review/tracks/5-players/raw-refit/ascending-reference/rds'
```

Elle est aussi enregistrée avec son cwd, ses heures et son exit 0 dans `collection-command.json`. `collect.py` dépend du lanceur existant `E/tracks/6-teams/capture.py` et de son runtime `E/query_batch.py` ; ces scripts n'ont pas été modifiés. La vérification de conversion locale peut être reproduite avec Python/psycopg 3.3.9 et PostgreSQL 18.6 à `127.0.0.1:55439`, par `storage_roundtrip.py` ; elle n'est pas nécessaire au rejeu condensé, ses cellules complètes étant archivées.

Limites explicites : les observations statistiques complètes de 2025/2026 n'ont pas été exportées, seulement leurs hashes, comptes et quelques exemples ; les spools ont été supprimés. Le paquet rejoue le contraste à C fixé et vérifie ses références, **pas le fit brut 2025 complet hors ligne**. Aucun écran ou cache API n'est testé. Les indices candidats binary32 ne simulent pas le writer et sa tolérance. Aucun classement annuel, prior de joueur ou autre élément de la chaîne historique n'est qualifié. Les six années précédentes n'ont pas été recalculées : la référence ponctuelle d'une année achevée est directement issue de ses propres contributions ; cela ne constitue pas une validation de leurs Elo ou autres états antérieurs.

## Fichiers de preuve

- `PROTOCOLE.md`, `probe.py`, `collect.py` : protocole et collecte figée.
- `rds/receipt.json`, `rds/checkpoints.txt`, `collection-command.json` : exécution unique et contrôles de lecture.
- `rds/inputs.json.zlib` : preuve condensée ; SHA **e719f4d12b9e84b38765f2fe3e4b48c2b085d99bb5be336c85b9e25a1d967fc4**.
- `roundtrip-cells.json.zlib` : chaque cellule du passage réel ; SHA **ec61d51da8f53e65f3849117c185c67a500df859a9611778941f243d07895fe4**.
- `reference-2025-after-copy-and-read.json` : référence finale relue ; SHA **c4de4566711c2a6ae8456acc957e4f9a00742f6d7f5cbed2f45f59729336e151**.
- `replay-receipt.json`, les CSV et `portable-replay-receipt.json` : résultats finaux et reproduction.
- `SHA256SUMS` et `ascending-reference-evidence.zip` : manifeste figé et archive ; `archive-receipt.json` en consigne les mesures et le hash.
