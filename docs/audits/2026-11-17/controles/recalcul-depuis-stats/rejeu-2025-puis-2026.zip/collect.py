"""Launch exactly once, only after the preceding Elo diagnostic has its complete receipt."""
from pathlib import Path
import hashlib,importlib.util,json,sys,zlib
Q=Path(__file__).resolve().parent;E=Q.parents[3]
gate=Q.parent/'elo-counterfactual/rds';receipt=json.loads((gate/'receipt.json').read_bytes());blob=(gate/'inputs.json.zlib').read_bytes()
assert receipt['exit_code']==0 and receipt['definition_end_state']=='INACTIVE'and hashlib.sha256(blob).hexdigest()==receipt['sha256']
json.loads(zlib.decompress(blob))
prior={}
for year in [2025,2026]:
    folder=Q.parent/str(year)/'rds';r=json.loads((folder/'receipt.json').read_bytes());b=(folder/'inputs.json.zlib').read_bytes();d=json.loads(zlib.decompress(b));assert r['exit_code']==0 and hashlib.sha256(b).hexdigest()==r['sha256']
    prior[year]={'snapshot':d['snapshot'],'raw_multiset_sha256':d['raw_multiset_sha256'],'source_sha256':d['source_sha256'],'player_sql_sha256':d['player_sql_sha256'],'result_sha256':r['sha256'],'counts':d['counts']}
(Q/'prior-inputs.json').write_text(json.dumps({'gate_sha256':receipt['sha256'],'years':prior},indent=2)+'\n')
spec=importlib.util.spec_from_file_location('capture',E/'tracks/6-teams/capture.py');capture=importlib.util.module_from_spec(spec);spec.loader.exec_module(capture);capture.here=Q
capture.main()
