"""Verify all seven signed digests and recompute the first year with no network."""
from collections import Counter
import csv
import hashlib
import json
from pathlib import Path
import subprocess
import sys
import tempfile
import zlib

here=Path(__file__).resolve().parent
def h(b):
    return hashlib.sha256(b).hexdigest()
def read(p):
    return json.loads(p.read_bytes())
def obs(tag,source=None):
    d=here/tag/'rds'
    rc=read(d/'receipt.json')
    blob=(d/'inputs.json.zlib').read_bytes()
    assert rc['exit_code']==0 and rc['sha256']==h(blob) and rc['bytes']==len(blob)
    assert rc['actual_image_digest']=='sha256:8184f72a335b9b4c126e77ead0e71771b6a4a146ee1b7a026ed2c2c1a6aba352' and rc['definition_end_state']=='INACTIVE'
    if source is not None:assert h(source)==rc['probe_sha256']
    result=json.loads(zlib.decompress(blob))
    assert result['snapshot'][0]=='vega_v2' and result['snapshot'][3:5]==['on','repeatable read']
    return result

for name,value in read(here/'hashes.json').items():
    file=here/name
    assert file.is_file() and h(file.read_bytes())==value,name
fields=('admitted','no_role','assigned','computable_index','computable_published','computable_unpublished','opponent_elo_changed','contribution_abs_gt_1e-4','grade_index_abs_gt_1e-4','score_gap_gt_001','score_gap_gt_01','score_gap_gt_1','changed_rounded_score')
with (here/'annees.csv').open() as fp:annual=list(csv.DictReader(fp))
with (here/'editions.csv').open() as fp:editions=list(csv.DictReader(fp))
observed={}
totals=Counter()
template=(here/'live/template.py').read_text()
for year,row in zip(range(2020,2027),annual,strict=True):
    d=obs(str(year),template.replace('__AWARD_YEAR__',str(year)).encode())
    observed[year]=d
    c=Counter(d['counts'])
    assert d['award']==year and row['raw_multiset_sha256']==d['raw_multiset_sha256']
    assert c['admitted']==c['assigned']+c['no_role']
    assert c['computable_index']==c['computable_published']+c['computable_unpublished']
    assert c['computable_published']==d['stored_grades'] and d['stored_grades_without_admitted_key']==d['stored_power_without_admitted_key']==0
    assert c['bad_grade_identity']==c['bad_power_identity']==0
    assert all(b.get('null_mismatch',0)==0 for b in d['block_comparisons'].values())
    sub=[e for e in editions if int(e['award'])==year]
    assert len(sub)==len(d['editions']) and len(sub)==len({e['edition'] for e in sub})
    for e in sub:
        ec=Counter(d['editions'][e['edition']])
        assert all(ec[k]==int(e[k]) for k in fields)
    for k in fields:
        assert c[k]==sum(int(e[k]) for e in sub)==int(row[k])
    totals.update(c)
assert [totals[k] for k in ('admitted','no_role','computable_index','computable_published','computable_unpublished','score_gap_gt_001','score_gap_gt_01','score_gap_gt_1','changed_rounded_score')]==[2297613,615,2296998,2282580,14418,517588,122268,2713,50139]
calc=json.loads(subprocess.check_output([sys.executable,'-B',here/'2020-inputs/replay.py'],cwd=here))
assert calc==read(here/'2020-inputs/offline-result.json')
cf=obs('elo-counterfactual',(here/'elo-counterfactual/probe.py').read_bytes())
assert cf['raw_multiset_sha256']==observed[2022]['raw_multiset_sha256']
c=observed[2022]['counts'];m=cf['comparisons']
assert all(c[k]==m['current_vs_published'][k] for k in ('score_gap_gt_001','score_gap_gt_01','changed_rounded_score'))
assert cf['coverage']['rows_with_both_sides']==c['assigned'] and cf['coverage'].get('rows_abstaining_missing_historical_side',0)==0
assert m['stored_pair_vs_published']['different_contribution_f32']==m['stored_pair_vs_published']['score_gap_gt_001']==0
pw=obs('public-witnesses',(here/'public-witnesses/probe.py').read_bytes())
checked=0
by_id={(r[3],r[4]):dict(zip(pw['columns'],r)) for r in pw['rows']}
for item in read(here/'public-witnesses/comparison.json'):
    expected=observed[item['award']]['worst_score_gaps'][0]
    m_id,p_id=expected[1]
    assert (m_id,p_id)==(item['match_id'],item['player_id'])
    source=by_id[m_id,p_id]
    assert expected[5]==item['from_actual_inputs'] and expected[6]==item['published_at_scoring_read']
    raw=(here/'public-witnesses/http'/f"{item['award']}-response.json").read_bytes()
    meta=read(here/'public-witnesses/http'/f"{item['award']}-headers.json")
    row=json.loads(raw)['data']['row']
    assert meta['sha256']==h(raw) and meta['status']==200 and item['http']==200
    assert row['id']==source['match_key']+':'+source['player_key']
    assert row['grade']==item['served_grade'] and abs(float(row['grade'])-expected[6])<1e-5
    checked+=1
assert checked==6
print(json.dumps(dict(annual_reads=len(annual),award_edition_rows=len(editions),admitted=totals['admitted'],computed=totals['computable_index'],published=totals['computable_published'],greater_than_one=totals['score_gap_gt_1'],complete_2020_replay=calc['computed'],reconstructed_pairs_2022=cf['coverage']['rows_with_both_sides'],public_responses=checked,verified_files=len(read(here/'hashes.json')))))
