from collections import Counter, defaultdict
import hashlib
import heapq
import inspect
import json
import math
import struct
import time
from vega import power as p


def collect(db):
    begin = time.monotonic()
    year = 2024
    sha = lambda b: hashlib.sha256(b).hexdigest()
    def binary32(value):
        return None if value is None else struct.unpack('!f', struct.pack('!f', value))[0]

    module_hash = sha(inspect.getsource(p).encode())
    assert module_hash == '75d3b2a829b585d8dbadb60d1fb2a6b4233e7f74d220a0f76bab0ebb6fdb93ff'
    with db.transaction():
        db.execute('SET TRANSACTION ISOLATION LEVEL REPEATABLE READ READ ONLY')
        db.execute("SET LOCAL statement_timeout='300s'")
        meta = db.execute("SELECT current_database(),transaction_timestamp()::text,pg_current_snapshot()::text,current_setting('transaction_read_only'),current_setting('transaction_isolation')").fetchone()
        assert meta[0] == 'vega_v2' and meta[3:] == ('on','repeatable read')
        with db.cursor(name='counterfactual_inputs') as cur:
            cur.itersize = 3000
            cur.execute(p.PLAYER_MATCHES, ([year, year+1], *p.award_year(year)))
            names = [item.name for item in cur.description]
            rows = [{k:(v if k in p._KEPT else p._num(v)) for k,v in zip(names,row)} for row in cur]
        with db.cursor(name='counterfactual_historical_sides') as cur:
            cur.itersize = 4000
            cur.execute("""SELECT x.match_id,x.player_id,x.team_id,x.opponent_elo,x.contribution,x.match_index,g.z,g.role,g.minutes,m.home_team_id,m.away_team_id
                   FROM agg.player_power_matches x JOIN core.matches m ON m.id=x.match_id
                   LEFT JOIN agg.player_match_grades g ON (g.season_id,g.match_id,g.player_id)=(m.season_id,x.match_id,x.player_id) AND g.award_season=x.season_id
                   WHERE x.season_id=%s""",(year,))
            stored = {}
            sides = defaultdict(dict)
            teams = {}
            for match,player,team,oppo,c,z,g,role,minutes,home,away in cur:
                assert (match,player) not in stored
                stored[match,player] = (team,c,z,g,role,minutes)
                assert team in (home,away) and home != away
                assert sides[match].get(team,oppo) == oppo
                sides[match][team] = oppo
                teams[match] = (home,away)
        runs = db.execute("SELECT id,kind,season_id,method_version,started_at::text,finished_at::text FROM agg.power_runs WHERE status='published' AND (kind='elo' OR (kind='players' AND season_id=%s)) ORDER BY id",(year,)).fetchall()

    print('CHECKPOINT', 'read',len(rows),len(stored),round(time.monotonic()-begin,2),flush=True)
    def key(r):
        return (r['match_id'],r['player_id'])
    raw_sha = sha(b''.join(sorted(hashlib.sha256(json.dumps(list(r.values()),ensure_ascii=True,separators=(',',':'),allow_nan=False).encode()).digest() for r in rows)))
    key_count = len({key(r) for r in rows})
    assert key_count == len(rows)
    p.restore_zeros(rows)
    assigned = p.assign_roles(rows)
    del rows
    coverage = Counter()
    seen_m = set()
    pairs = {}
    for r in assigned:
        match, player = key(r)
        home, away = teams.get(match,(None,None))
        team = r['team_id']
        other = away if team==home else home if team==away else None
        saved_sides = sides.get(match,{})
        if r['team_id'] not in saved_sides or other not in saved_sides:
            coverage['rows_abstaining_missing_historical_side'] += 1
            continue
        if match not in seen_m:
            seen_m.add(match)
            coverage['matches_with_both_sides'] += 1
        old_own,old_oppo = saved_sides[other],saved_sides[team]
        pairs[match,team] = (old_own,old_oppo)
        coverage['rows_with_both_sides'] += 1
        if old_own is None or old_oppo is None:
            coverage['pair_has_null'] += 1
        if (old_own,old_oppo)!=(r['own_elo'],r['opponent_elo']):
            coverage['pair_changed_from_current'] += 1
    def fit(label):
        for r in assigned:
            own,opp = r['own_elo'],r['opponent_elo']
            if label=='stored_pair':
                own,opp = pairs.get((r['match_id'],r['team_id']),(own,opp))
            r['delta'] = 0.0 if own is None or opp is None else (opp-own)/400
        refs = p.references(assigned)
        contributions = [p.match_contribution(r,refs)[1] for r in assigned]
        gr = p.grade_references([(r['role'],r['competition_id'],r['minutes_played'],c) for r,c in zip(assigned,contributions)])
        return [(c,p.match_index(r['role'],r['competition_id'],c,gr)) for r,c in zip(assigned,contributions)]

    actual = fit('current')
    print('CHECKPOINT current',len(actual),round(time.monotonic()-begin,2),flush=True)
    old = fit('stored_pair')
    def compare(total,left,right):
        a,az = left
        b,bz = right
        total['rows'] += 1
        total['different_contribution_f32'] += int(binary32(a)!=binary32(b))
        total['different_index_f32'] += int(binary32(az)!=binary32(bz))
        if (a is None)!=(b is None):total['contribution_nulls_differ']+=1
        if (az is None)!=(bz is None):total['index_nulls_differ']+=1
        if a is not None and b is not None:total['contribution_abs_gt_1e-4']+=int(abs(a-b)>1e-4)
        if az is None or bz is None:return
        total['index_abs_gt_1e-4']+=int(abs(az-bz)>1e-4)
        sa,sb = p.score_of(az),p.score_of(bz)
        gap = abs(sa-sb)
        total['score_gap_gt_001']+=int(gap>0.01)
        total['score_gap_gt_01']+=int(gap>0.1)
        total['score_gap_gt_1']+=int(gap>1)
        total['changed_rounded_score']+=int(math.floor(sa+0.5)!=math.floor(sb+0.5))
        total['max_score_gap'] = max(total['max_score_gap'],gap)
        return gap

    summ=defaultdict(Counter)
    editions=defaultdict(lambda:defaultdict(Counter))
    extremes=[]
    for r,now,prior in zip(assigned,actual,old):
        k=key(r)
        ctr=summ['population']
        ctr['assigned']+=1
        if k not in stored:
            ctr['missing_power']+=1
            continue
        team,cs,zs,gs,gr,mins=stored[k]
        ctr['identity_diff']+=int((team,gr,mins)!=(r['team_id'],r['role'],int(r['minutes_played'])))
        comparisons={'current_vs_published':(now,(cs,gs)),'stored_pair_vs_published':(prior,(cs,gs)),'current_vs_stored_pair':(now,prior)}
        gaps={}
        for name,(a,b) in comparisons.items():
            gaps[name]=compare(summ[name],a,b)
            compare(editions[r['competition_season_id']][name],a,b)
        if None not in gaps.values():
            n0,n1=gaps['current_vs_published'],gaps['stored_pair_vs_published']
            ctr['closer_to_publication_by_over_001']+=int(n0-n1>0.01)
            ctr['farther_from_publication_by_over_001']+=int(n1-n0>0.01)
            item=(n0-n1,k,r['competition_season_id'],now[1],prior[1],gs)
            if len(extremes)<12:heapq.heappush(extremes,item)
            elif item>extremes[0]:heapq.heapreplace(extremes,item)
    print('CHECKPOINT finished',len(assigned),round(time.monotonic()-begin,2),flush=True)
    return dict(year=year,snapshot=meta,power_sha256=module_hash,raw_multiset_sha256=raw_sha,raw_count=key_count,stored_keys=len(stored),coverage=coverage,comparisons=summ,by_edition=editions,runs=runs,most_reconciled=sorted(extremes,reverse=True))
