import hashlib
import inspect
from vega import power as p


def collect(db):
    module = hashlib.sha256(inspect.getsource(p).encode()).hexdigest()
    assert module == '75d3b2a829b585d8dbadb60d1fb2a6b4233e7f74d220a0f76bab0ebb6fdb93ff'
    with db.transaction():
        db.execute('SET TRANSACTION ISOLATION LEVEL REPEATABLE READ READ ONLY')
        meta=db.execute("SELECT current_database(),transaction_timestamp()::text,pg_current_snapshot()::text,current_setting('transaction_read_only'),current_setting('transaction_isolation')").fetchone()
        assert meta[0]=='vega_v2' and meta[3:]==('on','repeatable read')
        with db.cursor(name='award_2020_archive_inputs') as cur:
            cur.execute(p.PLAYER_MATCHES,([2020,2021],*p.award_year(2020)))
            cols=[d.name for d in cur.description]
            rows=[[v if k in p._KEPT else p._num(v) for k,v in zip(cols,r)] for r in cur]
        persisted = db.execute("SELECT (SELECT count(*) FROM agg.player_match_grades WHERE award_season=2020),(SELECT count(*) FROM agg.player_power_matches WHERE season_id=2020)").fetchone()
    rows.sort(key=lambda r:(r[0],r[1]))
    return dict(module_sha256=module,query_sha256=hashlib.sha256(p.PLAYER_MATCHES.encode()).hexdigest(),snapshot=meta,columns=cols,inputs=rows,persisted=persisted)
