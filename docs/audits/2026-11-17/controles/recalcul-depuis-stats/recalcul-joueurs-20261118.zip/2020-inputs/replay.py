"""Offline replay of the entire first award on fixed, normalized source observations."""
import hashlib
import importlib.util
import json
import struct
import sys
import zlib
from collections import Counter, defaultdict
from pathlib import Path

folder = Path(__file__).resolve().parent
source = folder/'power.py' if len(sys.argv)==1 else Path(sys.argv[1])/'backend/vega/power.py'
packed = folder/'rds'/'inputs.json.zlib'
prior = folder.parent/'2020'/'rds'/'inputs.json.zlib'
def sha(b):
    return hashlib.sha256(b).hexdigest()
def read(p):
    return json.loads(zlib.decompress(p.read_bytes()))
def raw_bytes(r):
    return json.dumps(r,ensure_ascii=True,separators=(',',':'),allow_nan=False).encode()
def inspect_receipt(f):
    receipt=json.loads(f.with_name('receipt.json').read_text())
    assert sha(f.read_bytes()) == receipt['sha256'] and receipt['exit_code']==0
    return receipt['actual_image_digest']
assert inspect_receipt(packed)==inspect_receipt(prior)
d=read(packed)
baseline=read(prior)
assert sha(source.read_bytes())==d['module_sha256']==baseline['source_sha256']
mod=importlib.util.spec_from_file_location('vega_production_power',source)
p=importlib.util.module_from_spec(mod)
mod.loader.exec_module(p)
assert sha(p.PLAYER_MATCHES.encode())==d['query_sha256']==baseline['player_sql_sha256']
assert d['columns']==baseline['raw_column_order'] and d['persisted']==[0,0]
rows=[dict(zip(d['columns'],raw,strict=True)) for raw in d['inputs']]
signature=sha(b''.join(sorted(hashlib.sha256(raw_bytes(row)).digest() for row in d['inputs'])))
assert signature==baseline['raw_multiset_sha256']
per=defaultdict(Counter)
for r in rows:
    per[r['competition_season_id']]['admitted']+=1
    r['delta']=0.0 if r['own_elo'] is None or r['opponent_elo'] is None else (r['opponent_elo']-r['own_elo'])/400
p.restore_zeros(rows)
assigned=p.assign_roles(rows)
for r in rows:
    if not r['role']:per[r['competition_season_id']]['no_role']+=1
refs=p.references(assigned)
contributions=[p.match_contribution(r,refs)[1] for r in assigned]
gr=p.grade_references([(r['role'],r['competition_id'],r['minutes_played'],c) for r,c in zip(assigned,contributions)])
scores=[]
for r,c in zip(assigned,contributions):
    z=p.match_index(r['role'],r['competition_id'],c,gr)
    bucket=per[r['competition_season_id']]
    bucket['assigned']+=1
    if c is not None:bucket['contribution']+=1
    if z is not None:
        bucket['computable_index']+=1
        scores.append((r['match_id'],r['player_id'],r['team_id'],r['role'],r['edition'],r['competition_season_id'],int(r['minutes_played']),z))
    assert c is not None and z is not None
for eid,c in per.items():
    expected=baseline['editions'][str(eid)]
    assert all(c[k]==expected.get(k,0) for k in ('admitted','no_role','assigned','contribution','computable_index'))
assert set(per)=={int(k) for k in baseline['editions']}
assert len({(r[0],r[1]) for r in scores})==len(scores)
score_binary32=hashlib.sha256()
for row in sorted(scores):
    score_binary32.update(raw_bytes(row[:-1]))
    score_binary32.update(struct.pack('!f',row[-1]))
summary=dict(first_read=baseline['snapshot'][1],second_read=d['snapshot'][1],inputs=len(rows),assigned=len(assigned),missing_role=len(rows)-len(assigned),computed=len(scores),persisted=d['persisted'][0],editions=dict(sorted(per.items())),raw_multiset_sha256=signature,computed_grade_keys_and_binary32_sha256=score_binary32.hexdigest(),roles_used={k:v[0] for k,v in gr['roles'].items()})
print(json.dumps(summary,ensure_ascii=False,indent=2,sort_keys=True))
