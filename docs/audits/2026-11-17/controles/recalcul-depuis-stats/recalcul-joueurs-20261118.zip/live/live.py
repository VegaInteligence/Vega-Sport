"""Start one read-only diagnostic on the same deployed worker image in an authorized AWS environment."""
import argparse
from pathlib import Path
import sys

here=Path(__file__).resolve().parent
ap=argparse.ArgumentParser(description=__doc__)
ap.add_argument('award_or_probe',choices=[str(y) for y in range(2020,2027)]+['2020-inputs','elo-counterfactual','elo-context-2023','elo-context-2024','public-witnesses'])
ap.add_argument('new_directory',type=Path)
args=ap.parse_args()
from capture import main as capture_main
import capture
folder=args.new_directory.resolve()
folder.mkdir(parents=True,exist_ok=False)
template=(here/'template.py').read_text()
if args.award_or_probe.isdigit():
    script=template.replace('__AWARD_YEAR__',args.award_or_probe)
else:
    script=(here.parent/args.award_or_probe/'probe.py').read_text()
(folder/'probe.py').write_text(script)
capture.here=folder
sys.argv=[sys.argv[0],str(folder/'rds')]
capture_main()
