"""Read-only production snapshot. Run in a fresh directory so the attested run is preserved."""
import argparse
import base64
import hashlib
import json
from pathlib import Path
import sys
import time
import zlib

here = Path(__file__).resolve().parent
sys.path.insert(0,str(here.parents[1]))
from query_batch import aws, RUNTIME

def main():
    ap=argparse.ArgumentParser()
    ap.add_argument("output",type=Path)
    out=ap.parse_args().output
    out.mkdir(exist_ok=False,parents=True)
    probe=(here/"probe.py").read_bytes()
    packed=base64.b64encode(zlib.compress(probe,9)).decode()
    runtime=RUNTIME[:RUNTIME.index("queries=")]+RUNTIME[RUNTIME.index("with psycopg.connect"):RUNTIME.index(" for name,q")]
    runtime += """
 exec(zlib.decompress(base64.b64decode(PACKED)),globals())
 snapshot=collect(db)
 blob=zlib.compress(json.dumps(snapshot,default=str,ensure_ascii=True,separators=(',',':')).encode(),6)
 import hashlib
 print('META',len(blob),hashlib.sha256(blob).hexdigest(),flush=True)
 data=base64.b64encode(blob).decode()
 for i in range(0,len(data),32000): print('ROW',i,data[i:i+32000],flush=True)
 print('AUDIT_END',flush=True)
""".replace("PACKED",repr(packed))
    svc=aws("ecs","describe-services","--cluster","vega-v2","--services","vega-v2-worker")["services"][0]
    worker=aws("ecs","describe-task-definition","--task-definition",svc["taskDefinition"])["taskDefinition"]
    template=aws("ecs","describe-task-definition","--task-definition","vega-v2-diagnose")["taskDefinition"]
    spec={k:v for k,v in template.items() if k in ("networkMode","taskRoleArn","executionRoleArn","containerDefinitions","volumes","placementConstraints","requiresCompatibilities","cpu","memory","runtimePlatform","ephemeralStorage")}
    cn=spec["containerDefinitions"][0]
    assert len(spec["containerDefinitions"])==1 and cn["entryPoint"]==["python","-c"]
    image=worker["containerDefinitions"][0]["image"]
    assert image.endswith(":8018e0836ca0f32e8b2eb51fc2847154abff7f13"),image
    cn.update(image=image,command=[runtime])
    spec["family"]="vega-audit-readonly-vi27"
    definition=aws("ecs","register-task-definition","--cli-input-json",json.dumps(spec))["taskDefinition"]["taskDefinitionArn"]
    receipt=dict(worker_definition=svc["taskDefinition"],definition=definition,image=image,probe_sha256=hashlib.sha256(probe).hexdigest())
    def save(): (out/"receipt.json").write_text(json.dumps(receipt,indent=2)+"\n")
    save()
    task=None
    stopped=False
    try:
        launched=aws("ecs","run-task","--cluster","vega-v2","--task-definition",definition,"--launch-type","FARGATE","--started-by","vega-audit-vi27","--network-configuration",json.dumps(svc["networkConfiguration"]))
        assert not launched["failures"],launched["failures"]
        task=receipt["task"]=launched["tasks"][0]["taskArn"]
        save()
        for _ in range(150):
            status=aws("ecs","describe-tasks","--cluster","vega-v2","--tasks",task)["tasks"][0]
            stopped=status["lastStatus"]=="STOPPED"
            if stopped: break
            time.sleep(4)
        assert stopped, "diagnostic timed out"
        c=status["containers"][0]
        receipt.update(exit_code=c.get("exitCode"),actual_image_digest=c.get("imageDigest"),finished=status["stoppedAt"])
        save()
        opt=cn["logConfiguration"]["options"]
        stream=opt["awslogs-stream-prefix"]+"/"+cn["name"]+"/"+task.rsplit("/",1)[-1]
        token=None
        pieces={}
        end=False
        lines=[]
        size=expected_hash=None
        for _ in range(120):
            req=["logs","filter-log-events","--log-group-name",opt["awslogs-group"],"--log-stream-names",stream,"--no-paginate"]
            if token: req.extend(["--next-token",token])
            page=aws(*req)
            for event in page["events"]:
                s=event["message"]
                if s.startswith("ROW "):
                    _,i,data=s.split(" ",2)
                    pieces[int(i)]=data
                else:
                    lines.append(s)
                    if s.startswith("META "):
                        _,size,expected_hash=s.split()
                    if s=="AUDIT_END":end=True
            nxt=page.get("nextToken")
            if not nxt:break
            token=nxt
        (out/"checkpoints.txt").write_text("\n".join(lines)+"\n")
        assert receipt["exit_code"]==0 and end,lines[-10:]
        blob=base64.b64decode("".join(pieces[i] for i in sorted(pieces)),validate=True)
        assert len(blob)==int(size) and hashlib.sha256(blob).hexdigest()==expected_hash
        (out/"inputs.json.zlib").write_bytes(blob)
        receipt.update(bytes=len(blob),sha256=expected_hash,chunk_count=len(pieces))
    finally:
        if task and not stopped:
            aws("ecs","stop-task","--cluster","vega-v2","--task",task,"--reason","VI-27 diagnostic lifetime complete")
        receipt["definition_end_state"]=aws("ecs","deregister-task-definition","--task-definition",definition,"--query","taskDefinition.status")
        save()

if __name__=="__main__": main()
