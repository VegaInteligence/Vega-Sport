"""Run a finite batch of reviewed SELECT files in the existing private diagnostic task. No service changes."""
import argparse, base64, datetime, hashlib, json, os, pathlib, re, subprocess, sys, time, zlib
P=pathlib.Path(__file__).resolve().parent
RUNTIME = """import base64,zlib,json,os,sys,datetime,psycopg
def enc(x): return base64.b64encode(zlib.compress(json.dumps(x,default=str,ensure_ascii=False).encode(),9)).decode()
queries=json.loads(zlib.decompress(base64.b64decode(DATA)))
with psycopg.connect(host=os.environ['V2_DB_HOST'],dbname=os.environ['V2_DB_NAME'],user=os.environ['V2_DB_USER'],password=os.environ['V2_DB_PASSWORD'],sslmode='verify-full',sslrootcert='/app/rds-ca.pem',application_name='vega_audit_readonly',options='-c default_transaction_read_only=on -c statement_timeout=90000 -c lock_timeout=1500 -c max_parallel_workers_per_gather=0',autocommit=True) as db:
 for name,q in queries.items():
  try:
   with db.transaction():
    assert db.execute('show transaction_read_only').fetchone()[0]=='on'
    stamp=db.execute('select statement_timestamp(),current_database()').fetchone()
    c=db.execute(q); result={'at':str(stamp[0]),'database':stamp[1],'columns':[k.name for k in c.description],'rows':c.fetchall()}
  except Exception as err: result={'error':str(err),'type':type(err).__name__}
  data=enc(result)
  for i in range(0,len(data),9000): print('AUDIT '+name+' '+str(i)+' '+data[i:i+9000],flush=True)
print('AUDIT_END',flush=True)
"""
def aws(*args):
 out=subprocess.run(['aws','--region','us-east-2','--profile','statarena',*args,'--output','json'],capture_output=True,text=True,check=True).stdout
 return json.loads(out) if out.strip() else None
def main():
 ap=argparse.ArgumentParser();ap.add_argument('batch');ap.add_argument('sql',nargs='+',type=pathlib.Path);a=ap.parse_args()
 o=P/'db'/a.batch;o.mkdir(exist_ok=False,parents=True);qs={}
 for p in a.sql:
  q=p.read_text();s=re.sub(r'--[^\n]*','',q).strip().rstrip(';');assert re.match(r'(?i)^(select|with)\b',s) and ';' not in s and not re.search(r'(?i)\b(?:INSERT|DELETE|UPDATE|TRUNCATE|ALTER|DROP|CREATE|pg_sleep|pg_terminate_backend)\b',s),p
  assert p.stem not in qs;qs[p.stem]=s;(o/(p.stem+'.sql')).write_text(q)
 svc=aws('ecs','describe-services','--cluster','vega-v2','--services','vega-v2-worker')['services'][0]; network=svc['networkConfiguration']
 t=aws('ecs','describe-task-definition','--task-definition',os.environ.get('VEGA_READONLY_TASK_DEFINITION','vega-v2-diagnose'))['taskDefinition']; cn=t['containerDefinitions'][0]; assert cn['entryPoint']==['python','-c'] and t['status']=='ACTIVE'
 payload=base64.b64encode(zlib.compress(json.dumps(qs).encode(),9)).decode();code=RUNTIME.replace('base64.b64decode(DATA)','base64.b64decode('+repr(payload)+')')
 override=json.dumps({'containerOverrides':[{'name':cn['name'],'command':[code]}]});assert len(override)<8192,('split batch',len(override))
 launched=aws('ecs','run-task','--cluster','vega-v2','--task-definition',t['taskDefinitionArn'],'--launch-type','FARGATE','--started-by','vega-architecture-review','--network-configuration',json.dumps(network),'--overrides',override)
 assert not launched['failures'],launched['failures'];task=launched['tasks'][0]['taskArn'];tid=task.rsplit('/',1)[-1];receipt={'task':task,'definition':t['taskDefinitionArn'],'image':cn['image'],'query_sha256':{k:hashlib.sha256(v.encode()).hexdigest() for k,v in qs.items()}};(o/'receipt.json').write_text(json.dumps(receipt,indent=2));print(a.batch,tid,flush=True)
 for _ in range(160):
  st=aws('ecs','describe-tasks','--cluster','vega-v2','--tasks',task)['tasks'][0]
  if st['lastStatus']=='STOPPED': break
  time.sleep(5)
 else: raise RuntimeError('task still running, inspect receipt')
 if st['containers'][0].get('exitCode')!=0:
  receipt.update(exit_code=st['containers'][0].get('exitCode'),stoppedAt=st.get('stoppedAt'),reason=st.get('stoppedReason'));(o/'receipt.json').write_text(json.dumps(receipt,indent=2));raise RuntimeError(receipt['reason'])
 opt=cn['logConfiguration']['options'];stream=opt['awslogs-stream-prefix']+'/'+cn['name']+'/'+tid
 for attempt in range(8):
  ev=aws('logs','get-log-events','--log-group-name',opt['awslogs-group'],'--log-stream-name',stream,'--start-from-head')['events']; lines=[r['message'] for r in ev]
  if 'AUDIT_END' in lines:break
  time.sleep(3)
 chunks={};errs={}
 for line in lines:
  if line.startswith('AUDIT '):
   _,k,i,b=line.split(' ',3);chunks.setdefault(k,{})[int(i)]=b
 assert 'AUDIT_END' in lines,(st.get('stoppedReason'),[x[:200] for x in lines if not x.startswith('AUDIT ')][-6:])
 for k in qs:
  c=chunks[k];r=json.loads(zlib.decompress(base64.b64decode(''.join(c[i] for i in sorted(c)))));(o/(k+'.json')).write_text(json.dumps(r,ensure_ascii=False,indent=1)+'\n');print(k,'rows',len(r.get('rows',[])),r.get('error',''),flush=True)
  if 'error' in r:errs[k]=r['error']
 receipt.update(exit_code=st['containers'][0].get('exitCode'),sql_errors=errs,stoppedAt=st['stoppedAt']);(o/'receipt.json').write_text(json.dumps(receipt,indent=2));return int(bool(errs))
if __name__=='__main__':sys.exit(main())
