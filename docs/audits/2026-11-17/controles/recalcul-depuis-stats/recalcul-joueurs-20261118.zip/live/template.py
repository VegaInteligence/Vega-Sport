"""Read the official annual selection once, close its transaction, and compare the complete refit in memory."""
from collections import Counter, defaultdict
import hashlib
import heapq
import inspect
import json
import math
import struct
import time

from vega import power as p

AWARD = __AWARD_YEAR__

def collect(db):
    started=time.monotonic()
    def log(stage,n):
        print('CHECKPOINT',AWARD,stage,n,round(time.monotonic()-started,2),flush=True)
    def sha(b):
        return hashlib.sha256(b).hexdigest()
    def f32(value):
        return None if value is None else struct.unpack('!f',struct.pack('!f',value))[0]
    def key(r):
        return (r['match_id'],r['player_id'])
    def encode(v):
        return json.dumps(v,ensure_ascii=True,separators=(',',':'),allow_nan=False).encode()
    modhash=sha(inspect.getsource(p).encode())
    assert modhash=='75d3b2a829b585d8dbadb60d1fb2a6b4233e7f74d220a0f76bab0ebb6fdb93ff'
    with db.transaction():
        db.execute("SET TRANSACTION ISOLATION LEVEL REPEATABLE READ READ ONLY")
        db.execute("SET LOCAL statement_timeout='300s'")
        meta=db.execute("SELECT current_database(),transaction_timestamp()::text,pg_current_snapshot()::text,current_setting('transaction_read_only'),current_setting('transaction_isolation'),current_date").fetchone()
        assert meta[0]=='vega_v2' and meta[3:5]==('on','repeatable read')
        runs=db.execute("SELECT id,season_id,method_version,started_at::text,finished_at::text,matches,players FROM agg.power_runs WHERE kind='players' AND season_id IN (%s,%s) AND status='published' ORDER BY season_id",(AWARD-1,AWARD)).fetchall()
        refyear=p.grade_reference_year(AWARD,meta[-1])
        assert refyear in (AWARD,AWARD-1)
        oldrefs=p.read_grade_references(db,refyear) if refyear==AWARD-1 else None
        if refyear==AWARD-1 and not oldrefs:
            raise ValueError('Missing expected previous-year reference; explicit fallback replay required')
        with db.cursor(name='raw_refit_inputs') as cur:
            cur.itersize=3000
            cur.execute(p.PLAYER_MATCHES,([AWARD,AWARD+1],*p.award_year(AWARD)))
            names=[v.name for v in cur.description]
            rows=[{k:(value if k in p._KEPT else p._num(value)) for k,value in zip(names,record)} for record in cur]
        log('raw-read',len(rows))
        powers={}
        with db.cursor(name='raw_refit_persisted_blocks') as cur:
            cur.itersize=4000
            cur.execute(f"SELECT match_id,player_id,team_id,role,minutes,opponent_elo,{', '.join(p.BLOCK_COLUMNS)},contribution,match_index FROM agg.player_power_matches WHERE season_id=%s",(AWARD,))
            for match,player,*record in cur:
                assert (match,player) not in powers
                powers[match,player]=tuple(record)
        grades={}
        with db.cursor(name='raw_refit_publication') as cur:
            cur.itersize=4000
            cur.execute("SELECT match_id,player_id,team_id,role,minutes,season_id,z,run_id FROM agg.player_match_grades WHERE award_season=%s",(AWARD,))
            for match,player,*record in cur:
                assert (match,player) not in grades
                grades[match,player]=tuple(record)
    log('closed-read-transaction',len(grades))
    raw_count=len(rows)
    per=defaultdict(Counter); totals=Counter(); blocks=defaultdict(Counter);raw_keys=set()
    hashes=[];examples=heapq.nsmallest(5,rows,key=key)
    raw_examples=[dict(r) for r in examples]
    for r in rows:
        k=key(r)
        if k in raw_keys:raise ValueError(f'Duplicate input rows in award {AWARD}: {k}')
        raw_keys.add(k)
        hashes.append(hashlib.sha256(encode(list(r.values()))).digest())
        per[r['competition_season_id']]['admitted']+=1
        r['delta']=0.0 if r['own_elo'] is None or r['opponent_elo'] is None else (r['opponent_elo']-r['own_elo'])/400
    raw_sha=sha(b''.join(sorted(hashes)))
    del hashes
    orphan_grade=len(grades.keys()-raw_keys);orphan_power=len(powers.keys()-raw_keys)
    del raw_keys
    p.restore_zeros(rows)
    assigned=p.assign_roles(rows)
    for r in rows:
        if not r['role']:
            assert key(r) not in grades or grades[key(r)][1] is not None
            per[r['competition_season_id']]['no_role']+=1
            if key(r) in grades:per[r['competition_season_id']]['graded_despite_no_replayed_role']+=1
    log('fit-begin',len(assigned))
    localrefs=p.references(assigned)
    del rows
    calculated=[];reference_inputs=[];worst_c=[]
    for r in assigned:
        scores,c=p.match_contribution(r,localrefs);k=key(r);eid=r['competition_season_id']
        ctr=per[eid];ctr['assigned']+=1
        if c is None:ctr['no_contribution']+=1
        else:ctr['contribution']+=1
        stored=powers.get(k)
        if stored is None:
            ctr['no_power']+=1
        else:
            ctr['has_power']+=1
            if (r['team_id'],r['role'],int(r['minutes_played']))!=stored[:3]:ctr['bad_power_identity']+=1
            if f32(r['opponent_elo'])!=f32(stored[3]):ctr['opponent_elo_changed']+=1
            for j,col in enumerate(p.BLOCK_COLUMNS):
                observed=stored[4+j];v=scores.get(col);bucket=blocks[col]
                if v is not None:bucket['computed']+=1
                if observed is not None:bucket['stored']+=1
                if (v is None)!=(observed is None):bucket['null_mismatch']+=1
                if f32(v)!=f32(observed):bucket['different_binary32']+=1
            pc=stored[-2];ctr['equal_contribution_f32']+=int(f32(c)==f32(pc))
            if (c is None)!=(pc is None):ctr['contribution_null_disagreement']+=1
            if c is not None and pc is not None:
                diff=abs(float(c)-float(pc))
                ctr['contribution_abs_gt_1e-4']+=int(diff>1e-4)
                item=(diff,k,float(c),float(pc))
                if len(worst_c)<10:heapq.heappush(worst_c,item)
                elif item>worst_c[0]:heapq.heapreplace(worst_c,item)
        reference_inputs.append((r['role'],r['competition_id'],r['minutes_played'],c))
        calculated.append((k,r['team_id'],r['role'],int(r['minutes_played']),r['edition'],eid,r['competition_id'],c))
    del assigned
    refs=oldrefs if oldrefs is not None else p.grade_references(reference_inputs)
    del reference_inputs
    log('annual-refit',len(calculated))
    worst=[];role_ref_counts={role:vals[0] for role,vals in refs['roles'].items()}
    for k,team,role,minutes,partition,eid,comp,c in calculated:
        z=p.match_index(role,comp,c,refs);g=grades.get(k);ctr=per[eid]
        if z is None:
            ctr['no_index']+=1
            if g:ctr['published_despite_null_index']+=1
            continue
        assert math.isfinite(z);ctr['computable_index']+=1
        if g is None:ctr['computable_unpublished']+=1;continue
        gt,gr,gm,gy,stored_z,run=g;ctr['computable_published']+=1
        if (team,role,minutes,partition)!=(gt,gr,gm,gy):ctr['bad_grade_identity']+=1
        if stored_z is None:ctr['published_null_index']+=1;continue
        pi=powers.get(k)
        if pi and f32(pi[-1])!=f32(z):ctr['power_index_diff_f32']+=1
        diff_z=abs(z-stored_z)
        ctr['grade_index_eq_f32']+=int(f32(z)==f32(stored_z))
        ctr['grade_index_abs_gt_1e-4']+=int(diff_z>1e-4)
        score=p.score_of(z);official=p.score_of(stored_z);gap=abs(score-official)
        ctr['score_gap_gt_001']+=int(gap>0.01);ctr['score_gap_gt_01']+=int(gap>0.1)
        ctr['score_gap_gt_1']+=int(gap>1)
        ctr['changed_rounded_score']+=int(math.floor(score+0.5)!=math.floor(official+0.5))
        item=(gap,k,partition,eid,role,score,official,run)
        if len(worst)<18:heapq.heappush(worst,item)
        elif item>worst[0]:heapq.heapreplace(worst,item)
    for value in per.values():totals.update(value)
    assert totals['admitted']==raw_count and totals['admitted']==totals['assigned']+totals['no_role']
    assert totals['computable_index']==totals['computable_unpublished']+totals['computable_published']
    log('finished',dict(totals))
    return dict(award=AWARD,snapshot=meta,source_sha256=modhash,player_sql_sha256=sha(p.PLAYER_MATCHES.encode()),raw_multiset_sha256=raw_sha,raw_column_order=names,raw_examples=raw_examples,
                counts=totals,editions=dict(sorted(per.items())),block_comparisons=blocks,stored_grades=len(grades),stored_intermediates=len(powers),
                stored_grades_without_admitted_key=orphan_grade,stored_power_without_admitted_key=orphan_power,
                reference_year=refyear,used_saved_previous=oldrefs is not None,full_match_reference_observations=role_ref_counts,
                runs=runs,worst_score_gaps=sorted(worst,reverse=True),worst_contribution_gaps=sorted(worst_c,reverse=True),
                wall_seconds=round(time.monotonic()-started,2))
