# Une correction en 2024/25 laisse les notes 2021/22 en retard

**Sur PostgreSQL 18.6, la passe quotidienne réelle réécrit les 320 côtés Elo de 2021/22 et conserve les 320 notes historiques.** Pour 298 côtés, la valeur de l’Elo d’avant-match change. Une fois 2021/22 recalculée explicitement, 245 notes changent, dont 96 à l’entier. Le plus grand écart est de 2,016111 points sur 100. Le témoin sans correction produit zéro changement de note. Deux montages indépendants retrouvent les mêmes comptes, les mêmes coefficients et les mêmes écarts numériques. [Résultats](result.json) · [Comparaison des 320 participations](comparaison-320.csv) · [Second montage](repetition-result.json)

## Ce qui a été modifié

Le jeu synthétique déterministe comprend deux années non adjacentes, 2021/22 et 2024/25. Seize clubs disputent deux championnats nationaux et un tournoi interligues. Chaque année compte 112 matchs nationaux, 48 interligues et 320 participations mesurées de 90 minutes. Le rôle et les tirs cadrés sont enregistrés pour un avant-centre de chaque côté. La génération des statistiques utilise l’identité des équipes et du match, indépendamment du calcul Vega de l’Elo. Les deux ligues sont liées dans les deux branches. [Générateur](fixture.py)

Le match interligues 4160 du **31 mars 2025** entre les clubs 16 et 3 passe de 2–1 à 1–2. La nouvelle version arrive en base le **18 novembre 2026 à 08:49:37 UTC**, par `Store.save_matches` avec une entrée de famille normalisée. La révision passe de 1 à 2. La comparaison des 320 fiches de match des deux saisons détecte cette seule modification. Les empreintes des statistiques des deux années, équipes, joueurs, compétitions et identifiants sont stables. Les feuilles, événements, statistiques avancées et couvertures 2021/22 sont aussi contrôlés. La version reste `power-ranking-v8`. [Instrumentation et requêtes](run.py) · [Empreintes des valeurs](empreintes-valeurs.json)

## Ce que fait le worker

| Étape | Saisons choisies par le worker | Elo global publié | Publication joueur 2021 | Notes 2021 différentes du départ |
| --- | --- | ---: | ---: | ---: |
| Premier `Worker.daily` | 2024, 2021 | 1 | 3 | 0 |
| Passe sans changement | aucune | 1 | 3 | 0 |
| Correction reçue, avant la temporisation | aucune | 1 | 3 | 0 |
| Passe après la temporisation | 2024 | 4 | 3 | 0 |
| Nouvelle passe normale | aucune | 4 | 3 | 0 |
| `refresh_players(2021)` explicite | appel ciblé | 4 | 6 | 245 |
| Même recalcul explicite répété | appel ciblé | 4 | 7 | 245 |

Toutes les lectures, écritures de publications et comparaisons de date SQL sont réelles. Le worker utilise son horloge habituelle pour l’amorçage et la première passe après réception. Son paramètre public `clock` est ensuite avancé de sept heures, soit 15:49 UTC le même 18 novembre, pour simuler l’expiration de la temporisation de six heures des saisons passées. PostgreSQL continue d’horodater les écritures à 08:49 UTC. Aucun marqueur `updated_at`, aucune version et aucune liste de saisons dues n’ont été écrits à la main. Les sources réseau et les copies de médias sont désactivées. Le chemin quotidien exécute ses autres étapes locales. [Horloges et sélections](capture/run.json) · [Journal du passage après expiration](capture/normal_due.log)

Le niveau initial de la première ligue reste 1 541,7124. Celui de la seconde passe de 1 458,2876 à 1 447,8325. Le modèle mondial ajuste ses niveaux de ligue avec les rencontres entre ligues, puis déroule les matchs dans l’ordre avec ces niveaux initiaux. Un résultat de 2025 peut donc modifier les entrées Elo d’un match de 2021 dans le recalcul d’aujourd’hui. Les 320 lignes Elo 2021 portent le nouvel identifiant, 298 valeurs avant et 306 valeurs après changent. L’écart maximal d’Elo avant est de 10,4551. Le marqueur des modèles 2021 et la publication joueur 3 restent identiques pendant cette passe. [Attendus consignés avant le montage](attendus.md) · [Valeurs et numéros de publication](result.json)

## Mesure des notes et limite historique

Le lecteur `PLAYER_MATCHES`, l’attribution des rôles et les références déployées ont fourni 320 observations pour l’indicateur tirs cadrés, au-dessus du minimum de 200. L’ajustement initial observe 297 différences Elo distinctes. Son coefficient Poisson passe de **−1,135431 à −1,063166**. Le lecteur hors ligne compare aussi, clé par clé, le résultat que donneraient les entrées du moment au `z` publié. L’écart excède le seuil d’écriture de 0,0001 pour zéro clé à la publication initiale, 245 après la passe quotidienne, puis zéro après le recalcul historique. [Requête et appel des méthodes exactes](run.py) · [Comparateur](verify.py)

Le rattrapage actualise les 320 contributions et 245 indices de match. Les **245 valeurs exposées par la vue SQL `api.match_grades`** changent également au dixième et 96 changent à l’entier le plus proche. Il s’agit d’une mesure de la vue SQL locale. Au match 1006, le joueur 14 descend de 77,522295 à 75,506185. Son `z` passe de 2,150699 à 1,955704. `first_z` et `graded_at` sont conservés sur toutes les clés, `changed_at` évolue pour les 245 mises à jour. Les éditions et les 320 clés sont identiques avant et après. Le second recalcul publie un nouveau run historique et conserve toutes les valeurs et tous les horodatages des notes. [Détail des 320 clés](comparaison-320.csv)

La branche témoin est une copie PostgreSQL du même état initial, créée avant toute correction. Sa passe normale après sept heures ne sélectionne aucune saison. En imposant le même nombre de calculs Elo et un recalcul joueur sans modifier aucun score, la seconde résolution numérique déplace 150 Elo avant de **0,0002 au maximum** et 278 contributions de **0,0000021 au maximum**. Elle conserve tous les indices et toutes les notes. La branche corrigée et la branche témoin diffèrent encore sur 245 notes après recalcul. Les numéros de run se lisent dans chaque base séparément. [Comparaison témoin et traitement](result.json)

La première publication reproduit les données alors disponibles dans cette expérience à mieux que 0,00000016 en `z`. Le résultat établit un défaut de convergence **après réception** de la correction tardive. Le match de 2025 était encore futur durant les matchs de 2021/22. L’expérience ne reconstitue ni l’état d’une publication de production, ni ce que l’application connaissait en 2021. Elle ne donne pas une fréquence applicable aux notes réelles.

## Reproduire

Le vérificateur hors ligne utilise la bibliothèque standard Python et les instantanés compressés. Depuis ce dossier, ces commandes vérifient les deux mesures et reconstruisent la table par clé.

```sh
python3 -B verify.py capture
python3 -B verify.py repetition --compare capture
python3 -B details.py capture .
```

Pour un nouveau montage local, le conteneur PostgreSQL 18 déjà démarré par l’audit sous Colima doit écouter sur `127.0.0.1:55439`. Le script vérifie l’adresse exacte et la version du serveur, extrait au moyen de `git archive` le backend du commit `8018e0836ca0f32e8b2eb51fc2847154abff7f13`, applique ses migrations à une base neuve, clone le témoin, puis supprime exclusivement les deux bases créées pour le test. La commande suivante choisit un nouveau répertoire de sortie. Le premier argument Git peut pointer vers tout clone détenant l’objet.

```sh
E=/Users/lemonnierhugo/.codex/visualizations/2026/11/17/01a1e6f1-9c43-7b81-a52e-3ee15c953578/production-architecture-review
W='/Users/lemonnierhugo/Developer/Coding Project/Vega-Sport-audit-tracks-20261117/5-players'
cd "$E/tracks/5-players/raw-refit/elo-scheduler-local"
"$E/ci-clean/bin/python" -B run.py "$W" nouveau-rejeu
python3 -B verify.py nouveau-rejeu --compare capture
```

Deux essais préparatoires ont échoué avant le premier calcul, faute de pays dans le jeu d’essai, puis de récepteur du callback du client. Ces deux préconditions de montage ont été corrigées. Un troisième essai a traversé le parcours entier, puis les captures finales ont ajouté le calcul indépendant des 320 indices attendus et les empreintes des données partagées. [Échec de contrainte](essai-1.log) · [Échec d’initialisation](essai-2.log)
