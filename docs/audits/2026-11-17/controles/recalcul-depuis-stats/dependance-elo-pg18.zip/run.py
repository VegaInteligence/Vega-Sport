"""End-to-end worker experiment on committed source and two disposable PG18 databases."""
import argparse
import contextlib
import csv
from datetime import datetime,timedelta,timezone
import gzip
import hashlib
import io
import json
from pathlib import Path
import subprocess
import sys
import tarfile
import tempfile
import uuid
from types import SimpleNamespace
import psycopg
from psycopg import sql
from fixture import seed

HERE=Path(__file__).resolve().parent
DEPLOY='8018e0836ca0f32e8b2eb51fc2847154abff7f13'
BASE='postgresql://postgres@127.0.0.1:55439/'
OLD=2021
NEW=2024
def enc(o):
    return json.dumps(o,sort_keys=True,default=str,separators=(',',':')).encode()
def sha(o):return hashlib.sha256(enc(o)).hexdigest()
def records(cur):
    keys=[d.name for d in cur.description]
    return [dict(zip(keys,row,strict=True)) for row in cur.fetchall()]

def snapshot(db,power):
    q=lambda s,*params: records(db.execute(s,params))
    tables={'matches':q('SELECT * FROM core.matches WHERE season_id=%s ORDER BY id',OLD),
            'stats':q('SELECT * FROM core.player_match_stats WHERE season_id=%s ORDER BY match_id,player_id',OLD),
            'coverage':q('SELECT * FROM core.match_coverage WHERE season_id=%s ORDER BY match_id',OLD),
            'lineups':q('SELECT * FROM core.lineups WHERE season_id=%s ORDER BY match_id,team_id',OLD),
            'lineup_players':q('SELECT * FROM core.lineup_players WHERE season_id=%s ORDER BY match_id,player_id',OLD),
            'advanced':q('SELECT * FROM core.player_match_advanced WHERE season_id=%s ORDER BY match_id,player_id',OLD),
            'events':q('SELECT * FROM core.match_events WHERE season_id=%s ORDER BY match_id,seq',OLD)}
    x={'raw_fingerprint':{k:[len(v),sha(v)] for k,v in tables.items()}}
    x['corrected']=q('SELECT id,season_id,competition_season_id,match_date,home_team_id,away_team_id,home_score,away_score,revision,updated_at FROM core.matches ORDER BY kickoff_at DESC,id DESC LIMIT 1')[0]
    x['levels']=q('SELECT competition_id,entry_level,linked FROM agg.league_levels ORDER BY 1')
    x['runs']=q("""SELECT id,kind,season_id,method_version,status,matches,players,linked_leagues,started_at,finished_at
                FROM agg.power_runs ORDER BY id""")
    x['watermarks']=q("""SELECT cohort_definition AS scope, max(started_at) AS levels_at FROM agg.calc_runs WHERE kind='levels' AND status='published' GROUP BY 1 ORDER BY 1""")
    x['stale']=power.stale_rankings(db)
    x['elo']=q('SELECT match_id,team_id,elo_before,elo_after,expected,result,run_id FROM agg.team_elo WHERE season_id=%s ORDER BY 1,2',OLD)
    x['power']=q("""SELECT match_id,player_id,role,minutes,opponent_elo,contribution,match_index,run_id
                 FROM agg.player_power_matches WHERE season_id=%s ORDER BY 1,2""",OLD)
    x['grades']=q("""SELECT g.match_id,g.player_id,g.z,g.first_z,g.ref_season,g.run_id,g.graded_at,g.changed_at,v.grade
         FROM agg.player_match_grades g JOIN api.match_grades v ON v.match_key=g.match_id AND v.player_id=api.public_id('player', g.player_id)
         WHERE award_season=%s ORDER BY 1,2""",OLD)
    x['refs_hash']={}
    for t in ['roles','spreads','quantiles']:
        values=q(f'SELECT * FROM agg.match_grade_{t} WHERE ref_season=%s ORDER BY 1,2,3',OLD)
        x['refs_hash'][t]=[len(values),sha(values)]
    x['all_match_fingerprints']={r['id']:sha(r) for r in q('SELECT * FROM core.matches ORDER BY id')}
    x['shared_input_fingerprints']={name:sha(q('SELECT * FROM core.'+name+' ORDER BY '+order))
        for name,order in [('teams','id'),('players','id'),('competitions','id'),('competition_seasons','id'),
                           ('player_match_stats','season_id,match_id,player_id'),('provider_ids','entity_type,entity_id,provider,provider_key')]}
    start,end=power.award_year(OLD)
    assert power.grade_reference_year(OLD, db.execute('SELECT current_date').fetchone()[0])==OLD
    raw=q(power.PLAYER_MATCHES,[OLD,OLD+1],start,end)
    converted=[{k:(v if k in power._KEPT else power._num(v)) for k,v in row.items()} for row in raw]
    for r in converted:
        r['delta']=(r['opponent_elo']-r['own_elo'])/400
    power.restore_zeros(converted)
    fit_rows=power.assign_roles(converted)
    assert all(r['role']=='centre_forward' for r in fit_rows)
    observations=[(r['shots_on_target'],r['minutes_played']/90,r['delta']) for r in fit_rows]
    fitted=power.fit_poisson(observations)
    x['shots_fit']={'n':len(observations),'alpha_beta':fitted,
             'distinct_delta':len({r[2] for r in observations}), 'min_fit':power.MIN_FIT}
    refs=power.references(fit_rows);expect,_=refs['centre_forward','shots_on_target']
    from math import exp
    assert all(abs(expect(r)-(r['minutes_played']/90)*exp(fitted[0]+fitted[1]*r['delta']))<1e-10 for r in fit_rows)
    scored=[(r['role'],r['competition_id'],r['minutes_played'],power.match_contribution(r,refs)[1]) for r in fit_rows]
    current=power.grade_references(scored)
    x['preview']=sorted([dict(match_id=r['match_id'],player_id=r['player_id'],contribution=c,
              z=power.match_index(role,competition,c,current)) for r,(role,competition,_,c) in zip(fit_rows,scored)],
              key=lambda r:(r['match_id'],r['player_id']))
    return x

def main():
    ap=argparse.ArgumentParser();ap.add_argument('repo',type=Path);ap.add_argument('output',type=Path);args=ap.parse_args()
    out=args.output.resolve();assert out.is_relative_to(HERE) and out!=HERE;out.mkdir(exist_ok=False)
    port=subprocess.check_output(['docker','--context','colima','port','vega-vi27-audit-ci-pg18','5432/tcp'],text=True).strip()
    assert port=='127.0.0.1:55439'
    archive=subprocess.check_output(['git','-C',str(args.repo.resolve()),'archive',DEPLOY,'backend'])
    admin=psycopg.connect(BASE+'postgres',autocommit=True)
    assert admin.execute("SELECT current_setting('server_version_num')::int / 10000").fetchone()==(18,)
    created=[]
    try:
        with tempfile.TemporaryDirectory(dir=HERE,prefix='source-') as sd:
            with tarfile.open(fileobj=io.BytesIO(archive)) as tar: tar.extractall(sd,filter='data')
            sys.path.insert(0,str(Path(sd)/'backend'))
            from vega import models,power,store,worker
            from vega.normalize import NormalizedFamily
            meta={'release':DEPLOY,'source_files':{n:hashlib.sha256((Path(sd)/'backend/vega'/f'{n}.py').read_bytes()).hexdigest()
                    for n in ['models','power','worker','store']},'pg':admin.execute('SHOW server_version').fetchone()[0],
                    'port':port,'worker_clock_offset_hours_when_mature':7,'stages':{}}
            assert meta['source_files']['power']=='75d3b2a829b585d8dbadb60d1fb2a6b4233e7f74d220a0f76bab0ebb6fdb93ff'
            make=lambda label:'vega_v2_elo_sched_'+label+'_'+uuid.uuid4().hex
            primary=make('case');negative=make('control')
            def create(n,template=None):
                cmd=sql.SQL('CREATE DATABASE {}').format(sql.Identifier(n))
                if template:cmd+=sql.SQL(' TEMPLATE {}').format(sql.Identifier(template))
                admin.execute(cmd);created.append(n)
            def stage(n,db):
                s=snapshot(db,power)
                (out/(n+'.json.gz')).write_bytes(gzip.compress(enc(s),mtime=0))
                meta['stages'][n]={'observed_db_utc':str(db.execute('SELECT clock_timestamp()').fetchone()[0]),'state_sha':sha(s)}
            def daily(n,db,wr):
                before=wr.clock()
                buf=io.StringIO()
                with contextlib.redirect_stdout(buf):ran=wr.daily()
                (out/(n+'.log')).write_text(buf.getvalue())
                assert 'error=' not in buf.getvalue() and not wr._retry_at,(n,buf.getvalue(),wr._retry_at)
                meta.setdefault('daily',{})[n]={'clock_utc':str(before),'due':ran}
                return ran
            create(primary)
            with contextlib.closing(store.connect_local(BASE+primary)) as db:
                store.migrate(db);book=store.Store(db);last=seed(db,book)
                wr=worker.Worker(book,SimpleNamespace())
                assert daily('baseline',db,wr)==[NEW,OLD]
                stage('baseline',db)
                assert daily('initial_idle',db,wr)==[]
                stage('initial_idle',db)
            create(negative,primary)
            with contextlib.closing(store.connect_local(BASE+negative)) as db:
                wr=worker.Worker(store.Store(db),SimpleNamespace(),clock=lambda:datetime.now(timezone.utc)+timedelta(hours=7))
                assert daily('control_idle',db,wr)==[]
                stage('control_idle',db)
                power.refresh_elo(db)
                stage('control_after_elo',db)
                power.refresh_players(db,OLD)
                stage('control_after_refit',db)
            with contextlib.closing(store.connect_local(BASE+primary)) as db:
                book=store.Store(db);wr=worker.Worker(book,SimpleNamespace())
                assert (last['year'],last['home_score'],last['away_score'])==(NEW,2,1)
                book.save_matches(NormalizedFamily(rows={'core.matches':[dict(id=f"m_{last['id']:06}",home_score=1,away_score=2)]}),last['edition'])
                stage('correction_received',db)
                assert daily('before_deadline',db,wr)==[]
                stage('before_deadline',db)
                wr.clock=lambda:datetime.now(timezone.utc)+timedelta(hours=7)
                assert daily('normal_due',db,wr)==[NEW]
                stage('normal_due',db)
                assert daily('normal_repeat',db,wr)==[]
                stage('normal_repeat',db)
                power.refresh_players(db,OLD)
                stage('explicit_historical',db)
                power.refresh_players(db,OLD)
                stage('explicit_repeat',db)
                assert daily('final_idle',db,wr)==[]
            meta['fixture_counts']={'years':[OLD,NEW],'clubs':16,'forwards':16,'domestic_leagues':2,'interleague_tournament':1}
            (out/'run.json').write_text(json.dumps(meta,indent=2,default=str)+'\n')
    finally:
        for n in reversed(created):
            assert n.startswith('vega_v2_elo_sched_')
            admin.execute(sql.SQL('DROP DATABASE {}').format(sql.Identifier(n)))
        admin.close()

if __name__=='__main__':main()
