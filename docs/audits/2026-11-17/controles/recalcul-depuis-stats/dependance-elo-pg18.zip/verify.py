"""Offline comparison of value, version and time, indexed by match and player/team."""
import argparse
import csv
import gzip
import hashlib
import json
import math
from collections import Counter
from pathlib import Path

D=Path(__file__).resolve().parent
def sha(x):
    return hashlib.sha256(json.dumps(x,sort_keys=True,separators=(',',':')).encode()).hexdigest()
def read(folder):
    meta=json.loads((folder/'run.json').read_bytes())
    values={}
    for n,info in meta['stages'].items():
        raw=gzip.decompress((folder/(n+'.json.gz')).read_bytes())
        assert hashlib.sha256(raw).hexdigest()==info['state_sha']
        values[n]=json.loads(raw)
    return meta,values
def mapping(rows,t):
    k='team_id' if t=='elo' else 'player_id'
    out={(r['match_id'],r[k]):r for r in rows}
    assert len(out)==len(rows)==320
    return out
def cols(a,b,t,col):
    x,y=mapping(a[t],t),mapping(b[t],t)
    assert x.keys()==y.keys()
    return [y[k][col]-x[k][col] for k in sorted(x)]
def measure(ds):
    return dict(changed=sum(v!=0 for v in ds),over_1e4=sum(abs(v)>1e-4 for v in ds),max_abs=max(map(abs,ds)))
def comparisons(a,b):
    out={t+'.'+k:measure(cols(a,b,t,k)) for t,ks in [('elo',('elo_before','elo_after','run_id')),
          ('power',('opponent_elo','contribution','match_index','run_id')),('grades',('z','first_z','grade','run_id'))] for k in ks}
    out['rounded_grade']=sum(math.floor(x['grade']+.5)!=math.floor(y['grade']+.5) for x,y in zip(a['grades'],b['grades']))
    out['one_decimal_grade']=sum(math.floor(10*x['grade']+.5)!=math.floor(10*y['grade']+.5) for x,y in zip(a['grades'],b['grades']))
    out['first_graded_at_changed']=sum(x['graded_at']!=y['graded_at'] for x,y in zip(a['grades'],b['grades']))
    out['last_changed_at_changed']=sum(x['changed_at']!=y['changed_at'] for x,y in zip(a['grades'],b['grades']))
    return out
def dynamics(s):
    g=mapping(s['grades'],'grades');preview=mapping(s['preview'],'preview')
    return measure([preview[k]['z']-g[k]['z'] for k in g])
def active(s):
    return {('elo' if r['kind']=='elo' else 'players_'+str(r['season_id'])):r['id'] for r in s['runs'] if r['status']=='published'}
def make(folder):
    m,ss=read(folder);base=ss['baseline'];change=ss['normal_due'];report=ss['explicit_historical'];ctrl=ss['control_after_refit']
    assert all(s['raw_fingerprint']==base['raw_fingerprint'] for s in ss.values())
    assert all(s['shared_input_fingerprints']==base['shared_input_fingerprints'] for s in ss.values())
    target=str(change['corrected']['id'])
    for n,s in ss.items():
        expected=set() if n in ['baseline','initial_idle','control_idle','control_after_elo','control_after_refit'] else {target}
        assert {k for k in s['all_match_fingerprints'] if s['all_match_fingerprints'][k]!=base['all_match_fingerprints'][k]}==expected
        assert len(s['all_match_fingerprints'])==320
        assert s['stale']==[] and s['shots_fit']['n']==320 and s['shots_fit']['distinct_delta']>1
        assert s['shots_fit']['min_fit']==200 and abs(s['shots_fit']['alpha_beta'][1])>1e-6
        assert len({r['method_version'] for r in s['runs']})==1
    assert m['daily']['baseline']['due']==[2024,2021] and m['daily']['normal_due']['due']==[2024]
    assert all(x['due']==[] for k,x in m['daily'].items() if k not in ('normal_due','baseline'))
    assert base['corrected']['revision']+1==change['corrected']['revision'] and base['corrected']['updated_at']<change['corrected']['updated_at']
    for k in ('elo','power','grades','refs_hash','levels','runs'):
        assert base[k]==ss['initial_idle'][k]==ss['control_idle'][k]==ss['correction_received'][k]==ss['before_deadline'][k]
        assert change[k]==ss['normal_repeat'][k]
    assert active(base)['players_2021']==active(change)['players_2021']!=active(report)['players_2021']
    assert active(change)['elo']==active(report)['elo']!=active(base)['elo']
    assert active(base)['players_2024']!=active(change)['players_2024']
    assert base['power']==change['power'] and base['grades']==change['grades'] and base['refs_hash']==change['refs_hash']
    assert base['refs_hash']!=report['refs_hash']
    assert change['elo']==report['elo'] and all(s['grades']==base['grades'] for s in (ss['control_idle'],ss['control_after_elo'],ctrl))
    assert max(abs(v) for v in cols(base,change,'elo','elo_before'))>1
    assert dynamics(base)['over_1e4']==dynamics(ctrl)['over_1e4']==dynamics(report)['over_1e4']==0
    assert dynamics(change)['over_1e4']>0 and comparisons(change,report)['grades.z']['changed']>0
    assert report['grades']==ss['explicit_repeat']['grades']
    steps={'normal_vs_original':comparisons(base,change),'explicit_vs_normal':comparisons(change,report),
           'end_vs_control':comparisons(ctrl,report),'control_vs_original':comparisons(base,ctrl),
           'second_refit_vs_first':comparisons(report,ss['explicit_repeat'])}
    x=mapping(base['grades'],'grades');y=mapping(report['grades'],'grades')
    biggest=max(x,key=lambda k:abs(y[k]['grade']-x[k]['grade']))
    fp={n:{t:sha(ss[n][t]) for t in ('elo','power','grades','refs_hash')} for n in ['baseline','control_after_refit','normal_due','explicit_historical','explicit_repeat']}
    result=dict(release=m['release'],postgres=m['pg'],observed_clocks=m['daily'],baseline_rows=320,corrected_match=change['corrected'],
      first_match_version=base['corrected'],due_sets={n:t['due'] for n,t in m['daily'].items()},
      compared=steps,shots_fit={n:ss[n]['shots_fit'] for n in ('baseline','control_after_refit','normal_due','explicit_historical')},
      resolved_runs={n:active(ss[n]) for n in ('baseline','control_after_refit','normal_due','explicit_historical','explicit_repeat')},
      old_levels_watermarks={n:ss[n]['watermarks'] for n in ('baseline','normal_due')},
      leagues={n:ss[n]['levels'] for n in ('baseline','control_after_refit','normal_due')},
      preview_minus_published_z={n:dynamics(ss[n]) for n in ('baseline','control_after_refit','normal_due','explicit_historical','explicit_repeat')},
      largest_api_grade=dict(baseline=x[biggest],after=y[biggest]),
      persisted_full_row_fingerprints=fp,historical_source_fingerprints=base['raw_fingerprint'],
      raw_match_changes=1,method_versions=sorted({r['method_version'] for s in ss.values() for r in s['runs']}))
    return result

if __name__=='__main__':
    ap=argparse.ArgumentParser();ap.add_argument('folder',type=Path);ap.add_argument('--compare',type=Path)
    args=ap.parse_args();out=make(args.folder)
    if args.compare:
        previous=make(args.compare)
        for k in ('due_sets','shots_fit','leagues','method_versions','compared','preview_minus_published_z'):
            assert previous[k]==out[k],k
        out['repeated_numerics']='identical'
    print(json.dumps(out,indent=2,ensure_ascii=False))
