"""Generate the 320 matched keys and independent sample fingerprints from offline tables."""
import argparse
import csv
import json
from pathlib import Path
from verify import mapping, read, sha

def export(source,out):
    _,snap=read(source)
    stages={'initial':'baseline','temoin':'control_after_refit','quotidien':'normal_due','explicite':'explicit_historical',
            'repete':'explicit_repeat'}
    rows={}
    hashes={}
    for prefix,label in stages.items():
        s=snap[label]
        el=mapping(s['elo'],'elo');p=mapping(s['power'],'power');g=mapping(s['grades'],'grades'); preview=mapping(s['preview'],'preview')
        hashes[prefix]={}
        for t,fields in {'elo':['match_id','team_id','elo_before','elo_after','expected','result'],
                         'power':['match_id','player_id','role','minutes','opponent_elo','contribution','match_index'],
                         'grades':['match_id','player_id','z','first_z','ref_season','grade']}.items():
            hashes[prefix][t]=sha([[a[k] for k in fields] for a in s[t]])
        for key,x in g.items():
            # This synthetic fixture has exactly one forward for each side; his ID equals his team's.
            e=el[key];pl=p[key];other,=[v for k,v in el.items() if k[0]==key[0] and k!=key]
            row=rows.setdefault(key,{'match':key[0],'joueur':key[1],'equipe':key[1]})
            for name,value in [('elo_propre',e['elo_before']),('elo_adverse',other['elo_before']),('elo_adverse_stocke',pl['opponent_elo']),
                  ('contribution',pl['contribution']),('z_source_actuelle',preview[key]['z']),('z_stocke',x['z']),('note_sur_100',x['grade']),
                  ('run_elo',e['run_id']),('run_intermediaire',pl['run_id']),('run_de_la_note',x['run_id'])]:
                row[prefix+'_'+name]=value
    with (out/'comparaison-320.csv').open('w',newline='') as f:
        w=csv.DictWriter(f,fieldnames=next(iter(rows.values())).keys(),lineterminator='\n')
        w.writeheader();w.writerows(rows.values())
    (out/'empreintes-valeurs.json').write_text(json.dumps(hashes,indent=2)+'\n')

if __name__=='__main__':
    p=argparse.ArgumentParser();p.add_argument('capture',type=Path);p.add_argument('sortie',type=Path)
    a=p.parse_args();export(a.capture,a.sortie)
