"""Deterministic two-season football panel; none of its statistics is read from an Elo."""
from datetime import date, timedelta

YEARS = (2021, 2024)

def schedule():
    for y in YEARS:
        start = date(y, 9, 1)
        fixtures = []
        for division in (0,1):
            teams = list(range(division*8+1, division*8+9))
            for rnd in range(7):
                for k in range(4):
                    h,a=teams[k],teams[7-k]
                    if (rnd+k)%2: h,a=a,h
                    for leg in (0,1):
                        day = start + timedelta(days=14*(rnd+leg*7))
                        fixtures.append((day,division+1,h if leg==0 else a,a if leg==0 else h))
                teams = [teams[0],teams[-1],*teams[1:-1]]
        for rnd in range(6):
            day = start + timedelta(days=16+rnd*39)
            for k in range(8):
                h,a=k+1,9+(k+rnd)%8
                if rnd%2: h,a=a,h
                fixtures.append((day,3,h,a))
        for seq,(day,comp,h,a) in enumerate(sorted(fixtures),1):
            m=(y-2020)*1000+seq
            def strength(t): return (t-1)%8 + (1 if t<=8 else 0)
            def score(t,o):
                return max(0, (8 + strength(t)-strength(o) + (m*13+t*11)%15-7)//5)
            home,away=score(h,a),score(a,h)
            if y==2024 and seq==len(fixtures):
                assert comp==3
                home,away=2,1
            stats=[]
            for t,o in ((h,a),(a,h)):
                shots=max(0,(14+strength(t)-strength(o)+(m*7+t*3)%13-6)//5)
                stats.append((m,y,t,t,105,90,shots,33+(m+3*t)%25))
            yield dict(id=m,year=y,day=day,competition=comp,edition=10*(y-2020)+comp,
                       home=h,away=a,home_score=home,away_score=away,stats=stats)

def seed(db,book):
    all_matches=list(schedule())
    with db.transaction():
        db.execute("INSERT INTO core.countries(code) VALUES('FRA'),('ESP'),('INT') ON CONFLICT DO NOTHING")
        for year in YEARS:book.season(f'{year}/{year+1}')
        db.execute("""INSERT INTO core.competitions(id,name,country_code) VALUES
                    (1,'Audit North domestic','FRA'),(2,'Audit South domestic','ESP'),(3,'Audit continental','INT')""")
        for y in YEARS:
            for c in (1,2,3):
                db.execute('INSERT INTO core.competition_seasons(id,competition_id,season_id,native_label) VALUES(%s,%s,%s,%s)',
                           (10*(y-2020)+c,c,y,f'{y}/{y+1}'))
        for t in range(1,17):
            db.execute('INSERT INTO core.teams(id,name,country_code) VALUES(%s,%s,%s)',(t,f'Audit club {t:02}', 'FRA' if t<=8 else 'ESP'))
            db.execute('INSERT INTO core.players(id,name) VALUES(%s,%s)',(t,f'Audit forward {t:02}'))
        with db.cursor().copy("""COPY core.matches(id,competition_season_id,season_id,match_date,kickoff_at,status,source,
                                      home_team_id,away_team_id,home_score,away_score) FROM STDIN""") as q:
            for r in all_matches:
                q.write_row([r['id'],r['edition'],r['year'],r['day'],str(r['day'])+' 17:00:00+00','finished','pitchapi',
                             r['home'],r['away'],r['home_score'],r['away_score']])
        with db.cursor().copy('COPY core.player_match_stats(match_id,season_id,team_id,player_id,position_id,minutes_played,shots_on_target,touches) FROM STDIN') as q:
            for r in all_matches:
                for row in r['stats']:q.write_row(row)
        db.execute("""INSERT INTO core.match_coverage(match_id,season_id,player_stats)
                      SELECT id,season_id,'ok' FROM core.matches""")
        db.execute("""INSERT INTO core.provider_ids(entity_type,provider,provider_key,entity_id)
                      SELECT 'match','pitchapi','m_'||lpad(id::text,6,'0'),id FROM core.matches""")
        for entity,table,prefix in [('player','players','p_'),('team','teams','t_')]:
            db.execute(f"""INSERT INTO core.provider_ids(entity_type,provider,provider_key,entity_id)
                        SELECT %s,'pitchapi',%s||lpad(id::text,6,'0'),id FROM core.{table}""",(entity,prefix))
    return all_matches[-1]
