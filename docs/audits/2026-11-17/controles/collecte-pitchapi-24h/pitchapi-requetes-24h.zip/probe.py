SQL = "WITH attempts AS MATERIALIZED (\n  SELECT id,(extract(epoch FROM (fetched_at - timestamptz '2026-11-17 08:00 UTC'))*1000000)::bigint AS us,\n         family::text,entity_type,entity_id,target_date,competition_season_id,global_key,http_status,error_code,\n         job_id,request_id,encode(response_sha256,'hex') AS body_sha,parser_version,rows_written,is_empty,duration_ms\n  FROM ops.fetch_log\n  WHERE fetched_at >= timestamptz '2026-11-17 08:00 UTC'\n    AND fetched_at < timestamptz '2026-11-18 08:00 UTC'\n), repeated_entity AS (\n  SELECT DISTINCT entity_type,entity_id FROM (\n    SELECT family,entity_type,entity_id FROM attempts WHERE entity_type IS NOT NULL AND entity_id IS NOT NULL\n    GROUP BY family,entity_type,entity_id HAVING count(*)>1\n  ) repeated\n), repeated_edition AS (\n  SELECT competition_season_id FROM attempts WHERE family='league_matches' AND competition_season_id IS NOT NULL\n  GROUP BY 1 HAVING count(*)>1\n)\nSELECT 'attempt' AS kind, jsonb_build_array(id,us,family,entity_type,entity_id,target_date,competition_season_id,\n       global_key,http_status,error_code,job_id,request_id,body_sha,parser_version,rows_written,is_empty,duration_ms) AS value\nFROM attempts\nUNION ALL\nSELECT 'entity',jsonb_build_array(r.entity_type,r.entity_id,p.keys,m.kickoff_at,m.status,m.competition_season_id)\nFROM repeated_entity r\nLEFT JOIN core.matches m ON r.entity_type='match' AND m.id=r.entity_id\nLEFT JOIN LATERAL (SELECT jsonb_agg(jsonb_build_array(i.provider_key,i.is_current) ORDER BY i.provider_key) keys\n                   FROM core.provider_ids i WHERE i.provider='pitchapi' AND i.entity_type=r.entity_type AND i.entity_id=r.entity_id) p ON true\nUNION ALL\nSELECT 'edition',jsonb_build_array(e.id,e.competition_id,e.native_label,p.keys)\nFROM repeated_edition r JOIN core.competition_seasons e ON e.id=r.competition_season_id\nLEFT JOIN LATERAL (SELECT jsonb_agg(jsonb_build_array(i.provider_key,i.is_current) ORDER BY i.provider_key) keys\n                   FROM core.provider_ids i WHERE i.provider='pitchapi' AND i.entity_type='competition' AND i.entity_id=e.competition_id) p ON true\n"
def collect(db):
    import hashlib
    with db.transaction():
        db.execute('SET TRANSACTION ISOLATION LEVEL REPEATABLE READ READ ONLY')
        db.execute("SET LOCAL TIME ZONE 'UTC'")
        db.execute("SET LOCAL statement_timeout='65s'")
        db.execute("SET LOCAL enable_seqscan=off")
        meta = db.execute("""SELECT current_database(),transaction_timestamp()::text,pg_current_snapshot()::text,
                              current_setting('transaction_read_only'),current_setting('transaction_isolation')""").fetchone()
        assert meta[0]=='vega_v2' and meta[3:] == ('on','repeatable read')
        plan = db.execute('EXPLAIN (FORMAT JSON) ' + SQL).fetchone()[0]
        def nodes(node):
            yield node
            for child in node.get('Plans', []):
                yield from nodes(child)
        slices=[n for n in nodes(plan[0]['Plan']) if 'fetch_log_' in str(n.get('Index Name','')) and 'fetched_at' in n.get('Index Cond','')]
        assert slices and all(n['Node Type'] in ('Index Scan','Index Only Scan','Bitmap Index Scan') for n in slices)
        result = {'attempt':[], 'entity':[], 'edition':[]}
        ids = {}
        for kind,row in db.execute(SQL):
            if kind=='attempt' and row[11] is not None:
                # Preserve equality of opaque request identifiers; only export a local integer.
                row[11] = ids.setdefault(row[11],len(ids)+1)
            result[kind].append(row)
        result['attempt'].sort(key=lambda r:(r[1],r[0]))
        result['entity'].sort(key=lambda r:r[:2])
        result['edition'].sort(key=lambda r:r[0])
        return dict(meta=meta,sql_sha256=hashlib.sha256(SQL.encode()).hexdigest(),plan=plan,**result)
