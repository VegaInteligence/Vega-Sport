# Appels PitchAPI du 17 au 18 novembre 2026

Sur la fenêtre complète du **17 novembre à 08:00 UTC inclus au 18 novembre à 08:00 UTC exclu**, le journal déployé compte **88 275 tentatives**. Sur **65 494 succès**, aucun couple famille–cible ne réussit deux fois. Les deux seules cibles répétées ont chacune deux HTTP 500 suivis d’un succès. Cette mesure ne justifie aucune suppression de requête réussie. [Par famille](resultats/familles.csv) · [Par statut et code](resultats/statuts.csv) · [Par heure UTC](resultats/heures-utc.csv)

| Comptage | Observations |
| --- | ---: |
| Familles présentes | 16 |
| Couples famille–cible | 88 271 |
| Cibles distinctes toutes familles confondues | 8 675, dont 6 972 matchs, 1 691 joueurs, 3 équipes et 9 dates |
| Succès HTTP avec enveloppe admise par le client | 65 494 |
| Indisponibilités documentées | 22 759, dont 22 729 HTTP 404 analytiques et 30 HTTP 403 de profils hors forfait |
| Autres erreurs | 18 HTTP 404 de profils introuvables, 4 HTTP 500 |
| Tentatives sans cible exploitable | 0 |
| Empreintes de corps et identifiants de job renseignés | 0 sur 88 275 pour chacun |
| Identifiants de requête fournisseur | 88 275 distincts |

Le premier événement est enregistré le 17 à 08:00:00.264353 et le dernier le 18 à 05:00:25.935884 UTC. Les heures ultérieures sont incluses dans le filtre et ne contiennent aucune ligne. Un créneau vide dans ce journal renseigne uniquement sur les tentatives enregistrées. Un intervalle chevauchant une borne, notamment une correction à J+1, échappe à la comparaison des paires. Le décompte est nul dans chacune des sept tranches de temps comprises entre moins d’une seconde et 24 heures. [Intervalles entre succès](resultats/intervalles.csv)

## Deux séquences après erreur, aucun corps dupliqué établi

Le 17 novembre à 22:24 UTC, le profil du joueur Vega 64900, `/players/p_30ZcPu`, répond 500, 500 puis 200, à 0,632 et 1,149 seconde d’écart. Pour le match Vega 248782, `/matches/m_3jQbsx/players` répond également 500, 500 puis 200, à 0,641 et 1,151 seconde d’écart. Dans la transaction, chacune des deux cibles correspond à une seule clé PitchAPI courante et aucune autre clé conservée. Le chemin se déduit de cette clé et du contrat du worker. Le client réessaie les HTTP 5xx avec des délais minimaux de 0,5 puis 1 seconde. Les horodatages sont compatibles avec ce code. Le journal ne lie pas les tentatives à une invocation de `fetch` ou à un job. [Horaires, routes et identifiants](resultats/apres-erreur.csv) · [Client déployé](sources/pitchapi.py.txt) · [Worker déployé](sources/worker.py.txt)

Les quatre autres champs de traçabilité `response_sha256`, `parser_version`, `rows_written` et `is_empty` restent NULL dans toute la fenêtre. La fonction de journalisation omet ces champs et `job_id`. L’identifiant de requête est opaque et propre à la tentative. L’empreinte normalisée dans `ops.family_state` représente le dernier état de la famille et ne donne pas le corps de chacune des réponses. Il est donc impossible de mesurer les réponses identiques au-delà du constat que, dans la fenêtre et sur la même cible logique, il n’existe aucune paire de succès à comparer. [Schéma du journal](sources/008_validated_core_ops.sql.txt) · [Écriture du journal et état des faits](sources/store.py.txt)

## Un refus de couverture vaut pour un endpoint

Sur les cinq familles analytiques, 4 546 matchs ont au moins une réponse d’indisponibilité. Pour 4 545, les cinq familles répondent indisponibles. Le match **248802** fournit une exception vérifiable. Le 17 à 21:30:50 UTC, `advanced` répond 404. `advanced_players`, `heatmaps` et `network` suivent avec le même code d’indisponibilité. À 21:30:54.883588, `player_halves` réussit, ligne 1035602. Étendre le premier refus aux autres endpoints aurait supprimé un succès. Les 2 087 matchs pour lesquels les cinq familles réussissent et les 42 qui n’ont qu’une de ces cinq familles dans la fenêtre figurent aussi dans le tableau. Aucun corps ni contenu de mi-temps ne peut être déduit du 200. [Comptage croisé](resultats/couverture-croisee.csv) · [Cinq tentatives du match](resultats/temoins-couverture-mixte.csv)

## Routes, autorité et limites

| Cible et famille | Contrat du worker `8018e0836c` |
| --- | --- |
| Match, 13 familles | `/matches/{clé}` pour le résumé. Les douze autres familles ont chacune leur propre suffixe. `/players` et `/players/halves` ont des portées différentes. Le client impose `frame=acting_ltr` sur `/heatmaps`. [Table des suffixes](sources/pilot.py.txt) |
| Joueur, équipe | `/players/{clé}`, `/teams/{clé}` |
| Calendrier par date | `/date/{date}?status=all` |
| Ligue ou calendrier d’édition | Catalogue `/leagues`, profil `/leagues/{clé}`, ou `/leagues/{clé}/matches?season=…&status=all`. Aucune ligne des familles `league` et `league_matches` dans cette fenêtre. |

Les 16 familles observées ont une cible reconnue pour chaque ligne. Le code peut aussi appeler une équipe ou ligue pendant l’enrichissement, ou le catalogue pendant une reprise historique, sans passer de cible de job. Une telle ligne est comptée individuellement et exclue des comparaisons. Un même match demandé pour son calendrier, ses compositions, ses tirs et ses événements alimente des faits différents. Les contrats observés dans ces familles ne transmettent aucun paramètre de pagination. Le programme garde séparés famille, date, édition, type et identifiant. Les 88 271 couples sont des cibles logiques. La projection ne résout les clés natives que pour les cibles répétées. [Règles de classification](analyse.py) · [Relevé des cibles indéterminées](resultats/sans-cible.csv)

Le planificateur prévoit plusieurs lectures des compositions avant le coup d’envoi, le suivi de score et la correction à 24 heures. Le dossier français antérieur montre deux HTTP 200 pour chacun des six matchs 111 à 116, les 9 et 10 novembre, à environ 24 h 45 d’écart. Le motif de chaque seconde lecture et l’identité de ses octets restent inconnus. L’ancien contrôle du 17 novembre avait compté 125 228 tentatives, dont 95 575 succès HTTP, et zéro cible répétée dans la même minute sur **sa propre fenêtre**. Son filtre supplémentaire `count(distinct job_id)>1` est aveugle aux lignes sans job. Les deux mesures n’ont pas le même dénominateur. [Six matchs précédents](sources/six-matchs.csv) · [Ancienne requête](sources/ancien.sql) · [Ancien résultat](sources/ancien.json) · [Planificateur](sources/planner.py.txt)

PitchAPI fournit les identifiants natifs, les calendriers de ses compétitions et les détails de match de ces routes. Son enveloppe décide de la disponibilité exposée par son endpoint, sans certifier un score homologué ou la disponibilité chez un autre fournisseur. Les calendriers d’organisateurs servent à trancher l’identité sportive, le tour et le résultat officiel. Le contrôle antérieur de Ligue 1 distingue un calendrier de compétition et les résumés des matchs chez PitchAPI. Pour les saisons dont PitchAPI détient déjà le championnat concerné, le connecteur Open Matchday saute le dossier avant de télécharger ses résultats et fixtures. La consultation du seul manifeste européen n’est pas une nouvelle requête de match. Les journaux ne démontrent pas trois acquisitions autonomes du même contenu. [Règle de priorité déployée](sources/open_matchday.py.txt) Le présent journal ne couvre pas les autres connecteurs. Pour VI-21, attendre une preuve par chemin, paramètres et empreinte avant d’enlever des appels. Si une mesure de redondance devient nécessaire, tracer l’opération de collecte, le job quand il existe, le chemin et les paramètres normalisés, le rang de tentative et l’empreinte des octets reçus. Le propriétaire peut alors distinguer une correction voulue d’une répétition économisable.

## Vérification hors ligne

Après extraction dans un dossier vide, exécuter la commande suivante depuis la racine du paquet avec Python 3.10 ou ultérieur. La bibliothèque standard suffit.

```sh
python3 -I -B verifier.py
```

Le vérificateur contrôle l’inventaire et l’empreinte du gel, refait les comptages, les classements de statuts et les comparaisons de temps, puis compare neuf sorties aux fichiers livrés. Le JSON compressé contient une projection par tentative. L’identifiant de requête est remplacé par un entier local préservant exactement l’égalité entre valeurs. Le reçu expose les empreintes, les bornes et les conditions de lecture. [Requête SQL](requests.sql) · [Sonde exécutée](probe.py) · [Reçu de capture](recu-rds.json) · [Résultat complet](resultats/resultat.json) · [Sources du code](sources/provenance.json)

La transaction RDS `4423126:4423126:` a été ouverte à 08:56:54 UTC, en isolation répétable et lecture seule. Le plan préparé utilise `fetch_log_202611_pkey` avec les deux bornes de temps. Le seul SELECT sur les données ouvre la partition de novembre. Une première tâche de diagnostic n’a pas pu télécharger son image et n’a pas ouvert de connexion. La tâche suivante, épinglée à l’image déployée, s’est terminée avec le code 0. La première récupération des journaux n’a pas vu le marqueur de fin. La pagination sur le même flux a récupéré les 60 fragments et leur empreinte de bout en bout. Une nouvelle lecture RDS n’a pas été nécessaire.
