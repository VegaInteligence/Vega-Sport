"""Rebuild interval and target accounting from the single frozen fetch_log projection."""
import argparse
from collections import Counter, defaultdict
import csv
from datetime import datetime, timezone, timedelta
import hashlib
import json
from pathlib import Path
from urllib.parse import urlencode
import zlib

ROOT = Path(__file__).resolve().parent
START = datetime(2026, 11, 17, 8, tzinfo=timezone.utc)
SUFFIX = {'summary':'', 'lineups':'/lineups', 'player_stats':'/players', 'team_stats':'/stats',
          'shots':'/shots', 'events':'/events', 'momentum':'/momentum', 'player_halves':'/players/halves',
          'advanced':'/advanced','advanced_players':'/advanced/players','network':'/advanced/network',
          'heatmaps':'/heatmaps','h2h':'/h2h'}
BOUNDS = [('lt1s',1),('1s_10s',10),('10s_60s',60),('1m_10m',600),('10m_1h',3600),('1h_6h',21600),('6h_24h',86400)]
FIELDS = ('id','us','family','type','entity','day','edition','global_key','http','error','job','request','sha','parser','rows_written','empty','duration')

def shape(r):
    family = r['family']
    expected_type = 'match' if family in SUFFIX else {'league':'competition','team':'team','player':'player'}.get(family)
    entity, day, edition, glob = [r[k] for k in ('entity','day','edition','global_key')]
    if sum(v is not None for v in (entity,day,edition,glob)) != 1:
        return None
    if expected_type and entity is not None and r['type']==expected_type:
        return (r['type'],entity)
    if r['type'] is not None:
        return None
    if family=='calendar' and day is not None:
        return ('date',day)
    if family=='league_matches' and edition is not None:
        return ('edition',edition)
    if family=='league' and glob=='catalogue':
        return ('global',glob)
    return None

def result(r):
    code,status=r['error'],r['http']
    if status is not None and 200<=status<=299 and code is None:
        return 'success'
    if ((status==404 and code in ('ANALYTICS_UNAVAILABLE','HALVES_UNAVAILABLE'))
        or (status==403 and code=='PLAN_UPGRADE_REQUIRED' and r['family']=='player')):
        return 'unavailable'
    if status==429 or (status is not None and 500<=status<600) or (status is None and code=='TRANSPORT_ERROR'):
        return 'retryable'
    return 'other_error'

def route(family,target,entities,editions):
    kind,value=target
    if kind=='date':
        return '/date/'+value+'?status=all'
    if kind=='global':
        return '/leagues'
    if kind=='edition':
        info=editions.get(value)
        if not info:
            return None
        _,_,season,keys=info
        if not season or not keys or len(keys)!=1 or not keys[0][1]:
            return None
        return '/leagues/'+keys[0][0]+'/matches?'+urlencode({'season':season,'status':'all'})
    rec=entities.get(target)
    if not rec or not rec[2] or len(rec[2])!=1 or not rec[2][0][1]:
        return None
    key=rec[2][0][0]
    if kind=='match':
        return '/matches/'+key+SUFFIX[family]+('?frame=acting_ltr' if family=='heatmaps' else '')
    return ('/leagues/' if kind=='competition' else '/'+kind+'s/')+key

def csv_write(dest,rows,fields):
    with dest.open('w',newline='',encoding='utf-8') as f:
        writer=csv.DictWriter(f,fieldnames=fields,lineterminator='\n')
        writer.writeheader()
        writer.writerows({k:r.get(k,0) for k in fields} for r in rows)

def run(data,out):
    out.mkdir(exist_ok=True,parents=True)
    raw=json.loads(zlib.decompress(data.read_bytes()))
    assert raw['meta'][3:]==['on','repeatable read']
    assert raw['sql_sha256']==hashlib.sha256((ROOT/'requests.sql').read_bytes()).hexdigest()
    entities={tuple(r[:2]):r for r in raw['entity']}
    editions={r[0]:r for r in raw['edition']}
    families=defaultdict(Counter); groups=defaultdict(list); statuses=Counter(); status_targets=defaultdict(set)
    seen=set(); trace=Counter(); requests=Counter(); observed_targets=set();less=Counter()
    hours=defaultdict(Counter); analytics=defaultdict(dict)
    optional={'advanced','advanced_players','heatmaps','network','player_halves'}
    for a in raw['attempt']:
        r=dict(zip(FIELDS,a,strict=True))
        assert 0<=r['us']<86400*10**6 and (r['us'],r['id']) not in seen
        seen.add((r['us'],r['id']))
        f=r['family']; t=shape(r); outcome=result(r); c=families[f]; c['attempts']+=1; c[outcome]+=1
        h=hours[r['us']//3_600_000_000]; h['attempts']+=1; h[outcome]+=1
        if r['http'] and 200<=r['http']<300:
            c['http_2xx']+=1
        status_key=(f,r['http'],r['error'],outcome)
        statuses[status_key]+=1
        if r['request'] is not None:
            requests[r['request']]+=1
        for k in ('job','request','sha','parser','rows_written','empty'):
            trace[k]+=r[k] is not None
            c[k+'_present']+=r[k] is not None
        if t is None:
            c['unidentified']+=1
            less[(f,r['type'],r['entity'] is not None,r['day'] is not None,r['edition'] is not None,r['global_key'])]+=1
        else:
            c['identified']+=1
            groups[(f,t)].append(r); observed_targets.add(t);status_targets[status_key].add(t)
            if f in optional and t[0]=='match':
                analytics[t[1]].setdefault(f,set()).add(outcome)
    events=[]; retry_events=[]; same_body_pairs=0; same_body_intervals=0
    for (f,t),rows in sorted(groups.items()):
        c=families[f]; c['targets']+=1
        clean=[r for r in rows if result(r)=='success']
        c['targets_with_success']+=bool(clean); c['repeated_targets']+=len(rows)>1
        c['repeated_success_targets']+=len(clean)>1
        if len(rows)<2:
            continue
        path=route(f,t,entities,editions); hashes=Counter()
        if path:
            hashes.update(r['sha'] for r in clean if r['sha'])
            same_body_pairs+=sum(n*(n-1)//2 for n in hashes.values())
        rec=entities.get(t,[])
        for prev,nxt in zip(rows,rows[1:]):
            if result(prev)=='retryable':
                retry_events.append(dict(family=f,target_type=t[0],target=t[1],first=prev['id'],next=nxt['id'],
                    first_utc=(START+timedelta(microseconds=prev['us'])).isoformat(),next_utc=(START+timedelta(microseconds=nxt['us'])).isoformat(),
                    route_from_contract=path or '',seconds=(nxt['us']-prev['us'])/1e6,previous_code=prev['error'],next_outcome=result(nxt)))
        for prev,nxt in zip(clean,clean[1:]):
            delta=(nxt['us']-prev['us'])/1e6
            bucket=next(n for n,b in BOUNDS if delta<b)
            c[bucket]+=1; c['repeat_success_intervals']+=1
            eq=bool(path and prev['sha'] and prev['sha']==nxt['sha']); same_body_intervals+=eq
            events.append(dict(family=f,target_type=t[0],target=t[1],first=prev['id'],second=nxt['id'],
                first_utc=(START+timedelta(microseconds=prev['us'])).isoformat(),
                second_utc=(START+timedelta(microseconds=nxt['us'])).isoformat(),seconds=delta,bucket=bucket,
                route_from_contract=path or '',edition=rec[5] if rec and t[0]=='match' else '',
                kickoff_utc=rec[3] if rec and t[0]=='match' else '',status_at_snapshot=rec[4] if rec and t[0]=='match' else '',
                compared_hashes=int(bool(prev['sha'] and nxt['sha'])),same_response=int(eq)))
    common=['attempts','identified','unidentified','targets','targets_with_success','http_2xx','success','unavailable','retryable','other_error',
            'repeated_targets','repeated_success_targets','repeat_success_intervals']+[b for b,_ in BOUNDS]+[k+'_present' for k in ('job','request','sha','parser','rows_written','empty')]
    csv_write(out/'familles.csv',[dict(family=f,**d) for f,d in sorted(families.items())],['family']+common)
    csv_write(out/'statuts.csv',[dict(family=k[0],http=k[1],code=k[2],outcome=k[3],attempts=n,known_targets=len(status_targets[k])) for k,n in sorted(statuses.items(),key=lambda x:str(x[0]))],['family','http','code','outcome','attempts','known_targets'])
    csv_write(out/'intervalles.csv',events,['family','target_type','target','first','second','first_utc','second_utc','seconds','bucket','route_from_contract','edition','kickoff_utc','status_at_snapshot','compared_hashes','same_response'])
    csv_write(out/'apres-erreur.csv',retry_events,['family','target_type','target','first','next','first_utc','next_utc','route_from_contract','seconds','previous_code','next_outcome'])
    csv_write(out/'heures-utc.csv',[dict(debut_utc=(START+timedelta(hours=i)).isoformat(),**hours[i]) for i in range(24)],
              ['debut_utc','attempts','success','unavailable','retryable','other_error'])
    masks=Counter(tuple('/'.join(sorted(s.get(f,{'absent'}))) for f in sorted(optional)) for s in analytics.values())
    csv_write(out/'couverture-croisee.csv',[dict(zip(sorted(optional),k),matches=n) for k,n in sorted(masks.items())],sorted(optional)+['matches'])
    mixed={k:{f:sorted(status) for f,status in sorted(v.items())} for k,v in analytics.items()
           if any('success' in s for s in v.values()) and any('unavailable' in s for s in v.values())}
    witnesses=[dict(match=t[1],family=f,id=r['id'],at=(START+timedelta(microseconds=r['us'])).isoformat(),
                    http=r['http'],error=r['error'],request_local=r['request'])
               for (f,t),rr in groups.items() if t[0]=='match' and t[1] in mixed and f in optional for r in rr]
    csv_write(out/'temoins-couverture-mixte.csv', sorted(witnesses,key=lambda a:a['at']),
              ['match','family','id','at','http','error','request_local'])
    csv_write(out/'sans-cible.csv',[dict(family=k[0],entity_type=k[1],has_id=k[2],has_date=k[3],has_edition=k[4],global_key=k[5],rows=n) for k,n in sorted(less.items(),key=lambda x:str(x[0]))],['family','entity_type','has_id','has_date','has_edition','global_key','rows'])
    totals=sum(families.values(),Counter())
    assert totals['attempts']==len(seen)==totals['identified']+totals['unidentified']==sum(statuses.values())
    assert len(events)==totals['repeat_success_intervals']==sum(totals[b] for b,_ in BOUNDS)
    assert totals['attempts']==sum(totals[k] for k in ('success','unavailable','retryable','other_error'))
    summary=dict(window=['2026-11-17T08:00:00Z','2026-11-18T08:00:00Z'],snapshot=raw['meta'],rows=totals['attempts'],
        families=len(families),counts={k:totals[k] for k in common},distinct_targets_across_families=len(observed_targets),
        targets_by_type=dict(sorted(Counter(t[0] for t in observed_targets).items())),present_trace_fields=dict(trace),
        requests_with_reused_request_id=sum(n for n in requests.values() if n>1),distinct_request_ids=len(requests),
        retryable_followed_same_target=len(retry_events),later_outcome_after_retryable=dict(Counter(r['next_outcome'] for r in retry_events)),
        earliest=(START+timedelta(microseconds=min(t for t,_ in seen))).isoformat(),
        latest=(START+timedelta(microseconds=max(t for t,_ in seen))).isoformat(),
        observed_optional_match_targets=len(analytics),distinct_with_optional_unavailable=sum(any('unavailable' in s for s in v.values()) for v in analytics.values()),
        all_five_optional_unavailable=sum(len(v)==5 and all(s=={'unavailable'} for s in v.values()) for v in analytics.values()),
        mixed_optional=mixed,
        repeated_success_intervals_with_resolvable_route=sum(bool(r['route_from_contract']) for r in events),
        repeated_success_intervals_with_both_response_hashes=sum(r['compared_hashes'] for r in events),
        identical_response_immediate_success_pairs=same_body_intervals,identical_response_any_success_pairs=same_body_pairs)
    (out/'resultat.json').write_text(json.dumps(summary,indent=2,ensure_ascii=False)+'\n')
    return summary

if __name__=='__main__':
    p=argparse.ArgumentParser();p.add_argument('snapshot',type=Path);p.add_argument('destination',type=Path)
    args=p.parse_args(); print(json.dumps(run(args.snapshot,args.destination),ensure_ascii=False))
