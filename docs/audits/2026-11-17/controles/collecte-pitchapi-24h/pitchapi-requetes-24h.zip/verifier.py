"""Verify the delivered files and reproduce all nine accounting outputs, without network."""
import csv
from datetime import datetime
import hashlib
import json
from pathlib import Path
import sys
import tempfile
import zlib

root=Path(__file__).resolve().parent
sys.path.insert(0,str(root))
from analyse import run

def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()

def main():
    files={}
    for line in (root/'SHA256SUMS').read_text().splitlines():
        digest, path=line.split('  ',1)
        assert path not in files and not Path(path).is_absolute() and '..' not in Path(path).parts
        assert digest==sha(root/path),path
        files[path]=digest
    receipt=json.loads((root/'recu-rds.json').read_bytes())
    snap=root/'rds/inputs.json.zlib'
    assert sha(snap)==receipt['transport']['sha256']=='2061113d0b6053779dd319981a991a2bc722178363ccca3b4778bb1437288235'
    assert sha(root/'probe.py')==receipt['probe_sha256'] and sha(root/'requests.sql')==receipt['sql_sha256']
    raw=json.loads(zlib.decompress(snap.read_bytes()))
    assert raw['meta']==receipt['metadata']
    assert len(raw['attempt'])==88275
    assert len({r[0] for r in raw['attempt']})==len({r[11] for r in raw['attempt']})==88275
    assert set(r[12] for r in raw['attempt'])=={None}
    with tempfile.TemporaryDirectory() as tmp:
        dest=Path(tmp);summary=run(snap,dest)
        stored=root/'resultats'
        produced={p.name for p in dest.iterdir()}
        assert len(produced)==9 and produced=={p.name for p in stored.iterdir()}
        for name in produced:
            assert sha(dest/name)==sha(stored/name),name
        counts=summary['counts']
        assert [counts[k] for k in ('targets','identified','success','unavailable','other_error','retryable','repeat_success_intervals')]==[88271,88275,65494,22759,18,4,0]
        assert summary['all_five_optional_unavailable']==4545 and list(summary['mixed_optional'])==[248802]
        mixed=list(csv.DictReader((dest/'temoins-couverture-mixte.csv').read_text().splitlines()))
        assert [r['http'] for r in mixed]==['404']*4+['200'] and mixed[-1]['family']=='player_halves'
    six=list(csv.DictReader((root/'sources/six-matchs.csv').read_text().splitlines()))
    for mid in range(111,117):
        times=[datetime.fromisoformat(r['fetched_at']) for r in six if r['match']==str(mid) and r['http_status']=='200' and not r['job_id']]
        assert len(times)==2 and 24.75 < (max(times)-min(times)).total_seconds()/3600 < 24.76
    print(json.dumps(dict(resultat='OK',fichiers=len(files),sorties_reproduites=9,tentatives=88275,
       couples_famille_cible=88271,intervalles_succes_repete=0,temoins_erreur=2,temoin_couverture_mixte=248802)))

if __name__=='__main__':
    main()
