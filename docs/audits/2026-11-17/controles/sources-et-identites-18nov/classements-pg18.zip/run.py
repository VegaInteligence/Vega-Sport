"""Launch the two frozen standings replays in a disposable local PostgreSQL 18 cluster."""
import argparse
import collections
import csv
import gzip
import hashlib
import json
import os
from pathlib import Path
import platform
import secrets
import shutil
import socket
import subprocess
import sys
import tempfile
import zlib
from datetime import datetime, timezone

ROOT = Path(__file__).resolve().parent
VERSION = "1b28961a88e968d5602f9fb278fc3c471ebb7467"

def read(path):
    return json.loads(path.read_bytes())

def sha(raw):
    return hashlib.sha256(raw).hexdigest()

def dump(path, value):
    path.write_text(json.dumps(value, indent=2, ensure_ascii=False) + "\n")

def verify_package():
    listed = set()
    for line in (ROOT / "SHA256SUMS").read_text().splitlines():
        checksum, name = line.split("  ",1)
        target = (ROOT / name).resolve()
        assert target.is_relative_to(ROOT) and name not in listed and not (ROOT/name).is_symlink()
        assert target.is_file() and sha(target.read_bytes()) == checksum, name
        listed.add(name)
    actual = {p.relative_to(ROOT).as_posix() for p in ROOT.rglob("*") if p.is_file()}
    assert actual == listed | {"SHA256SUMS"}, sorted(actual ^ (listed | {"SHA256SUMS"}))
    return len(listed)

def expected_statements(fixtures):
    for base in (fixtures, fixtures / "worldcup"):
        data = (base / "rds/inputs.json.zlib").read_bytes()
        receipt = read(base / "rds/receipt.json")
        assert sha(data) == receipt["sha256"] and sha((base/"probe.py").read_bytes()) == receipt["probe_sha256"]
        assert receipt["exit_code"] == 0 and json.loads(zlib.decompress(data))["snapshot"][-1] == "on"
    census=json.loads(zlib.decompress((fixtures / "rds/inputs.json.zlib").read_bytes()))
    assert census["sources"]["rows"] == [["sportscore", 1086, 60, 981]]
    assert census["collisions"]["rows"] == [[1086, 0]]
    multi=[(r[2],r[6],r[7]) for r in census["editions"]["rows"] if r[6]>1]
    assert len(multi)==2
    return {"source": "sportscore", "stored_rows":1086,"editions":60,"distinct_teams":981,"mixed_source_keys":0,
            "editions_with_multiple_tables":multi,"captured":census["snapshot"][1]}

def public_models(directory):
    views = {}
    for file in sorted(directory.glob("0[0-6]-*.json")):
        snapshot = read(file)
        http = snapshot["public"]
        assert http["status"] == 200 and snapshot["same_etag"]["status"] == 304
        if snapshot["conditional"]:
            assert snapshot["conditional"]["status"] == 200
        body = dict(http["body"])
        body.pop("fetchedAt")
        views[file.stem] = sha(json.dumps(body, ensure_ascii=False, sort_keys=True, separators=(",", ":")).encode())
    assert len(views)==7
    return views

def run(args):
    if sys.version_info < (3, 13):
        raise SystemExit("Python 3.13 ou ultérieur est nécessaire.")
    if os.name != "posix":
        raise SystemExit("Les binaires PostgreSQL POSIX sont nécessaires.")
    verified = verify_package()
    if args.verify_only:
        print(json.dumps({"package_files_verified": verified}))
        return
    if not args.pg_bin or not args.out:
        raise SystemExit("--pg-bin et --out sont nécessaires au rejeu.")
    out=args.out.resolve()
    if out.is_relative_to(ROOT):
        raise SystemExit("Choisir un dossier de sortie neuf en dehors du paquet.")
    out.mkdir(exist_ok=False,parents=True)
    pg=args.pg_bin.resolve()
    for name in ("initdb","pg_ctl","postgres"):
        if not (pg/name).is_file():
            raise SystemExit(f"Binaire PostgreSQL absent : {name}")
    pg_version=subprocess.check_output([str(pg/"postgres"),"--version"],text=True).strip()
    if " 18." not in pg_version:
        raise SystemExit(f"PostgreSQL 18 requis, obtenu {pg_version}")
    node=shutil.which("node")
    if not node:
        raise SystemExit("Node.js 20 ou ultérieur est nécessaire.")
    node_version=subprocess.check_output([node,"--version"],text=True).strip()
    if int(node_version[1:].split(".")[0]) < 20:
        raise SystemExit("Node.js 20 ou ultérieur est nécessaire.")
    started=datetime.now(timezone.utc).isoformat()
    fixtures=ROOT/"fixtures"/"secondary-source-qualification"
    census=expected_statements(fixtures)
    gold=read(ROOT/"expected.json")
    with tempfile.TemporaryDirectory(prefix="vega-standings-") as temp_name:
        scratch=Path(temp_name)
        local=scratch/"fixtures"/"secondary-source-qualification"
        shutil.copytree(ROOT/"fixtures",scratch/"fixtures")
        runtime=scratch/"runtime"
        runtime.mkdir()
        password=secrets.token_urlsafe(32)
        pw=runtime/"initdb.pw"
        pw.touch(mode=0o600)
        pw.write_text(password+"\n")
        with socket.socket() as sock:
            sock.bind(("127.0.0.1",0))
            port=sock.getsockname()[1]
        pgdata=runtime/"db"
        # Only a generated local password is inherited. No cloud or user database configuration is forwarded.
        env={"PATH":os.pathsep.join([str(Path(node).parent),str(pg),"/usr/bin","/bin"]),
             "HOME":str(scratch), "TMPDIR":temp_name, "TZ":"UTC","LC_ALL":"C", "LC_CTYPE":"C",
             "PYTHONDONTWRITEBYTECODE":"1","PYTHONNOUSERSITE":"1","PYTHONPATH":str(ROOT/"vendor/python"),
             "PSYCOPG_IMPL":"python","PGPASSWORD":password,"REPLAY_LOCAL_PG":f"postgresql://replay@127.0.0.1:{port}",
             "REPLAY_CANDIDATE_REVISION":VERSION,
             "LD_LIBRARY_PATH":str(args.pg_lib.resolve() if args.pg_lib else pg.parent/"lib"),
             "DYLD_LIBRARY_PATH":str(args.pg_lib.resolve() if args.pg_lib else pg.parent/"lib")}
        def execute(argv,log,cwd=scratch):
            with (out/log).open("ab") as fd:
                proc=subprocess.run([str(s) for s in argv],cwd=cwd,env=env,stdout=fd,stderr=subprocess.STDOUT)
            if proc.returncode:
                raise RuntimeError(f"Échec {proc.returncode} : consulter {log}")
        driver=subprocess.check_output([sys.executable,"-S","-c","import psycopg;from psycopg import pq;print(psycopg.__version__,pq.__impl__,pq.version())"],cwd=scratch,env=env,text=True).strip()
        assert driver.startswith("3.3.9 python ")
        execute([pg/"initdb","-D",pgdata,"-U","replay","--locale=C","-E","UTF8","--auth-local=trust","--auth-host=scram-sha-256","--pwfile",pw],"postgres.log")
        pw.unlink()
        try:
            execute([pg/"pg_ctl","-D",pgdata,"-l",runtime/"server.log","-o",
                     f"-c listen_addresses=127.0.0.1 -p {port} -c unix_socket_directories='' -c fsync=off","-w","start"],"postgres.log")
            code=ROOT/"candidate"
            execute([sys.executable,"-S",local/"replay.py",code],"multisource.log")
            execute([sys.executable,"-S",local/"worldcup/replay.py","--tree",code,"--out",local/"worldcup/actual"],"mondial.log")
        finally:
            if (pgdata/"postmaster.pid").is_file():
                execute([pg/"pg_ctl","-D",pgdata,"-m","fast","-w","stop"],"postgres.log")
        multi=read(local/"result.json")
        assert multi == gold["multisource"], "Les réponses, lignes stockées ou empreintes du cas multi-source ont changé"
        wc=local/"worldcup/actual"
        matches=list(csv.DictReader((wc/"fifa-rds-104.csv").open()))
        assert len(matches)==len({r["match_id"] for r in matches})==104
        assert all((r["fifa_home_score"],r["fifa_away_score"])==(r["rds_home_score"],r["rds_away_score"]) for r in matches)
        result=read(wc/"findings.json")
        for k in ("inputs","bronze","impacted_result_teams","position_changes","group_totals","restored_values_verified",
                  "all_48_corrected_stats_equal_fifa","public_table_retention_acceptance","deployed_name_parser_for_bronze"):
            assert result[k] == gold["worldcup"][k], k
        assert public_models(wc) == gold["http_football_digests"]
        shape={s:{k:v for k,v in r.items() if k!="etag"} for s,r in result["steps"].items()}
        assert shape==gold["steps"]
        for filename in ("fifa-rds-104.csv","fallback-by-team.csv","widget-derived-twelve.json","widget-13-original.json"):
            assert sha((wc/filename).read_bytes())==gold["derived_files"][filename],filename
        shutil.copyfile(local/"result.json",out/"multisource.json")
        shutil.copytree(wc,out/"mondial")
        # Completeness and verification evidence only. The temporary server password is not an output.
        for file in out.rglob("*"):
            if file.is_file():
                assert password.encode() not in file.read_bytes(),file.name
    new_sources={k:v["body"]["source"] for k,v in multi.items() if isinstance(v,dict) and "body" in v}
    summary={"execution":"PASS", "original_contracts":{"qualify_single_authority":"FAIL","preserve_transversal_table":"FAIL","exclude_bronze_from_group_table":"FAIL"},
             "start_utc":started,"end_utc":datetime.now(timezone.utc).isoformat(),"package_files_verified":verified,
             "python":platform.python_version(),"node":node_version,"postgres":pg_version,"client":driver,
             "production_census":census,"multisource_get":new_sources,"foreign_points_reproduced":777,
             "worldcup_counts":{s:[r["official_rows"],r["get_tables"],r["get_third"]] for s,r in result["steps"].items()},
             "fifa_dates_sides_scores_verified":len(matches),"bronze_match":result["bronze"]["match_id"],"changed_positions":len(result["position_changes"]),
             "numeric_group_totals":result["group_totals"],"worldcup_semantic_http_bodies_compared":len(gold["http_football_digests"])}
    dump(out/"receipt.json",summary)
    print(json.dumps(summary,ensure_ascii=False))

if __name__=="__main__":
    p=argparse.ArgumentParser(description=__doc__)
    p.add_argument("--pg-bin",type=Path,help="Répertoire des binaires PostgreSQL 18.")
    p.add_argument("--pg-lib",type=Path,help="Répertoire libpq si différent du voisin lib des binaires.")
    p.add_argument("--out",type=Path,help="Nouveau répertoire de résultats, extérieur au ZIP extrait.")
    p.add_argument("--verify-only",action="store_true")
    run(p.parse_args())
