// The read API of a checkout over local HTTP, as the production role vega_read reads it.
// argv: checkout, DSN of the run's own local database.
import { createServer } from "node:http";
import { resolve } from "node:path";
import { pathToFileURL } from "node:url";

const [tree, dsn] = process.argv.slice(2);
const target = new URL(dsn);
if (target.hostname !== "127.0.0.1" || !target.pathname.startsWith("/vega_v2_ssauth_")) throw Error("the run's local database required");
const fromTree = (path) => import(pathToFileURL(resolve(tree, path)));
const { createReader } = await fromTree("backend/api/src/db.mjs");
const { createHandler } = await fromTree("backend/api/src/handler.mjs");
const reader = createReader(dsn, { role: "vega_read" });
const route = createHandler({ read: reader.read });
const server = createServer(async (req, res) => {
  try {
    const out = await route(new Request("http://127.0.0.1" + req.url, { method: req.method, headers: req.headers }));
    res.writeHead(out.status, Object.fromEntries(out.headers));
    res.end(Buffer.from(await out.arrayBuffer()));
  } catch (error) {
    res.writeHead(500);
    res.end(String(error));
  }
});
server.listen(0, "127.0.0.1", () => console.log(server.address().port));
process.on("SIGTERM", () => server.close(async () => { await reader.end(); process.exit(0); }));
