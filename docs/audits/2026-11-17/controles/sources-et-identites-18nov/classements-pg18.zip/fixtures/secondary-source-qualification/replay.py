"""Measure an approved table, a stale minority source and a newer fallback on the actual API."""
from pathlib import Path
import hashlib
import json
import os
import subprocess
import sys
import uuid
from urllib.request import urlopen

import psycopg
from psycopg import sql

p=Path(__file__).resolve().parent
tree=Path(sys.argv[1]).resolve()
sys.path[:0]=[str(tree/'backend'),str(tree/'backend/tests')]
from vega import store, sources
from vega.sources import sportscore
import sportscore_replay as replay
from sportscore_cases import CASES, CURRENT

case=next(c for c in CASES if c['id']=='S30')
n=CASES.index(case)+1
k=replay.ids(n)
step=case['steps'][0]
edition=k['editions'][CURRENT]
first_team=k['teams']['Aster City']
base=os.environ['REPLAY_LOCAL_PG'].rstrip('/')+'/'
assert base.startswith('postgresql://replay@127.0.0.1:')
dbname='vega_v2_ssauth_'+uuid.uuid4().hex
dsn=base+dbname
admin=psycopg.connect(base+'postgres',autocommit=True)
admin.execute(sql.SQL('CREATE DATABASE {}').format(sql.Identifier(dbname)))
db=store.connect_local(dsn)
node=None
try:
    store.migrate(db)
    with db.transaction():
        replay.build(db,store.Store(db))
    for action in step['before']:replay.apply(db,n,action)
    slug=sportscore.LEAGUES[case['key']]
    code=replay.play(sources,sportscore,db,case,step,lambda url:replay.widget(step['body'],slug))
    assert code is None
    node=subprocess.Popen(['node',str(p.parent/'sportscore-authority/e2e/serve.mjs'),str(tree),dsn],text=True,stdout=subprocess.PIPE)
    api='http://127.0.0.1:'+node.stdout.readline().strip()+'/api/standings?competition='+case['key']
    def sample():
        with urlopen(api,timeout=10) as r:
            result=dict(status=r.status,etag=r.headers['etag'],body=json.load(r))
        result['stored']=db.execute("SELECT team_id,source::text,stage,group_name,points,basis,as_of::text FROM core.standings_official WHERE competition_season_id=%s ORDER BY source,team_id,stage,group_name",(edition,)).fetchall()
        result['served_sql']=db.execute("SELECT team_id,source,points FROM api.standings WHERE competition_season_id=%s ORDER BY team_id",(edition,)).fetchall()
        return result
    def points(obs,team):
        return next(r[2] for r in obs['served_sql'] if r[0]==team)
    baseline=sample()
    assert baseline['body']['source']=='SportScore'
    cols='competition_season_id,stage,group_name,team_id,position,played,won,drawn,lost,goals_for,goals_against'
    def secondary(source,phase,basis,interval):
        # Insert only into our scratch fixture. All real accepted rows are retained.
        with db.transaction():
            db.execute(f"""INSERT INTO core.standings_official({cols},points,source,as_of,basis)
                SELECT competition_season_id,coalesce(%s,stage),group_name,team_id,position,played,won,drawn,lost,goals_for,goals_against,
                    777,%s,as_of+%s::interval,coalesce(%s::smallint[],basis)
                FROM core.standings_official WHERE competition_season_id=%s AND team_id=%s AND source='sportscore' AND stage IS DISTINCT FROM 'old-playoff'""",
                (phase,source,interval,basis,edition,first_team))
    def drop(source,phase=None):
        with db.transaction():
            db.execute("DELETE FROM core.standings_official WHERE competition_season_id=%s AND source=%s AND (%s::text IS NULL OR stage=%s)",(edition,source,phase,phase))
    secondary('other',None,[0]*6,'-1 day');stale=sample()
    drop('other');recovered=sample()
    secondary('other',None,None,'1 day');newer=sample()
    drop('other');secondary('sportscore','old-playoff',[0]*6,'-1 day');old_phase=sample()
    assert points(baseline,first_team)!=777
    assert stale['body']['source']=='Vega' and recovered['body']==baseline['body']
    assert points(newer,first_team)==777 and any(r['points']==777 for t in newer['body']['tables'] for r in t['rows'])
    assert old_phase['body']['source']=='Vega'
    docs={'input_case':case['id'],'edition':edition,'member':first_team,'expected':'Fresh approved regular table remains visible; a minority fallback cannot replace a row by clock alone.','baseline':baseline,'with_stale_secondary':stale,'after_secondary_removed':recovered,'with_later_secondary':newer,'with_stale_other_phase_same_source':old_phase,'git_head':os.environ['REPLAY_CANDIDATE_REVISION'],'source_sha256':{f:hashlib.sha256((tree/f).read_bytes()).hexdigest() for f in ('backend/sql/138_sportscore_standings.sql','backend/vega/sources/sportscore.py','backend/api/src/routes/reference.mjs')}}
    (p/'result.json').write_text(json.dumps(docs,indent=2,default=str)+'\n')
    print({k:r['body']['source'] for k,r in docs.items() if isinstance(r,dict) and 'body' in r},'newer fallback points',points(newer,first_team))
finally:
    if node:
        node.terminate();node.wait(timeout=15)
    db.close()
    admin.execute(sql.SQL('DROP DATABASE {}').format(sql.Identifier(dbname)))
    admin.close()
