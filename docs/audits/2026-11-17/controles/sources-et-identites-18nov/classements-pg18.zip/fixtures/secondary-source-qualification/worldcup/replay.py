"""Replay a captured 2026 World Cup edition via the candidate writer, local PG18 and normal GET."""
import argparse
import collections
import csv
import gzip
import hashlib
import json
import os
import subprocess
import sys
import uuid
import zlib
from datetime import datetime, timedelta, timezone
from pathlib import Path
from urllib.error import HTTPError
from urllib.parse import urlsplit
from urllib.request import Request, urlopen

import psycopg
from psycopg import sql

D = Path(__file__).resolve().parent
T = D.parents[1]
parser = argparse.ArgumentParser(description=__doc__)
parser.add_argument("--tree", type=Path, required=True)
parser.add_argument("--out", type=Path, required=True)
args = parser.parse_args()
tree, out = args.tree.resolve(), args.out.resolve()
assert out.is_relative_to(D)
out.mkdir(parents=True, exist_ok=False)
sys.path.insert(0, str(tree / "backend"))
sys.path.insert(0, str(tree / "backend/tests"))
from vega import calculator, sources
from vega.sources import sportscore
from vega.store import Store, connect_local, migrate, round_stage
from sportscore_replay import play

def read(path):
    return json.loads(path.read_bytes())

def sha(raw):
    return hashlib.sha256(raw).hexdigest()

def dump(name, obj):
    (out / name).write_text(json.dumps(obj, indent=2, ensure_ascii=False, default=str) + "\n")

def exhibit(name, records):
    with (out / name).open("w", newline="") as handle:
        w = csv.DictWriter(handle, fieldnames=list(records[0]), lineterminator="\n")
        w.writeheader()
        w.writerows(records)

raw = (D / "rds/inputs.json.zlib").read_bytes()
receipt = read(D / "rds/receipt.json")
assert sha(raw) == receipt["sha256"] and sha((D / "probe.py").read_bytes()) == receipt["probe_sha256"]
snap = json.loads(zlib.decompress(raw))
assert snap["snapshot"][-1] == "on"
def tab(name):
    return snap[name]["rows"]

original = (D.parent / "widget/fifa-world-cup.json").read_bytes()
widget_receipt = read(D.parent / "widget/fifa-world-cup-receipt.json")
assert sha(original) == widget_receipt["sha256"] and widget_receipt["status"] == 200
widget = json.loads(original)
third = "Ranking of third placed teams"
subset = dict(widget, tables=[x for x in widget["tables"] if x["group"] != third])
assert len(subset["tables"]) == 12 and len(widget["tables"]) == 13
assert len({r["team"] for g in subset["tables"] for r in g["rows"]}) == 48
assert len(next(t["rows"] for t in widget["tables"] if t["group"] == third)) == 12
# This frozen body ends with that table. Preserve every retained byte with a single deletion.
marker = b', {"group": "Ranking of third placed teams"'
assert original.count(marker)==1 and original.endswith(b"]}")
offset = original.index(marker)
truncated = original[:offset] + original[-2:]
assert json.loads(truncated)==subset and len(truncated)==16000
(out / "widget-13-original.json").write_bytes(original)
(out / "widget-derived-twelve.json").write_bytes(truncated)
third_rows=widget["tables"][-1]["rows"]
group_thirds={r["team"]:r for g in subset["tables"] for r in g["rows"] if r["pos"]==3}
assert set(group_thirds)=={r["team"] for r in third_rows}
assert all(r[k]==group_thirds[r["team"]][k] for r in third_rows for k in ("p","w","d","l","gf","ga","pts"))
qualified=[r["team"] for r in third_rows if r["promo_name"]=="Advancing to the Round of 32"]
assert len(qualified)==8

fifadir = T / "world-cup-calendar/raw"
fifa_receipt = read(fifadir / "worldcup2026.json")
fifa_bytes = gzip.decompress((fifadir / "worldcup2026.gz").read_bytes())
assert sha(fifa_bytes) == fifa_receipt["sha256"]
fifa = json.loads(fifa_bytes)["Results"]
rds_teams = {r[0]: r[1] for r in tab("teams")}
rds_ids = {v: k for k, v in rds_teams.items()}
aliases = {"Cabo Verde": "Cape Verde", "Congo DR": "DR Congo", "Curaçao": "Curacao", "Côte d'Ivoire": "Ivory Coast",
           "IR Iran": "Iran", "Korea Republic": "South Korea", "Türkiye": "Turkiye"}
def team_id(obj):
    name = obj["TeamName"][0]["Description"]
    return rds_ids[aliases.get(name, name)]
date_map = {(r[1],r[4],r[5]): r for r in tab("matches")}
assert len(date_map) == 104
metrics = ("played", "won", "drawn", "lost", "goals_for", "goals_against", "points")
group_stats = collections.defaultdict(lambda: [0] * len(metrics))
fixtures = []
for game in fifa:
    day = game["Date"][:10]
    home, away = team_id(game["Home"]), team_id(game["Away"])
    row = date_map[day, home, away]
    stage = game["StageName"][0]["Description"]
    h, a = game["HomeTeamScore"], game["AwayTeamScore"]
    fixtures.append(dict(fifa_id=game["IdMatch"], fifa_number=game["MatchNumber"], fifa_stage_id=game["IdStage"],
                         fifa_stage=stage, fifa_group=(game["GroupName"] or [{}])[0].get("Description"),
                         fifa_date=game["Date"], match_id=row[0], home_id=home, home=rds_teams[home],
                         away_id=away, away=rds_teams[away], fifa_home_score=h, fifa_away_score=a,
                         rds_home_score=row[6],rds_away_score=row[7],rds_round_id=row[8],rds_round=row[9],
                         rds_stage=row[10]))
    if stage == "First Stage":
        assert (h,a) == tuple(row[6:8])
        for t, gf, ga in ((home,h,a),(away,a,h)):
            values = (1,int(gf>ga),int(gf==ga),int(gf<ga),gf,ga,3*int(gf>ga)+int(gf==ga))
            group_stats[t] = [x+y for x,y in zip(group_stats[t],values)]
bronze, = [r for r in fixtures if r["fifa_stage"] == "Bronze final"]
assert len({r["match_id"] for r in fixtures}) == 104 and all(v[0]==3 for v in group_stats.values()) and len(group_stats)==48
assert bronze["fifa_id"] == "400021542" and bronze["match_id"] == 69466 and bronze["rds_round"] == "bronze"
exhibit("fifa-rds-104.csv", fixtures)
stored_groups = {r[1]:list(r[3:10]) for r in tab("official") if r[0] != third}
assert stored_groups == dict(group_stats)
api_names = {rds_teams[k]:k for k in rds_teams}
computed_original = {r[2]: r for r in tab("computed")}
assert len(computed_original)==48 and len(tab("official"))==60
fields = "group_name,team_id,position,played,won,drawn,lost,goals_for,goals_against,points"
scope = "l_1XLtP0"
base = os.environ["REPLAY_LOCAL_PG"].rstrip("/")
assert urlsplit(base).hostname == "127.0.0.1"
db_name = "vega_v2_ssauth_wc_" + uuid.uuid4().hex
dsn = base + "/" + db_name
initial_time = datetime.fromisoformat(widget_receipt["utc"])
server = None
PG = None
calls = []
versions = {}
for file in ("backend/vega/sources/sportscore.py","backend/vega/sources/__init__.py","backend/vega/calculator.py","backend/vega/store.py",
             "backend/sql/138_sportscore_standings.sql","backend/api/src/routes/reference.mjs","backend/api/src/handler.mjs",
             "backend/api/src/db.mjs","backend/tests/sportscore_replay.py"):
    versions[file]=sha((tree / file).read_bytes())
dump("sources.json",dict(git=os.environ["REPLAY_CANDIDATE_REVISION"],
     checkout="candidate",code=versions,serve_sha256=sha((T/"sportscore-authority/e2e/serve.mjs").read_bytes()),
     production_read=snap["snapshot"],rds_sha256=sha(raw),widget=widget_receipt,fifa=fifa_receipt,aliases=aliases))
state = {}

def put_rows(conn, query, values):
    with conn.cursor() as c:
        c.executemany(query,values)

def query_dict(conn, query):
    cur=conn.execute(query)
    return [dict(zip((c.name for c in cur.description),r)) for r in cur.fetchall()]

def get(url, tag=None):
    request=Request(url, headers={"If-None-Match":tag} if tag else {})
    try: reply=urlopen(request,timeout=15)
    except HTTPError as err: reply=err
    body=reply.read()
    return dict(status=reply.status, etag=reply.headers.get("ETag"),body=json.loads(body) if body else None)

def observe(label, tag=None):
    public=get(api)
    assert public["status"]==200
    tables=public["body"]["tables"]
    with PG.transaction():
        dbrows=query_dict(PG, f"SELECT {fields},basis,as_of FROM core.standings_official WHERE competition_season_id=1004 ORDER BY group_name,position,team_id")
        calc=query_dict(PG,"SELECT stage,group_name,team_id,position,played,won,drawn,lost,goals_for,goals_against,points FROM agg.standings WHERE competition_season_id=1004 ORDER BY position,team_id")
    conditional = get(api,tag) if tag else None
    same=get(api,public["etag"])
    assert same["status"]==304 and same["body"] is None
    full = dict(step=label,observed_at=datetime.now(timezone.utc),public=public,conditional=conditional,same_etag=same,official=dbrows,computed=calc)
    dump(label+".json",full)
    state[label]=dict(source=public["body"]["source"],http_status=public["status"],etag=public["etag"],
                      conditional_status=conditional["status"] if conditional else None,etag_same_status=same["status"],official_rows=len(dbrows),
                      official_teams=len({r['team_id'] for r in dbrows}),official_third=sum(r['group_name']==third for r in dbrows),
                      get_tables=len(tables),get_rows=sum(len(t['rows']) for t in tables),
                      get_third=sum(len(t['rows']) for t in tables if t['name']==third))
    return full

def supply(label, body, at, previous):
    def frozen_get(url):
        assert url == widget_receipt["url"]
        calls.append(dict(step=label, time=at.isoformat(), url=url, bytes=len(body), sha256=sha(body),
                          input="upstream bytes" if body==original else "derived omission in local fixture"))
        return json.loads(body)
    code = play(sources,sportscore,PG,{"key":scope},{"at":at},frozen_get)
    result=observe(label,previous["public"]["etag"])
    state[label]["adapter_outcome"]=code or "ok"
    assert code is None,code
    return result

def plain_rows(view):
    return [{k:v for k,v in r.items() if k not in ("basis","as_of")} for r in view["official"]]

def scores(view):
    return {r["team_id"]:[r[k] for k in metrics] for r in view["computed"]}

def rank(view):
    return {r["team_id"]:r["position"] for r in view["computed"]}

def recalc():
    PG.execute("DELETE FROM agg.standings WHERE competition_season_id=1004")
    PG.execute(calculator.STANDINGS_SQL,{"cs":1004})

admin = psycopg.connect(base + "/postgres",autocommit=True)
try:
    admin.execute(sql.SQL("CREATE DATABASE {}").format(sql.Identifier(db_name)))
    PG=connect_local(dsn)
    assert PG.execute("SHOW server_version").fetchone()[0].startswith("18.")
    server_version=PG.execute("SHOW server_version").fetchone()[0]
    migrate(PG)
    with PG.transaction():
        Store(PG).season("2025/2026")
        ed, = tab("editions")
        PG.execute("INSERT INTO core.competitions(id,name,kind) VALUES (%s,%s,%s)",(ed[1],ed[5],ed[6]))
        PG.execute("INSERT INTO core.competition_seasons(id,competition_id,season_id,native_label,is_current) VALUES (%s,%s,%s,%s,%s)",ed[:5])
        PG.execute("INSERT INTO core.provider_ids(entity_type,provider,provider_key,entity_id) VALUES ('competition','pitchapi',%s,%s)",(ed[7],ed[1]))
        put_rows(PG,"INSERT INTO core.teams(id,name,short_name,is_national) VALUES (%s,%s,%s,true)",(r[:3] for r in tab("teams")))
        put_rows(PG,"INSERT INTO core.provider_ids(entity_type,provider,provider_key,entity_id) VALUES ('team','pitchapi',%s,%s)",((r[3],r[0]) for r in tab("teams")))
        put_rows(PG,"INSERT INTO core.team_seasons(team_id,competition_season_id) VALUES (%s,1004)",((r[0],) for r in tab("teams")))
        put_rows(PG,"INSERT INTO core.entity_names(entity_type,entity_id,name,normalized,kind,source) VALUES ('team',%s,%s,%s,%s,%s)",tab("names"))
        rounds={r[8]:(r[8],r[9],r[10]) for r in tab("matches")}
        put_rows(PG,"INSERT INTO core.rounds(competition_season_id,id,name,stage) VALUES (1004,%s,%s,%s)",rounds.values())
        put_rows(PG,"INSERT INTO core.matches(competition_season_id,season_id,id,match_date,kickoff_at,status,home_team_id,away_team_id,home_score,away_score,round_id,first_finished_at,source) VALUES (1004,2025,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,'pitchapi')",
                 (r[:9]+[r[11]] for r in tab("matches")))
        put_rows(PG,f"INSERT INTO core.standings_official(competition_season_id,{fields},as_of,source) VALUES (1004,"+",".join(["%s"]*12)+")",tab("official"))
        put_rows(PG,"INSERT INTO agg.standings(competition_season_id,stage,group_name,team_id,position,played,won,drawn,lost,goals_for,goals_against,points,updated_at) VALUES (1004,"+",".join(["%s"]*12)+")",tab("computed"))
    with (out / "server.stderr").open("w") as stderr:
        server=subprocess.Popen(["node",str(T/"sportscore-authority/e2e/serve.mjs"),str(tree),dsn],stdout=subprocess.PIPE,stderr=stderr,text=True)
        port=server.stdout.readline().strip()
        assert port.isdigit(),(out/"server.stderr").read_text()
        api="http://127.0.0.1:"+port+"/api/standings?competition="+scope
        seed=observe("00-rds-seed")
        complete=supply("01-complete",original,initial_time,seed)
        repeat=supply("02-repeat",original,initial_time+timedelta(hours=3),complete)
        partial=supply("03-without-third",truncated,initial_time+timedelta(hours=6),repeat)
        recovered=supply("04-recovered",original,initial_time+timedelta(hours=9),partial)
        assert plain_rows(seed)==plain_rows(complete)==plain_rows(repeat)==plain_rows(recovered)
        assert plain_rows(partial)==[r for r in plain_rows(complete) if r["group_name"]!=third]
        assert partial["public"]["body"]["tables"]==[g for g in complete["public"]["body"]["tables"] if g["name"]!=third]
        assert recovered["public"]["body"]["tables"]==complete["public"]["body"]["tables"]
        for step in (partial,recovered):
            assert step["conditional"]["status"]==200
        # A separate controlled state exercises the actual fallback without pretending that the omission triggered it.
        with PG.transaction():
            PG.execute("DELETE FROM core.standings_official WHERE competition_season_id=1004")
            recalc()
        fallback=observe("05-fallback-as-captured",recovered["public"]["etag"])
        assert fallback["computed"]==seed["computed"], "computed inputs reconstructed from captured matches"
        with PG.transaction():
            PG.execute("UPDATE core.rounds SET stage='knockout' WHERE id=%s",(bronze['rds_round_id'],))
            recalc()
        fixed=observe("06-fallback-bronze-excluded",fallback["public"]["etag"])
        assert scores(fixed)==dict(group_stats)
        for view in (fallback,fixed):
            assert view["public"]["body"]["source"]=="Vega"
            flat=[r for g in view["public"]["body"]["tables"] for r in g["rows"]]
            assert len(flat)==48
            for row in flat:
                team=api_names[row["name"]]
                assert [row[k] for k in ("played","wins","draws","losses","goalsFor","goalsAgainst","points")]==scores(view)[team]
                assert row["position"]==rank(view)[team]
        differences=[]
        for team in sorted(group_stats):
            before,after=scores(fallback)[team],scores(fixed)[team]
            differences.append(dict(team_id=team,team=rds_teams[team],vega_position_before=rank(fallback)[team],
                  vega_position_after=rank(fixed)[team],position_delta=rank(fixed)[team]-rank(fallback)[team],
                  **{"before_"+k:v for k,v in zip(metrics,before)},**{"group_only_"+k:v for k,v in zip(metrics,after)}))
        exhibit("fallback-by-team.csv", differences)
        sporting=[r["team"] for r in differences if r["before_played"]!=r["group_only_played"]]
        assert set(sporting)=={"England","France"}
        label_rows={x["group"]:len(x["rows"]) for x in widget["tables"]}
        dump("findings.json",dict(server_version=server_version,inputs=dict(source_tables=label_rows,
            original_sha256=sha(original),omission_sha256=sha(truncated),source_observed=widget_receipt["utc"],
            database_observed=snap["snapshot"][1],qualified_thirds_in_original=qualified,
            removed_byte_interval=[offset,len(original)-2],deleted_bytes=len(original)-len(truncated)),
            steps=state, bronze=bronze, deployed_name_parser_for_bronze=round_stage("bronze"),impacted_result_teams=sporting,
            position_changes=[r for r in differences if r["position_delta"]], all_48_corrected_stats_equal_fifa=True,
            group_totals=dict(observed=sum(r["before_played"] for r in differences),group_only=sum(r["group_only_played"] for r in differences)),
            public_table_retention_acceptance="FAIL" if state["03-without-third"]["get_third"]==0 else "PASS",
            restored_values_verified=True))
        dump("provider-observations.json",calls)
        print(json.dumps({"states":state,"bronze":bronze["match_id"],"teams_with_changed_numbers":sporting,"changed_positions":sum(bool(r["position_delta"]) for r in differences)},ensure_ascii=False))
finally:
    if server is not None:
        server.terminate()
        server.wait(timeout=12)
    if PG is not None:
        PG.close()
    admin.execute(sql.SQL("DROP DATABASE IF EXISTS {} WITH (FORCE)").format(sql.Identifier(db_name)))
    admin.close()
