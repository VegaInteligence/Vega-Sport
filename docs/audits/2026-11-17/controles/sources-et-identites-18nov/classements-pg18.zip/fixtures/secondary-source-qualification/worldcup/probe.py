def collect(db):
    def t(q):
        c=db.execute(q);return dict(columns=[x.name for x in c.description],rows=c.fetchall())
    with db.transaction():
        db.execute("SET TRANSACTION ISOLATION LEVEL REPEATABLE READ READ ONLY")
        db.execute("SET LOCAL statement_timeout='45s'")
        meta=db.execute("SELECT current_database(),transaction_timestamp()::text,pg_current_snapshot()::text,current_setting('transaction_read_only')").fetchone()
        assert meta[0]=='vega_v2' and meta[-1]=='on'
        editions=t("""SELECT cs.id,cs.competition_id,cs.season_id,cs.native_label,cs.is_current,c.name,c.kind::text,
                      p.provider_key AS pitch_key FROM core.competition_seasons cs JOIN core.competitions c ON c.id=cs.competition_id
                      JOIN core.provider_ids p ON p.entity_type='competition' AND p.provider='pitchapi' AND p.entity_id=c.id AND p.is_current
                      WHERE cs.id=1004 AND p.provider_key='l_1XLtP0'""")
        teams=t("""SELECT t.id,t.name,t.short_name,p.provider_key FROM core.team_seasons ts JOIN core.teams t ON t.id=ts.team_id
                   LEFT JOIN core.provider_ids p ON p.entity_type='team' AND p.provider='pitchapi' AND p.entity_id=t.id AND p.is_current
                   WHERE ts.competition_season_id=1004 ORDER BY 1,4""")
        names=t("""SELECT n.entity_id,n.name,n.normalized,n.kind::text,n.source::text FROM core.entity_names n JOIN core.team_seasons ts
                   ON ts.team_id=n.entity_id AND ts.competition_season_id=1004 WHERE n.entity_type='team' ORDER BY 1,2,3,4,5""")
        matches=t("""SELECT m.id,m.match_date::text,m.kickoff_at::text,m.status::text,m.home_team_id,m.away_team_id,m.home_score,m.away_score,
                     m.round_id,r.name,r.stage::text,m.first_finished_at::text FROM core.matches m LEFT JOIN core.rounds r ON r.id=m.round_id
                     WHERE m.competition_season_id=1004 ORDER BY m.id""")
        official=t("""SELECT group_name,team_id,position,played,won,drawn,lost,goals_for,goals_against,points,as_of::text,source::text FROM core.standings_official
                      WHERE competition_season_id=1004 ORDER BY group_name,position,team_id""")
        computed=t("""SELECT stage,group_name,team_id,position,played,won,drawn,lost,goals_for,goals_against,points,updated_at::text FROM agg.standings
                      WHERE competition_season_id=1004 ORDER BY stage,group_name,position,team_id""")
        return dict(snapshot=meta,editions=editions,teams=teams,names=names,matches=matches,official=official,computed=computed)
