# Rejouer les deux contrôles de classement

Ce paquet reconstruit les deux cas sur une base PostgreSQL 18 locale et interroge la vraie route HTTP de Vega. Les migrations, le writer SportScore, le lecteur API, ses dépendances JavaScript, le pilote PostgreSQL Python, les données d’entrée et les résultats de référence sont inclus. Le lancement se fait depuis un dossier nouvellement extrait. Aucun dépôt Git, serveur de production, compte fournisseur, accès internet, conteneur ou installation de paquets n’est nécessaire.

## Lancement

Utiliser un compte local non-root, Python 3.13 ou ultérieur, Node.js 20 ou ultérieur et PostgreSQL 18 avec `initdb`, `pg_ctl`, `postgres` et sa bibliothèque cliente `libpq`. La répétition de référence a utilisé Python 3.14.6, Node.js 26.4.0 et PostgreSQL 18.6 sur macOS arm64. Le pilote Python pur fourni se charge avec la libpq locale. Les binaires du système restent des prérequis.

```sh
mkdir extraction
unzip -q classements-pg18.zip -d extraction
python3 -I extraction/run.py --verify-only
python3 -I extraction/run.py --pg-bin /chemin/vers/postgresql-18/bin --out "$PWD/resultats"
```

Si la bibliothèque partagée est installée dans un autre dossier que `../lib` par rapport aux binaires, ajouter `--pg-lib /chemin/vers/libpq`. Le dossier de résultats doit être neuf et extérieur au dossier extrait. Le lanceur crée une instance privée sur un port libre de la boucle locale. Un mot de passe aléatoire ne sert qu’à cette instance et le répertoire temporaire est supprimé à la fin. Les deux parcours utilisent chacun une base neuve. Le lecteur HTTP exécute les requêtes sous le rôle `vega_read`.

## Résultats attendus

| Parcours | Observation attendue dans le rejeu |
|---|---|
| Plusieurs sources officielles | Le scénario S30 commence avec SportScore. Une observation secondaire périmée sur une équipe provoque le repli de toute l’édition vers Vega. Son retrait rétablit le corps initial. Une observation secondaire plus récente sur cette seule équipe produit un GET mixte avec 777 points. Une ancienne phase périmée de la même source entraîne aussi le repli vers Vega. |
| Classement des troisièmes du Mondial 2026 | Le widget authentique contient 13 tableaux, 60 lignes et 48 équipes. Une réponse dérivée, amputée uniquement des douze lignes transversales, est acceptée par le writer. Le stockage et le GET SportScore passent ensemble à 48 lignes et 12 tableaux. Le corps original rétablit les valeurs et rangs des treize tableaux. |
| Match de bronze dans le secours Vega | France–Angleterre 4–6 est la petite finale FIFA du 18 juillet 2026, match 400021542 et match Vega 69466. Le tour natif `bronze` est classé `regular`. Dans un état de secours simulé séparément, corriger ce seul type restitue les chiffres des 48 équipes des poules, ramène le total de 146 à 144 côtés et modifie sept positions du classement global. |

Le résultat `execution: PASS` confirme que les observations sont reproduites. Les trois critères sportifs et de conservation restent en échec sur ce candidat. Les cinq observations multi-source sont injectées ou mesurées localement. La transaction de production du 18 novembre à 07:52 UTC trouvait une seule source sur 1 086 lignes, 60 éditions et 981 équipes. À 07:56:11 UTC, le widget du Mondial retournait HTTP 200 avec les treize tableaux. RDS en conservait les 60 lignes à 07:57:10 UTC. La réponse amputée et la suppression des lignes officielles utilisée pour forcer le secours sont des entrées de test. Les observations live proviennent uniquement de ces pièces congelées.

Le reçu principal est `resultats/receipt.json`. Le détail des lignes stockées et des GET se trouve dans `resultats/multisource.json` et dans les sept états `resultats/mondial/0*-*.json`. Les comparaisons avec FIFA, y compris dates, côtés et scores des 104 matchs, figurent dans `resultats/mondial/fifa-rds-104.csv`. Les 48 rangs avant et après correction figurent dans `resultats/mondial/fallback-by-team.csv`. Pour le Mondial, les sept corps sportifs sont comparés à leurs empreintes historiques après retrait de l’heure de calcul. Les GET conditionnels et les heures sont vérifiés dans les observations de chaque expérience. Les valeurs temporelles d’un nouveau calcul sont conservées dans sa propre sortie.

## Provenance

L’archive contient également [le reçu d’une première extraction vierge](verification/receipt.json), [les cinq observations multi-source](verification/multisource.json), [les résultats du Mondial](verification/mondial/findings.json), [le GET amputé](verification/mondial/03-without-third.json) et [le GET rétabli](verification/mondial/04-recovered.json). Ce premier reçu décrit les fichiers du paquet avant l’ajout des observations elles-mêmes. Une nouvelle extraction produit son propre reçu et compte les fichiers effectivement présents dans son manifeste.

La partie exécutable correspond au checkout d’ingestion sur la base Git `1b28961a88e968d5602f9fb278fc3c471ebb7467` avec les changements locaux du candidat nécessaires aux tests. [Inventaire de la base, des fichiers candidats et des bibliothèques](PROVENANCE.json) · [Diff des quatre fichiers du candidat par rapport à la base](candidate.patch) · [Empreintes du paquet](SHA256SUMS)

Le lanceur portable adapte uniquement la configuration locale, les chemins du paquet et l’enregistrement de la révision dans les deux scripts de preuve. Le writer, les migrations et le lecteur du candidat sont fournis sous leurs octets de travail. `fixtures/sportscore-authority/e2e/serve.mjs` est le serveur HTTP original. Les deux reçus RDS portent les empreintes des données et des requêtes. Les identifiants techniques du compte et des tâches cloud ont été retirés de leur copie. Les seules données de football distribuées sont le recensement des sources, l’édition mondiale en question, le widget et les pièces FIFA correspondantes. Les scénarios de l’outil de test utilisent des clubs synthétiques. Les dépendances conservent leurs licences.

La vérification ne réinterroge pas les services distants. La qualification d’un second fournisseur revient à VI-29. La phase du match de bronze et la republication des classements concernés reviennent à VI-21.
