-- Role eligibility equals assign_roles under the deployed source: only a detailed slot (11, 30..119) supplies role history.
-- Generic codes and goalkeeper signals apply only to that same player's current row.
WITH missing AS MATERIALIZED (
 SELECT m.competition_season_id AS edition_id,extract(year FROM m.match_date-interval '7 months')::int AS award,m.id AS match_id,p.player_id,
        coalesce(l.position_id,p.position_id) AS pos,p.position_id AS stats_slot,p.goals_prevented IS NOT NULL AS keeper,p.touches IS NOT NULL AS measured,p.updated_at
 FROM core.matches m JOIN core.competition_seasons cs ON cs.id=m.competition_season_id AND cs.cup_key IS NULL AND cs.archive_key IS NULL
 JOIN core.player_match_stats p ON p.match_id=m.id AND p.season_id=m.season_id AND p.minutes_played>0 JOIN core.teams t ON t.id=p.team_id
 LEFT JOIN core.lineup_players l ON (l.season_id,l.match_id,l.player_id)=(p.season_id,p.match_id,p.player_id)
 LEFT JOIN agg.player_power_matches pm ON pm.season_id=extract(year FROM m.match_date-interval '7 months')::int AND pm.match_id=m.id AND pm.player_id=p.player_id
 WHERE m.season_id=%(partition)s AND m.status='finished' AND pm.match_id IS NULL
 AND extract(year FROM m.match_date-interval '7 months')::int IN (%(partition)s,%(partition)s-1)
), direct AS MATERIALIZED (
 SELECT *,coalesce(pos IN(0,1,2,3,11) OR pos BETWEEN 30 AND 119,false) OR keeper AS immediate FROM missing
), unresolved AS MATERIALIZED (
 SELECT DISTINCT award,player_id FROM direct WHERE NOT immediate
), history AS MATERIALIZED (
 SELECT u.*,exists(
 SELECT 1 FROM core.player_match_stats p JOIN core.matches m ON m.id=p.match_id AND m.season_id=p.season_id AND m.status='finished'
 JOIN core.competition_seasons cs ON cs.id=m.competition_season_id AND cs.archive_key IS NULL AND cs.cup_key IS NULL
 JOIN core.teams t ON t.id=p.team_id LEFT JOIN core.lineup_players l ON (l.season_id,l.match_id,l.player_id)=(p.season_id,p.match_id,p.player_id)
 WHERE p.season_id IN(u.award,u.award+1) AND m.match_date>=make_date(u.award,8,1) AND m.match_date<make_date(u.award+1,8,1)
 AND p.player_id=u.player_id AND p.minutes_played>0 AND (coalesce(l.position_id,p.position_id)=11 OR coalesce(l.position_id,p.position_id) BETWEEN 30 AND 119)) AS has_detailed
 FROM unresolved u
)
SELECT d.edition_id,d.award,d.match_id,d.player_id,d.pos,d.stats_slot,d.keeper,d.measured FROM direct d
JOIN history h USING(award,player_id) WHERE NOT d.immediate AND NOT h.has_detailed ORDER BY d.match_id,d.player_id
