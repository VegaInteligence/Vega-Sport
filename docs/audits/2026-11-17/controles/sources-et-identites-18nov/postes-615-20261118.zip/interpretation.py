"""Name the claim supported by the evidence independently of the engine and date."""
STATUS = {
    'wrong statistics actor proved': 'erreur_acteur_attestee',
    'one issuer player, two source IDs on this fixture': 'acteur_match_corrobore',
    'same footballer in official match report': 'acteur_match_corrobore',
    'same footballer supported by club and federation': 'acteur_match_corrobore',
    'one match-qualified transliteration candidate': 'identite_candidate_sur_le_match',
    'participant and missing lineup proved': 'participation_attestee_composition_absente',
    'participation only; competing source identity': 'participation_attestee_identite_concurrente',
    'hold confirmed homonyms': 'homonymes_distincts_attestes',
    'hold conflicting existing statistical row': 'refus_autre_ligne_statistique',
    'candidate source pair corroborated on other fixtures': 'identite_candidate',
    'same name and side, different IDs, validate exact actor': 'identite_candidate',
    'same-key measured slot outside decoder': 'emplacement_atteste_role_non_decode',
    'prior-year detailed same-ID observation only': 'observation_autre_annee',
    'future-only detailed same-ID observation': 'observation_autre_annee',
    'no verified match role; source review': 'role_match_indetermine'
}

def interpretation(r, prior, later):
    chronology = ('anterieur_et_futur' if prior and later else
                  'anterieur_seul' if prior else 'futur_seul' if later else 'aucun_temoin_autre_annee')
    usable = ('rencontre_anterieure_ingestion_historique_inconnue' if prior else
              'impossible_au_match_toutes_les_rencontres_sont_futures' if later else 'aucune_rencontre_detaillee_autre_annee')
    return dict(partition=r['partition'],award=r['award'],edition=r['edition'],match=r['match'],player=r['player'],
                moteur='aucun_role',preuve=STATUS[r['note_source']],chronologie_autre_annee=chronology,
                utilisation_au_match=usable,disponibilite_historique_source_du_match='non_demontree')
