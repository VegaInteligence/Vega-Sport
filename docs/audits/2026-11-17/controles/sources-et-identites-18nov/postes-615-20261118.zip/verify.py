"""Validate the delivered projections and replay role assignment, using Python's standard library."""
import argparse
import csv
import hashlib
import json
import sys
from collections import Counter, defaultdict
from pathlib import Path

D = Path(__file__).resolve().parent
sys.dont_write_bytecode = True
sys.path.insert(0,str(D))
sys.path.insert(0,str(D/'reader'))
from assign import assign_roles
from interpretation import interpretation

def table(name):
    with (D/name).open(encoding='utf-8',newline='') as f:
        return list(csv.DictReader(f))

def obj(name):
    return json.loads((D/name).read_bytes())

def key(row):
    return row['partition'],row['match'],row['player']

def unique(rows):
    keyed={key(r):r for r in rows}
    assert len(keyed)==len(rows)
    return keyed

def number(value):
    return int(value) if value!='' else None

def verify():
    if not __debug__:
        raise SystemExit("Désactiver le mode Python -O pour exécuter les contrôles.")
    contents={name:h for h,name in (l.split('  ',1) for l in (D/'SHA256SUMS').read_text().splitlines())}
    actual={p.relative_to(D).as_posix() for p in D.rglob('*') if p.is_file() and '__pycache__' not in p.parts}
    assert actual==set(contents)|{'SHA256SUMS'}, 'inventaire'
    for n,h in contents.items():
        assert hashlib.sha256((D/n).read_bytes()).hexdigest()==h, 'empreinte '+n
    originated=obj('provenance.json')
    assert originated['sealed_manifest_sha256']=='16f811472dbb03f10229f9691ff968b4953b3e2fff82c450ecfb0424d275669e'
    assert all(contents[n]==h for n,h in originated['sealed_inputs'].items() if n in contents)
    base=unique(table('appearances-615.csv'));decisions=unique(table('decisions-615.csv'))
    angles=unique(table('lecture-615.csv'));assert base.keys()==decisions.keys()==angles.keys() and len(base)==615
    assert len({k[1] for k in base})==587 and len({k[2] for k in base})==131
    editions=Counter(r['edition'] for r in base.values())
    assert len(editions)==69 and editions=={r['edition']:int(r['rows']) for r in table('by-edition.csv')}
    assert Counter(r['player'] for r in base.values())=={r['player']:int(r['rows']) for r in table('by-player.csv')}
    assert Counter((r['edition'],r['player'],r['note_source']) for r in decisions.values())=={
        (r['edition'],r['player'],r['source_class']):int(r['participations']) for r in table('by-edition-player-source.csv')}
    audits=obj('adjudication.json')
    assert Counter(r['note_source'] for r in decisions.values())==audits['exclusive_decisions']
    observations=defaultdict(list)
    for w in table('chronologie/observations.csv'):
        observations[w['player']].append(w)
    for k,r in base.items():
        w=observations[k[2]]
        assert all(t['award']!=r['award'] and t['source']=='lineup' for t in w)
        prior=[v for v in w if v['date'] < r['date']];future=[v for v in w if v['date'] > r['date']]
        assert len(prior)+len(future)==len(w)==int(r['other_year_detailed'])
        assert (len(prior),len(future))==(int(r['prior_year_detailed']),int(r['future_year_detailed']))
        assert angles[k]==interpretation(decisions[k],prior,future)
    chronology=Counter(r['chronologie_autre_annee'] for r in angles.values())
    assert chronology==dict(anterieur_et_futur=9,anterieur_seul=15,futur_seul=150,aucun_temoin_autre_annee=441)
    denied=set();awardrows=defaultdict(list);maxima=defaultdict(dict)
    for r in table('reader/2914-entrees.csv'):
        year=r['award'];part=r['partition'];m=int(r['match']);t=int(r['team'])
        slot=number(r['slot']);pid=int(r['player'])
        awardrows[year].append(dict(partition=part,match_id=m,team_id=t,player_id=pid,minutes_played=int(r['minutes']),
            position_id=slot,formation=r['formation'] or None,goals_prevented=0 if r['keeper_signal']=='True' else None))
        if slot==11 or 30<=(slot or 0)<=119:
            v=int(r['full_side_max']);assert v>=slot and maxima[year].setdefault((m,t),v)==v
    receipt=obj('reader-replay.json');total=0
    for year, rows in awardrows.items():
        assert len({(r['partition'],r['match_id'],r['player_id']) for r in rows})==len(rows)
        fillers=[dict(match_id=m,team_id=t,player_id=-i-1,minutes_played=0,position_id=v,formation=None,goals_prevented=None)
                 for i,((m,t),v) in enumerate(sorted(maxima[year].items()))]
        keep=assign_roles(rows+fillers)
        omitted={(r['partition'],str(r['match_id']),str(r['player_id'])) for r in rows if r['role'] is None}
        assert not (omitted & denied)
        denied.update(omitted);total+=len(rows)
        expected=receipt['award'][year]
        assert len(rows)==expected['rows'] and len(omitted)==expected['excluded']
        assert sum(r['player_id']>0 for r in keep)==expected['qualifying']
    assert denied==base.keys() and total==2914
    checks=table('official-appearance-checks.csv')
    local={r['match']:r for r in table('preuves/26-rencontres-locales.csv')}
    assert len(local)==26 and len(checks)==17
    reliable={r['match']:r for r in checks if r['adjudication']=='wrong statistics actor proved'}
    eight=obj('preuves/lfp-huit.json')
    assert {str(r['match']) for r in eight}==reliable.keys() and len(eight)==8
    for f in eight:
        m=str(f['match']);c=reliable[m];l=local[m]
        t=base[l['partition'],m,'5978']
        assert (t['date'],c['date'],c['url'])==(f['date'],f['date'],f['url']) and f['club']=='Lorient'
        assert f['player_id']==511296 and f['shirt']==29 and f['position']==4 and f['played']
        assert f['name'].casefold().startswith('doucour') and '511296'==c['issuer_id']
        distribution=f['team_minutes_touches_counts'];assert sum(v[2] for v in distribution)==f['team_players']
        assert sum(n for mi,to,n in distribution if (mi,to)==(int(t['mins']),int(t['touches'])))==1
        assert (f['minutes'],f['touches'])==(int(l['minutes']),int(l['touches']))==(int(t['mins']),int(t['touches']))
        assert l['stats_player']=='5978' and l['lineup_player']=='18586' and l['team']==l['lineup_team']==t['team']
        assert l['other_stats_present']=='False' and l['slot'] in ('3','115')
    assert Counter(local[m]['slot'] for m in reliable)=={'3':6,'115':2}
    controls=table('korean-homonym-controls.csv');negative=obj('preuves/kleague.json')
    assert {'수비수 김민혁','미드필더 김민혁','1992 년생 동갑내기','성남으로 유니폼'}==set(negative['terms'])
    assert len(controls)==len({r['match'] for r in controls})==18
    present=0
    for c in controls:
        m=c['match'];l=local[m];k=(l['partition'],m,'45927')
        assert angles[k]['preuve']=='homonymes_distincts_attestes'
        assert c['player']==l['stats_player']=='45927' and c['other']==l['lineup_player']=='62771'
        assert l['team']==l['lineup_team'] and c['source']==negative['url']
        assert (c['stats_minutes'],c['stats_touches'])==(l['minutes'],l['touches'])
        assert (c['other_minutes'],c['other_touches'])==(l['other_minutes'],l['other_touches'])
        present+=int(l['other_stats_present']=='True' and int(l['other_minutes'] or 0)>0)
    assert present==4
    strict=[r for r in base.values() if r['sheet_comparison'].startswith('same-name other ID, no stats') and r['player']!='45927']
    assert len(strict)==313 and sum(int(r['other_slot'] or -100)==11 or 30<=int(r['other_slot'] or -100)<=119 for r in strict)==175
    return dict(verification='OK',fichiers_verifies=len(contents),participations=total,sans_role=len(denied),
                editions=len(editions),joueurs=131,matchs=587,chronologie=dict(chronology),preuves_lfp=len(eight),
                homonymes=18,avec_deux_lignes_positives=present,candidats_nominaux=len(strict)),angles

if __name__=='__main__':
    p=argparse.ArgumentParser()
    p.add_argument('--match',help='identifiant numérique local')
    p.add_argument('--joueur',help='identifiant numérique local')
    args=p.parse_args()
    result,angles=verify()
    if args.match or args.joueur:
        result['selection']=[r for r in angles.values() if (not args.match or r['match']==args.match)
                             and (not args.joueur or r['player']==args.joueur)]
    print(json.dumps(result,indent=2,ensure_ascii=False))
