from collections import defaultdict
LINE_DEFAULT = {0: "goalkeeper", 1: "centre_back", 2: "central_midfielder", 3: "centre_forward"}

def role_of(formation, pos, top):
    """The role of a starter's slot, read with his team's formation and its highest slot.

    A slot is a row (its tens: 3 the defence … 10 and 11 the attack) and a place across
    the pitch (its units: 1 and 9 the touchlines, 5 the axis). The same slot is not the
    same role everywhere: 103 and 107 are the wingers of a 4-3-3 and the strikers of a
    4-2-4; 72 and 78 the wide midfielders of a 4-4-2 and the wing-backs of a 3-4-3; 84 and
    86 the interiors of a 4-1-4-1 and the playmakers of a 3-4-2-1 (slots seen on the base,
    12 November 2026)."""
    if pos is None or pos <= 3:
        return None
    if pos == 11:
        return "goalkeeper"
    try:
        lines = [int(x) for x in (formation or "").split("-")]
    except ValueError:
        lines = []
    back_three = bool(lines) and lines[0] == 3
    row, place = pos // 10, pos % 10
    wide = place in (1, 2, 8, 9)
    if row == 3:
        return "full_back" if wide else "centre_back"
    if row == 4:
        return "full_back"
    if row == 5:
        return "full_back" if place in (1, 9) else "defensive_midfielder"
    if row in (6, 7):
        if wide:
            return "full_back" if back_three else "winger"
        if row == 7:
            return "central_midfielder"
        return "central_midfielder" if place in (3, 7) else "defensive_midfielder"
    if row == 8:
        if wide:
            return "full_back" if back_three else "winger"
        # Behind a single holding midfielder the row is the midfield itself.
        return "central_midfielder" if len(lines) >= 3 and lines[1] == 1 else "winger"
    if row == 9:
        if wide:
            return "winger"
        return "centre_forward" if (top or pos) // 10 == 9 else "winger"
    if row in (10, 11):
        if wide:
            return "winger"
        if place in (3, 7):
            return "centre_forward" if lines and lines[-1] == 4 else "winger"
        return "centre_forward"
    return None

def assign_roles(rows):
    """The role of each player-match: its slot's, else the player's most played role."""
    top = defaultdict(int)
    for r in rows:
        if r["position_id"]:
            key = (r["match_id"], r["team_id"])
            top[key] = max(top[key], r["position_id"])
    slot_role = {}
    minutes = defaultdict(lambda: defaultdict(float))
    for r in rows:
        role = role_of(r.get("formation"), r["position_id"], top[(r["match_id"], r["team_id"])])
        slot_role[(r["match_id"], r["player_id"])] = role
        if role:
            minutes[r["player_id"]][role] += r["minutes_played"]
    for r in rows:
        role = slot_role[(r["match_id"], r["player_id"])]
        if role is None:
            played = minutes.get(r["player_id"])
            pos = r["position_id"]
            if pos == 0:
                role = "goalkeeper"
            elif played:
                role = max(sorted(played), key=lambda x: played[x])
            else:
                role = LINE_DEFAULT.get(pos)
            if role is None and r.get("goals_prevented") is not None:
                role = "goalkeeper"
        r["role"] = role
    return [r for r in rows if r["role"]]
