# Les 615 participations sans poste

Le 18 novembre 2026, le moteur déployé laisse 615 participations sans rôle sur les 2 914 qu’il lit pour les 131 joueurs concernés. Elles couvrent 587 matchs et 69 éditions. Ce complément permet de refaire ce calcul hors ligne, d’ouvrir la décision de chaque ligne et d’examiner deux dossiers d’identité documentés. Les données représentent les captures RDS du 18 novembre, de 07:42 à 08:12 UTC. [Vue par participation](lecture-615.csv) · [Résultat du moteur](reader-replay.json)

## Lire ou vérifier

Extraire le ZIP entier dans un dossier dédié. Avec Python 3.10 ou version ultérieure, depuis sa racine, exécuter la première commande pour tout vérifier. Les deux suivantes affichent aussi la décision du match ou du joueur choisi. Le lecteur utilise uniquement la bibliothèque standard et les fichiers de l’archive.

```sh
python3 -B verify.py
python3 -B verify.py --match 126697
python3 -B verify.py --joueur 45927
```

La sortie attendue donne `OK`, 2 914 participations lues, 615 sans rôle, huit erreurs d’acteur LFP et 18 participations soumises au refus d’homonymie. Les clés de jointure sont la partition physique, le match et le joueur. L’année `award` court du 1er août au 1er août suivant. L’édition désigne une compétition-saison. [Registre technique des 615](appearances-615.csv) · [Décisions et motifs](decisions-615.csv) · [Par édition](by-edition.csv) · [Par joueur](by-player.csv) · [Par édition, joueur et type de preuve](by-edition-player-source.csv)

## Lire la preuve à la date du match

Chaque ligne de la [vue de lecture](lecture-615.csv) donne trois réponses distinctes.

| Colonne | Interprétation |
| --- | --- |
| `moteur` | `aucun_role` signifie que le calcul déployé écarte cette clé. La méthode originale est rejouée sur sept fenêtres de notation. |
| `preuve` | Le libellé précise si l’acteur, l’homonymie, la participation ou le seul emplacement sont attestés, ou si l’identité reste candidate. Un compte rendu peut confirmer une présence sans trancher le poste tactique. |
| `utilisation_au_match` | Une rencontre antérieure peut être consultée rétrospectivement. Son heure d’ingestion historique reste inconnue. Une rencontre future ne pouvait pas être observée pendant le match cible. |
| `disponibilite_historique_source_du_match` | La capture de 2026 ne restitue pas l’état du système le jour de chaque match. La disponibilité à cette date est marquée `non_demontree`, y compris pour les erreurs d’acteur établies aujourd’hui. |

Un poste détaillé du même ID existe exclusivement dans le futur pour **150** participations. Il existe seulement dans une année antérieure pour **15**, des deux côtés du match pour **9** et dans aucune autre année admissible pour **441**. Les 24 avec un précédent ouvrent une piste d’examen. Sept matchs documentent les dossiers des cinq joueurs qui concentrent 213 participations. Les 206 autres nécessitent encore une vérification individuelle. Après contrôle des homonymes, 313 participations ont un autre identifiant de même nom, sur le bon côté, sans ligne statistique concurrente. Ces groupes se recoupent. [Observations datées par joueur](chronologie/observations.csv) · [17 contrôles avec source primaire](official-appearance-checks.csv) · [Agrégats de décision](adjudication.json)

## Huit erreurs d’acteur et un contrôle négatif

Pour les huit matchs lorientais 126697, 127910, 127991, 87633, 87644, 87650, 87658 et 87665, la LFP attribue à Siriné Doucouré (Opta 511296, n° 29) le couple minutes/touches de la ligne Vega d’Henri (5978). Chaque couple est unique dans l’effectif du côté examiné. Le joueur correct est déjà dans la composition locale sous 18586, avec six codes 3 et deux codes 115. La correction porte sur les huit attributions individuelles. Les deux joueurs restent distincts. Le ZIP conserve, par match, l’histogramme complet des couples minutes/touches du côté lorientais, le joueur retenu, l’URL et le SHA-256 de la réponse officielle. [Projections LFP](preuves/lfp-huit.json) · [Lignes locales](preuves/26-rencontres-locales.csv)

À Seongnam, la K League décrit deux joueurs du même nom et de la même année de naissance, un défenseur et un milieu. Le registre conserve les ID locaux 45927 et 62771 séparés pour 18 matchs. Ils ont chacun leur propre ligne statistique positive sur quatre matchs. Les quatorze autres seraient passés au travers d’un contrôle limité à l’absence de ligne concurrente. Le ZIP inclut les quatre fragments courts du texte officiel utilisés pour trancher, son URL et son empreinte. [Contrôles des 18 matchs](korean-homonym-controls.csv) · [Pièce K League](preuves/kleague.json)

## Portée de la reproduction

Le lecteur vérifie l’inventaire, les comptages et les clés, refait les jointures du temps sur les observations datées, puis utilise le vrai `assign_roles` sur les 2 914 entrées projetées. Le maximum du côté entier est restitué pour les emplacements détaillés. Le résultat donne exactement les 615 clés du registre. Le ZIP comprend le SQL de la sélection, le SQL intégral déployé et le résultat du rejeu de référence. Les rôles historiquement observés d’un joueur ne sont jamais injectés dans l’algorithme déployé. [Sélection SQL](selection.sql) · [SQL déployé](reader/deployed-reader.sql) · [Code du moteur](reader/assign.py) · [Entrées du rejeu](reader/2914-entrees.csv)

Les huit vérifications LFP et le contrôle des 18 homonymes peuvent être reproduits sur les extraits inclus. Les réponses HTTP brutes, les compositions intégrales des deux équipes, les dates de naissance individuelles et les connexions RDS restent dans la preuve opérateur. Pour les neuf autres matchs du tableau des 17 sources primaires, l’archive fournit la décision et le lien documentaire. Le contrôle intégral des réponses correspondantes a été exécuté sur le lot scellé, puis son reçu a été inclus. Aucun recalcul de note ni aucune correction de production ne fait partie de ce reçu. [Empreintes de provenance](provenance.json) · [Reçu de la vérification opérateur](verification.json)
