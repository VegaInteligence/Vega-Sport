"""E04a / E04g / E03h: the three English leagues served today vs the 575 official results of 18 Nov.

Inputs (extracted read-only from docs/audits/2026-11-17/controles/verification-integree/angleterre-575.zip):
  inputs/angleterre-575/outputs/official-finished.csv, VI21-restoration-35.csv,
  inputs/review/organizer/name-crosswalk.json
Reads /api/cup-table?competition=<folder>&season=2026/2027&kind=results twice (ETag stability),
then once with If-None-Match. Writes out/angleterre.json.
"""
import csv, json, os, sys, collections
HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, HERE)
from fetch import getj, get

ROOT = os.path.dirname(HERE)
IN = os.path.join(ROOT, "inputs", "angleterre-575")
OUT = os.path.join(ROOT, "out"); os.makedirs(OUT, exist_ok=True)
xw = json.load(open(os.path.join(IN, "inputs/review/organizer/name-crosswalk.json")))
official = list(csv.DictReader(open(os.path.join(IN, "outputs/official-finished.csv"))))
restor = {r["official_id"] for r in csv.DictReader(open(os.path.join(IN, "outputs/VI21-restoration-35.csv")))}
FOLDERS = {"north": "ENG_6_national-league-north", "south": "ENG_6_national-league-south",
           "npl": "ENG_7_northern-premier-league"}

served = {}
report = {"reads": {}}
for lg, folder in FOLDERS.items():
    url = f"/api/cup-table?competition={folder}&season=2026%2F2027&kind=results"
    s1, h1, b1 = getj(f"eng-{lg}-results-1", url)
    s2, h2, b2 = getj(f"eng-{lg}-results-2", url)
    s3, h3, _ = get(f"eng-{lg}-results-inm", url, h1.get("etag"))
    report["reads"][lg] = {"url": url, "status": [s1, s2, s3], "etag1": h1.get("etag"), "etag2": h2.get("etag"),
                           "age": [h1.get("age"), h2.get("age")], "conditional_status": s3,
                           "rows": len(b1 or []), "dates": [min(r["date"] for r in b1), max(r["date"] for r in b1)] if b1 else None}
    for r in b1 or []:
        key = (r["date"], xw.get(r["home"], r["home"]), xw.get(r["away"], r["away"]))
        served.setdefault(lg, {})[key] = r

cmp = collections.Counter(); per = collections.defaultdict(collections.Counter)
withdrawn_back, withdrawn_still, details = [], [], []
matched = set()
for o in official:
    lg = o["league"]; key = (o["date"], o["home"], o["away"])
    r = served.get(lg, {}).get(key)
    if r is None:
        c = "absent"
    elif (r["ft_home"], r["ft_away"]) == (o["hs"], o["aws"]):
        c = "exact"; matched.add((lg, key))
    else:
        c = "different_score"; matched.add((lg, key))
        details.append({"official_id": o["official_id"], "date": o["date"], "home": o["home"], "away": o["away"],
                        "official": f'{o["hs"]}-{o["aws"]}', "served": f'{r["ft_home"]}-{r["ft_away"]}'})
    cmp[c] += 1; per[lg][c] += 1
    if o["official_id"] in restor:
        (withdrawn_back if c != "absent" else withdrawn_still).append(o["official_id"])
extra = [(lg, k) for lg in served for k in served[lg] if (lg, k) not in matched]
report.update({
    "official_finished_18nov": len(official),
    "comparison_today": dict(cmp), "per_league": {k: dict(v) for k, v in per.items()},
    "score_differences": details,
    "withdrawn_35_back": len(withdrawn_back), "withdrawn_35_still_absent": len(withdrawn_still),
    "served_rows_not_in_official_18nov_list": len(extra),
    "served_extra_sample": [list(x[1]) for x in extra[:60]],
    "served_total": sum(len(v) for v in served.values()),
})
ashton = [r for k, r in served.get("npl", {}).items() if k[0] == "2026-11-03" and "Ashton" in k[1]]
report["ashton_warrington_2026_11_03"] = ashton
json.dump(report, open(os.path.join(OUT, "angleterre.json"), "w"), indent=1, ensure_ascii=False)
print(json.dumps({k: v for k, v in report.items() if k != "served_extra_sample"}, indent=1, ensure_ascii=False)[:5000])
