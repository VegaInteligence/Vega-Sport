#!/usr/bin/env python3
"""Anonymous GET helper for the production read API (read only, <= 1 request/s).

Usage as a CLI:
    python -I fetch.py LABEL URL [If-None-Match-ETag]
Each call writes raw/<LABEL>.body and raw/<LABEL>.meta.json and appends one line
to raw/index.jsonl (url, status, ETag, Cache-Control, Age, UTC time, SHA-256).
"""
import hashlib, json, os, sys, time, urllib.request, urllib.error, gzip
from datetime import datetime, timezone

API = "https://dngp6kh9jx2bl.cloudfront.net"
ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
RAW = os.path.join(ROOT, "raw")
os.makedirs(RAW, exist_ok=True)
_last = [0.0]
KEEP = ("etag", "cache-control", "age", "x-cache", "last-modified", "content-type",
        "x-vercel-id", "x-vercel-cache", "server", "date", "x-amz-cf-pop", "vary",
        "x-matched-path", "content-length")


def get(label, url, inm=None):
    if url.startswith("/"):
        url = API + url
    wait = 1.05 - (time.time() - _last[0])
    if wait > 0:
        time.sleep(wait)
    req = urllib.request.Request(url, headers={"User-Agent": "audit-readonly/1.0",
                                               "Accept-Encoding": "gzip"})
    if inm:
        req.add_header("If-None-Match", inm)
    at = datetime.now(timezone.utc).isoformat(timespec="seconds")
    try:
        r = urllib.request.urlopen(req, timeout=60)
        status, headers, body = r.status, r.headers, r.read()
    except urllib.error.HTTPError as e:
        status, headers, body = e.code, e.headers, e.read()
    _last[0] = time.time()
    if headers.get("content-encoding") == "gzip" and body:
        body = gzip.decompress(body)
    h = {k.lower(): v for k, v in headers.items() if k.lower() in KEEP}
    meta = {"label": label, "url": url, "status": status, "at_utc": at,
            "if_none_match": inm, "sha256": hashlib.sha256(body).hexdigest(),
            "bytes": len(body), "headers": h}
    with open(os.path.join(RAW, label + ".body"), "wb") as f:
        f.write(body)
    with open(os.path.join(RAW, label + ".meta.json"), "w") as f:
        json.dump(meta, f, indent=1)
    with open(os.path.join(RAW, "index.jsonl"), "a") as f:
        f.write(json.dumps(meta) + "\n")
    return status, h, body


def getj(label, url, inm=None):
    s, h, b = get(label, url, inm)
    try:
        return s, h, json.loads(b) if b else None
    except ValueError:
        return s, h, None


if __name__ == "__main__":
    s, h, b = get(sys.argv[1], sys.argv[2], sys.argv[3] if len(sys.argv) > 3 else None)
    print(s, json.dumps(h), len(b))
    print(b[:1500].decode("utf-8", "replace"))
