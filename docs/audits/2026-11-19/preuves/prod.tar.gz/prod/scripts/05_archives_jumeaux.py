"""E03f: residual archive twins after merge_twins (0f368fd389). Lists every match of the archive
competitions whose count exceeds the double round robin and prints the pairs met more than twice
(or the same home/away pair more than once)."""
import json, os, sys, collections, unicodedata
HERE = os.path.dirname(os.path.abspath(__file__)); sys.path.insert(0, HERE)
from fetch import getj
ROOT = os.path.dirname(HERE); OUT = os.path.join(ROOT, "out")
CASES = [("2001/2002", "england/2001-02/eng.1", 380), ("2000/2001", "engsoccerdata/italy/all/2000", 306),
         ("2019/2020", "2019-20/en.1", 380), ("2000/2001", "england/2000-01/eng.1", 380),
         ("2006/2007", "engsoccerdata/france/all/2006", 380)]
def n(s): return unicodedata.normalize("NFKD", s).encode("ascii", "ignore").decode().lower().strip()
rep = {}
for season, comp, expected in CASES:
    ms, page = [], 1
    while True:
        url = (f"/api/read/archive?season={season.replace('/', '%2F')}&competition={comp.replace(':', '%3A').replace('/', '%2F')}"
               f"&limit=50&page={page}")
        s, h, b = getj(f"twins-{comp.replace('/', '_')}-p{page}", url)
        if s != 200: break
        ms += b["data"]["matches"]
        if not b["pagination"]["hasMore"]: break
        page += 1
    ordered = collections.defaultdict(list)
    teams = collections.Counter()
    for m in ms:
        ordered[(n(m["team1"]), n(m["team2"]))].append((m["key"], m["date"], m["score"], m["goalCount"]))
        teams[m["team1"]] += 1; teams[m["team2"]] += 1
    dup = {f"{k[0]} - {k[1]}": v for k, v in ordered.items() if len(v) > 1}
    rep[f"{season} {comp}"] = {"served": len(ms), "expected": expected, "teams": len(teams),
                               "same_home_away_more_than_once": dup,
                               "team_appearances": dict(teams.most_common())}
    print(season, comp, len(ms), "expected", expected, "teams", len(teams), "dups", json.dumps(dup, ensure_ascii=False)[:800])
    odd = {t: c for t, c in teams.items() if c != 2 * (len(teams) - 1)}
    print("   teams with unexpected match count:", odd)
json.dump(rep, open(os.path.join(OUT, "archives-jumeaux.json"), "w"), indent=1, ensure_ascii=False)
