"""Catalogues: version, competitions, cups, supplemental (open-matchday), archives, rankings, nations."""
import json, os, sys
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from fetch import getj

for label, url in [
    ("health", "/api/health"),
    ("status", "/api/status"),
    ("manifest", "/api/dashboard/manifest"),
    ("competitions", "/api/competitions"),
    ("cups-index", "/api/cups/index"),
    ("cup-index-supplemental", "/api/cup-index?kind=supplemental"),
    ("archives-index", "/api/archives/index"),
    ("rankings-index", "/api/rankings/index"),
    ("nations", "/api/nations"),
    ("players-facts-coverage", "/api/players/facts-coverage"),
]:
    s, h, b = getj(label, url)
    print(label, s, h.get("etag"), h.get("age"), h.get("cache-control"))
