"""VI-27 / VI-29 (E02c, E02d, E03h, E05c, E01b):
- Euro 2024 (l_v0000063, 2024): /api/cups/edition and /api/cup-snapshot?kind=edition, two reads + If-None-Match;
  Germany–Scotland 5–1 with half time 3–0; all 51 scores present.
- Standings of every manifest league (/api/standings): source, ETag stable over two reads, 304 on If-None-Match for
  the SportScore ones; arithmetic checks (played = W+D+L, GD = GF-GA, sum W = sum L, sum GF = sum GA, one row per team).
- Open Matchday tables (all supplemental folders): results and fixtures twice; ETag and body equality; fixtures with
  a forecast; each row's sides (team ids) present."""
import json, os, sys, collections
HERE = os.path.dirname(os.path.abspath(__file__)); sys.path.insert(0, HERE)
from fetch import getj, get
ROOT = os.path.dirname(HERE); OUT = os.path.join(ROOT, "out"); RAW = os.path.join(ROOT, "raw")
rep = {"euro2024": {}, "standings": {}, "open_matchday": {}}

# Euro 2024
for kind, url in [("edition", "/api/cups/edition?competition=l_v0000063&season=2024"),
                  ("snapshot", "/api/cup-snapshot?kind=edition&competition=l_v0000063&season=2024")]:
    s1, h1, b1 = getj(f"euro2024-{kind}-1", url)
    s2, h2, b2 = getj(f"euro2024-{kind}-2", url)
    s3 = get(f"euro2024-{kind}-inm", url, h1.get("etag"))[0]
    ms = (b1 or {}).get("matches", [])
    gs = [m for m in ms if {"Germany", "Scotland"} <= {m.get("team1"), m.get("team2")}]
    rep["euro2024"][kind] = {"url": url, "status": [s1, s2, s3], "etag": [h1.get("etag"), h2.get("etag")], "age": [h1.get("age"), h2.get("age")],
                             "matches": len(ms), "with_ft": sum(1 for m in ms if (m.get("score") or {}).get("ft")),
                             "with_ht": sum(1 for m in ms if (m.get("score") or {}).get("ht")),
                             "germany_scotland": gs, "worker": (b1 or {}).get("worker"),
                             "same_body": json.dumps(b1, sort_keys=True) == json.dumps(b2, sort_keys=True)}

# Standings
man = json.load(open(os.path.join(RAW, "manifest.body")))
for c in man["competitions"]:
    lid = c["id"]
    url = f"/api/standings?competition={lid}"
    s1, h1, b1 = getj(f"standings-{lid}-1", url)
    r = {"name": c["name"], "country": c["country"], "status": s1, "etag1": h1.get("etag"), "age1": h1.get("age")}
    if s1 == 200:
        r.update({"source": b1.get("source"), "season": b1.get("season"), "fetchedAt": b1.get("fetchedAt"),
                  "tables": len(b1.get("tables", []))})
        issues = []
        for t in b1["tables"]:
            ids = [x["id"] for x in t["rows"]]
            if len(ids) != len(set(ids)): issues.append(f"{t['name']}: duplicate team")
            sw = sl = gf = ga = 0
            for x in t["rows"]:
                w, d, l, p = x["wins"], x["draws"], x["losses"], x["played"]
                if None in (w, d, l, p): issues.append(f"{x['name']}: null record"); continue
                if w + d + l != p: issues.append(f"{x['name']}: W+D+L {w+d+l} != P {p}")
                if x["goalsFor"] is not None and x["goalsAgainst"] is not None and x["difference"] is not None and x["goalsFor"] - x["goalsAgainst"] != x["difference"]:
                    issues.append(f"{x['name']}: GD")
                if x["points"] is not None and x["points"] > 3 * w + d: issues.append(f"{x['name']}: points {x['points']} > 3W+D {3*w+d}")
                if min(w, d, l, p) < 0: issues.append(f"{x['name']}: negative")
                sw += w; sl += l; gf += x["goalsFor"] or 0; ga += x["goalsAgainst"] or 0
            if len(b1["tables"]) == 1 and (sw != sl or gf != ga): issues.append(f"{t['name']}: sum W {sw} vs L {sl}, GF {gf} vs GA {ga}")
            positions = [x["position"] for x in t["rows"]]
            if sorted(positions) != list(range(1, len(positions) + 1)): issues.append(f"{t['name']}: positions {positions[:5]}...")
        r["rows"] = sum(len(t["rows"]) for t in b1["tables"])
        r["issues"] = issues
        if b1.get("source") == "SportScore":
            s2, h2, b2 = getj(f"standings-{lid}-2", url)
            s3 = get(f"standings-{lid}-inm", url, h1.get("etag"))[0]
            r.update({"etag2": h2.get("etag"), "age2": h2.get("age"), "status2": s2, "conditional": s3,
                      "same_body": json.dumps(b1, sort_keys=True) == json.dumps(b2, sort_keys=True)})
    rep["standings"][lid] = r

# Open Matchday
sup = json.load(open(os.path.join(RAW, "cup-index-supplemental.body")))
for e in sup["competitions"]:
    for kind in ["results", "fixtures"]:
        url = f"/api/cup-table?competition={e['folder']}&season={e['season'].replace('/', '%2F')}&kind={kind}"
        s1, h1, b1 = getj(f"om-{e['folder']}-{kind}-1", url)
        s2, h2, b2 = getj(f"om-{e['folder']}-{kind}-2", url)
        rows = b1 if isinstance(b1, list) else []
        rep["open_matchday"][f"{e['folder']} {kind}"] = {
            "status": [s1, s2], "etag_equal": h1.get("etag") == h2.get("etag"), "age": [h1.get("age"), h2.get("age")],
            "body_equal": json.dumps(b1, sort_keys=True) == json.dumps(b2, sort_keys=True), "rows": len(rows),
            "index_rows": e["tables"][kind]["rows"], "rows_without_both_sides": sum(1 for x in rows if len((x.get("sides") or {})) < 2),
            "with_forecast": sum(1 for x in rows if x.get("forecast")),
            "duplicate_pairs": [k for k, n in collections.Counter((x["home"], x["away"]) for x in rows).items() if n > 1][:10]}
json.dump(rep, open(os.path.join(OUT, "coupes-classements.json"), "w"), indent=1, ensure_ascii=False)
print(json.dumps(rep["euro2024"], ensure_ascii=False)[:3000])
for k, v in rep["standings"].items():
    print(k, v["name"], v["country"], v["status"], v.get("source"), v.get("season"), v.get("rows"), v.get("issues"), v.get("conditional"), v.get("same_body"))
for k, v in rep["open_matchday"].items(): print(k, v)
