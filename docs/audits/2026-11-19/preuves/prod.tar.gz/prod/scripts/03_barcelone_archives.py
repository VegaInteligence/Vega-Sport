"""E03e: the 15 Barcelona matches (barcelone-15.csv) via /api/matches/{id}/summary;
football-data.co.uk coverage via /api/archives/details (totals vs 117 833 / 97 616)."""
import csv, json, os, sys
HERE = os.path.dirname(os.path.abspath(__file__)); sys.path.insert(0, HERE)
from fetch import getj
ROOT = os.path.dirname(HERE); OUT = os.path.join(ROOT, "out"); os.makedirs(OUT, exist_ok=True)
REPO = "/home/romai/Agents/worktrees/vega-audit-reprise-20261119"
rows = list(csv.DictReader(open(f"{REPO}/docs/audits/2026-11-17/controles/verification-integree/barcelone-15.csv")))
res = []
for r in rows:
    s, h, b = getj(f"barca-{r['public_match']}", f"/api/matches/{r['public_match']}/summary")
    res.append({"match": r["public_match"], "date": r["date"], "competition": r["competition"], "side": r["affected_side"],
                "stored_18nov": r["stored_public_club"], "sporting": r["sporting_public_club"], "status": s,
                "etag": h.get("etag"), "age": h.get("age"), "body_excerpt": json.dumps(b, ensure_ascii=False)[:600]})
s, h, cov = getj("archives-details-coverage", "/api/archives/details")
tot = {}
if s == 200 and cov:
    data = cov.get("data", cov)
    c = data.get("coverage", [])
    tot = {"divisions_seasons": len(c), "matches": sum(x["matches"] or 0 for x in c), "paired": sum(x["paired"] or 0 for x in c),
           "withStats": sum(x["withStats"] or 0 for x in c), "withOdds": sum(x["withOdds"] or 0 for x in c),
           "seasons": [min(x["season"] for x in c), max(x["season"] for x in c)] if c else None,
           "credit": data.get("credit")}
json.dump({"barcelona": res, "archives_details": {"status": s, "etag": h.get("etag"), "age": h.get("age"), "totals": tot}},
          open(os.path.join(OUT, "barcelone-archives.json"), "w"), indent=1, ensure_ascii=False)
for x in res: print(x["match"], x["status"], x["side"], x["stored_18nov"], "->", x["body_excerpt"][:300])
print(json.dumps(tot, ensure_ascii=False)[:800])
