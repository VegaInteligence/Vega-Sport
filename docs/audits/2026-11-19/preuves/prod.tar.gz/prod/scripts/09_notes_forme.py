"""E04f: per-match player grades for MLS (l_0eg6C9) and Eliteserien (l_0uqFK8) season 2021 matches played
before 1 Aug 2021 (Vega rating year 2020: 1 Aug 2020 - 31 Jul 2021) vs after (control), via /api/rankings/match.
E04l / VI-32: Max Dowman (p_0ogEyt) 2026/27 data the player page's « Forme récente » reads."""
import json, os, sys
HERE = os.path.dirname(os.path.abspath(__file__)); sys.path.insert(0, HERE)
from fetch import getj
ROOT = os.path.dirname(HERE); OUT = os.path.join(ROOT, "out")
rep = {"grades": {}, "dowman": {}}
for lid, name in [("l_0eg6C9", "MLS"), ("l_0uqFK8", "Eliteserien")]:
    for label, frm, to in [("before_aug_2021", "2021-04-01", "2021-07-31"), ("after_aug_2021", "2021-08-01", "2021-11-30")]:
        s, h, b = getj(f"grades-fixtures-{name}-{label}", f"/api/fixtures?league={lid}&season=2021&status=played&from={frm}&to={to}&limit=50")
        ms = (b or {}).get("data", {}).get("matches", []) if s == 200 else []
        sample = ms[:: max(1, len(ms) // 6)][:6]
        out = []
        for m in sample:
            s2, h2, g = getj(f"grades-{m['id']}", f"/api/rankings/match?match={m['id']}")
            grades = (g or {}).get("data", g or {}).get("grades", []) if s2 == 200 else []
            out.append({"match": m["id"], "date": m["date"], "home": m["home_team"]["name"], "away": m["away_team"]["name"], "status": s2,
                        "players": len(grades), "with_grade": sum(1 for x in grades if x.get("grade") is not None),
                        "with_gradeExact": sum(1 for x in grades if x.get("gradeExact") is not None),
                        "minutes_ge_20": sum(1 for x in grades if (x.get("minutes") or 0) >= 20)})
        rep["grades"][f"{name} {label}"] = {"fixtures_status": s, "fixtures_in_window_page1": len(ms), "sample": out}
# Max Dowman
pid = "p_0ogEyt"
for label, url in [("profile", f"/api/players/{pid}"),
                   ("read-player", f"/api/read/player?season=2026%2F2027&player={pid}"),
                   ("power-player", f"/api/rankings/power/player?season=2026%2F2027&player={pid}"),
                   ("power-history", f"/api/rankings/power/history?player={pid}")]:
    s, h, b = getj(f"dowman-{label}", url)
    rep["dowman"][label] = {"url": url, "status": s, "etag": h.get("etag"), "age": h.get("age"), "excerpt": json.dumps(b, ensure_ascii=False)[:1500]}
json.dump(rep, open(os.path.join(OUT, "notes-forme.json"), "w"), indent=1, ensure_ascii=False)
for k, v in rep["grades"].items(): print(k, v["fixtures_status"], v["fixtures_in_window_page1"], [(x["date"], x["status"], x["players"], x["with_grade"], x["minutes_ge_20"]) for x in v["sample"]])
for k, v in rep["dowman"].items(): print(k, v["status"], v["excerpt"][:700])
