"""E04d: the four champions shown « 1er tour » (Argentina Copa América 2024, Côte d'Ivoire AFCON 2023,
Qatar Asian Cup 2023, Mexico Gold Cup 2023) and Argentina's World Cup 2026 match count in /api/nations/{id};
Elo: France in /api/nations (rank, Elo) and the latest Elo date served."""
import json, os, sys, collections
HERE = os.path.dirname(os.path.abspath(__file__)); sys.path.insert(0, HERE)
from fetch import getj
ROOT = os.path.dirname(HERE); OUT = os.path.join(ROOT, "out")
SEASON = "2026%2F2027"
s, h, b = getj("nations-2026", f"/api/nations?season={SEASON}")
nations = b["data"]["nations"] if "data" in b else b["nations"]
body = b.get("data", b)
rep = {"list": {"status": s, "etag": h.get("etag"), "age": h.get("age"), "ranked": body.get("ranked"), "count": len(nations),
                "top10": [(n["name"], n.get("ranking", {}).get("rank"), n.get("elo"), n.get("lastMatch")) for n in nations[:10]],
                "lastMatch_max": max((n.get("lastMatch") or "") for n in nations)}}
want = {"Argentina": [("copa-america", 2024), ("world-cup", 2026)], "Ivory Coast": [("afcon", 2023)],
        "Côte d'Ivoire": [("afcon", 2023)], "Qatar": [("asian-cup", 2023)], "Mexico": [("gold-cup", 2023)], "France": []}
for n in nations:
    if n["name"] in want:
        s, h, d = getj(f"nation-{n['id']}", f"/api/nations/{n['id']}?season={SEASON}")
        d = d.get("data", d)
        runs = [{k: r[k] for k in ("tournament", "label", "year", "stage", "matches")} | {"rounds": [g.get("round") for g in r["games"]],
                 "last": r["games"][-1] if r["games"] else None} for r in d.get("tournaments", [])
                if (r["tournament"], r["year"]) in want[n["name"]] or r["tournament"] in [w[0] for w in want[n["name"]]]]
        elo = d.get("elo") or []
        wc26 = [m for m in d.get("matches", []) if "2026" in str(m.get("edition") or m.get("season") or "") and "World Cup" in str(m.get("competition"))
                or (m.get("competition") or "").lower().startswith("coupe du monde") and (m.get("date") or "").startswith("2026")]
        rep[n["name"]] = {"id": n["id"], "status": s, "etag": h.get("etag"), "ranking": n.get("ranking"), "elo": n.get("elo"),
                          "lastMatch": n.get("lastMatch"), "runs": runs, "elo_points": len(elo), "elo_last": elo[-3:] if elo else None,
                          "elo_first": elo[:1], "wc2026_matches_listed": len(wc26),
                          "wc2026_rows": [(m.get("date"), m.get("competition"), m.get("edition"), m.get("round"), m["home"]["name"], m["away"]["name"], m.get("homeScore"), m.get("awayScore"), m.get("status")) for m in wc26]}
json.dump(rep, open(os.path.join(OUT, "nations-elo.json"), "w"), indent=1, ensure_ascii=False)
print(json.dumps(rep, ensure_ascii=False, indent=1)[:9000])
