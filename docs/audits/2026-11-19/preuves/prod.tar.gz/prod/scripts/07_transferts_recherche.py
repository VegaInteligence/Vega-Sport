"""E03g / VI-31: served transfer history (migration 153 view: absent_since column, absentSince field),
200 / 304 / 404; search: players Giroud, Lamine Yamal, Max Dowman; clubs of removed competitions (scope.py)."""
import json, os, sys
HERE = os.path.dirname(os.path.abspath(__file__)); sys.path.insert(0, HERE)
from fetch import getj, get
ROOT = os.path.dirname(HERE); OUT = os.path.join(ROOT, "out")
rep = {"search": {}, "transfers": {}, "removed_scope_search": {}}
SEASONS = ["2026/2027", "2025/2026"]
players = {}
for q in ["Giroud", "Lamine Yamal", "Dowman"]:
    for season in SEASONS:
        s, h, b = getj(f"search-{q.replace(' ', '_')}-{season[:4]}", f"/api/search?q={q.replace(' ', '%20')}&season={season.replace('/', '%2F')}")
        body = b.get("data", b) if isinstance(b, dict) else {}
        rep["search"][f"{q} {season}"] = {"status": s, "players": body.get("players"), "clubs": body.get("clubs")}
        for p in body.get("players") or []:
            players.setdefault(p["id"], p["name"])
# Transfers of each found player: GET, GET again (ETag), conditional GET.
for pid, name in players.items():
    url = f"/api/players/{pid}/transfers"
    s1, h1, b1 = getj(f"transfers-{pid}-1", url)
    s2, h2, b2 = getj(f"transfers-{pid}-2", url)
    s3 = get(f"transfers-{pid}-inm", url, h1.get("etag"))[0] if h1.get("etag") else None
    moves = (b1 or {}).get("data", b1 or {}).get("transfers") if s1 == 200 else None
    rep["transfers"][pid] = {"name": name, "status": [s1, s2, s3], "etag": [h1.get("etag"), h2.get("etag")], "age": [h1.get("age"), h2.get("age")],
                             "cache_control": h1.get("cache-control"), "moves": len(moves) if moves is not None else None,
                             "with_absentSince": sum(1 for m in moves or [] if "absentSince" in m),
                             "moves_list": moves}
# Unknown player id (never read): expect 404.
s, h, b = getj("transfers-unknown", "/api/players/p_v9999999/transfers")
rep["transfers"]["p_v9999999 (unknown)"] = {"status": s, "body": b}
# Removed competitions: clubs search (league named in meta) for a club of several REMOVED leagues.
for q in ["Malmo", "Kawasaki", "Ulsan", "Al Ahly", "Mamelodi", "Riga", "Aalesund", "Shanghai", "Astana", "Apoel", "Partick", "Bala Town"]:
    s, h, b = getj(f"search-scope-{q}", f"/api/search?q={q.replace(' ', '%20')}&season=2026%2F2027")
    body = b.get("data", b) if isinstance(b, dict) else {}
    rep["removed_scope_search"][q] = {"status": s, "players": [(p["name"], p.get("meta")) for p in body.get("players") or []],
                                      "clubs": [(c["name"], c.get("meta")) for c in body.get("clubs") or []]}
json.dump(rep, open(os.path.join(OUT, "transferts-recherche.json"), "w"), indent=1, ensure_ascii=False)
for k, v in rep["transfers"].items():
    print(k, {x: v[x] for x in v if x not in ("moves_list",)})
for k, v in rep["search"].items(): print(k, v["status"], [(p["id"], p["name"], p.get("meta")) for p in v["players"] or []])
for k, v in rep["removed_scope_search"].items(): print(k, v)
