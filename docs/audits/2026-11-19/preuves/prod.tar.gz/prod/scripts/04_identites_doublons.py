"""E03e / E03f: club identities (707 vs 740), Concacaf matches under edition 3333 (Champions League 2008/09
archive), Lanús–Estudiantes duplicate, archive twins (PL 2019/20, Portugal « Sp Lisbon »/« Sporting CP»)."""
import json, os, sys, collections
HERE = os.path.dirname(os.path.abspath(__file__)); sys.path.insert(0, HERE)
from fetch import getj
ROOT = os.path.dirname(HERE); OUT = os.path.join(ROOT, "out")
rep = {}

# Team profiles: t_2fucJi (internal 707, Barcelona SC per the 18 Nov CSV), t_32jSEF (740, FC Barcelona).
for t in ["t_2fucJi", "t_32jSEF"]:
    s, h, b = getj(f"team-{t}", f"/api/teams/{t}")
    rep[f"team_{t}"] = {"status": s, "body": b}

# Champions League (l_v0000231) archive 2008/09: all pages, names of the 33 matches of edition 3333.
def archive_all(label, season, comp, q=None):
    out, page = [], 1
    while True:
        url = f"/api/read/archive?season={season.replace('/', '%2F')}&competition={comp.replace(':', '%3A').replace('/', '%2F')}&limit=50&page={page}"
        if q: url += "&q=" + q.replace(" ", "+")
        s, h, b = getj(f"{label}-p{page}", url)
        if s != 200: return s, out, None
        out += b["data"]["matches"]
        if not b["pagination"]["hasMore"]: return s, out, b
        page += 1

s, ldc, b = archive_all("archive-ldc-2008", "2008/2009", "g:champions-league")
rep["ldc_2008_09"] = {"status": s, "matches": len(ldc), "sample": [(m["date"], m["team1"], m["team2"], m["score"]) for m in ldc],
                      "competition_overview": [c for c in (b or {}).get("data", {}).get("competitions", []) if c["id"] == "g:champions-league"]}

# The nine European Barcelona archive matches: names only (the archive body carries no team id).
for season, comp, label in [("1998/1999", "europe/1998-99/champs", "archive-ecc-1998"), ("2020/2021", "g:champions-league", "archive-ldc-2020")]:
    s, ms, _ = archive_all(label, season, comp, q="barcelona")
    rep[label] = {"status": s, "rows": [(m["key"], m["date"], m["team1"], m["team2"], m["score"]) for m in ms]}

# Lanús–Estudiantes, 2026-09-22 (RDS ids 40022 / 40023 on 18 Nov): Liga Profesional (ARG) l_45VZuL.
s, h, b = getj("lanus-fixtures", "/api/fixtures?league=l_45VZuL&season=2026&from=2026-09-20&to=2026-09-23&limit=50")
rows = (b or {}).get("data", b) if isinstance(b, dict) else b
rep["lanus_fixtures"] = {"status": s, "raw_excerpt": json.dumps(b, ensure_ascii=False)[:200]}
try:
    items = b["data"]["matches"]
except Exception:
    items = []
lan = [x for x in items if "Lan" in json.dumps(x, ensure_ascii=False)]
rep["lanus_fixtures"]["lanus_rows"] = lan

# Archive season overviews: per-competition counts (twins: PL 2019/20, Portugal 2000/01–2020/21).
ov = {}
for y in range(2000, 2021):
    season = f"{y}/{y+1}"
    s, h, b = getj(f"archive-overview-{y}", f"/api/read/archive?season={season.replace('/', '%2F')}&limit=1")
    if s == 200:
        ov[season] = [{k: c[k] for k in ("id", "name", "country", "matches", "withGoals", "goals")} for c in b["data"]["competitions"]
                      if c.get("country") in ("Angleterre", "Portugal")]
    else:
        ov[season] = s
rep["archive_overviews"] = ov
json.dump(rep, open(os.path.join(OUT, "identites-doublons.json"), "w"), indent=1, ensure_ascii=False)
print(json.dumps({k: (v if k != "archive_overviews" else "...") for k, v in rep.items()}, ensure_ascii=False)[:6000])
