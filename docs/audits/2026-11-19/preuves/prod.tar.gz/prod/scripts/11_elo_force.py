"""Elo / strength: /api/rankings/power for nations and clubs (method version and computedAt), France's row."""
import json, os, sys
HERE = os.path.dirname(os.path.abspath(__file__)); sys.path.insert(0, HERE)
from fetch import getj
OUT = os.path.join(os.path.dirname(HERE), "out")
rep = {}
for kind in ["nations", "clubs"]:
    s, h, b = getj(f"power-{kind}", f"/api/rankings/power?kind={kind}&season=2026%2F2027&limit=200")
    b = (b or {}).get("data", b) or {}
    rows = b.get("rows") or []
    fr = [r for r in rows if r.get("name") in ("France", "Paris Saint-Germain")]
    rep[kind] = {"status": s, "etag": h.get("etag"), "age": h.get("age"), "method": b.get("method"), "rows": len(rows),
                 "top3": rows[:3], "france_or_psg": fr}
json.dump(rep, open(os.path.join(OUT, "elo-force.json"), "w"), indent=1, ensure_ascii=False)
print(json.dumps(rep, ensure_ascii=False)[:3000])
