// E04l / VI-32 and C: renders the public player page of Max Dowman (2026/27) in headless Chromium, reads the
// « Forme récente » card, takes a screenshot, records the network calls to the read API and the page's version hints.
// Usage: node 10_site_dowman.mjs <out-dir> [playwright-core dir] [chrome-headless-shell path]
import { createRequire } from "node:module";
import { writeFile, mkdir } from "node:fs/promises";
import path from "node:path";
const [out, pwDir = "/home/romai/Agents/scratch/vega-charts-20261119/node_modules/playwright-core",
  exe = "/home/romai/.cache/ms-playwright/chromium_headless_shell-1228/chrome-headless-shell-linux64/chrome-headless-shell"] = process.argv.slice(2);
await mkdir(out, { recursive: true });
const { chromium } = createRequire(import.meta.url)(pwDir);
const browser = await chromium.launch({ executablePath: exe });
const result = { observed: new Date().toISOString(), setup: "chrome-headless-shell 1228, playwright-core " + createRequire(import.meta.url)(pwDir + "/package.json").version + ", 1365x900, fr-FR" };
try {
  const page = await browser.newPage({ locale: "fr-FR", viewport: { width: 1365, height: 900 } });
  const api = [];
  page.on("response", async (r) => {
    if (r.url().includes("cloudfront.net/api/")) api.push({ url: r.url(), status: r.status(), etag: r.headers()["etag"] ?? null, age: r.headers()["age"] ?? null });
  });
  const url = "https://vegasport.vercel.app/joueurs?id=p_0ogEyt&season=2026%2F2027";
  const resp = await page.goto(url, { waitUntil: "domcontentloaded", timeout: 30000 });
  result.url = page.url();
  result.document = { status: resp.status(), headers: Object.fromEntries(Object.entries(resp.headers()).filter(([k]) => /^(x-vercel|age|etag|cache-control|server|date|x-matched-path|last-modified)/.test(k))) };
  const target = page.getByRole("heading", { name: /Forme récente/i });
  await target.waitFor({ state: "attached", timeout: 25000 });
  await page.waitForTimeout(2500);
  const card = target.locator("..").locator("..");
  await card.scrollIntoViewIfNeeded();
  await card.screenshot({ path: path.join(out, "dowman-forme-recente.png") });
  result.title = await page.title();
  result.card = await card.innerText();
  result.buildHints = await page.evaluate(() => ({
    nextData: document.getElementById("__NEXT_DATA__")?.textContent?.slice(0, 400) ?? null,
    buildId: window.__NEXT_DATA__?.buildId ?? null,
    scripts: [...document.scripts].map((s) => s.src).filter(Boolean).slice(0, 12),
    metas: [...document.querySelectorAll("meta")].map((m) => [m.name || m.getAttribute("property"), m.content]).filter(([n]) => n),
  }));
  result.api = api;
  await page.screenshot({ path: path.join(out, "dowman-page.png"), fullPage: false });
} catch (e) {
  result.error = String(e);
} finally {
  await browser.close();
  await writeFile(path.join(out, "dowman-site.json"), JSON.stringify(result, null, 1));
  console.log(JSON.stringify({ card: result.card, error: result.error, document: result.document, title: result.title }, null, 1));
}
