BEGIN;
DELETE FROM agg.standings WHERE competition_season_id = 6;
SET LOCAL ROLE vega_read;
SET LOCAL search_path = api;
PREPARE standings(text, text) AS
WITH edition AS (
       SELECT k.competition_season_id FROM api.edition_keys k
       CROSS JOIN LATERAL (
         SELECT r.season,r.native_label,r.is_current FROM api.standing_rows r
         WHERE r.competition_season_id=k.competition_season_id
         UNION ALL
         SELECT x.season,x.native_label,x.is_current FROM api.standings_withheld() x
         WHERE x.competition_season_id=k.competition_season_id
         LIMIT 1) s
       WHERE k.league_id=$1 AND ($2::text IS NULL OR s.season=$2 OR s.native_label=$2)
       ORDER BY s.is_current DESC,s.season DESC LIMIT 1)
     SELECT r.competition_season_id, r.source, count(*) FROM api.standing_rows r WHERE r.competition_season_id=(SELECT competition_season_id FROM edition)
     GROUP BY 1, 2;
\echo conflicted current edition 6 without Vega table, no season: expect no row
EXECUTE standings('l_000100', NULL);
\echo season 2025 of the same league (edition 5, clean sportscore): expect sportscore 20
EXECUTE standings('l_000100', '2025');
\echo edition 12 (conflicted, league 101, 2026) with Vega table: expect vega 20
EXECUTE standings('l_000101', NULL);
ROLLBACK;
