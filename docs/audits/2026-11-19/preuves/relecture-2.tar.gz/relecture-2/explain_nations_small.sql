-- Prod-like nation volume: the International Results archive removed (12 000 nation matches left), 480 000 club matches kept.
\timing off
BEGIN;
SET LOCAL session_replication_role = replica;
DELETE FROM core.matches WHERE id >= 3000000 AND id < 4000000;
ANALYZE core.matches;
SET jit = off; SET max_parallel_workers_per_gather = 0; SET search_path = api;
SET ROLE vega_read;
PREPARE nlist(text) AS SELECT * FROM api.nation_list((SELECT season_id FROM api.season_keys WHERE season=$1));
PREPARE nmatches(integer) AS SELECT * FROM api.nation_matches($1::integer) ORDER BY match_date DESC NULLS LAST;
\echo == 159 nation_list
EXPLAIN (ANALYZE, BUFFERS) EXECUTE nlist('2026/2027');
\echo == 159 nation_matches
EXPLAIN (ANALYZE, BUFFERS) EXECUTE nmatches(100001);
RESET ROLE;
CREATE OR REPLACE FUNCTION api.nation_list(season_key smallint)
RETURNS TABLE(team_id text, team_key integer, name text, image_url text, matches integer, last_match date,
  elo float8, elo_at date, rank integer, season_elo float8, elo_change float8, season_matches integer,
  wins integer, draws integer, losses integer, result_sum float8, expected_sum float8)
LANGUAGE sql STABLE STRICT SECURITY DEFINER SET search_path = pg_catalog AS $$
  WITH nations AS MATERIALIZED (
    SELECT t.id, t.name, t.crest_asset_id FROM core.teams t WHERE t.is_national AND t.merged_into IS NULL
  ), games AS MATERIALIZED (
    SELECT n.id AS team, coalesce(m.match_date, m.kickoff_at::date) AS d,
      least(m.home_team_id, m.away_team_id) AS a, greatest(m.home_team_id, m.away_team_id) AS b, m.id AS match
    FROM nations n JOIN core.matches m ON m.home_team_id = n.id
    UNION ALL
    SELECT n.id, coalesce(m.match_date, m.kickoff_at::date),
      least(m.home_team_id, m.away_team_id), greatest(m.home_team_id, m.away_team_id), m.id
    FROM nations n JOIN core.matches m ON m.away_team_id = n.id
  ), played AS MATERIALIZED (
    -- A match without a date is its own match.
    SELECT team, count(DISTINCT coalesce(d::text || ':' || a || ':' || b, 'm' || match))::integer AS matches, max(d) AS last_match
    FROM games GROUP BY team
  )
  SELECT api.public_id('team', n.id), n.id, n.name, cr.source_url, p.matches, p.last_match,
    e.elo_after::numeric::float8, e.kickoff_at::date,
    tp.rank, tp.elo::numeric::float8, tp.elo_change::numeric::float8, tp.matches, tp.wins, tp.draws, tp.losses,
    tp.result_sum::numeric::float8, tp.expected_sum::numeric::float8
  FROM nations n
  JOIN played p ON p.team = n.id
  LEFT JOIN core.assets cr ON cr.id = n.crest_asset_id
  LEFT JOIN LATERAL (
    SELECT x.elo_after, x.kickoff_at FROM agg.team_elo x WHERE x.team_id = n.id ORDER BY x.kickoff_at DESC NULLS LAST LIMIT 1
  ) e ON true
  LEFT JOIN agg.team_power tp ON tp.season_id = season_key AND tp.team_id = n.id AND tp.scope = 'nations'
$$;
CREATE OR REPLACE FUNCTION api.nation_matches(team_key integer)
RETURNS TABLE(match_id text, match_date date, season text, competition text, edition text, round text, status text,
  collected boolean, home_id text, home_name text, home_image text, away_id text, away_name text, away_image text,
  home_score integer, away_score integer, home_penalties integer, away_penalties integer)
LANGUAGE sql STABLE STRICT SECURITY DEFINER SET search_path = pg_catalog AS $$
  WITH own AS MATERIALIZED (
    SELECT m.id, m.season_id, m.competition_season_id, m.round_id, m.status, m.home_team_id, m.away_team_id,
      m.home_score, m.away_score, m.home_penalty_score, m.away_penalty_score, coalesce(m.match_date, m.kickoff_at::date) AS d
    FROM core.matches m WHERE m.home_team_id = team_key
    UNION ALL
    SELECT m.id, m.season_id, m.competition_season_id, m.round_id, m.status, m.home_team_id, m.away_team_id,
      m.home_score, m.away_score, m.home_penalty_score, m.away_penalty_score, coalesce(m.match_date, m.kickoff_at::date)
    FROM core.matches m WHERE m.away_team_id = team_key AND m.home_team_id <> team_key
  ), copies AS (
    SELECT o.*, cs.cup_key, cs.archive_key, co.name AS competition_name, r.name AS round_name,
      least(o.home_team_id, o.away_team_id) AS lo, greatest(o.home_team_id, o.away_team_id) AS hi,
      -- Each copy's penalties by team: the lower team id's, then the other's.
      CASE WHEN o.home_team_id <= o.away_team_id THEN o.home_penalty_score ELSE o.away_penalty_score END AS pens_lo,
      CASE WHEN o.home_team_id <= o.away_team_id THEN o.away_penalty_score ELSE o.home_penalty_score END AS pens_hi
    FROM own o
    JOIN core.competition_seasons cs ON cs.id = o.competition_season_id
    JOIN core.competitions co ON co.id = cs.competition_id
    LEFT JOIN core.rounds r ON r.id = o.round_id
  ), picked AS (
    SELECT c.*,
      row_number() OVER w AS pick,
      max(c.round_name) OVER (PARTITION BY coalesce(c.d::text, 'm' || c.id), c.lo, c.hi) AS any_round,
      max(c.pens_lo) OVER (PARTITION BY coalesce(c.d::text, 'm' || c.id), c.lo, c.hi) AS any_pens_lo,
      max(c.pens_hi) OVER (PARTITION BY coalesce(c.d::text, 'm' || c.id), c.lo, c.hi) AS any_pens_hi
    FROM copies c
    WINDOW w AS (
      PARTITION BY coalesce(c.d::text, 'm' || c.id), c.lo, c.hi
      ORDER BY (c.cup_key IS NULL AND c.archive_key IS NULL) DESC, (c.home_score IS NOT NULL) DESC, c.id
    )
  )
  SELECT api.public_id('match', p.id), p.d, se.label, p.competition_name, coalesce(p.cup_key, p.archive_key),
    coalesce(p.round_name, p.any_round), p.status::text, p.cup_key IS NULL AND p.archive_key IS NULL,
    api.public_id('team', p.home_team_id), h.name, hc.source_url, api.public_id('team', p.away_team_id), a.name, ac.source_url,
    p.home_score::integer, p.away_score::integer,
    coalesce(p.home_penalty_score, CASE WHEN p.home_team_id = p.lo THEN p.any_pens_lo ELSE p.any_pens_hi END)::integer,
    coalesce(p.away_penalty_score, CASE WHEN p.away_team_id = p.lo THEN p.any_pens_lo ELSE p.any_pens_hi END)::integer
  FROM picked p
  JOIN core.seasons se ON se.id = p.season_id
  JOIN core.teams h ON h.id = p.home_team_id
  JOIN core.teams a ON a.id = p.away_team_id
  LEFT JOIN core.assets hc ON hc.id = h.crest_asset_id
  LEFT JOIN core.assets ac ON ac.id = a.crest_asset_id
  WHERE p.pick = 1
$$;
SET ROLE vega_read;
DEALLOCATE ALL;
PREPARE nlist(text) AS SELECT * FROM api.nation_list((SELECT season_id FROM api.season_keys WHERE season=$1));
PREPARE nmatches(integer) AS SELECT * FROM api.nation_matches($1::integer) ORDER BY match_date DESC NULLS LAST;
\echo == baseline nation_list
EXPLAIN (ANALYZE, BUFFERS) EXECUTE nlist('2026/2027');
\echo == baseline nation_matches
EXPLAIN (ANALYZE, BUFFERS) EXECUTE nmatches(100001);
ROLLBACK;
