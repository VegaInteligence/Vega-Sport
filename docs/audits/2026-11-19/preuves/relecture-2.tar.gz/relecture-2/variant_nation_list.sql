CREATE OR REPLACE FUNCTION api.nation_list(season_key smallint)
RETURNS TABLE(team_id text, team_key integer, name text, image_url text, matches integer, last_match date,
  elo float8, elo_at date, rank integer, season_elo float8, elo_change float8, season_matches integer,
  wins integer, draws integer, losses integer, result_sum float8, expected_sum float8)
LANGUAGE sql STABLE STRICT SECURITY DEFINER SET search_path = pg_catalog AS $$
  WITH nations AS MATERIALIZED (
    SELECT t.id, t.name, t.crest_asset_id FROM core.teams t WHERE t.is_national AND t.merged_into IS NULL
  ), games AS MATERIALIZED (
    SELECT g.team, g.d, least(g.h, g.aw) AS a, greatest(g.h, g.aw) AS b, g.match,
      g.edition, coalesce(cs.cup_key IS NULL AND cs.archive_key IS NULL, true) AS native,
      CASE WHEN g.h <= g.aw THEN g.hs ELSE g.as_ END AS score_a,
      CASE WHEN g.h <= g.aw THEN g.as_ ELSE g.hs END AS score_b
    FROM (
      SELECT n.id AS team, m.id AS match, coalesce(m.match_date, m.kickoff_at::date) AS d, m.home_team_id AS h, m.away_team_id AS aw,
        m.home_score AS hs, m.away_score AS as_, m.competition_season_id AS edition FROM nations n JOIN core.matches m ON m.home_team_id = n.id
      UNION ALL
      SELECT n.id, m.id, coalesce(m.match_date, m.kickoff_at::date), m.home_team_id, m.away_team_id, m.home_score, m.away_score,
        m.competition_season_id FROM nations n JOIN core.matches m ON m.away_team_id = n.id
    ) g
    LEFT JOIN core.competition_seasons cs ON cs.id = g.edition
  ), played AS MATERIALIZED (
    -- A match without a date is its own match; a copy api.nation_matches absorbs is not counted.
    SELECT g.team, count(DISTINCT coalesce(g.d::text || ':' || g.a || ':' || g.b, 'm' || g.match))::integer AS matches, max(g.d) AS last_match
    FROM games g
    WHERE NOT EXISTS (
      SELECT 1 FROM games k WHERE k.team = g.team AND k.a = g.a AND k.b = g.b AND abs(k.d - g.d) = 1 AND k.edition <> g.edition
        AND k.score_a IS NOT DISTINCT FROM g.score_a AND k.score_b IS NOT DISTINCT FROM g.score_b
        AND (k.native > g.native OR (k.native = g.native AND k.match < g.match)))
    GROUP BY g.team
  )
  SELECT api.public_id('team', n.id), n.id, n.name, cr.source_url, p.matches, p.last_match,
    e.elo_after::numeric::float8, e.kickoff_at::date,
    tp.rank, tp.elo::numeric::float8, tp.elo_change::numeric::float8, tp.matches, tp.wins, tp.draws, tp.losses,
    tp.result_sum::numeric::float8, tp.expected_sum::numeric::float8
  FROM nations n
  JOIN played p ON p.team = n.id
  LEFT JOIN core.assets cr ON cr.id = n.crest_asset_id
  LEFT JOIN LATERAL (
    SELECT x.elo_after, x.kickoff_at FROM agg.team_elo x WHERE x.team_id = n.id ORDER BY x.kickoff_at DESC NULLS LAST LIMIT 1
  ) e ON true
  LEFT JOIN agg.team_power tp ON tp.season_id = season_key AND tp.team_id = n.id AND tp.scope = 'nations'
$$;
