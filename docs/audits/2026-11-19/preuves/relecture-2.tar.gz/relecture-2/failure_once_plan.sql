\d ops.parse_failures
BEGIN;
INSERT INTO ops.parse_failures(competition_season_id, error_code, message, at)
SELECT CASE WHEN g % 3 = 0 THEN NULL ELSE g % 2400 + 1 END, 'CODE_' || g % 20, 'message ' || g || repeat('é', 300), now() FROM generate_series(1, 300000) g;
ANALYZE ops.parse_failures;
PREPARE f1(text, text, text) AS SELECT EXISTS (SELECT 1 FROM ops.parse_failures WHERE error_code = $1 AND competition_season_id IS NULL AND md5(message) = md5($2) AND message = $3);
PREPARE f2(text, integer, text, text) AS SELECT EXISTS (SELECT 1 FROM ops.parse_failures WHERE error_code = $1 AND competition_season_id = $2 AND md5(message) = md5($3) AND message = $4);
EXPLAIN (ANALYZE, BUFFERS) EXECUTE f1('CODE_3', 'message 3', 'message 3');
EXPLAIN (ANALYZE, BUFFERS) EXECUTE f2('CODE_1', 2, 'message 1', 'message 1');
SET plan_cache_mode = force_generic_plan;
EXPLAIN (ANALYZE, BUFFERS) EXECUTE f2('CODE_1', 2, 'message 1', 'message 1');
ROLLBACK;
