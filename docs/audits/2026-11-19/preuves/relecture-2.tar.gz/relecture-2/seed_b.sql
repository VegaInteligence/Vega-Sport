-- Seed for relecture_b_159 (schema of 1cc4af1200). Volumes: 480 000 club matches in 2 400 editions, 30 000 SportScore
-- rows (1 500 editions, 6 of them with rank conflicts), 48 000 agg.standings rows, 250 nations, ~50 000 nation matches
-- (native editions, Open Cups copies on the same day and the day before, International Results archive).
SET session_replication_role = replica;
INSERT INTO core.seasons(id, label) SELECT y, y || '/' || (y + 1) FROM generate_series(1950, 2026) y;
-- Club leagues 100..499, nation competitions 10..14.
INSERT INTO core.competitions(id, name) SELECT c, 'League ' || c FROM generate_series(100, 499) c;
INSERT INTO core.competitions(id, name) VALUES (10, 'World Cup'), (11, 'World Cup 1930'), (13, 'International results');
INSERT INTO core.provider_ids(entity_type, provider, provider_key, entity_id)
SELECT 'competition', 'pitchapi', 'l_' || lpad(c::text, 6, '0'), c FROM generate_series(100, 499) c;
-- 2 400 club editions: id = (c - 100) * 6 + (s - 2021) + 1.
INSERT INTO core.competition_seasons(id, competition_id, season_id, native_label, is_current)
SELECT (c - 100) * 6 + (s - 2021) + 1, c, s, s::text, s = 2026 FROM generate_series(100, 499) c, generate_series(2021, 2026) s;
-- Clubs: 20 per league (ids 1..8000), nations 100001..100250.
INSERT INTO core.teams(id, name) SELECT t, 'Club ' || t FROM generate_series(1, 8000) t;
INSERT INTO core.teams(id, name, is_national) SELECT 100000 + t, 'Nation ' || t, true FROM generate_series(1, 250) t;
-- 200 finished club matches per edition.
INSERT INTO core.matches(id, competition_season_id, season_id, source, status, match_date, kickoff_at, home_team_id, away_team_id,
  home_score, away_score, first_finished_at)
SELECT (e - 1) * 200 + g, e, 2021 + (e - 1) % 6, 'pitchapi', 'finished', date '2021-08-01' + ((e - 1) % 6) * 365 + g,
  timestamptz '2021-08-01 18:00Z' + (((e - 1) % 6) * 365 + g) * interval '1 day',
  ((e - 1) / 6) * 20 + 1 + g % 20, ((e - 1) / 6) * 20 + 1 + (g * 7 + 3) % 20 + CASE WHEN (g * 7 + 3) % 20 = g % 20 THEN 1 ELSE 0 END,
  g % 4, (g * 3) % 3, timestamptz '2021-08-02Z' + (((e - 1) % 6) * 365 + g) * interval '1 day'
FROM generate_series(1, 2400) e, generate_series(1, 200) g;
UPDATE core.matches SET away_team_id = ((competition_season_id - 1) / 6) * 20 + 1 WHERE away_team_id > ((competition_season_id - 1) / 6) * 20 + 20;
-- Vega's tables for every club edition (20 rows each).
INSERT INTO agg.standings(competition_season_id, team_id, position, played, won, drawn, lost, goals_for, goals_against, points)
SELECT e, ((e - 1) / 6) * 20 + t, t, 20, 10, 5, 5, 30, 20, 35 FROM generate_series(1, 2400) e, generate_series(1, 20) t;
-- SportScore's tables for 1 500 editions; 6 with a rank shared at different points, 3 with a gap.
INSERT INTO core.standings_official(competition_season_id, team_id, position, played, won, drawn, lost, goals_for, goals_against,
  points, source, as_of)
SELECT e, ((e - 1) / 6) * 20 + t, t, 20, 10, 5, 5, 30, 20, 60 - t, 'sportscore', now() - interval '1 hour'
FROM generate_series(1, 1500) e, generate_series(1, 20) t;
UPDATE core.standings_official SET position = 1 WHERE competition_season_id IN (6, 12, 18, 24, 30, 36) AND position IN (2, 3);
UPDATE core.standings_official SET position = 25 WHERE competition_season_id IN (60, 120, 180) AND position = 20;
-- Nation editions: native (comp 10) per season 2021..2026, Open Cups copies (comp 11, cup_key/cup_name) per season,
-- International Results archive (comp 13, archive_key) per year 1950..2026.
INSERT INTO core.competition_seasons(id, competition_id, season_id, native_label, is_current)
SELECT 9000 + s, 10, s, s::text, s = 2026 FROM generate_series(2021, 2026) s;
INSERT INTO core.competition_seasons(id, competition_id, season_id, native_label, cup_key, cup_name)
SELECT 9100 + s, 11, s, s::text, 'open-cups:world-cup-history:' || s, 'World Cup ' || s FROM generate_series(2021, 2026) s;
INSERT INTO core.competition_seasons(id, competition_id, season_id, native_label, archive_key, archive_name)
SELECT 7000 + y, 13, y, y::text, 'international-results:' || y, 'International results ' || y FROM generate_series(1950, 2026) y;
-- 1 250 native matches per season (7 500): about 60 per nation.
INSERT INTO core.matches(id, competition_season_id, season_id, source, status, match_date, kickoff_at, home_team_id, away_team_id,
  home_score, away_score, first_finished_at)
SELECT 1000000 + (s - 2021) * 1250 + g, 9000 + s, s, 'pitchapi', 'finished', date '2021-06-01' + (s - 2021) * 365 + g / 4,
  timestamptz '2021-06-01 22:00Z' + ((s - 2021) * 365 + g / 4) * interval '1 day',
  100001 + g % 250, 100001 + (g % 250 + 1 + (g / 250) * 37 % 249) % 250, g % 3, g % 2, now()
FROM generate_series(2021, 2026) s, generate_series(1, 1250) g;
-- Open Cups copies of 40 % of them: half the day before, half the same day; same score by team, sides swapped one in two.
INSERT INTO core.matches(id, competition_season_id, season_id, source, status, match_date, home_team_id, away_team_id, home_score, away_score)
SELECT 2000000 + m.id - 1000000, 9100 + m.season_id, m.season_id, 'openfootball', 'finished',
  m.match_date - (m.id % 2),
  CASE WHEN m.id % 4 < 2 THEN m.home_team_id ELSE m.away_team_id END, CASE WHEN m.id % 4 < 2 THEN m.away_team_id ELSE m.home_team_id END,
  CASE WHEN m.id % 4 < 2 THEN m.home_score ELSE m.away_score END, CASE WHEN m.id % 4 < 2 THEN m.away_score ELSE m.home_score END
FROM core.matches m WHERE m.competition_season_id BETWEEN 11021 AND 11026 AND m.id % 5 < 2;
-- International Results: 500 matches a year 1950..2026 (38 500), and a copy of 20 % of the natives the day before.
INSERT INTO core.matches(id, competition_season_id, season_id, source, status, match_date, home_team_id, away_team_id, home_score, away_score, archive_key)
SELECT 3000000 + (y - 1950) * 500 + g, 7000 + y, y, 'international_results', 'finished', make_date(y, 1, 1) + (g * 2) / 3,
  100001 + (g * 13) % 250, 100001 + ((g * 13) % 250 + 1 + g % 249) % 250, g % 4, g % 3, 'ir:' || y || ':' || g
FROM generate_series(1950, 2026) y, generate_series(1, 500) g;
INSERT INTO core.matches(id, competition_season_id, season_id, source, status, match_date, home_team_id, away_team_id, home_score, away_score, archive_key)
SELECT 4000000 + m.id - 1000000, 7000 + m.season_id, m.season_id, 'international_results', 'finished', m.match_date - 1,
  m.home_team_id, m.away_team_id, m.home_score, m.away_score, 'irc:' || m.id
FROM core.matches m WHERE m.competition_season_id BETWEEN 11021 AND 11026 AND m.id % 5 = 3;
-- Elo and power of the nations.
INSERT INTO agg.team_elo(match_id, team_id, season_id, kickoff_at, elo_before, elo_after, expected, result, run_id)
SELECT m.id, m.home_team_id, m.season_id, m.kickoff_at, 1500, 1510, 0.5, 1, 1 FROM core.matches m WHERE m.competition_season_id BETWEEN 11021 AND 11026;
INSERT INTO agg.team_power(season_id, team_id, scope, elo, elo_change, matches, rank, run_id)
SELECT 2026, 100000 + t, 'nations', 1500, 1, 10, t, 1 FROM generate_series(1, 250) t;
RESET session_replication_role;
ANALYZE;
