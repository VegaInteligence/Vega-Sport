\timing on
SET jit = off; SET max_parallel_workers_per_gather = 0; SET statement_timeout = '8s'; SET search_path = api; SET ROLE vega_read;
SET default_transaction_read_only = on;
PREPARE standings(text, text) AS
WITH edition AS (
       SELECT k.competition_season_id FROM api.edition_keys k
       CROSS JOIN LATERAL (
         SELECT r.season,r.native_label,r.is_current FROM api.standing_rows r
         WHERE r.competition_season_id=k.competition_season_id
         UNION ALL
         SELECT x.season,x.native_label,x.is_current FROM api.standings_withheld() x
         WHERE x.competition_season_id=k.competition_season_id
         LIMIT 1) s
       WHERE k.league_id=$1 AND ($2::text IS NULL OR s.season=$2 OR s.native_label=$2)
       ORDER BY s.is_current DESC,s.season DESC LIMIT 1)
     SELECT r.* FROM api.standing_rows r WHERE r.competition_season_id=(SELECT competition_season_id FROM edition)
     ORDER BY r.stage NULLS FIRST,r.group_name NULLS FIRST,r.position,r.name;
PREPARE nlist(text) AS SELECT * FROM api.nation_list((SELECT season_id FROM api.season_keys WHERE season=$1));
PREPARE nmatches(integer) AS SELECT * FROM api.nation_matches($1::integer) ORDER BY match_date DESC NULLS LAST;
\echo == standings conflicted current edition (l_000100), no season
EXPLAIN (ANALYZE, BUFFERS) EXECUTE standings('l_000100', NULL);
\echo == standings clean league (l_000400 = editions >1500 without official), season 2025
EXPLAIN (ANALYZE, BUFFERS) EXECUTE standings('l_000150', '2025');
\echo == standings official league l_000200 no season
EXPLAIN (ANALYZE, BUFFERS) EXECUTE standings('l_000200', NULL);
\echo == rows returned
EXECUTE standings('l_000100', NULL);
\echo == nation_list
EXPLAIN (ANALYZE, BUFFERS) EXECUTE nlist('2026/2027');
\echo == nation_matches 100001
EXPLAIN (ANALYZE, BUFFERS) EXECUTE nmatches(100001);
SELECT count(*) FROM api.nation_matches(100001);
SELECT matches FROM api.nation_list(2026::smallint) WHERE team_key = 100001;
\echo == withheld
EXPLAIN (ANALYZE, BUFFERS) SELECT * FROM api.standings_withheld();
SELECT competition_season_id, reason FROM api.standings_withheld();
\echo == generic plans
SET plan_cache_mode = force_generic_plan;
EXPLAIN (ANALYZE, BUFFERS) EXECUTE standings('l_000200', NULL);
EXPLAIN (ANALYZE) EXECUTE nmatches(100001);
RESET plan_cache_mode;
\echo == worker count of api.standings (vega_read can read it)
EXPLAIN (ANALYZE, BUFFERS) SELECT count(*) FROM api.standings;
