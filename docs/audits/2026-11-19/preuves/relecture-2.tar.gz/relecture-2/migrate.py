import sys, psycopg
sys.dont_write_bytecode = True
sys.path.insert(0, "/home/romai/Agents/worktrees/vega-audit-reprise-20261119/backend")
from vega.store import migrate
with psycopg.connect(f"host=127.0.0.1 port=55535 user=postgres dbname={sys.argv[1]}", autocommit=True) as c:
    migrate(c)
print("ok")
