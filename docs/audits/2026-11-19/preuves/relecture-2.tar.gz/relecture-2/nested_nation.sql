LOAD 'auto_explain';
SET auto_explain.log_min_duration = 0; SET auto_explain.log_analyze = on; SET auto_explain.log_buffers = on;
SET auto_explain.log_nested_statements = on; SET auto_explain.log_level = notice; SET client_min_messages = notice;
SET jit = off; SET max_parallel_workers_per_gather = 0; SET statement_timeout = '8s'; SET search_path = api; SET ROLE vega_read;
\timing on
SELECT count(*) FROM api.nation_matches(100001);
SELECT count(*) FROM api.nation_list(2026::smallint);
