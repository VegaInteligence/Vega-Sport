SET jit = off; SET max_parallel_workers_per_gather = 0; SET search_path = api; SET ROLE vega_read;
SELECT api.internal_id('match','m_v0000123') AS m, api.internal_id('player','p_v0000005') AS p;
PREPARE gs(int, text, text) AS SELECT (SELECT gs.grade_status FROM api.player_grade_status gs WHERE gs.season_id=$1::smallint
           AND gs.match_id=api.internal_id('match',$2) AND gs.player_id=api.internal_id('player',$3)) AS grade_status;
EXPLAIN (ANALYZE, BUFFERS) EXECUTE gs(2024, 'm_v0000123', 'p_v0000005');
EXECUTE gs(2024, 'm_v0000123', 'p_v0000005');
SET plan_cache_mode = force_generic_plan;
EXPLAIN (ANALYZE, BUFFERS) EXECUTE gs(2024, 'm_v0000123', 'p_v0000005');
