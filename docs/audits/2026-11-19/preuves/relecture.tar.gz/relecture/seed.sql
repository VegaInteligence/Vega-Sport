SET session_replication_role = replica;
INSERT INTO core.competition_seasons(id, competition_id, season_id) SELECT s, 1, s FROM generate_series(2021,2026) s ON CONFLICT DO NOTHING;
INSERT INTO core.matches(id, competition_season_id, season_id, source, status, match_date, home_team_id, away_team_id)
SELECT g, 2021 + g % 6, 2021 + g % 6, 'pitchapi', 'finished', date '2021-09-01' + (g % 6) * 365 + (g % 200), (g % 500) + 1, (g % 500) + 2
FROM generate_series(1, 60000) g;
INSERT INTO core.player_match_stats(season_id, match_id, player_id, team_id, minutes_played)
SELECT 2021 + g % 6, g, p, CASE WHEN p <= 12 THEN (g % 500) + 1 ELSE (g % 500) + 2 END, 90
FROM generate_series(1, 60000) g, generate_series(1, 25) p;
INSERT INTO core.lineup_players(season_id, match_id, player_id)
SELECT 2021 + g % 6, g, p FROM generate_series(1, 60000) g, generate_series(1, 30) p;
INSERT INTO core.match_coverage(season_id, match_id) SELECT 2021 + g % 6, g FROM generate_series(1, 60000) g;
INSERT INTO agg.power_runs(id, kind, method_version, season_id, status, started_at) SELECT s, 'players', 'x', s, 'published', now() FROM generate_series(2021,2026) s;
INSERT INTO agg.player_match_grades(season_id, match_id, player_id, award_season, role, minutes, z, first_z, run_id)
SELECT season_id, match_id, player_id, season_id, 'M', 90, 0.5, 0.5, season_id FROM core.player_match_stats;
INSERT INTO agg.player_power_matches(season_id, match_id, player_id, role, minutes, run_id)
SELECT season_id, match_id, player_id, 'M', 90, season_id FROM core.player_match_stats;
ANALYZE;
