import sys, time, psycopg
sys.path.insert(0, "/home/romai/Agents/worktrees/vega-audit-reprise-20261119/backend")
from vega.worker import elo_due
with psycopg.connect("host=127.0.0.1 port=55535 user=postgres dbname=relecture_a", autocommit=True) as c:
    c.execute("SET session_replication_role = replica")
    c.execute("DELETE FROM agg.team_elo")
    c.execute("INSERT INTO agg.power_runs(id, kind, method_version, status, started_at) VALUES (9001,'elo','x','published', now()) ON CONFLICT DO NOTHING")
    c.execute("""INSERT INTO agg.team_elo(match_id, team_id, season_id, kickoff_at, elo_before, elo_after, expected, result, run_id, stakes)
                 SELECT m.id, t, m.season_id, now(), 1500, 1500, 0.5, 0.5, 9001, 1 FROM core.matches m, unnest(ARRAY[m.home_team_id, m.away_team_id]) t""")
    c.execute("ANALYZE agg.team_elo")
    t = time.time(); r = elo_due(c); print("elo_due", r, f"{time.time()-t:.3f}s over", c.execute("select count(*) from agg.team_elo").fetchone()[0], "sides")
