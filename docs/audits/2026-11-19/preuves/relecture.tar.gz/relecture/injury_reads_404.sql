-- A first injuries read answered 404: Reader.read's Missing path calls done(status=404, error='NOT_FOUND'), which sets read_at.
BEGIN;
SET session_replication_role = replica;
INSERT INTO core.provider_ids(entity_type, provider, provider_key, entity_id) VALUES ('player','transfermarkt','404404', 999001);
INSERT INTO ops.transfermarkt_reads(kind, provider_key, priority, next_due_at, read_at, last_http_status, error_code, rows_written)
VALUES ('injuries','404404',1, now() + interval '30 days', now(), 404, 'NOT_FOUND', 0);
SELECT 'known after a 404 first read (160):' AS what, count(*) FROM api.player_injury_reads WHERE player_key = 999001;
SELECT 'known under 116 rule (error_code IS NULL):' AS what, count(*) FROM ops.transfermarkt_reads r WHERE r.kind='injuries' AND r.provider_key='404404' AND r.read_at IS NOT NULL AND r.error_code IS NULL;
ROLLBACK;
