\timing on
EXPLAIN (ANALYZE, BUFFERS, COSTS OFF)
WITH target AS MATERIALIZED (SELECT 2024::smallint AS season_id, 30003 AS match_id, 5 AS player_id)
SELECT (SELECT gs.grade_status FROM api.player_grade_status gs JOIN target t
           ON gs.season_id=t.season_id AND gs.match_id=t.match_id AND gs.player_id=t.player_id) AS grade_status;
