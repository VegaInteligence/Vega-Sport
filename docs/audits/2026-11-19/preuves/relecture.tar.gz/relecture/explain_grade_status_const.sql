\timing on
EXPLAIN (ANALYZE, COSTS OFF)
SELECT gs.grade_status FROM api.player_grade_status gs WHERE gs.season_id=2024::smallint AND gs.match_id=30003 AND gs.player_id=5;
