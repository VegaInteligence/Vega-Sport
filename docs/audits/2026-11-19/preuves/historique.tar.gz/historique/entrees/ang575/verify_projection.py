from html.parser import HTMLParser
import pathlib,json,re,hashlib
class Visible(HTMLParser):
 def __init__(self):super().__init__();self.skip=0;self.parts=[]
 def handle_starttag(self,tag,attrs):
  if tag in ('script','style'):self.skip+=1
 def handle_endtag(self,tag):
  if tag in ('script','style'):self.skip-=1
 def handle_data(self,data):
  if not self.skip and data.strip():self.parts.append(data.strip())
def facts(blob):
 parser=Visible();parser.feed(blob.decode());text=' '.join(parser.parts);out=[]
 for date,label,away in [('2026-10-31','Sat 31st October','Warrington Rylands'),('2026-11-03','Tue 3rd November','Warrington Town')]:
  pattern=re.escape(label)+r' League KO \d{2}:\d{2} Ashton United '+re.escape(away)+r' (\d+) (\d+)';hits=re.findall(pattern,text);assert len(hits)==1,(date,hits)
  home_score,away_score=map(int,hits[0]);out.append(dict(date=date,home='Ashton United',away=away,home_score=home_score,away_score=away_score))
 return out
def verify(base):
 p=base/'inputs/clubs';meta=json.loads((p/'ashton-projection.json').read_text());blob=(p/'club-ashton-results.html').read_bytes();assert hashlib.sha256(blob).hexdigest()==meta['projection_sha256'];assert len(blob)==meta['projection_bytes'];assert blob.count(meta['replacement'].encode())==4
 actual=facts(blob);assert actual==json.loads((p/'ashton-sporting-facts.json').read_text());return actual
if __name__=='__main__':print(json.dumps(verify(pathlib.Path(__file__).resolve().parent),indent=2))
