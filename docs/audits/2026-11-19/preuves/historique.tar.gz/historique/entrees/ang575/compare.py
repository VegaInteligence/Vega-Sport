import csv,json,zlib,gzip,collections,pathlib,hashlib
BASE=pathlib.Path(__file__).resolve().parent;C=BASE/'outputs';C.mkdir(exist_ok=True);R=BASE/'inputs/review';E=BASE/'inputs'
SLUGS={'north':('ENG_6_national-league-north',332),'south':('ENG_6_national-league-south',333),'npl':('ENG_7_northern-premier-league',334)}
ASOF='2026-11-18'
xw=json.loads((R/'organizer/name-crosswalk.json').read_text())
j=json.loads(zlib.decompress((R/'rds-3/inputs.json.zlib').read_bytes()));rds=[dict(zip(j['fixtures']['columns'],x)) for x in j['fixtures']['rows']]
names={};teamnames={}
for r in rds:
 if r['competition_season_id'] not in (332,333,334):continue
 for side in ['home','away']:
  name=xw.get(r[side],r[side]);tid=r[side+'_team_id'];assert name not in names or names[name]==tid;names[name]=tid;teamnames[tid]=r[side]
assert len(names)==70
out=[];summary={};nonfinished=[];extras=[];allcandidates=[]
def k(r):return(r['date'],r['home_id'],r['away_id'])
def csvrows(p):
 return [{'date':r['date'],'home_id':names[xw.get(r['home'],r['home'])],'away_id':names[xw.get(r['away'],r['away'])],'hs':int(r['ft_home']),'aws':int(r['ft_away']),'state':'finished','id':''} for r in csv.DictReader(p.open())]
def idx(rows):
 d=collections.defaultdict(list)
 for r in rows:d[k(r)].append(r)
 assert all(len(v)==1 for v in d.values()),'duplicate sporting key'
 return d
def disposition(o,rows,index):
 same=index.get(k(o),[])
 if same:
  r=same[0]
  if r['state']!='finished':return 'not_finished',r
  if (r['hs'],r['aws'])==(o['hs'],o['aws']):return 'exact',r
  return 'different_score',r
 return 'absent',None
for league,(slug,edition) in SLUGS.items():
 if league in ['north','south']:
  data=json.loads((R/f'organizer/national-{league}-2026.json').read_text());assert len(data['data'])==552
  official=[]
  for v in data['data']:
   a=v['attributes'];h=a['homeTeam'];aw=a['awayTeam'];official.append({'official_id':v['id'],'date':a['kickOffDateUTC'][:10],'home':h['name'],'away':aw['name'],'home_id':names.get(h['name']),'away_id':names.get(aw['name']),'hs':h.get('score'),'aws':aw.get('score'),'state':a['matchPeriod']})
 else:
  official=[]
  for month in ['08','09','10','11']:
   state=json.loads((BASE/'inputs/npl'/f'npl-{month}-state.json').read_text());q=next(q for q in state['queries'] if q['queryKey'][0]=='matches-infinite');pages=q['state']['data']['pages'];assert len(pages)==1;page=pages[0];assert not page['pagination']['hasNextPage'];assert page['pagination']['totalItems']==len(page['items'])
   for v in page['items']:
    assert v['competition']['id']=='67d7c7bb74247876e6dae40a'
    h=v['homeTeamName'];aw=v['awayTeamName'];score=(v.get('score') or {}).get('current') or {};official.append({'official_id':v.get('id') or v['_id'],'date':v['date'],'home':h,'away':aw,'home_id':names.get(h),'away_id':names.get(aw),'hs':score.get('home'),'aws':score.get('away'),'state':v['status']})
 assert len({o['official_id'] for o in official})==len(official)
 rs=[{'date':r['match_date'],'home_id':r['home_team_id'],'away_id':r['away_team_id'],'hs':r['home_score'],'aws':r['away_score'],'state':r['status'],'id':r['id']} for r in rds if r['competition_season_id']==edition]
 old=csvrows(R/'public-source/old/data'/slug/'results_2627.csv');current=csvrows(R/'public-source/current/data'/slug/'results_2627.csv')
 httpdata=json.loads(gzip.decompress((BASE/'inputs/product'/f'{slug}.json.gz').read_bytes()))
 http=[{'date':v['date'],'home_id':names[xw.get(v['home'],v['home'])],'away_id':names[xw.get(v['away'],v['away'])],'hs':int(v['ft_home']),'aws':int(v['ft_away']),'state':'finished','id':''} for v in httpdata]
 sources={'rds':rs,'previous_csv':old,'current_csv':current,'http':http};indexes={name:idx(rows) for name,rows in sources.items()}
 finished=[]
 for o in official:
  o.update(league=league,edition=edition)
  if o['state']!='FullTime' or o['date']>ASOF:nonfinished.append(o);continue
  finished.append(o)
  row=dict(o)
  if o['home_id'] is None or o['away_id'] is None:
   row['classification']='unaligned_club';out.append(row);continue
  for label,rr in sources.items():
   stat,found=disposition(o,rr,indexes[label]);row[label]=stat;row[label+'_id']=found['id'] if found else '';row[label+'_score']=f"{found['hs']}-{found['aws']}" if found else ''
  row['classification']='present_exact' if row['rds']=='exact' else 'withdrawn_from_previous_csv' if row['previous_csv']=='exact' and row['current_csv']=='absent' else 'already_absent_previous_csv' if row['previous_csv']=='absent' else 'other_difference'
  samepair=[r for r in rs if (r['home_id'],r['away_id'])==(o['home_id'],o['away_id']) and r['date']!=o['date']]
  row['same_pair_other_dates']=json.dumps(samepair,ensure_ascii=False)
  out.append(row)
  if row['rds']!='exact':allcandidates.append(row)
 officialidx=idx(finished)
 for label,rr in sources.items():
  for r in rr:
   if r['state']=='finished' and k(r) not in officialidx:extras.append({'league':league,'source':label,**r})
 summary[league]={'edition':edition,'official_total':len(official),'official_states':dict(collections.Counter(o['state'] for o in official)),'official_finished_asof':len(finished),'unaligned_names':sorted({o[s] for o in official for s in ['home','away'] if o[s+'_id'] is None}),'sources_total':{x:len(rr) for x,rr in sources.items()},'sources_finished':{x:sum(r['state']=='finished' for r in rr) for x,rr in sources.items()},'classification':dict(collections.Counter(o['classification'] for o in out if o['league']==league)),'comparisons':{label:dict(collections.Counter(o.get(label,'unaligned') for o in out if o['league']==league)) for label in sources},'extras':dict(collections.Counter(o['source'] for o in extras if o['league']==league))}
for name,rows in [('official-finished',out),('official-not-finished',nonfinished),('source-extra',extras),('candidates',allcandidates)]:
 with (C/f'{name}.csv').open('w') as f:
  fields=list(dict.fromkeys(k for r in rows for k in r));w=csv.DictWriter(f,fieldnames=fields);w.writeheader();w.writerows(rows)
(C/'summary.json').write_text(json.dumps(summary,indent=2,ensure_ascii=False));(C/'candidates.json').write_text(json.dumps(allcandidates,indent=2,ensure_ascii=False));print(json.dumps(summary,indent=2,ensure_ascii=False))
