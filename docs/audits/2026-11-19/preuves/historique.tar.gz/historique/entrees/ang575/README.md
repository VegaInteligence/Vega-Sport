# Capsule autonome — complétude de trois ligues anglaises

Analyse gpt-6-astra/xhigh du 18/11/2026. Lecture seule des sources ; aucune restauration, correction produit, décision de modèle ou publication externe réalisée. Tous les chemins utiles sont relatifs à cette capsule. Les sources sont conservées, sauf la projection explicite du contact public Ashton décrite ci-dessous. Aucune dépendance à une arborescence personnelle.

## Reproduire sans réseau

Python 3.10+ et bibliothèque standard seulement. Depuis n'importe quel emplacement après extraction :

```bash
python3 verifier.py > replay.log
```

Le script vérifie les empreintes de chaque entrée, refait la comparaison des575 rencontres officielles, écrit les dispositions par rencontre et le relais VI-21 dans `outputs/`, puis vérifie les invariants. Verdict inspectable : `outputs/verification.json` et dernière ligne de `replay.log`. Le fichier `SHA256SUMS` fige les fichiers livrés ; après une nouvelle exécution, les outputs sont régénérés avec les mêmes chemins relatifs.

## Résultat attendu

| Compétition 2026/27 | Officiels terminés | Exacts | Absents | Retraits récents | Absents du CSV précédent | Score divergent |
|---|---:|---:|---:|---:|---:|---:|
| North 332 | 187 | 116 | 71 | 12 | 59 | 0 |
| South 333 | 188 | 112 | 76 | 12 | 64 | 0 |
| NPL 334 | 200 | 110 | 89 | 11 | 78 | 1 |
| Total | 575 | 338 | 236 | 35 | 201 | 1 |

Les mêmes 339 résultats Vega, dont338 exacts, figurent dans le RDS14:08, les CSV du18/11 et le produit HTTP15:02 UTC. Les201 absences antérieures sont200 matchs d'août plus Ashton–Warrington Rylands du31/10. Parmi ces201,22 étaient présents dans le CSV du4/11 puis disparaissent avant le17/11 ; les179 autres ne sont pas retrouvés dans les quatre clichés inspectés. « Déjà absent » ne signifie pas « jamais collecté ».

Le différend de score est Ashton United3412–Warrington Town2591,03/11, officiel0–1 contre Vega1–2 (match8625). Ashton–Warrington Rylands3399 du31/10 est un autre match, officiel1–2, absent. L'organisateur et les calendriers des deux clubs corroborent les scores. Le rapport détaillé Warrington Town confirme0–1 et Gumbs81 mais contient un en-tête de date erroné (« 3 October »), conservé et non employé seul pour dater. Preuves et URLs dans `inputs/clubs/club-witness-receipts.json`.

## Dossiers entrants et preuves minimales

- `inputs/review/organizer/` : JSON organisateur North/South,552 fixtures chacun et pagination complète ; dictionnaire explicite des noms.
- `inputs/npl/` : quatre mois officiels Premier Division jusqu'au18/11,87+19+64+32=202 IDs uniques, toutes pages terminées.200FullTime,1Abandoned et1Postponed. La première réponse globale de100 éléments est conservée comme témoin de pagination incomplète et n'est pas utilisée seule.
- `inputs/review/rds-3/` : capture physique de907 fixtures couvrant les quatre éditions inspectées, dont332/333/334. Lecture du18/11 à14:08 UTC.
- `inputs/review/public-source/` : résultats source des commits17/11 `496e94ec4c976cbc244fc734c86e6772778a35f1` et18/11 `13a434955de865f66f95a71937205a3a286488c6`.
- `inputs/product/` : trois réponses produit HTTP15:02 et reçus de transport.
- `inputs/global/` : lecture READ ONLY237 candidats, toutes compétitions, IDs canoniques exacts, deux orientations et±31jours,15:09:55 UTC. Une ligne retrouvée :8625 au mauvais score. Zéro fait exact alternatif. Image déployée `8018e0836ca0f32e8b2eb51fc2847154abff7f13`, empreintes et sortie0 dans le reçu.
- `inputs/preimage/` : préimage physique04:50 des35 pour préserver les anciennes IDs/provider keys, parents et70Elo. Son inventaire expose explicitement les tables non vérifiables ; cette comparaison ne certifie pas une restauration physique complète.
- `inputs/upstream-history/` et `inputs/upstream-docs/` : publications additionnelles04/11 et10/11, retraits précédents et documentation privée/publique du fournisseur. Voir `CONTRAT-UPSTREAM.md`.
- `inputs/clubs/` : corroborations officielles des deux rencontres d'Ashton, HTML et reçus.

## Sorties et propriétaire

`outputs/official-finished.csv` contient les575 dispositions ; `candidates.csv` les236 absences et1 score. `VI21-handover.csv` contient compétition/saison, noms, IDs canoniques, score/date officiels, cibles FK prouvées, chemins/URLs/empreintes et résultats de recherche globale. Les sous-fichiers `VI21-prior-201.csv`, `VI21-restoration-35.csv`, `VI21-score-1.csv` gardent les trois actions séparées.

Les35 portent les anciennes IDs physiques et provider keys de la préimage. Les201 n'ont **aucun ID physique, provider key ni statistique inventés**. Les70 clubs canoniques existent, sans fusion sortante. L'inventaire trouve aussi l'alias1553 Morecambe FC vers5548 ; son contrôle complémentaire est décrit dans `ALIAS-MORECAMBE.md`. Ni les homonymes, ni une date déplacée, ni un vainqueur identique ne permettent de transformer un écart en correspondance exacte.

Les règles d'appartenance VI-21 demeurent inchangées. Le relais ne constitue pas une autorisation d'intégrer ces compétitions à un modèle ou de les traiter comme saisons complètes. Restaurer les35, compléter les201 et corriger8625 sont des travaux distincts.

## Limites explicites

725PreMatch futurs,5reports et1abandon exclus du décompte des terminés. Pas d'inventaire de toutes les fixtures futures NPL. La recherche physique est bornée aux clubs identifiés et±31jours ; identités inconnues ou dates plus lointaines non exclues. Pipeline upstream privé : recul historique récurrent démontré, mais aucune règle fixe de nombre de jours/journées/lignes démontrée. Historique source des179 avant les quatre clichés non vérifié. Impact numérique des201 et du score, correction, restauration, déploiement et revue intégrée restent hors de cette capsule.

## Variante partageable — projection du contact public Ashton

Ce ZIP standard contient `verifier.py` directement à sa racine. L'original HTTP du calendrier Ashton reste sur le disque privé. Seules les quatre occurrences d'un même téléphone public sont remplacées, dont la répétition dans l'état JSON embarqué. Aucun fait sportif n'est retiré.

`inputs/clubs/ashton-projection.json` conserve le SHA256 HTTP original, le SHA256 de la projection, les positions et longueurs du remplacement, sa justification et sa limite de vérification. Le reçu HTTP garde son empreinte originale et distingue explicitement la représentation projetée. Le manifeste des entrées engage les octets projetés effectivement livrés.

`verify_projection.py` recalcule indépendamment les deux rencontres d'Ashton depuis le HTML visible projeté :31/10 contre Rylands1–2 et03/11 contre Town0–1. Le constructeur privé a vérifié l'égalité de ces faits avant/après ; `verifier.py` les vérifie à chaque rejeu, avec les575 comparaisons,237 dispositions et contrôles d'identité antérieurs. La reconstitution exacte de l'opération à partir des octets originaux nécessite l'original privé ; le ZIP ne le contient pas.
