# Ancien alias Morecambe fermé dans la fenêtre connue

Le probe `alias-probe.py` (SHA256 `cac562e8ddaf4988a328da0de2d9f2597503c6d2255ab606a2fcf4768b9e0b16`) lit les deux côtés de tous les matchs physiques sous `core.teams.id=1553`, Morecambe FC, du **08/07/2026 au 01/10/2026**, toutes compétitions et tous statuts. Cette fenêtre englobe les dates officielles des candidats Morecambe et leurs ±31 jours. L'inventaire global a prouvé la fusion directe1553→5548 ; le club canonique5548 est présent et sans fusion sortante.

Le coordinateur a exécuté cette lecture à **15:17:35 UTC**, transaction repeatable-read **read_only=on** : **zéro ligne**. Capture `inputs/alias/inputs.json.zlib`, SHA256 `4ed6682a9d41ee1838179c2fbf1dec617985973348af70203e95ceff885d1af4`. Le reçu conserve le probe, l'image, la sortie0 et la fermeture de la définition de transport. Aucun accès AWS par l'agent de revue.

Le seul alias direct découvert n'explique donc aucune des236 absences. Cela n'exclut pas une autre identité non déclarée ni une date hors de la fenêtre. Le vérificateur contrôle aussi cette capture et le zéro ligne.
