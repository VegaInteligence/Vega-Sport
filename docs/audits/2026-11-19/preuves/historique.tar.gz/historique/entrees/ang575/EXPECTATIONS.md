# Attendus avant comparaison

- Chaque réponse officielle doit avoir une pagination complète, des IDs uniques et une seule compétition attendue ; aucun résultat futur ou reporté n'est compté comme joué.
- Les 70 clubs doivent s'aligner sans rapprochement approximatif, par le dictionnaire explicite déjà vérifié sur les 35 rencontres.
- Une rencontre est « exacte » seulement avec la même date, les mêmes côtés et le même score terminé. Une collision de clé, une autre date, un autre score ou un état non terminé reste exposé.
- Les 35 retraits sont identifiés par les anciennes lignes sportives exactes, pas par le nombre seul. Une absence du CSV précédent signifie « déjà absente de ce cliché », pas « jamais collectée ».
- HTTP, RDS, CSV courant et précédent sont contrôlés séparément. L'absence dans l'édition ne prouve pas l'absence de toute autre édition ni sous une autre identité.
- Aucun calcul produit, restauration ou intervention AWS n'est exécuté ; cette contre-épreuve documentaire ne certifie pas une saison ou un modèle complet.
