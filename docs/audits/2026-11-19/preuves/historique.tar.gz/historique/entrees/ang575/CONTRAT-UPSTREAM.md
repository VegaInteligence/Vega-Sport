## Contrat upstream : ce qui est établi et ce qui ne l'est pas

Le [README figé du fournisseur](https://github.com/oladeeayo/open-matchday/blob/13a434955de865f66f95a71937205a3a286488c6/README.md) présente un export quotidien de résultats et fixtures ; le [dictionnaire](https://github.com/oladeeayo/open-matchday/blob/13a434955de865f66f95a71937205a3a286488c6/DATA_DICTIONARY.md) documente les champs et la clé date/noms, sans ID de match. Son [index](https://github.com/oladeeayo/open-matchday/blob/13a434955de865f66f95a71937205a3a286488c6/LEAGUE_INDEX.md) attribue les trois ligues à Soccerway, page de calendrier. Le pipeline de construction est explicitement privé. Le [disclaimer](https://github.com/oladeeayo/open-matchday/blob/13a434955de865f66f95a71937205a3a286488c6/DISCLAIMER.md) ne garantit pas la complétude. **Aucun contrat public trouvé de saison complète, d'append-only, de tombstone pour un résultat supprimé, ou de conservation fixe de N journées.**

Quatre publications sont inspectées, pas seulement la différence du jour :

| Publication figée | North : lignes / premier résultat | South | NPL |
|---|---|---|---|
| 04/11, `06b3cf482d7e8e24912994739368f1764bb7bf54` | 113 / 31/08 | 121 / 31/08 | 107 / 28/08 |
| 10/11, `e1ec9773df8030a3e0c613f52eb3bd85437c21ab` | 121 / 31/08 | 120 / 05/09 | 114 / 29/08 |
| 17/11, `496e94ec4c976cbc244fc734c86e6772778a35f1` | 124 / 31/08 | 122 / 05/09 | 118 / 31/08 |
| 18/11, `13a434955de865f66f95a71937205a3a286488c6` | 116 / 05/09 | 112 / 08/09 | 111 / 12/09 |

Les fichiers et empreintes des deux publications additionnelles figurent dans `inputs/upstream-history/upstream-history-receipts.json`, leurs lignes sorties dans `inputs/upstream-history/upstream-history-removals.csv`. La recherche « au 11/11 » renvoie un commit du **10/11**, explicitement conservé comme tel. Les retraits antérieurs portent sur des résultats officiels encore FullTime aujourd'hui. Les 11 matchs NPL de la même journée source `gw=7` sortent en deux fois (3 du 28/08 puis 8 du 29/08) : la publication ne conserve donc même pas toujours une journée atomique. Les comptes varient de 107 à 124 ; la South contient des `gw` de 1 à 28 malgré ses anciennes dates manquantes, du fait des rencontres décalées.

**Qualification utile : export courant partiel à recul historique observé et récurrent, inadapté comme seule preuve de suppression sportive.** Une fenêtre fixe de journées, de dates ou de lignes, son origine Soccerway versus la fusion privée et sa profondeur exacte demeurent **non vérifiées**. Il serait incorrect de transformer cette observation en règle automatique de remplissage des dates manquantes.

