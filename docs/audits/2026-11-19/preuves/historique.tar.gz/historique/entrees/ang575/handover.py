"""Produce VI-21 handover from immutable local evidence; no network, no product writes."""
import pathlib,json,csv,zlib,hashlib,collections,sys
BASE=pathlib.Path(__file__).resolve().parent;C=BASE/'outputs';R=BASE/'inputs/review';E=BASE/'inputs'
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def hashrow(r):return hashlib.sha256(json.dumps(r,ensure_ascii=False,sort_keys=True,separators=(',',':')).encode()).hexdigest()
def table(j,k):return [dict(zip(j[k]['columns'],r)) for r in j[k]['rows']]
def csvwrite(name,rows):
 with (C/name).open('w') as f:
  w=csv.DictWriter(f,fieldnames=list(rows[0]));w.writeheader();w.writerows(rows)
cap=pathlib.Path(sys.argv[1]).resolve();assert cap.is_relative_to(BASE),'capture must be in authorized evidence directory'
j=json.loads(zlib.decompress(cap.read_bytes()));assert j['read_only']=='on';assert j['probe_version']=='completeness-v1';assert len(j['candidates'])==237
facts=table(j,'global_facts');teams={r['id']:r for r in table(j,'team_ids_and_direct_merges')};provider=table(j,'provider_ids')
rdsfile=R/'rds-3/inputs.json.zlib';rds=json.loads(zlib.decompress(rdsfile.read_bytes()));fixtures=table(rds,'fixtures');anchors={}
for r in fixtures:
 if r['competition_season_id'] not in [332,333,334]:continue
 for side in ['home','away']:anchors.setdefault(r[side+'_team_id'],r)
xw=json.loads((R/'organizer/name-crosswalk.json').read_text());prepath=BASE/'inputs/preimage/inputs.json.zlib';pre=json.loads(zlib.decompress(prepath.read_bytes()));pread=pre['reads']
oldmatches={r['id']:r for r in map(json.loads,pread['table.core.matches']['rows_json'])};oldproviders={r['entity_id']:r for r in map(json.loads,pread['table.core.provider_ids']['rows_json'])};editions={r['id']:r for r in map(json.loads,pread['parent.matches_competition_season_id_season_id_fkey']['rows_json'])}
oldbykey={(r['match_date'],r['home_team_id'],r['away_team_id'],r['home_score'],r['away_score']):r for r in oldmatches.values()};assert len(oldbykey)==35
candidates=json.loads((C/'candidates.json').read_text());receipts=json.loads((R/'organizer/national-season-receipts.json').read_text());national={r['file']:r for r in receipts};nplreceipts={r['file']:r for r in json.loads((BASE/'inputs/npl/npl-month-receipts.json').read_text())}
rows=[]
for o in candidates:
 h=teams[o['home_id']];a=teams[o['away_id']];assert xw.get(h['name'],h['name'])==o['home'];assert xw.get(a['name'],a['name'])==o['away'];assert h['merged_into'] is None and a['merged_into'] is None
 key=(o['date'],o['home_id'],o['away_id'],o['hs'],o['aws']);old=oldbykey.get(key);ed=editions[o['edition']]
 assert bool(old)==(o['classification']=='withdrawn_from_previous_csv')
 if o['league'] in ['north','south']:
  file=R/f"organizer/national-{o['league']}-2026.json";receipt=national[file.name]
 else:
  file=BASE/'inputs/npl'/f"npl-{o['date'][5:7]}-state.json";receipt=nplreceipts[f"npl-{o['date'][5:7]}.html"]
 found=[f for f in facts if f['official_id']==o['official_id']]
 exact=[f for f in found if f['match_date']==o['date'] and f['home_team_id']==o['home_id'] and f['away_team_id']==o['away_id'] and f['home_score']==o['hs'] and f['away_score']==o['aws'] and f['status']=='finished']
 fact={'official_id':o['official_id'],'date':o['date'],'competition_season_id':o['edition'],'home_team_id':o['home_id'],'away_team_id':o['away_id'],'home_score':o['hs'],'away_score':o['aws']}
 historical=[]
 slug=ed['cup_key'].split(':')[1]
 for label in ['2026-11-04','2026-11-11']:
  p=BASE/'inputs/upstream-history'/f'upstream-{label}-{slug}.csv'
  for r in csv.DictReader(p.open()):
   if (r['date'],xw.get(r['home'],r['home']),xw.get(r['away'],r['away']),int(r['ft_home']),int(r['ft_away']))==(o['date'],o['home'],o['away'],o['hs'],o['aws']):historical.append(str(p.relative_to(BASE)));break
 role='restore_historical_physical_row' if old else 'verify_existing_score' if o['rds']=='different_score' else 'missing_official_result_owner_decision'
 row={'owner':'VI-21','role':role,'league':o['league'],'competition_id':ed['competition_id'],'competition_season_id':o['edition'],'season_id':2026,'season_label':ed['native_label'],'cup_key':ed['cup_key'],'official_id':o['official_id'],'match_date':o['date'],'home_official':o['home'],'home_vega':h['name'],'home_team_id':h['id'],'away_official':o['away'],'away_vega':a['name'],'away_team_id':a['id'],'home_score_official':o['hs'],'away_score_official':o['aws'],'classification':o['classification'],'historical_match_id':old['id'] if old else '', 'current_match_id':o['rds_id'],'current_score':o['rds_score'],'current_provider_keys':json.dumps([v for v in provider if v['entity_id']==o['rds_id']],ensure_ascii=False),'historical_provider_key':oldproviders[old['id']]['provider_key'] if old else '', 'stats': 'physical_preimage_reference_only' if old else 'not_captured_not_invented','official_url':receipt['url'],'official_file':str(file.relative_to(BASE)),'official_file_sha256':sha(file),'official_http_sha256':receipt['sha256'],'official_sporting_tuple_sha256':hashrow(fact),'home_fk_target_proof':f"{cap.relative_to(BASE)}#team_ids_and_direct_merges:id={h['id']}",'home_fk_target_row_sha256':hashrow(h),'away_fk_target_proof':f"{cap.relative_to(BASE)}#team_ids_and_direct_merges:id={a['id']}",'away_fk_target_row_sha256':hashrow(a),'home_anchor_match_id':anchors[h['id']]['id'],'away_anchor_match_id':anchors[a['id']]['id'],'anchor_rds_file':str(rdsfile.relative_to(BASE)),'anchor_rds_file_sha256':sha(rdsfile),'historical_preimage_file':str(prepath.relative_to(BASE)) if old else '', 'historical_match_row_sha256':hashrow(old) if old else '', 'historical_preimage_sha256':sha(prepath) if old else '', 'earlier_source_publication_files':json.dumps(historical),'global_search_at':j['at'],'global_search_snapshot':j['snapshot'],'global_capture_file':str(cap.relative_to(BASE)),'global_capture_sha256':sha(cap),'global_same_known_pair_plus_minus_31_days_count':len(found),'global_exact_sporting_fact_count':len(exact),'global_candidate_match_ids':json.dumps([f['id'] for f in found]),'global_candidate_facts':json.dumps(found,ensure_ascii=False,sort_keys=True),'global_exact_other_edition_ids':json.dumps([f['id'] for f in exact if f['competition_season_id']!=o['edition']]),'limit':'exact canonical club IDs, both orientations, date +/-31 days; unknown aliases or greater date displacement not excluded; VI-21 membership unchanged'}
 rows.append(row)
assert len(rows)==237 and sum(bool(r['historical_match_id']) for r in rows)==35
assert sum(r['classification']=='already_absent_previous_csv' for r in rows)==201
csvwrite('VI21-handover.csv',rows);csvwrite('VI21-prior-201.csv',[r for r in rows if r['classification']=='already_absent_previous_csv']);csvwrite('VI21-restoration-35.csv',[r for r in rows if r['historical_match_id']]);csvwrite('VI21-score-1.csv',[r for r in rows if r['role']=='verify_existing_score'])
report={'capture':str(cap.relative_to(BASE)),'capture_sha256':sha(cap),'at':j['at'],'read_only':j['read_only'],'candidates':len(rows),'queried_team_ids':len({o[s+'_id'] for o in candidates for s in ['home','away']}),'team_rows_returned':len(teams),'extra_direct_merges':len(teams)-70,'candidate_result_rows':len(facts),'distinct_found_match_ids':len({f['id'] for f in facts}),'candidates_with_any_match_in_window':sum(r['global_same_known_pair_plus_minus_31_days_count']>0 for r in rows),'candidates_with_exact_sporting_fact':sum(r['global_exact_sporting_fact_count']>0 for r in rows),'exact_other_edition_ids':sorted({f['id'] for r in rows for f in json.loads(r['global_candidate_facts']) if f['match_date']==r['match_date'] and f['home_team_id']==r['home_team_id'] and f['away_team_id']==r['away_team_id'] and f['home_score']==r['home_score_official'] and f['away_score']==r['away_score_official'] and f['competition_season_id']!=r['competition_season_id']})}
(C/'global-search-summary.json').write_text(json.dumps(report,indent=2,ensure_ascii=False));print(json.dumps(report,indent=2,ensure_ascii=False))
