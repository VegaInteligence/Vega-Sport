"""Read-only optional closure of the one known direct alias left by completeness-v1.
No canonical match IDs or outcomes are assumed. No AWS or product imports.
"""
def collect(db):
    with db.transaction():
        db.execute("SET TRANSACTION ISOLATION LEVEL REPEATABLE READ READ ONLY")
        at,snap,ro=db.execute("SELECT transaction_timestamp(),pg_current_snapshot()::text,current_setting('transaction_read_only')").fetchone()
        assert ro=='on'
        out={'at':str(at),'snapshot':snap,'read_only':ro,'probe_version':'morecambe-alias-v1'}
        sql="""SELECT m.id,m.competition_season_id,m.season_id,m.match_date,m.status,m.home_team_id,h.name AS home,
          m.away_team_id,a.name AS away,m.home_score,m.away_score,m.source,cs.cup_key,cs.archive_key,c.name AS competition
          FROM core.matches m JOIN core.competition_seasons cs ON cs.id=m.competition_season_id
          JOIN core.competitions c ON c.id=cs.competition_id
          LEFT JOIN core.teams h ON h.id=m.home_team_id LEFT JOIN core.teams a ON a.id=m.away_team_id
          WHERE (m.home_team_id=%s OR m.away_team_id=%s) AND m.match_date BETWEEN %s::date AND %s::date
          ORDER BY m.match_date,m.id LIMIT 1001"""
        args=(1553,1553,'2026-07-08','2026-10-01');cur=db.execute(sql,args);rows=cur.fetchall();assert len(rows)<=1000
        out['alias_facts']={'sql':sql,'params':args,'columns':[c.name for c in cur.description],'rows':rows}
        return out
