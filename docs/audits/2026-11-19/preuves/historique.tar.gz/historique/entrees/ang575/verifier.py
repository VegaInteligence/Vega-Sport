#!/usr/bin/env python3
"""Offline portable replay: Python standard library only; no AWS, DB or network."""
import pathlib,json,hashlib,runpy,sys,csv,zlib,collections,re
B=pathlib.Path(__file__).resolve().parent
for r in json.loads((B/'inputs-manifest.json').read_text()):
 p=B/r['path'];assert p.stat().st_size==r['bytes'];assert hashlib.sha256(p.read_bytes()).hexdigest()==r['sha256'],r['path']
for month in ['08','09','10','11']:
 html=(B/f'inputs/npl/npl-{month}.html').read_text();decoded=json.loads(re.search(r'window\.__REACT_QUERY_STATE__=(.*?);</script>',html,re.S).group(1))
 assert decoded==json.loads((B/f'inputs/npl/npl-{month}-state.json').read_text())
for league in ['north','south']:
 data=json.loads((B/f'inputs/review/organizer/national-{league}-2026.json').read_text());assert data['meta']['count']==data['meta']['totalCount']==len(data['data'])==552
projection=runpy.run_path(str(B/'verify_projection.py'))
assert len(projection['verify'](B))==2
runpy.run_path(str(B/'compare.py'),run_name='__main__')
sys.argv=[str(B/'handover.py'),str(B/'inputs/global/inputs.json.zlib')];runpy.run_path(sys.argv[0],run_name='__main__')
summary=json.loads((B/'outputs/summary.json').read_text())
assert [summary[x]['official_finished_asof'] for x in ['north','south','npl']]==[187,188,200]
assert [summary[x]['comparisons']['rds'].get('absent',0) for x in ['north','south','npl']]==[71,76,89]
assert sum(s['comparisons']['rds'].get('exact',0) for s in summary.values())==338
assert sum(s['comparisons']['rds'].get('different_score',0) for s in summary.values())==1
for s in summary.values():
 assert not s['unaligned_names'] and not s['extras']
 assert s['comparisons']['rds']==s['comparisons']['http']==s['comparisons']['current_csv']
rows=list(csv.DictReader((B/'outputs/VI21-handover.csv').open()));assert len(rows)==237
prior=[r for r in rows if r['classification']=='already_absent_previous_csv'];restored=[r for r in rows if r['historical_match_id']]
assert len(prior)==201 and len(restored)==35
assert all(not r['historical_match_id'] and not r['historical_provider_key'] and r['stats']=='not_captured_not_invented' for r in prior)
assert sum(bool(json.loads(r['earlier_source_publication_files'])) for r in prior)==22
assert len({r['historical_match_id'] for r in restored})==35
assert len(list(csv.DictReader((B/'outputs/official-finished.csv').open())))==575
assert sum(int(r['global_exact_sporting_fact_count']) for r in rows)==0
assert sum(int(r['global_same_known_pair_plus_minus_31_days_count']) for r in rows)==1
assert next(r for r in rows if r['current_match_id'])['current_match_id']=='8625'
# All referenced local evidence paths and their hashes remain inspectable after moving the capsule.
for r in rows:
 for key in ['official_file','anchor_rds_file','global_capture_file']:
  p=B/r[key];assert p.exists();assert hashlib.sha256(p.read_bytes()).hexdigest()==r[{'global_capture_file':'global_capture_sha256'}.get(key,key+'_sha256')]
aliasfile=B/'inputs/alias/inputs.json.zlib';alias_status='not_captured'
if aliasfile.exists():
 a=json.loads(zlib.decompress(aliasfile.read_bytes()));assert a['read_only']=='on';assert a['probe_version']=='morecambe-alias-v1';assert not a['alias_facts']['rows'];alias_status='zero_rows_in_known_alias_window'
verification={'status':'PASS','official_finished':575,'exact':338,'absent':236,'withdrawn_recent':35,'prior_absences':201,'prior_seen_earlier':22,'prior_not_seen_four_snapshots':179,'score_discrepancy':1,'aligned_clubs':70,'new_physical_ids_invented':0,'global_exact_countermatches':0,'known_alias_control':alias_status,'network_calls':0}
(B/'outputs/verification.json').write_text(json.dumps(verification,indent=2));print('OFFLINE VERIFICATION',json.dumps(verification))
