"""Final measurement (§41): what the ordinary pass produces from today's real files, on a local PostgreSQL 18.

Usage: python -I mesure.py <worktree> <hist dir> <ang575 dir> <port> <out.json>

1. A fresh migrated base with the production parents of the 35 from the reviewed preimage (season, editions 332-334,
   rounds, the 70 clubs and their Open Matchday names) and the Elo run 2097, as the restore tool requires.
2. One run_due pass under vega_collect over today's results files of the seven folders (the latest Git versions,
   identical to the files downloaded on 19 Nov), fixtures declared 0.
3. The English editions compared with the organizer's 575 finished results (official-finished.csv through the keys of
   today's file, VI21-prior-201.csv and the 35-result ledger).
4. The restore tool (dry run, apply) with the reviewed captures, then two more passes; compared again.
"""
import csv
import json
import pathlib
import sys
import zipfile
import zlib
from datetime import datetime, timedelta, timezone

W, H, ORG, PORT, OUT = sys.argv[1:6]
W, H, ORG = pathlib.Path(W), pathlib.Path(H), pathlib.Path(ORG)
sys.path.insert(0, str(W / "backend"))
import psycopg  # noqa: E402
from psycopg import sql  # noqa: E402
from psycopg.types.json import Jsonb  # noqa: E402
from vega import open_matchday_restore, sources  # noqa: E402
from vega.sources import open_matchday, open_matchday_history  # noqa: E402
from vega.store import connect_local, migrate  # noqa: E402

SEASON = "2026/2027"
LATEST = {"ENG_6_national-league-north": "13a434955d", "ENG_6_national-league-south": "13a434955d",
          "ENG_7_northern-premier-league": "13a434955d", "POL_2_division-1": "772fb543b5", "POL_3_division-2": "a49c863c76",
          "WAL_1_cymru-premier": "772fb543b5", "ENG_CUP_fa-cup": "e1ec9773df"}
ENGLISH = {"north": "ENG_6_national-league-north", "south": "ENG_6_national-league-south", "npl": "ENG_7_northern-premier-league"}
NAME = "vega_v2_history_mesure"
with psycopg.connect(f"postgresql://postgres@127.0.0.1:{PORT}/postgres", autocommit=True) as ctl:
    ctl.execute(f'DROP DATABASE IF EXISTS "{NAME}" WITH (FORCE)')
    ctl.execute(f'CREATE DATABASE "{NAME}"')
DSN = f"postgresql://postgres@127.0.0.1:{PORT}/{NAME}"
db = connect_local(DSN)
migrate(db)
x = db.execute
collect = connect_local(DSN)
collect.execute("SET ROLE vega_collect")
archive = W / "docs/audits/2026-11-17/controles/verification-integree/35-matchs-identites-et-elo.zip"
with zipfile.ZipFile(archive) as z:
    before_raw, after_raw = z.read("rds/avant.zlib"), z.read("rds/apres.zlib")
before, after = json.loads(zlib.decompress(before_raw)), json.loads(zlib.decompress(after_raw))


def rows(view, key):
    return [json.loads(line) for line in view["reads"][key]["rows_json"]]


def insert(table, documents):
    columns = [c for (c,) in x("""SELECT attname FROM pg_attribute WHERE attrelid=%s::regclass AND attnum>0
                                 AND NOT attisdropped AND attgenerated='' ORDER BY attnum""", (table,))]
    names = sql.SQL(", ").join(map(sql.Identifier, columns))
    target = sql.Identifier(*table.split("."))
    x(sql.SQL("INSERT INTO {} ({}) SELECT {} FROM jsonb_populate_recordset(NULL::{}, %s)").format(target, names, names, target),
      (Jsonb(documents),))


insert("core.seasons", rows(before, "parent.matches_season_id_fkey"))
x("SELECT core.ensure_season_partitions(2026)")
teams = {r["id"]: dict(r, crest_asset_id=None, home_venue_id=None)
         for k in ("parent.matches_home_team_id_fkey", "parent.matches_away_team_id_fkey") for r in rows(before, k)}
x("INSERT INTO core.countries(code) SELECT unnest(%s::text[]) ON CONFLICT DO NOTHING",
  (sorted({t["country_code"] for t in teams.values() if t["country_code"]}),))
insert("core.teams", list(teams.values()))
editions = rows(before, "parent.matches_competition_season_id_season_id_fkey")
for e in editions:
    x("INSERT INTO core.competitions(id,name,country_code) VALUES (%s,%s,'ENG')", (e["competition_id"], e["cup_name"]))
    x("INSERT INTO core.provider_ids(entity_type,provider,provider_key,entity_id) VALUES ('competition','vega',%s,%s)",
      ("cup:open-matchday:" + e["cup_key"].split(":")[1], e["competition_id"]))
insert("core.competition_seasons", editions)
insert("core.rounds", rows(before, "parent.matches_round_id_fkey"))
for m in rows(before, "table.core.matches"):
    for side in ("home", "away"):
        x("""INSERT INTO core.provider_ids(entity_type,provider,provider_key,entity_id) VALUES ('team','open_matchday',%s,%s)
             ON CONFLICT DO NOTHING""", ("name:" + m[side + "_team_name"], m[side + "_team_id"]))
insert("agg.power_runs", rows(after, "elo_runs"))
insert("agg.team_elo", rows(after, "table.agg.team_elo"))
x("SELECT setval(pg_get_serial_sequence('core.matches','id'), 20000)")

files = {f: (H / f"{f}@{sha}.csv").read_text(encoding="utf-8") for f, sha in LATEST.items()}
step = [0]


def read():
    leagues = [{"folder": f"data/{f}", "league": f, "results": len(open_matchday.rows(t)), "fixtures": 0, "errors": []}
               for f, t in files.items()]
    bodies = {f"{open_matchday.RAW}data/{f}/results_2627.csv": t for f, t in files.items()}

    def get(url, *, as_text=False):
        if url.endswith("build_summary.json"):
            return {"season": "2627", "generated_utc": "2026-11-19T06:46:25Z", "leagues": leagues}
        return bodies[url]

    step[0] += 1
    at = datetime(2026, 11, 19, 7, tzinfo=timezone.utc) + timedelta(hours=7 * step[0])
    outcome = sources.run_due(collect, get, at, names={"open_matchday"})[("open_matchday", "europe")]
    return outcome, x("SELECT rows_written, unmatched FROM ops.source_runs WHERE source='open_matchday'").fetchone()


def stored():
    out = {}
    for key, mid, hs, aws, rev, xmin in x("""SELECT p.provider_key, m.id, m.home_score, m.away_score, m.revision, m.xmin::text
            FROM core.matches m JOIN core.provider_ids p ON p.entity_type='match' AND p.entity_id=m.id AND p.is_current
            WHERE p.provider='open_matchday' AND m.status='finished'"""):
        out[key] = (mid, hs, aws, rev, xmin)
    return out


# The organizer's 575: today's file keys (the 339 served, 8625 at the organizer's 0-1), the 201, the 35.
official = {}
for f in ENGLISH.values():
    for r in open_matchday.rows(files[f]):
        official[f"{f}:{SEASON}:{r['date']}|{r['home']}|{r['away']}"] = (int(r["ft_home"]), int(r["ft_away"]))
official[f"ENG_7_northern-premier-league:{SEASON}:2026-11-03|Ashton Utd|Warrington"] = (0, 1)
for r in csv.DictReader((ORG / "outputs/VI21-prior-201.csv").read_text().splitlines()):
    official[f"{ENGLISH[r['league']]}:{SEASON}:{r['match_date']}|{r['home_vega']}|{r['away_vega']}"] = (
        int(r["home_score_official"]), int(r["away_score_official"]))
ledger = json.loads((W / "backend/vega/sources/data/open_matchday_history.json").read_bytes())["results"]
for r in ledger:
    official[r["provider_key"]] = tuple(r["score"])
finished = list(csv.DictReader((ORG / "outputs/official-finished.csv").read_text().splitlines()))


def compare(found):
    english = {k: v for k, v in found.items() if k.split(":")[0] in ENGLISH.values()}
    exact = sum(1 for k, s in official.items() if k in english and english[k][1:3] == s)
    return {"official": len(official), "organizer_csv_finished": len(finished), "present_exact": exact,
            "present_other_score": sorted(k for k, s in official.items() if k in english and english[k][1:3] != s),
            "absent": len([k for k in official if k not in english]),
            "absent_are_the_35": sorted(k for k in official if k not in english) == sorted(r["provider_key"] for r in ledger),
            "extra_not_official": sorted(k for k in english if k not in official)}


def per_folder(found):
    attested = {f: len(open_matchday_history.for_edition(f, SEASON)) for f in LATEST}
    live = {f: len(open_matchday.rows(t)) for f, t in files.items()}
    return {f: {"live": live[f], "attested": attested[f], "stored": sum(1 for k in found if k.startswith(f + ":"))} for f in LATEST}


report = {"worktree_sha": __import__("subprocess").check_output(["git", "-C", str(W), "rev-parse", "HEAD"], text=True).strip(),
          "server": x("SHOW server_version").fetchone()[0], "files": LATEST}
report["pass_1"] = {"run": read()}
first = stored()
report["pass_1"].update(per_folder=per_folder(first), english_vs_organizer=compare(first),
                        failures=x("SELECT error_code, message FROM ops.parse_failures ORDER BY id").fetchall())
report["restore_dry_run"] = open_matchday_restore.restore(db, before, after, False)
report["restore_apply"] = open_matchday_restore.restore(db, before, after, True)
report["pass_2"] = {"run": read()}
second = stored()
report["pass_2"].update(per_folder=per_folder(second), english_vs_organizer=compare(second),
                        new_matches=len(set(second) - set(first)) - 35,
                        revisions_changed=sorted(k for k in first if first[k][3] != second[k][3]))
report["pass_3"] = {"run": read()}
third = stored()
report["pass_3"]["row_versions_changed"] = sorted(k for k in second if second[k][4] != third[k][4])
report["restore_again"] = open_matchday_restore.restore(db, before, after, True)
report["failures_total"] = x("SELECT error_code, count(*) FROM ops.parse_failures GROUP BY 1 ORDER BY 1").fetchall()
pathlib.Path(OUT).write_text(json.dumps(report, indent=1, ensure_ascii=False, default=str))
print(json.dumps({k: v for k, v in report.items()}, indent=1, ensure_ascii=False, default=str)[:6000])
