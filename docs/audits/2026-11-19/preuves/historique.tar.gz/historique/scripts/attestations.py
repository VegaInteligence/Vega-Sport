"""Rebuild backend/vega/sources/data/open_matchday_published.json from the Git history of open-matchday.

Usage:
  python -I attestations.py <worktree> <hist dir> <English organizer capsule dir> <out.json> <counts.json>

<hist dir>: for each folder, <folder>-commits.json (GitHub API commits?path=data/<folder>/results_2627.csv) and
<folder>@<sha10>.csv, the file at that commit (raw.githubusercontent.com/oladeeayo/open-matchday/<sha>/...).
<English organizer capsule dir>: the extracted docs/audits/2026-11-17/controles/verification-integree/angleterre-575.zip
(outputs/VI21-prior-201.csv, outputs/VI21-score-1.csv).
Every input is data: read, never executed. The worktree gives the 35-result ledger and the source's key rule.

A result is attested when (FAILURE_MODES.md §41):
- some version of the folder's results file lists it and the latest version does not;
- every version that lists it gives the same score;
- no later version (after the last that lists it) lists the same two sides, in the same order, on another day within
  31 days (the source moved the result), nor another result on its day with one of its two sides (a renamed key);
- it is not one of the 35 of the restore tool (open_matchday_history.json, id_at_incident);
- English folders: the organizer's official result (angleterre-575.zip, VI21-prior-201.csv) has its day, sides and
  score: it carries the organizer's proof, wherever it left the window;
- other folders: it left by the left edge of the window (dated before the first result of the version that dropped
  it): it carries the commit that published it.
The organizer's final of match 8625 (VI21-score-1.csv), which the latest version contradicts, is attested too.
"""
import csv
import hashlib
import json
import pathlib
import sys
from datetime import date

W, H, ORG, OUT, COUNTS = (pathlib.Path(p) for p in sys.argv[1:6])
SEASON = "2026/2027"
ENGLISH = {"north": "ENG_6_national-league-north", "south": "ENG_6_national-league-south",
           "npl": "ENG_7_northern-premier-league"}
FOLDERS = [*ENGLISH.values(), "POL_2_division-1", "POL_3_division-2", "WAL_1_cymru-premier", "ENG_CUP_fa-cup",
           "UKR_1_premier-league"]
SOURCE = "https://github.com/oladeeayo/open-matchday"
sys.path.insert(0, str(W / "backend"))
from vega.scope import REMOVED_FOLDERS  # noqa: E402
from vega.sources.open_matchday import COVERED, SPELLINGS  # noqa: E402

LEDGER = json.loads((W / "backend/vega/sources/data/open_matchday_history.json").read_bytes())
INCIDENT = {r["provider_key"]: r for r in LEDGER["results"]}
inputs = {}


def read_bytes(path):
    raw = path.read_bytes()
    inputs[str(path.relative_to(path.parents[1]))] = hashlib.sha256(raw).hexdigest()
    return raw


def key_of(folder, row):
    home, away = (row.get("home") or "").strip(), (row.get("away") or "").strip()
    home, away = SPELLINGS.get(home, home), SPELLINGS.get(away, away)
    return f"{folder}:{SEASON}:{(row.get('date') or '').strip()}|{home}|{away}", home, away


def versions(folder):
    commits = sorted(json.loads(read_bytes(H / f"{folder}-commits.json")), key=lambda c: c["commit"]["committer"]["date"])
    out = []
    for c in commits:
        text = read_bytes(H / f"{folder}@{c['sha'][:10]}.csv").decode("utf-8-sig")
        rows = {}
        for row in csv.DictReader(text.splitlines()):
            key, home, away = key_of(folder, row)
            rows[key] = {"date": row["date"].strip(), "home": home, "away": away,
                         "score": [int(row["ft_home"]), int(row["ft_away"])], "round": (row.get("gw") or "").strip() or None}
        out.append({"commit": c["sha"], "at": c["commit"]["committer"]["date"], "rows": rows,
                    "first": min(r["date"] for r in rows.values())})
    return out


def organizer_rows(name):
    out = {}
    for row in csv.DictReader(read_bytes(ORG / "outputs" / name).decode().splitlines()):
        key = f"{ENGLISH[row['league']]}:{SEASON}:{row['match_date']}|{row['home_vega']}|{row['away_vega']}"
        out[key] = row
    return out


official = organizer_rows("VI21-prior-201.csv")
score_1 = organizer_rows("VI21-score-1.csv")
results, counts, excluded = [], {}, []
for folder in FOLDERS:
    assert folder not in COVERED and folder not in REMOVED_FOLDERS, folder
    english = folder in ENGLISH.values()
    history = versions(folder)
    latest = history[-1]["rows"]
    seen = {}
    for index, version in enumerate(history):
        for key, row in version["rows"].items():
            seen.setdefault(key, []).append((index, row))
    c = {"versions": len(history), "latest_commit": history[-1]["commit"], "latest_results": len(latest),
         "published_then_gone": 0, "attested": 0, "restore_tool": 0}
    for key in sorted(set(seen) - set(latest)):
        c["published_then_gone"] += 1
        listed = seen[key]
        last_index, row = listed[-1]
        exit_version = history[last_index + 1]
        reason = None
        if key in INCIDENT:
            reason = "restore_tool"
        elif len({tuple(r["score"]) for _, r in listed}) != 1:
            reason = "score_varies"
        else:
            day = date.fromisoformat(row["date"])
            for version in history[last_index + 1:]:
                for other in version["rows"].values():
                    if other["date"] == row["date"] and (other["home"], other["away"]) != (row["home"], row["away"]) and (
                            other["home"] in (row["home"], row["away"]) or other["away"] in (row["home"], row["away"])):
                        reason = reason or "renamed_key"
                    if (other["home"], other["away"]) == (row["home"], row["away"]) and other["date"] != row["date"] and abs(
                            (date.fromisoformat(other["date"]) - day).days) <= 31:
                        reason = reason or "moved"
        left_edge = row["date"] < exit_version["first"]
        proof = official.get(key) if english else None
        if reason is None and english:
            if proof is None:
                reason = "not_corroborated"
            elif [int(proof["home_score_official"]), int(proof["away_score_official"])] != row["score"]:
                reason = "organizer_differs"
        if reason is None and not english and not left_edge:
            reason = "left_inside_window"
        if reason:
            c[reason] = c.get(reason, 0) + 1
            if reason != "restore_tool":
                excluded.append({"provider_key": key, "score": row["score"], "reason": reason,
                                 "last_published_in": history[last_index]["commit"]})
            continue
        entry = {"provider_key": key, "score": row["score"], "round": row["round"],
                 "published_in": {"commit": history[last_index]["commit"], "committed_at": history[last_index]["at"],
                                  "path": f"data/{folder}/results_2627.csv"},
                 "left_window": "left_edge" if left_edge else "inside"}
        if proof:
            entry.update(official_match_id=proof["official_id"], official_calendar=proof["official_url"],
                         official_file_sha256=proof["official_file_sha256"])
        results.append(entry)
        c["attested"] += 1
    if english:
        for key, proof in score_1.items():
            if key.startswith(folder + ":"):
                stated = latest[key]["score"]
                organizer = [int(proof["home_score_official"]), int(proof["away_score_official"])]
                assert stated != organizer and proof["current_match_id"] == "8625", (key, stated, organizer)
                results.append({"provider_key": key, "score": organizer, "round": latest[key]["round"], "published_in": None,
                                "source_reports": {"score": stated, "commit": history[-1]["commit"]},
                                "official_match_id": proof["official_id"], "official_calendar": proof["official_url"],
                                "official_file_sha256": proof["official_file_sha256"]})
                c["organizer_corrects_latest"] = 1
        missing = sorted(k for k in official if k.startswith(folder + ":") and k not in {r["provider_key"] for r in results})
        c["organizer_201_not_attested"] = missing
    counts[folder] = c

results.sort(key=lambda r: r["provider_key"])
document = {
    "schema": 1,
    "scope": "open-matchday 2026/2027: results the source published, then dropped from its sliding window, "
             "and one organizer final; FAILURE_MODES.md §41",
    "source": SOURCE,
    "built_by": "evidence/historique/scripts/attestations.py (python -I, from the Git history and angleterre-575.zip)",
    "inputs_sha256": dict(sorted(inputs.items())),
    "results": results,
}
OUT.write_text(json.dumps(document, indent=1, ensure_ascii=False, sort_keys=True) + "\n", encoding="utf-8")
COUNTS.write_text(json.dumps({"counts": counts, "excluded": excluded, "total_attested": len(results),
                              "sha256": hashlib.sha256(OUT.read_bytes()).hexdigest()}, indent=1, ensure_ascii=False))
print(json.dumps({f: {k: v for k, v in c.items() if k not in ("latest_commit",)} for f, c in counts.items()}, indent=1))
print("attested", len(results), "excluded", len(excluded), "sha256", hashlib.sha256(OUT.read_bytes()).hexdigest())
