"""For each Open Matchday results file in the Git history, compare consecutive versions:
which results leave, and whether they leave by the left edge of the window.

Usage: python -I fenetres.py <hist dir> <out.json>
Reads only <folder>-commits.json and <folder>@<sha10>.csv files (data, never executed)."""
import csv
import json
import pathlib
import sys

H = pathlib.Path(sys.argv[1])
out = {}
for commits in sorted(H.glob("*-commits.json")):
    folder = commits.name.removesuffix("-commits.json")
    order = sorted(json.loads(commits.read_text()), key=lambda c: c["commit"]["committer"]["date"])
    versions = []
    for c in order:
        path = H / f"{folder}@{c['sha'][:10]}.csv"
        if not path.exists():
            versions.append((c["sha"], c["commit"]["committer"]["date"], None))
            continue
        rows = list(csv.DictReader(path.open(encoding="utf-8-sig", newline="")))
        versions.append((c["sha"], c["commit"]["committer"]["date"],
                         {f"{r['date']}|{r['home']}|{r['away']}": (r["ft_home"], r["ft_away"], r.get("gw")) for r in rows}))
    steps = []
    prev = None
    for sha, when, rows in versions:
        if rows is None:
            steps.append({"sha": sha, "date": when, "missing_file": True})
            continue
        step = {"sha": sha, "date": when, "results": len(rows), "first": min(k[:10] for k in rows) if rows else None}
        if prev is not None:
            gone = sorted(set(prev) - set(rows))
            start = step["first"]
            left = [k for k in gone if k[:10] < start]
            interior = [k for k in gone if k[:10] >= start]
            changed = sorted(k for k in set(prev) & set(rows) if prev[k][:2] != rows[k][:2])
            overlap = [k for k in prev if k in rows]
            step.update(gone=len(gone), gone_left=len(left), gone_interior=interior, score_changed=changed,
                        overlap=len(overlap), overlap_days=len({k[:10] for k in overlap}),
                        new=len(set(rows) - set(prev)))
        steps.append(step)
        prev = rows
    out[folder] = steps
pathlib.Path(sys.argv[2]).write_text(json.dumps(out, indent=1, ensure_ascii=False))
for folder, steps in out.items():
    print(folder)
    for s in steps:
        if s.get("missing_file"):
            print("  ", s["sha"][:10], s["date"], "MISSING FILE")
            continue
        print("  ", s["sha"][:10], s["date"][:16], "n=%s first=%s" % (s["results"], s["first"]),
              "" if "gone" not in s else "gone=%s left=%s interior=%s changed=%s overlap=%s/%sd new=%s" % (
                  s["gone"], s["gone_left"], len(s["gone_interior"]), len(s["score_changed"]), s["overlap"], s["overlap_days"], s["new"]))
