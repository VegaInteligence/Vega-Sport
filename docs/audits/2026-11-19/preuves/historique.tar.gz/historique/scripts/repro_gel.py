"""Point 1: two consecutive real Git versions of a non-attested Open Matchday folder through the real writer
(sources.run_due) under vega_collect, on a disposable local PostgreSQL 18.

Usage: python -I repro_gel.py <worktree> <hist dir> <port> <folder> <old sha10> <new sha10>
Prints a JSON receipt: outcome of each read, matches stored, the parse failure."""
import json
import pathlib
import sys
from datetime import datetime, timedelta, timezone

W, H, PORT, FOLDER, OLD, NEW = sys.argv[1:7]
sys.path.insert(0, str(pathlib.Path(W) / "backend"))
import psycopg  # noqa: E402
from vega import sources  # noqa: E402
from vega.sources import open_matchday  # noqa: E402
from vega.store import connect_local, migrate  # noqa: E402

NAME = "vega_v2_history_repro"
with psycopg.connect(f"postgresql://postgres@127.0.0.1:{PORT}/postgres", autocommit=True) as ctl:
    ctl.execute(f'DROP DATABASE IF EXISTS "{NAME}" WITH (FORCE)')
    ctl.execute(f'CREATE DATABASE "{NAME}"')
DSN = f"postgresql://postgres@127.0.0.1:{PORT}/{NAME}"
owner = connect_local(DSN)
migrate(owner)
collect = connect_local(DSN)
collect.execute("SET ROLE vega_collect")


def body(sha):
    return (pathlib.Path(H) / f"{FOLDER}@{sha}.csv").read_text(encoding="utf-8")


def read(sha, at):
    text = body(sha)
    count = len(open_matchday.rows(text))

    def get(url, *, as_text=False):
        if url.endswith("build_summary.json"):
            return {"season": "2627", "generated_utc": at.isoformat(),
                    "leagues": [{"folder": f"data/{FOLDER}", "league": FOLDER, "results": count, "fixtures": 0, "errors": []}]}
        assert url == f"{open_matchday.RAW}data/{FOLDER}/results_2627.csv", url
        return text

    outcome = sources.run_due(collect, get, at, names={"open_matchday"})[("open_matchday", "europe")]
    run = owner.execute("SELECT status, error_code, rows_written, unmatched FROM ops.source_runs WHERE source='open_matchday'").fetchone()
    stored = owner.execute("""SELECT count(*) FROM core.matches m JOIN core.competition_seasons cs ON cs.id=m.competition_season_id
                              WHERE cs.cup_key=%s AND m.status='finished'""", (f"open-matchday:{FOLDER}:2026/2027",)).fetchone()[0]
    return {"sha": sha, "declared_results": count, "outcome": outcome, "source_run": run, "finished_stored": stored}


t0 = datetime(2026, 11, 19, 7, tzinfo=timezone.utc)
receipt = {"folder": FOLDER, "role": collect.execute("SELECT current_user").fetchone()[0],
           "server": owner.execute("SHOW server_version").fetchone()[0],
           "reads": [read(OLD, t0), read(NEW, t0 + timedelta(hours=7)), read(NEW, t0 + timedelta(hours=14))]}
receipt["parse_failures"] = owner.execute("SELECT error_code, message FROM ops.parse_failures ORDER BY id").fetchall()
receipt["checked_at"] = owner.execute(
    "SELECT cup_checked_at::text, cup_updated_at::text FROM core.competition_seasons WHERE cup_key=%s",
    (f"open-matchday:{FOLDER}:2026/2027",)).fetchone()
print(json.dumps(receipt, indent=1, default=str, ensure_ascii=False))
