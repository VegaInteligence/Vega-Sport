#!/bin/sh
# Start one isolated PostgreSQL 18 server. Python joins its loopback-only namespace.
set -eu
if [ "$#" -ne 1 ]; then
    echo "usage: sh hors-reseau.sh NEW_OUTPUT_DIRECTORY" >&2
    exit 2
fi
pkg=$(CDPATH= cd -- "$(dirname -- "$0")" && pwd -P)
out=$(python3 -I -B -c 'from pathlib import Path; import sys; print(Path(sys.argv[1]).resolve())' "$1")
case "$out/" in "$pkg/"*) echo "choose an output directory outside the capsule" >&2; exit 2;; esac
if [ -e "$out" ]; then echo "output already exists" >&2; exit 2; fi
mkdir -p "$out"
pg_image=${E04K_POSTGRES_IMAGE:-pgvector/pgvector:pg18}
py_image=${E04K_PYTHON_IMAGE:-e04k-python:3.14}
server=$(docker create --pull never --network none -e POSTGRES_HOST_AUTH_METHOD=trust "$pg_image")
cleanup() {
    docker rm -fv "$server" >/dev/null
}
trap cleanup EXIT
trap 'exit 1' HUP INT TERM
docker start "$server" >/dev/null
attempt=0
until docker exec "$server" pg_isready -q -h 127.0.0.1 -p 5432 -U postgres; do
    attempt=$((attempt+1))
    if [ "$attempt" -gt 60 ]; then docker logs "$server" >&2; exit 1; fi
    sleep 1
done
docker inspect -f '{{.HostConfig.NetworkMode}}' "$server" > "$out/postgres-network.txt"
docker image inspect -f '{{.Id}}' "$pg_image" "$py_image" > "$out/images.txt"
docker run --pull never --rm --network "container:$server" --read-only --tmpfs /tmp --tmpfs /app \
   -v "$pkg:/capsule:ro" -v "$out:/sortie" -w /capsule --entrypoint python "$py_image" \
   -I -B -c 'import errno,json,pathlib,runpy,socket,sys
links=sorted(p.name for p in pathlib.Path("/sys/class/net").iterdir())
routes=pathlib.Path("/proc/net/route").read_text().splitlines()[1:]
s=socket.socket()
s.settimeout(2)
rc=s.connect_ex(("192.0.2.1",443))
s.close()
if links != ["lo"] or routes or rc != errno.ENETUNREACH: raise SystemExit("external network not isolated")
pathlib.Path("/sortie/network.json").write_text(json.dumps({"interfaces":links,"ipv4_routes":routes,"external_ipv4_probe":rc,"expected":errno.ENETUNREACH,"postgres_address":"127.0.0.1:5432"},indent=2)+"\n")
sys.argv=["rejouer.py","--port","5432","--out","/sortie/passage"]
runpy.run_path("/capsule/rejouer.py",run_name="__main__")'
