CREATE SCHEMA core;

CREATE SCHEMA agg;

CREATE SCHEMA ops;

CREATE TYPE core.provider AS ENUM ('pitchapi',
                                   'wikidata',
                                   'openfootball',
                                   'open_matchday',
                                   'uefa',
                                   'sportscore',
                                   'vega',
                                   'other');

CREATE TYPE core.entity_type AS ENUM ('competition',
                                      'team',
                                      'player',
                                      'match',
                                      'coach',
                                      'referee',
                                      'venue',
                                      'asset');

CREATE TYPE core.competition_kind AS ENUM ('league',
                                           'cup',
                                           'international');

CREATE TYPE core.foot AS ENUM ('left',
                               'right',
                               'both');

CREATE TYPE core.asset_kind AS ENUM ('crest',
                                     'photo',
                                     'logo',
                                     'trophy');

CREATE TYPE core.match_status AS ENUM ('not_started',
                                       'in_play',
                                       'finished',
                                       'postponed',
                                       'awarded',
                                       'canceled');

CREATE TYPE core.coverage_status AS ENUM ('pending',
                                          'ok',
                                          'unavailable',
                                          'error');

CREATE TYPE core.side AS ENUM ('home',
                               'away');

CREATE TYPE core.event_type AS ENUM ('goal',
                                     'substitution',
                                     'yellow_card',
                                     'red_card');

CREATE TYPE core.period AS ENUM ('all',
                                 'first_half',
                                 'second_half',
                                 'extra_time',
                                 'penalties');

CREATE TYPE core.shot_outcome AS ENUM ('goal',
                                       'saved',
                                       'miss',
                                       'post');

CREATE TYPE core.shot_situation AS ENUM ('regular_play',
                                         'from_corner',
                                         'set_piece',
                                         'fast_break',
                                         'free_kick',
                                         'throw_in_set_piece',
                                         'penalty',
                                         'individual_play');

CREATE TYPE core.body_part AS ENUM ('right_foot',
                                    'left_foot',
                                    'header',
                                    'other');

CREATE TYPE core.absence_kind AS ENUM ('injury',
                                       'illness',
                                       'suspension');

CREATE TYPE core.transfer_kind AS ENUM ('transfer',
                                        'loan',
                                        'loan_return',
                                        'free');

CREATE TYPE core.honour_kind AS ENUM ('winner',
                                      'runner_up',
                                      'best_player',
                                      'top_scorer');

CREATE TYPE agg.metric_category AS ENUM ('finishing',
                                         'creation',
                                         'progression',
                                         'passing',
                                         'defending',
                                         'security',
                                         'physical');

CREATE TYPE ops.watch_state AS ENUM ('scheduled',
                                     'waiting_final',
                                     'final',
                                     'corrected');

CREATE TYPE ops.fetch_lane AS ENUM ('score',
                                    'details',
                                    'backfill',
                                    'reference');

CREATE TYPE ops.fetch_family AS ENUM ('calendar',
                                      'league_matches',
                                      'summary',
                                      'shots',
                                      'events',
                                      'lineups',
                                      'momentum',
                                      'team_stats',
                                      'player_stats',
                                      'player_halves',
                                      'advanced',
                                      'advanced_players',
                                      'network',
                                      'heatmaps',
                                      'h2h',
                                      'league',
                                      'team',
                                      'player');

CREATE TYPE ops.job_state AS ENUM ('pending',
                                   'leased',
                                   'done',
                                   'failed');

CREATE TYPE ops.scope_kind AS ENUM ('player_season',
                                    'team_season',
                                    'competition_season',
                                    'cohort');

CREATE TYPE ops.resource_kind AS ENUM ('match',
                                       'competition_season',
                                       'player',
                                       'team',
                                       'home');

CREATE TABLE core.countries(
  code text PRIMARY KEY,
  name_fr text,
  flag_code text,
  updated_at timestamptz NOT NULL DEFAULT now()
);

CREATE TABLE core.seasons(
  id smallint GENERATED BY DEFAULT AS IDENTITY PRIMARY KEY,
  label text UNIQUE NOT NULL,
  start_year smallint,
  updated_at timestamptz NOT NULL DEFAULT now()
);

CREATE TABLE core.assets(
  id integer GENERATED BY DEFAULT AS IDENTITY PRIMARY KEY,
  kind core.asset_kind NOT NULL,
  source_url text UNIQUE,
  s3_key text,
  sha256 bytea,
  content_type text,
  width smallint,
  height smallint,
  updated_at timestamptz NOT NULL DEFAULT now()
);

CREATE TABLE core.competitions(
  id integer GENERATED BY DEFAULT AS IDENTITY PRIMARY KEY,
  name text NOT NULL,
  country_code text REFERENCES core.countries,
  kind core.competition_kind,
  tier smallint,
  calendar_year boolean,
  logo_asset_id integer REFERENCES core.assets,
  updated_at timestamptz NOT NULL DEFAULT now()
);

CREATE TABLE core.competition_seasons(
  id integer GENERATED BY DEFAULT AS IDENTITY PRIMARY KEY,
  competition_id integer NOT NULL REFERENCES core.competitions,
  season_id smallint NOT NULL REFERENCES core.seasons,
  native_label text,
  start_date date,
  end_date date,
  is_current boolean,
  updated_at timestamptz NOT NULL DEFAULT now(),
  UNIQUE(competition_id, season_id),
  UNIQUE(id, season_id)
);

CREATE TABLE core.teams(
  id integer GENERATED BY DEFAULT AS IDENTITY PRIMARY KEY,
  name text NOT NULL,
  short_name text,
  country_code text REFERENCES core.countries,
  is_national boolean,
  crest_asset_id integer REFERENCES core.assets,
  updated_at timestamptz NOT NULL DEFAULT now()
);

CREATE TABLE core.team_seasons(
  team_id integer REFERENCES core.teams,
  competition_season_id integer REFERENCES core.competition_seasons,
  updated_at timestamptz NOT NULL DEFAULT now(),
  PRIMARY KEY(team_id, competition_season_id)
);

CREATE TABLE core.players(
  id integer GENERATED BY DEFAULT AS IDENTITY PRIMARY KEY,
  name text NOT NULL,
  short_name text,
  shirt_number smallint,
  position_id smallint,
  country_code text REFERENCES core.countries,
  photo_asset_id integer REFERENCES core.assets,
  birth_date date,
  height_cm smallint,
  weight_kg smallint,
  preferred_foot core.foot,
  updated_at timestamptz NOT NULL DEFAULT now()
);

CREATE EXTENSION IF NOT EXISTS pg_trgm;

CREATE INDEX players_name_trgm ON core.players USING gin(name gin_trgm_ops);

CREATE TABLE core.coaches(
  id integer GENERATED BY DEFAULT AS IDENTITY PRIMARY KEY,
  name text NOT NULL UNIQUE,
  updated_at timestamptz NOT NULL DEFAULT now()
);

CREATE TABLE core.referees(
  id integer GENERATED BY DEFAULT AS IDENTITY PRIMARY KEY,
  name text NOT NULL UNIQUE,
  updated_at timestamptz NOT NULL DEFAULT now()
);

CREATE TABLE core.venues(
  id integer GENERATED BY DEFAULT AS IDENTITY PRIMARY KEY,
  name text NOT NULL UNIQUE,
  city text,
  updated_at timestamptz NOT NULL DEFAULT now()
);

CREATE TABLE core.formation_slots(
  formation text,
  position_id smallint,
  position_code text,
  pitch_x real,
  pitch_y real,
  updated_at timestamptz NOT NULL DEFAULT now(),
  PRIMARY KEY(formation, position_id)
);

CREATE TABLE core.provider_ids(
  entity_type core.entity_type,
  provider core.provider,
  provider_key text,
  entity_id integer NOT NULL,
  updated_at timestamptz NOT NULL DEFAULT now(),
  PRIMARY KEY(entity_type, provider, provider_key),
  UNIQUE(entity_type, entity_id, provider)
);

CREATE TABLE core.matches(
  id integer GENERATED BY DEFAULT AS IDENTITY PRIMARY KEY,
  competition_season_id integer NOT NULL,
  season_id smallint NOT NULL REFERENCES core.seasons,
  round_name text,
  kickoff_at timestamptz,
  match_date date,
  status core.match_status,
  home_team_id integer REFERENCES core.teams,
  away_team_id integer REFERENCES core.teams,
  home_score smallint,
  away_score smallint,
  home_penalty_score smallint,
  away_penalty_score smallint,
  has_playoff boolean,
  referee_id integer REFERENCES core.referees,
  venue_id integer REFERENCES core.venues,
  source core.provider NOT NULL,
  revision integer NOT NULL DEFAULT 1 CHECK(revision>0),
  first_finished_at timestamptz,
  updated_at timestamptz NOT NULL DEFAULT now(),
  UNIQUE(id, season_id),
  FOREIGN KEY(competition_season_id, season_id) REFERENCES core.competition_seasons(id, season_id)
);

CREATE INDEX matches_competition_kickoff ON core.matches(competition_season_id, kickoff_at);

CREATE INDEX matches_home_kickoff ON core.matches(home_team_id, kickoff_at);

CREATE INDEX matches_away_kickoff ON core.matches(away_team_id, kickoff_at);

CREATE INDEX matches_upcoming ON core.matches(kickoff_at)
WHERE status='not_started';

CREATE TABLE core.match_coverage (
  season_id smallint NOT NULL,
  match_id integer NOT NULL,
  shots core.coverage_status NOT NULL DEFAULT 'pending',
  events core.coverage_status NOT NULL DEFAULT 'pending',
  lineups core.coverage_status NOT NULL DEFAULT 'pending',
  momentum core.coverage_status NOT NULL DEFAULT 'pending',
  team_stats core.coverage_status NOT NULL DEFAULT 'pending',
  player_stats core.coverage_status NOT NULL DEFAULT 'pending',
  player_halves core.coverage_status NOT NULL DEFAULT 'pending',
  advanced core.coverage_status NOT NULL DEFAULT 'pending',
  advanced_players core.coverage_status NOT NULL DEFAULT 'pending',
  network core.coverage_status NOT NULL DEFAULT 'pending',
  heatmaps core.coverage_status NOT NULL DEFAULT 'pending',
  h2h core.coverage_status NOT NULL DEFAULT 'pending',
  updated_at timestamptz NOT NULL DEFAULT now(),
  PRIMARY KEY(season_id, match_id),
  FOREIGN KEY(match_id, season_id) REFERENCES core.matches(id, season_id) ON DELETE CASCADE
) PARTITION BY LIST(season_id );

CREATE TABLE core.lineups (
  season_id smallint NOT NULL,
  match_id integer NOT NULL,
  team_id integer NOT NULL REFERENCES core.teams,
  side core.side NOT NULL,
  formation text,
  confirmed boolean,
  lineup_type text,
  coach_id integer REFERENCES core.coaches,
  updated_at timestamptz NOT NULL DEFAULT now(),
  PRIMARY KEY(season_id, match_id, team_id),
  FOREIGN KEY(match_id, season_id) REFERENCES core.matches(id, season_id) ON DELETE CASCADE
) PARTITION BY LIST(season_id );

CREATE TABLE core.lineup_players (
  season_id smallint NOT NULL,
  match_id integer NOT NULL,
  team_id integer REFERENCES core.teams,
  player_id integer NOT NULL REFERENCES core.players,
  is_starter boolean,
  shirt_number smallint,
  position_id smallint,
  is_captain boolean,
  pitch_x real,
  pitch_y real,
  updated_at timestamptz NOT NULL DEFAULT now(),
  PRIMARY KEY(season_id, match_id, player_id),
  FOREIGN KEY(match_id, season_id) REFERENCES core.matches(id, season_id) ON DELETE CASCADE
) PARTITION BY LIST(season_id );

CREATE INDEX lineup_players_player_id ON core.lineup_players(player_id);

CREATE TABLE core.match_events (
  season_id smallint NOT NULL,
  match_id integer NOT NULL,
  team_id integer REFERENCES core.teams,
  seq smallint NOT NULL,
  event_type core.event_type,
  minute smallint,
  minute_added smallint,
  period core.period,
  player_id integer REFERENCES core.players,
  related_player_id integer REFERENCES core.players,
  score_home smallint,
  score_away smallint,
  is_own_goal boolean,
  is_penalty boolean,
  updated_at timestamptz NOT NULL DEFAULT now(),
  PRIMARY KEY(season_id, match_id, seq),
  FOREIGN KEY(match_id, season_id) REFERENCES core.matches(id, season_id) ON DELETE CASCADE
) PARTITION BY LIST(season_id );

CREATE INDEX match_events_player_id ON core.match_events(player_id);

CREATE TABLE core.shots (
  season_id smallint NOT NULL,
  match_id integer NOT NULL,
  team_id integer REFERENCES core.teams,
  shot_no smallint NOT NULL,
  provider_shot_key text,
  period core.period,
  minute smallint,
  minute_added smallint,
  player_id integer REFERENCES core.players,
  keeper_id integer REFERENCES core.players,
  x real,
  y real,
  xg real,
  xgot real,
  is_on_target boolean,
  goal_crossed_y real,
  goal_crossed_z real,
  is_inside_box boolean,
  outcome core.shot_outcome,
  situation core.shot_situation,
  body_part core.body_part,
  is_blocked boolean,
  blocked_x real,
  blocked_y real,
  is_own_goal boolean,
  is_saved_off_line boolean,
  updated_at timestamptz NOT NULL DEFAULT now(),
  PRIMARY KEY(season_id, match_id, shot_no),
  FOREIGN KEY(match_id, season_id) REFERENCES core.matches(id, season_id) ON DELETE CASCADE
) PARTITION BY LIST(season_id );

CREATE INDEX shots_player_id ON core.shots(player_id);

CREATE INDEX shots_keeper_id ON core.shots(keeper_id);

CREATE TABLE core.match_momentum (
  season_id smallint NOT NULL,
  match_id integer NOT NULL,
  minute real NOT NULL,
  value real,
  updated_at timestamptz NOT NULL DEFAULT now(),
  PRIMARY KEY(season_id, match_id, minute),
  FOREIGN KEY(match_id, season_id) REFERENCES core.matches(id, season_id) ON DELETE CASCADE
) PARTITION BY LIST(season_id );

CREATE TABLE core.match_h2h (
  season_id smallint NOT NULL,
  match_id integer NOT NULL,
  home_wins smallint,
  draws smallint,
  away_wins smallint,
  total_matches smallint,
  updated_at timestamptz NOT NULL DEFAULT now(),
  PRIMARY KEY(season_id, match_id),
  FOREIGN KEY(match_id, season_id) REFERENCES core.matches(id, season_id) ON DELETE CASCADE
) PARTITION BY LIST(season_id );

CREATE TABLE core.player_match_stats (
  season_id smallint NOT NULL,
  match_id integer NOT NULL,
  team_id integer REFERENCES core.teams,
  player_id integer NOT NULL REFERENCES core.players,
  position_id smallint,
  minutes_played smallint,
  goals smallint,
  assists smallint,
  own_goals smallint,
  total_shots smallint,
  shots_on_target smallint,
  shots_off_target smallint,
  blocked_shots smallint,
  shots_woodwork smallint,
  big_chances_created smallint,
  big_chances_missed smallint,
  penalties_won smallint,
  penalties_missed smallint,
  accurate_passes smallint,
  accurate_passes_total smallint,
  passes_into_final_third smallint,
  chances_created smallint,
  crosses smallint,
  accurate_crosses smallint,
  accurate_crosses_total smallint,
  long_balls_accurate smallint,
  long_balls_total smallint,
  line_breaking_passes smallint,
  corners smallint,
  throw_ins smallint,
  touches smallint,
  touches_opp_box smallint,
  dribbles_succeeded smallint,
  dribbles_total smallint,
  dispossessed smallint,
  offsides smallint,
  was_fouled smallint,
  tackles smallint,
  last_man_tackles smallint,
  interceptions smallint,
  clearances smallint,
  headed_clearances smallint,
  clearances_off_line smallint,
  shot_blocks smallint,
  recoveries smallint,
  defensive_actions smallint,
  dribbled_past smallint,
  errors_led_to_goal smallint,
  penalties_conceded smallint,
  fouls smallint,
  duels_won smallint,
  duels_lost smallint,
  ground_duels_won smallint,
  ground_duels_total smallint,
  aerials_won smallint,
  aerials_total smallint,
  saves smallint,
  saves_inside_box smallint,
  diving_saves smallint,
  high_claims smallint,
  punches smallint,
  sweeper_actions smallint,
  goals_conceded smallint,
  penalties_saved smallint,
  shootout_penalties_saved smallint,
  sprints smallint,
  rating real,
  fantasy_points real,
  xg real,
  npxg real,
  xgot real,
  xa real,
  goals_prevented real,
  xgot_faced real,
  distance_m real,
  running_m real,
  sprinting_m real,
  top_speed_kmh real,
  updated_at timestamptz NOT NULL DEFAULT now(),
  PRIMARY KEY(season_id, match_id, player_id),
  FOREIGN KEY(match_id, season_id) REFERENCES core.matches(id, season_id) ON DELETE CASCADE
) PARTITION BY LIST(season_id );

CREATE INDEX player_match_stats_player_id_season_id ON core.player_match_stats(player_id, season_id);

CREATE TABLE core.player_match_half_stats (
  season_id smallint NOT NULL,
  match_id integer NOT NULL,
  team_id integer REFERENCES core.teams,
  player_id integer NOT NULL REFERENCES core.players,
  period core.period NOT NULL CHECK(period IN ('first_half', 'second_half')),
  position_id smallint,
  minutes_played smallint,
  goals smallint,
  assists smallint,
  own_goals smallint,
  total_shots smallint,
  shots_on_target smallint,
  shots_off_target smallint,
  blocked_shots smallint,
  shots_woodwork smallint,
  big_chances_created smallint,
  big_chances_missed smallint,
  penalties_won smallint,
  penalties_missed smallint,
  accurate_passes smallint,
  accurate_passes_total smallint,
  passes_into_final_third smallint,
  chances_created smallint,
  crosses smallint,
  accurate_crosses smallint,
  accurate_crosses_total smallint,
  long_balls_accurate smallint,
  long_balls_total smallint,
  line_breaking_passes smallint,
  corners smallint,
  throw_ins smallint,
  touches smallint,
  touches_opp_box smallint,
  dribbles_succeeded smallint,
  dribbles_total smallint,
  dispossessed smallint,
  offsides smallint,
  was_fouled smallint,
  tackles smallint,
  last_man_tackles smallint,
  interceptions smallint,
  clearances smallint,
  headed_clearances smallint,
  clearances_off_line smallint,
  shot_blocks smallint,
  recoveries smallint,
  defensive_actions smallint,
  dribbled_past smallint,
  errors_led_to_goal smallint,
  penalties_conceded smallint,
  fouls smallint,
  duels_won smallint,
  duels_lost smallint,
  ground_duels_won smallint,
  ground_duels_total smallint,
  aerials_won smallint,
  aerials_total smallint,
  saves smallint,
  saves_inside_box smallint,
  diving_saves smallint,
  high_claims smallint,
  punches smallint,
  sweeper_actions smallint,
  goals_conceded smallint,
  penalties_saved smallint,
  shootout_penalties_saved smallint,
  sprints smallint,
  xg real,
  npxg real,
  xgot real,
  xa real,
  goals_prevented real,
  xgot_faced real,
  distance_m real,
  running_m real,
  sprinting_m real,
  top_speed_kmh real,
  updated_at timestamptz NOT NULL DEFAULT now(),
  PRIMARY KEY(season_id, match_id, player_id, period),
  FOREIGN KEY(match_id, season_id) REFERENCES core.matches(id, season_id) ON DELETE CASCADE
) PARTITION BY LIST(season_id );

CREATE INDEX player_match_half_stats_player_id_season_id ON core.player_match_half_stats(player_id, season_id);

CREATE TABLE core.team_match_stats (
  season_id smallint NOT NULL,
  match_id integer NOT NULL,
  team_id integer NOT NULL REFERENCES core.teams,
  period core.period NOT NULL CHECK(period IN ('all', 'first_half', 'second_half')),
  total_shots smallint,
  shots_on_target smallint,
  shots_off_target smallint,
  blocked_shots smallint,
  shots_woodwork smallint,
  shots_inside_box smallint,
  shots_outside_box smallint,
  big_chances smallint,
  big_chances_missed smallint,
  passes smallint,
  accurate_passes smallint,
  own_half_passes smallint,
  opposition_half_passes smallint,
  long_balls_accurate smallint,
  accurate_crosses smallint,
  touches_opp_box smallint,
  corners smallint,
  offsides smallint,
  throw_ins smallint,
  tackles smallint,
  interceptions smallint,
  clearances smallint,
  shot_blocks smallint,
  keeper_saves smallint,
  duels_won smallint,
  ground_duels_won smallint,
  aerials_won smallint,
  dribbles_succeeded smallint,
  fouls smallint,
  yellow_cards smallint,
  red_cards smallint,
  sprints smallint,
  xg real,
  npxg real,
  xgot real,
  xg_open_play real,
  xg_set_play real,
  possession_pct real,
  long_balls_pct real,
  crosses_pct real,
  ground_duels_pct real,
  aerials_pct real,
  dribbles_pct real,
  distance_m real,
  walking_m real,
  running_m real,
  sprinting_m real,
  updated_at timestamptz NOT NULL DEFAULT now(),
  PRIMARY KEY(season_id, match_id, team_id, period),
  FOREIGN KEY(match_id, season_id) REFERENCES core.matches(id, season_id) ON DELETE CASCADE
) PARTITION BY LIST(season_id );

CREATE TABLE core.team_match_advanced (
  season_id smallint NOT NULL,
  match_id integer NOT NULL,
  team_id integer NOT NULL REFERENCES core.teams,
  actions smallint,
  passes smallint,
  progressive_passes smallint,
  passes_into_box smallint,
  key_passes smallint,
  assists smallint,
  through_balls smallint,
  crosses smallint,
  switches smallint,
  carries smallint,
  progressive_carries smallint,
  carries_into_final_third smallint,
  carries_into_box smallint,
  take_ons smallint,
  take_ons_won smallint,
  miscontrols smallint,
  dispossessed smallint,
  sca smallint,
  gca smallint,
  second_assists smallint,
  sca_pass_live smallint,
  sca_pass_dead smallint,
  sca_take_on smallint,
  sca_shot smallint,
  sca_defensive smallint,
  tackles smallint,
  interceptions smallint,
  blocks smallint,
  clearances smallint,
  duels_won smallint,
  aerials smallint,
  aerials_won smallint,
  sca_foul_drawn smallint,
  opponent_passes smallint,
  defensive_actions smallint,
  challenges smallint,
  high_turnovers smallint,
  counterpress_regains_5s smallint,
  final_third_entries smallint,
  box_entries smallint,
  buildup_attacks smallint,
  direct_attacks smallint,
  xt_total real,
  vaep_total real,
  vaep_offensive real,
  vaep_defensive real,
  pv_total real,
  pv_offensive real,
  pv_defensive real,
  pass_accuracy real,
  progressive_pass_distance real,
  carry_distance real,
  progressive_carry_distance real,
  xag real,
  ppda real,
  avg_defensive_action_x real,
  ball_recovery_time real,
  possession_pct real,
  field_tilt real,
  avg_action_x real,
  passes_per_sequence real,
  sequence_time real,
  direct_speed real,
  updated_at timestamptz NOT NULL DEFAULT now(),
  PRIMARY KEY(season_id, match_id, team_id),
  FOREIGN KEY(match_id, season_id) REFERENCES core.matches(id, season_id) ON DELETE CASCADE
) PARTITION BY LIST(season_id );

CREATE TABLE core.player_match_advanced (
  season_id smallint NOT NULL,
  match_id integer NOT NULL,
  team_id integer REFERENCES core.teams,
  player_id integer NOT NULL REFERENCES core.players,
  minutes_played smallint,
  actions smallint,
  passes smallint,
  progressive_passes smallint,
  passes_into_box smallint,
  key_passes smallint,
  assists smallint,
  through_balls smallint,
  crosses smallint,
  switches smallint,
  carries smallint,
  progressive_carries smallint,
  carries_into_final_third smallint,
  carries_into_box smallint,
  take_ons smallint,
  take_ons_won smallint,
  miscontrols smallint,
  dispossessed smallint,
  sca smallint,
  gca smallint,
  second_assists smallint,
  sca_pass_live smallint,
  sca_pass_dead smallint,
  sca_take_on smallint,
  sca_shot smallint,
  sca_defensive smallint,
  tackles smallint,
  interceptions smallint,
  blocks smallint,
  clearances smallint,
  duels_won smallint,
  aerials smallint,
  aerials_won smallint,
  claims smallint,
  claims_won smallint,
  sweeper_actions smallint,
  distributions smallint,
  launches smallint,
  xt_total real,
  vaep_total real,
  vaep_offensive real,
  vaep_defensive real,
  pv_total real,
  pv_offensive real,
  pv_defensive real,
  pass_accuracy real,
  progressive_pass_distance real,
  carry_distance real,
  progressive_carry_distance real,
  xag real,
  xg_chain real,
  xg_buildup real,
  claim_rate real,
  launch_pct real,
  avg_pass_length real,
  distribution_accuracy real,
  updated_at timestamptz NOT NULL DEFAULT now(),
  PRIMARY KEY(season_id, match_id, player_id),
  FOREIGN KEY(match_id, season_id) REFERENCES core.matches(id, season_id) ON DELETE CASCADE
) PARTITION BY LIST(season_id );

CREATE INDEX player_match_advanced_player_id_season_id ON core.player_match_advanced(player_id, season_id);

CREATE TABLE core.pass_network_teams (
  season_id smallint NOT NULL,
  match_id integer NOT NULL,
  team_id integer NOT NULL REFERENCES core.teams,
  window_kind text,
  window_until_s real,
  centralization real,
  updated_at timestamptz NOT NULL DEFAULT now(),
  PRIMARY KEY(season_id, match_id, team_id),
  FOREIGN KEY(match_id, season_id) REFERENCES core.matches(id, season_id) ON DELETE CASCADE
) PARTITION BY LIST(season_id );

CREATE TABLE core.pass_network_nodes (
  season_id smallint NOT NULL,
  match_id integer NOT NULL,
  team_id integer REFERENCES core.teams,
  player_id integer NOT NULL REFERENCES core.players,
  avg_x real,
  avg_y real,
  passes smallint,
  passes_received smallint,
  degree smallint,
  strength smallint,
  betweenness real,
  clustering real,
  updated_at timestamptz NOT NULL DEFAULT now(),
  PRIMARY KEY(season_id, match_id, player_id),
  FOREIGN KEY(match_id, season_id) REFERENCES core.matches(id, season_id) ON DELETE CASCADE
) PARTITION BY LIST(season_id );

CREATE TABLE core.pass_network_edges (
  season_id smallint NOT NULL,
  match_id integer NOT NULL,
  team_id integer REFERENCES core.teams,
  from_player_id integer NOT NULL REFERENCES core.players,
  to_player_id integer NOT NULL REFERENCES core.players,
  passes smallint,
  updated_at timestamptz NOT NULL DEFAULT now(),
  PRIMARY KEY(season_id, match_id, from_player_id, to_player_id),
  FOREIGN KEY(match_id, season_id) REFERENCES core.matches(id, season_id) ON DELETE CASCADE
) PARTITION BY LIST(season_id );

CREATE TABLE core.team_heatmaps (
  season_id smallint NOT NULL,
  match_id integer NOT NULL,
  team_id integer NOT NULL REFERENCES core.teams,
  actions smallint,
  cells smallint[] CHECK(cells IS NULL OR (array_ndims(cells)=1 AND array_lower(cells, 1)=1 AND cardinality(cells)=192 AND array_position(cells, NULL) IS NULL AND 0<=ALL(cells))),
  updated_at timestamptz NOT NULL DEFAULT now(),
  PRIMARY KEY(season_id, match_id, team_id),
  FOREIGN KEY(match_id, season_id) REFERENCES core.matches(id, season_id) ON DELETE CASCADE
) PARTITION BY LIST(season_id );

CREATE TABLE core.player_heatmaps (
  season_id smallint NOT NULL,
  match_id integer NOT NULL,
  team_id integer REFERENCES core.teams,
  player_id integer NOT NULL REFERENCES core.players,
  actions smallint,
  cells smallint[] CHECK(cells IS NULL OR (array_ndims(cells)=1 AND array_lower(cells, 1)=1 AND cardinality(cells)=192 AND array_position(cells, NULL) IS NULL AND 0<=ALL(cells))),
  updated_at timestamptz NOT NULL DEFAULT now(),
  PRIMARY KEY(season_id, match_id, player_id),
  FOREIGN KEY(match_id, season_id) REFERENCES core.matches(id, season_id) ON DELETE CASCADE
) PARTITION BY LIST(season_id );

CREATE INDEX player_heatmaps_player_id_season_id ON core.player_heatmaps(player_id, season_id);

CREATE TABLE core.player_physical_match (
  season_id smallint NOT NULL,
  match_id integer NOT NULL,
  team_id integer REFERENCES core.teams,
  player_id integer NOT NULL REFERENCES core.players,
  distance_m real,
  hsr_m real,
  sprint_m real,
  sprints smallint,
  accelerations smallint,
  decelerations smallint,
  top_speed_kmh real,
  zone_walk_m real,
  zone_jog_m real,
  zone_run_m real,
  zone_hi_m real,
  zone_sprint_m real,
  source core.provider NOT NULL,
  as_of date NOT NULL,
  updated_at timestamptz NOT NULL DEFAULT now(),
  PRIMARY KEY(season_id, match_id, player_id),
  FOREIGN KEY(match_id, season_id) REFERENCES core.matches(id, season_id) ON DELETE CASCADE
) PARTITION BY LIST(season_id );
