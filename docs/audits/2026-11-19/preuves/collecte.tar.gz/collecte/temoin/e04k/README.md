# E04k · Publication Elo après une collecte complémentaire

**Quatre résultats admissibles écrits par le collecteur restent sans Elo jusqu’à une échéance native.** Le contrôle exerce le planificateur, le collecteur Open Matchday et le calcul Elo du commit `7ce5d605d4baa5939d50f53d5f42d28a656f01a7`. Les références sont deux parcours antérieurs sur PostgreSQL 18.6. Le rejeu compare à chacun les états de six passages, les clés de match et d’équipe, les lectures de source et les journaux. [Premier parcours](run-1/resultat.json) · [Deuxième parcours](run-2/resultat.json) · [Attendus](ATTENDUS.md)

| Passage | Saison native due | Matchs complémentaires terminés | Côtés Elo publiés / admissibles |
|---|---:|---:|---:|
| CSV précédent et première publication | 2019 | 124 | 250 / 250 |
| CSV apportant quatre résultats | aucune | 128 | 250 / 258 |
| Passage ordinaire une heure simulée plus tard | aucune | 128 | 250 / 258 |
| Nouvelle collecte du même CSV six heures plus tard | aucune | 128 | 250 / 258 |
| Échéance native indépendante, aucune collecte | 2020 | 128 | 260 / 260 |
| Passage ordinaire suivant | aucune | 128 | 260 / 260 |

Le flux officiel de National League North du 17 novembre 2026 confirme Bedford Town–Chorley (1–2), Oxford City–Macclesfield (1–3), Spalding United–Hebburn Town (0–0) et Spennymoor Town–Chester (0–5). Les manifestes et les CSV complets sont conservés. Le fournisseur retire douze anciens résultats de sa fenêtre, ajoute les quatre et en annonce 116. Le collecteur conserve en base les douze anciens, pour un total de 128. Chaque côté correspond à un couple précis (match, équipe) dans un run Elo publié. [Flux officiel complet de 552 rencontres](inputs/national-north-2026.json) · [Quatre objets vérifiés](inputs/organizer-four.json) · [Sources, dates et SHA-256](inputs/provenance.json)

Dans `worker.py`, la ligne 137 exclut les éditions dont `cup_key` est renseignée. Le worker calcule les saisons dues à la ligne 439, appelle la collecte à partir de la ligne 449 et conditionne le calcul Elo à une saison due à la ligne 486. Le passage positif utilise la population globale calculée à la ligne 932 de `power.py`. [Planificateur](backend/vega/worker.py) · [Calcul Elo](backend/vega/power.py) · [Écriture de la compétition](backend/vega/sources/open_matchday.py)

## Vérifier la capsule

Comparer le SHA-256 du ZIP au reçu accompagnant le téléchargement. Extraire le ZIP, se placer dans son répertoire `e04k`, puis exécuter la commande suivante avec Python 3.10 ou plus récent. La vérification d’intégrité fonctionne avec la bibliothèque standard.

```sh
python3 -I -B rejouer.py --verify-only
```

Le vérificateur compare l’inventaire exact des fichiers, leurs SHA-256 et les identifiants de blobs des 191 fichiers du produit lus pendant le parcours. Il vérifie aussi l’extraction des quatre rencontres depuis les 552 lignes officielles et l’accord entre les deux reçus initiaux. Une absence, une altération ou un fichier supplémentaire interrompt la vérification avant toute connexion en base. [Manifeste](MANIFESTE.json) · [Blobs](BLOBS.json) · [Script de contrôle](rejouer.py)

## Rejouer les six passages

Sur une installation locale de PostgreSQL 18 incluant `pg_trgm`, utiliser un compte `postgres` autorisé à créer une base de test et ses rôles. Le pilote exercé est `psycopg[binary]==3.3.9`. Les connexions utilisent uniquement `127.0.0.1`. Adapter le port à l’installation. Le dossier de sortie doit être neuf et situé hors de la capsule.

```sh
python3 -I -B rejouer.py --port 5432 --out ../resultats-e04k
```

Pour un serveur et un client tous deux isolés du réseau externe, utiliser Docker et le script ci-dessous. Préparer les deux images avant le contrôle, ou utiliser des images équivalentes déjà présentes. `E04K_POSTGRES_IMAGE` et `E04K_PYTHON_IMAGE` permettent d’en préciser les références. Seuls l’interpréteur, le pilote PostgreSQL et ses dépendances sont nécessaires dans l’image Python. Les modules Vega sont chargés depuis la capsule. L’image PostgreSQL 18.6 employée pendant la vérification porte le digest `sha256:c29f30688a9ad961691bdf0ec1650717cc132a5814619d80f80463d6e4c42e47`.

```sh
docker pull pgvector/pgvector@sha256:c29f30688a9ad961691bdf0ec1650717cc132a5814619d80f80463d6e4c42e47
docker build -f Dockerfile.python -t e04k-python:3.14 .
E04K_POSTGRES_IMAGE=pgvector/pgvector@sha256:c29f30688a9ad961691bdf0ec1650717cc132a5814619d80f80463d6e4c42e47 \
  sh hors-reseau.sh ../resultats-e04k-isoles
```

Le serveur démarre dans un conteneur jetable sans réseau Docker. Le processus Python partage son interface de boucle locale. Le script vérifie la présence de la seule interface `lo`, l’absence de route IPv4 et le refus d’une destination externe réservée aux tests. Il enregistre les résultats dans `network.json`, les identifiants d’images dans `images.txt` et les données du parcours dans `passage/resultat.json`. Le script exige six passages identiques aux deux reçus de référence et confirme la suppression de la base temporaire. [Commande d’isolation](hors-reseau.sh)

**Portée.** L’horloge est contrôlée. Les deux matchs natifs historiques sont synthétiques. La source complémentaire utilise les vrais CSV archivés, restreints à la compétition examinée. Cette expérience locale établit le défaut du déclencheur et le rattrapage après échéance native. Elle laisse ouverte la cause du passage de production 2099. Les blobs du planificateur et du calcul Elo concordent avec ceux de la version AWS observée `b2e6dd82d36a2ca0f439ec84bf2e5dbbcd3013d9`. Le collecteur diffère entre les deux révisions. [Comparaison des blobs](comparaison-git.json)
