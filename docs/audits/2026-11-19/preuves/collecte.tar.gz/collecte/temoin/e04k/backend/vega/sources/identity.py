"""One entity per real team, whatever the sources (design doc, « Match » and « Référentiel »).

A team first seen in a complementary cup source (OpenFootball, OpenLigaDB, International
Results, the open matchday feed) is the same team as a PitchAPI one when the rule below
names exactly one:
- national teams: the PitchAPI national team of the same normalized name, or of a name
  Vega knows for it (core.entity_names);
- clubs: the PitchAPI club of the same normalized name, or of a reviewed spelling
  (curated.CLUB_ALIASES), in the same country when both countries are known.

A national team the sources name otherwise than PitchAPI (the site's French names of the
Nations League, an older English spelling) is the PitchAPI team of its reviewed spelling
(NATION_SPELLINGS).

The Club World Cup's source writes a club with its country after it ("Al Hilal (KSA)"), and
so do its files of the other confederations' club competitions (Copa Libertadores and
Sudamericana, the CONCACAF Champions Cup, the CAF Champions League): the club is looked for
under the name alone, in that country, and under the spelling reviewed for it when PitchAPI
writes another (WORLD_CLUB_SPELLINGS, WORLD_CLUB_KEYS).

Archive teams (every archive season, the ones after 2020/2021 included) are keyed by their
country's French name and their own name. One is the PitchAPI club of that country
(core.countries.name_fr) that has the same name; when no club has it, the club that has the
same name once the club-form words at either end are set aside ("West Ham United FC" and
"West Ham United") — provided the archive's name carries every form word PitchAPI's does:
a word PitchAPI keeps tells two clubs apart ("Wimbledon", 1929-2003, and "Wimbledon FC"
are not "AFC Wimbledon"; "CA Bastia" is not "SC Bastia"). The few archive spellings that
only lack such a word are reviewed one by one (ARCHIVE_SPELLINGS). A European cup edition
names no country: its teams are matched the same way among every PitchAPI club. In every
case exactly one club must answer; two archive teams whose form words contradict ("Parma
AC", "Parma FC") are not both the same club, and a merge that would make a club play
itself (two teams of one match naming the same club) is refused.

The source's team is then merged into the PitchAPI one: its matches and their facts, its
provider ids and its names move, its spelling stays as a `source_spelling` name of that
source, and the source-only row stays as a pointer to the team it is (core.teams.merged_into,
094), with nothing left naming it. A team's matches keep the names their source
gave (core.matches.home_team_name, away_team_name, 034): the archive and cup reads show
them. A club known to a source under several spellings holds one key per spelling, one of
them current (core.provider_ids.is_current). A team no rule names stays as it is.

The row is kept rather than removed: removing it made PostgreSQL look for the team in every
table that names teams, most of them without an index on the team, minutes per team by 14
November 2026. Merges run by sets (CHUNK), each in its own savepoint; a set PostgreSQL
refuses (a deadlock, a pointer that would loop) is halved down to the refused pair, which
waits for a later run.

A cup-source match between two merged teams that PitchAPI also has (same two teams, within
a day) exists for the site once: PitchAPI-era reads leave cup editions out. The pair is
noted in ops.data_warnings (duplicate_match, and score_disagreement when the final
scores differ), the PitchAPI match id in the detail.
"""

import re
import unicodedata

from datetime import timedelta

import psycopg

from . import normalize

CUP_PROVIDERS = ("openfootball", "openligadb", "international_results", "open_matchday")
# The country of an archive key whose edition is a European cup.
EUROPE = "europe"
CHUNK = 100
# The longest a statement of the pass may run (run): on 14 November 2026 removing a set of
# a hundred teams was still running after five hours and held the daily pass behind it.
STATEMENT_LIMIT = "10min"
# Merges on (a merged team stays as a pointer, 094). Turned off, the pass only notes the
# duplicate matches.
MERGES = True


def scopes(now):
    return {"teams": timedelta(days=1)}


def _candidates(conn):
    """Source-only cup teams: (team, name, provider, national?, country of their editions)."""
    return conn.execute(
        """SELECT t.id, t.name, p.provider::text, bool_or(c.kind = 'international' OR cs.cup_key LIKE 'nations-results:%%'
                 OR cs.cup_key LIKE 'open-cups:euro:%%' OR cs.cup_key LIKE 'open-cups:world-cup-history:%%'
                 OR cs.cup_key LIKE 'openligadb:nations-league:%%') AS national,
             min(c.country_code) AS country
           FROM core.teams t
           JOIN core.provider_ids p ON p.entity_type = 'team' AND p.entity_id = t.id AND p.provider = ANY(%s::core.provider[])
           JOIN core.matches m ON t.id IN (m.home_team_id, m.away_team_id)
           JOIN core.competition_seasons cs ON cs.id = m.competition_season_id AND cs.cup_key IS NOT NULL
           JOIN core.competitions c ON c.id = cs.competition_id
           WHERE NOT EXISTS (SELECT 1 FROM core.provider_ids x WHERE x.entity_type = 'team' AND x.entity_id = t.id AND x.provider = 'pitchapi')
           GROUP BY t.id, t.name, p.provider ORDER BY t.id""",
        (list(CUP_PROVIDERS),),
    ).fetchall()


def _pitch_teams(conn):
    """PitchAPI teams by normalized name (official and known names), national or not."""
    out = {}
    for team, name, national, country in conn.execute(
        """SELECT t.id, n.name, coalesce(t.is_national, false), t.country_code FROM core.teams t
           JOIN core.provider_ids p ON p.entity_type = 'team' AND p.entity_id = t.id AND p.provider = 'pitchapi'
           CROSS JOIN LATERAL (SELECT t.name UNION SELECT e.name FROM core.entity_names e
             WHERE e.entity_type = 'team' AND e.entity_id = t.id AND e.kind <> 'source_spelling') n(name)"""
    ):
        out.setdefault((normalize(name), national), set()).add((team, country))
    return out


# A club's name followed by its country, as OpenFootball writes the teams of the Club World
# Cup and of the confederations' club competitions: "Real Madrid (ESP)".
COUNTRY_SUFFIX = re.compile(r"^(.*\S)\s*\(([A-Z]{3})\)$")
# The teams of the editions of 2021, 2022, 2023 and 2025 that PitchAPI names otherwise,
# reviewed one by one on 12 November 2026: the source's team named as the key is PitchAPI's
# club of that country named as the value ("Botafogo RJ" is Serie A's Botafogo, not
# Botafogo SP; "Al Ain FC" the Emirati club, not the Saudi one).
WORLD_CLUB_SPELLINGS = {
    "Al Ain FC (UAE)": "Al Ain", "Al Jazira Club (UAE)": "Al Jazira", "Botafogo RJ (BRA)": "Botafogo", "CF Monterrey (MEX)": "Monterrey",
    "CF Pachuca (MEX)": "Pachuca", "Chelsea FC (ENG)": "Chelsea", "Club León (MEX)": "León", "Flamengo RJ (BRA)": "Flamengo",
    "Fluminense RJ (BRA)": "Fluminense", "Mamelodi Sundowns (RSA)": "Mamelodi Sundowns FC", "RB Salzburg (AUT)": "Salzburg",
    "Seattle Sounders (USA)": "Seattle Sounders FC", "SL Benfica (POR)": "Benfica",
    # The confederations' club competitions of 2021 to 2026, reviewed one by one on 14 November
    # 2026 against the PitchAPI clubs of each country (a club PitchAPI does not hold has no entry:
    # Uruguay's, most of Africa's). "Universidad Técnica" is UTC Cajamarca, not ADT.
    "Atlanta United FC (USA)": "Atlanta United", "Houston Dynamo (USA)": "Houston Dynamo FC", "Los Angeles Galaxy (USA)": "LA Galaxy",
    "St. Louis City SC (USA)": "St. Louis City",
    "Atlético Goianiense (BRA)": "Atlético-GO", "Atlético Mineiro (BRA)": "Atlético-MG", "CA Mineiro (BRA)": "Atlético-MG", "Bahia BA (BRA)": "Bahia", "EC Bahia (BRA)": "Bahia", "Botafogo FR (BRA)": "Botafogo",
    "CA Paranaense (BRA)": "Athletico Paranaense", "CR Flamengo (BRA)": "Flamengo", "Ceará CE (BRA)": "Ceará",
    "Corinthians SP (BRA)": "Corinthians", "SC Corinthians Paulista (BRA)": "Corinthians", "Cruzeiro EC (BRA)": "Cruzeiro",
    "Cuiabá MT (BRA)": "Cuiabá", "Fluminense FC (BRA)": "Fluminense", "Fortaleza CE (BRA)": "Fortaleza", "Fortaleza EC (BRA)": "Fortaleza",
    "Goiás GO (BRA)": "Goiás", "Grêmio FBPA (BRA)": "Grêmio", "Grêmio Porto Alegre (BRA)": "Grêmio", "Mirassol FC (BRA)": "Mirassol",
    "Red Bull Bragantino (BRA)": "RB Bragantino", "SC Internacional (BRA)": "Internacional", "SE Palmeiras (BRA)": "Palmeiras",
    "Santos FC (BRA)": "Santos", "São Paulo FC (BRA)": "São Paulo", "Vasco da Gama RJ (BRA)": "Vasco da Gama", "Vitória BA (BRA)": "Vitória",
    "AA Argentinos Juniors (ARG)": "Argentinos Juniors", "Arsenal de Sarandí (ARG)": "Arsenal Sarandi", "Belgrano de Córdoba (ARG)": "Belgrano",
    "CA Boca Juniors (ARG)": "Boca Juniors", "CA Central Córdoba (ARG)": "Central Córdoba de Santiago", "CA Huracán (ARG)": "Huracán",
    "CA Lanús (ARG)": "Lanús", "CA Platense (ARG)": "Club Atlético Platense", "CA River Plate (ARG)": "River Plate",
    "CA Rosario Central (ARG)": "Rosario Central", "CA San Lorenzo de Almagro (ARG)": "San Lorenzo", "CA Talleres (ARG)": "Talleres",
    "Talleres de Córdoba (ARG)": "Talleres", "CA Vélez Sarsfield (ARG)": "Vélez Sarsfield", "CD Godoy Cruz Antonio Tomba (ARG)": "Godoy Cruz",
    "CS Independiente Rivadavia (ARG)": "Independiente Rivadavia", "Colón de Santa Fe (ARG)": "Colon", "Estudiantes de La Plata (ARG)": "Estudiantes",
    "Gimnasia de La Plata (ARG)": "Gimnasia LP", "Unión de Santa Fe (ARG)": "Unión",
    "AD Tarma (PER)": "ADT", "Ayacucho FC (PER)": "Ayacucho", "CS Cristal (PER)": "Sporting Cristal", "CSD Sport Huancayo (PER)": "Sport Huancayo",
    "Club Alianza Lima (PER)": "Alianza Lima", "Club Universitario de Deportes (PER)": "Universitario", "Universitario de Deportes (PER)": "Universitario",
    "Cusco FC (PER)": "Cusco", "FBC Melgar (PER)": "Melgar", "Mannucci (PER)": "Carlos Mannucci", "Universidad Cesar Vallejo (PER)": "César Vallejo",
    "Universidad Técnica (PER)": "UTC Cajamarca",
    "Alianza FC (COL)": "Alianza", "Atlético Junior (COL)": "Junior", "CDP Junior FC (COL)": "Junior", "CA Bucaramanga (COL)": "Atlético Bucaramanga",
    "CD Independiente Medellín (COL)": "Independiente Medellín", "CD Tolima (COL)": "Deportes Tolima", "CDC Atlético Nacional (COL)": "Atlético Nacional",
    "Millonarios FC (COL)": "Millonarios", "Rionegro Águilas (COL)": "Águilas Doradas", "Santa Fe (COL)": "Independiente Santa Fe",
    "Atlas Guadalajara (MEX)": "Atlas", "Deportivo Guadalajara (MEX)": "Chivas", "Deportivo Toluca (MEX)": "Toluca", "Pumas UNAM (MEX)": "Pumas",
    "UANL Tigres (MEX)": "Tigres",
    "Barcelona SC (ECU)": "Barcelona", "CAR Independiente del Valle (ECU)": "Independiente Valle", "Independiente del Valle (ECU)": "Independiente Valle",
    "CSCyD El Nacional (ECU)": "El Nacional", "Delfín SC (ECU)": "Delfín", "LDU de Quito (ECU)": "LDU Quito", "Orense SC (ECU)": "Orense",
    "SD Aucas (ECU)": "Aucas",
    "CD Cobresal (CHI)": "Cobresal", "CD Coquimbo Unido (CHI)": "Coquimbo Unido", "CD Huachipato (CHI)": "Huachipato", "CD Iquique (CHI)": "Deportes Iquique",
    "CD Nublense (CHI)": "Ñublense", "CD Palestino (CHI)": "Palestino", "CD Universidad Católica (CHI)": "Universidad Católica",
    "CF Universidad de Chile (CHI)": "Universidad de Chile", "CSD Colo-Colo (CHI)": "Colo Colo", "O'Higgins FC (CHI)": "O'Higgins",
    "CD Blooming (BOL)": "Blooming", "CD Guabirá (BOL)": "Guabirá", "Club Always Ready (BOL)": "Always Ready", "Club Aurora (BOL)": "Aurora",
    "Club Bolívar (BOL)": "Bolívar", "Club Nacional Potosí (BOL)": "Nacional Potosí", "Club The Strongest (BOL)": "The Strongest",
    "Independiente Petrolero (BOL)": "Independiente",
    "Carabobo FC (VEN)": "Carabobo", "Caracas FC (VEN)": "Caracas", "Deportivo La Guaira FC (VEN)": "Deportivo La Guaira",
    "Deportivo Táchira FC (VEN)": "Deportivo Táchira", "Metropolitanos FC (VEN)": "Metropolitanos", "Monagas SC (VEN)": "Monagas",
    "Portuguesa FC (VEN)": "Portuguesa", "Universidad Central de Venezuela FC (VEN)": "UCV", "Zamora FC (VEN)": "Zamora",
    "Club Cerro Porteño (PAR)": "Cerro Porteño", "Club Libertad Asuncion (PAR)": "Libertad", "Club Nacional (PAR)": "Nacional Asunción",
    "Club Olimpia (PAR)": "Olimpia", "Olimpia Asuncion (PAR)": "Olimpia", "General Caballero DJLM (PAR)": "General Caballero JLM",
    "Guaraní (PAR)": "Club Guaraní",
    "Cavalry FC (CAN)": "Cavalry", "Forge FC (CAN)": "Forge",
}
# PitchAPI has two clubs named Al Hilal in Saudi Arabia, and two named Al Ittihad: the club
# and its women's team. The tournament's is the club, named here by its PitchAPI key.
WORLD_CLUB_KEYS = {"Al Hilal (KSA)": "t_2r8ytM", "Al Ittihad (KSA)": "t_4BG5Jn",
                   # The three Canadian MLS clubs, which PitchAPI files under the United States (CAN in the
                   # source): "Toronto FC" is not the Canadian league's Inter Toronto, nor "Vancouver
                   # Whitecaps" its Vancouver FC.
                   "CF Montréal (CAN)": "t_0vjCk0", "Toronto FC (CAN)": "t_1TFG85", "Vancouver Whitecaps (CAN)": "t_2CuHdk"}


# National teams the complementary sources name otherwise than PitchAPI does, reviewed on
# 12 November 2026 against PitchAPI's 54 national teams: the site's French names (the
# Nations League editions) and OpenFootball's spellings (the Euros, the World Cups). A
# national team PitchAPI does not hold (Italy, Greece, Ukraine…) has no entry here: its
# twins join each other (NATION_TWINS, nation_twins). The teams of states that no longer
# exist stay apart.
NATION_SPELLINGS = {
    "Allemagne": "Germany", "Angleterre": "England", "Autriche": "Austria", "Belgique": "Belgium", "Bosnie-Herzégovine": "Bosnia and Herzegovina",
    "Croatie": "Croatia", "Danemark": "Denmark", "Écosse": "Scotland", "Espagne": "Spain", "Norvège": "Norway", "Pays-Bas": "Netherlands",
    "Pays de Galles": "Wales", "Pologne": "Poland", "Serbie": "Serbia", "Suède": "Sweden", "Suisse": "Switzerland", "Tchéquie": "Czechia",
    "Turquie": "Turkiye",
    "Bosnia & Herzegovina": "Bosnia and Herzegovina", "Bosnia-Herzegovina": "Bosnia and Herzegovina", "Côte d'Ivoire": "Ivory Coast",
    "Czech Republic": "Czechia", "Turkey": "Turkiye", "United States": "USA",
}

# National teams PitchAPI does not hold, which one source names in French (the Nations League
# editions of OpenLigaDB and International Results) and another in English (OpenFootball's
# World Cups and Euros, International Results' other tournaments), reviewed on 16 November
# 2026: the French name is the English one's twin. A French name with no English twin in the
# base yet keeps its row until one comes.
NATION_TWINS = {
    "Albanie": "Albania", "Andorre": "Andorra", "Arménie": "Armenia", "Azerbaïdjan": "Azerbaijan", "Biélorussie": "Belarus",
    "Bulgarie": "Bulgaria", "Chypre": "Cyprus", "Estonie": "Estonia", "Finlande": "Finland", "Géorgie": "Georgia",
    "Grèce": "Greece", "Hongrie": "Hungary", "Îles Féroé": "Faroe Islands", "Irlande": "Ireland", "Irlande du Nord": "Northern Ireland",
    "Islande": "Iceland", "Israël": "Israel", "Italie": "Italy", "Lettonie": "Latvia", "Lituanie": "Lithuania",
    "Macédoine du Nord": "North Macedonia", "Malte": "Malta", "Moldavie": "Moldova", "Monténégro": "Montenegro",
    "Roumanie": "Romania", "Russie": "Russia", "Saint-Marin": "San Marino", "Slovaquie": "Slovakia", "Slovénie": "Slovenia",
}


def nation_twins(rows):
    """Merges of the source-only national teams that are one team: those whose name, or the
    English name of their French one (NATION_TWINS), is the same. `rows`: (team, name,
    provider) of source-only national teams no PitchAPI team claims. Returns (team, the twin
    it joins, provider, name): the twin named in English stays, else the oldest row."""
    groups = {}
    for team, name, provider in rows:
        english = NATION_TWINS.get(name, name)
        groups.setdefault(normalize(english), []).append((team, name, provider, name == english))
    found = []
    for members in groups.values():
        teams = {team for team, *_ in members}
        if len(teams) < 2:
            continue
        keep = min(members, key=lambda m: (not m[3], m[0]))[0]
        seen = set()
        for team, name, provider, _ in sorted(members):
            if team != keep and team not in seen:
                seen.add(team)
                found.append((team, keep, provider, name))
    return found


def _reviewed_clubs(conn):
    """The PitchAPI team of each key of WORLD_CLUB_KEYS."""
    return dict(conn.execute(
        "SELECT provider_key, entity_id FROM core.provider_ids WHERE entity_type = 'team' AND provider = 'pitchapi' AND provider_key = ANY(%s)",
        (sorted(set(WORLD_CLUB_KEYS.values())),),
    ).fetchall())


def match_team(pitch, name, national, country, reviewed=None):
    from .curated import CLUB_ALIASES

    spelling = None
    if not national:
        if name in WORLD_CLUB_KEYS:
            return (reviewed or {}).get(WORLD_CLUB_KEYS[name])
        suffix = COUNTRY_SUFFIX.match(name or "")
        if suffix:
            spelling, name, country = WORLD_CLUB_SPELLINGS.get(name), suffix.group(1), suffix.group(2)
    names = {normalize(name)}
    if spelling:
        names.add(normalize(spelling))
    if national and name in NATION_SPELLINGS:
        names.add(normalize(NATION_SPELLINGS[name]))
    if not national and name in CLUB_ALIASES:
        names.add(normalize(CLUB_ALIASES[name]))
    found = set()
    for n in names:
        for team, team_country in pitch.get((n, national), ()):
            if national or not country or not team_country or team_country == country:
                found.add(team)
    return found.pop() if len(found) == 1 else None


def spelling_row(conn, team, provider, name):
    if name and name.strip():
        conn.execute(
            """INSERT INTO core.entity_names(entity_type, entity_id, name, normalized, kind, source)
               VALUES ('team', %s, %s, lower(%s), 'source_spelling', %s) ON CONFLICT DO NOTHING""",
            (team, name, name, provider),
        )


# Club-form words set aside at either end of a club's name, never inside it.
CLUB_FORMS = {"fc", "afc", "cf", "sc", "ac", "ssc", "cd", "ud", "sv", "fk", "sk", "bk", "if", "as", "us", "rc", "ca", "cfc", "club",
              "calcio", "football", "futbol", "fussball", "1"}


def club_parts(name):
    """A club's name without the club-form words at either end, and those words.

    The ordinal of "1. FC Köln" says nothing of the club's form, and "FK" is how some
    sources write "FC": neither can contradict.
    """
    folded = unicodedata.normalize("NFKD", name or "").encode("ascii", "ignore").decode().lower()
    words = [w for w in re.split(r"[^a-z0-9]+", folded) if w]
    forms = set()
    while words and words[0] in CLUB_FORMS:
        forms.add(words.pop(0))
    while words and words[-1] in CLUB_FORMS:
        forms.add(words.pop())
    forms.discard("1")
    return "".join(words), frozenset("fc" if form == "fk" else form for form in forms)


def club_core(name):
    return club_parts(name)[0]


# Archive spellings that only lack the form word of PitchAPI's name, reviewed one by one on
# the 10 November 2026 list. Unreviewed, the word decides: "Beveren" (1995-2006), "AD Ceuta"
# (2000-2010) and "Erzurumspor" (1999-2000) are older clubs than "SK Beveren", "AD Ceuta FC"
# and "Erzurumspor FK".
ARCHIVE_SPELLINGS = {"Porto": "FC Porto", "Dundee": "Dundee FC", "Panserraikos": "Panserraikos FC",
                     "Crvena Zvezda": "FK Crvena Zvezda", "Houston Dynamo": "Houston Dynamo FC"}


def _archive_candidates(conn):
    """Archive-only teams: (team, name, normalized country of their key)."""
    rows = conn.execute(
        """SELECT t.id, t.name, p.provider_key FROM core.teams t
           JOIN core.provider_ids p ON p.entity_type = 'team' AND p.entity_id = t.id AND p.provider = 'vega' AND p.provider_key LIKE 'archive:%%'
           WHERE NOT EXISTS (SELECT 1 FROM core.provider_ids x WHERE x.entity_type = 'team' AND x.entity_id = t.id AND x.provider = 'pitchapi')
           ORDER BY t.id, p.provider_key"""
    ).fetchall()
    # The key keeps the spaces of the country's name ("pays bas"); the clubs are indexed without.
    return [(team, name, normalize(key.split(":")[1])) for team, name, key in rows if key.count(":") == 2]


def _pitch_clubs(conn):
    """PitchAPI clubs by normalized name, and by core name with the club forms of each of
    their names: under their country's normalized French name, and under None (every club)."""
    exact, core = {}, {}
    for team, name, country in conn.execute(
        """SELECT t.id, n.name, c.name_fr FROM core.teams t
           JOIN core.provider_ids p ON p.entity_type = 'team' AND p.entity_id = t.id AND p.provider = 'pitchapi'
           LEFT JOIN core.countries c ON c.code = t.country_code
           CROSS JOIN LATERAL (SELECT t.name UNION SELECT e.name FROM core.entity_names e
             WHERE e.entity_type = 'team' AND e.entity_id = t.id AND e.kind <> 'source_spelling') n(name)
           WHERE t.is_national IS NOT TRUE"""
    ):
        key, forms = club_parts(name)
        for where in {normalize(country) or None, None}:
            exact.setdefault((where, normalize(name)), set()).add(team)
            core.setdefault((where, key), {}).setdefault(team, set()).add(forms)
    return exact, core


def _archive_match(clubs, name, country):
    """(club, found by its exact name?) for an archive team, or (None, False)."""
    if not country:
        return None, False
    exact, core = clubs
    where = None if country == EUROPE else country
    found = exact.get((where, normalize(name)), ()) or exact.get((where, normalize(ARCHIVE_SPELLINGS.get(name, name))), ())
    if found:
        return (next(iter(found)), True) if len(found) == 1 else (None, False)
    key, forms = club_parts(name)
    found = core.get((where, key), {}) if key else {}
    if len(found) != 1:
        return None, False
    ((team, known),) = found.items()
    return (team, False) if all(other <= forms for other in known) else (None, False)


def match_archive_team(clubs, name, country):
    return _archive_match(clubs, name, country)[0]


def pairs(conn):
    """Every merge the rules name, as (source-only team, PitchAPI team, provider, spelling),
    and the number of source-only teams looked at."""
    pitch, reviewed = _pitch_teams(conn), _reviewed_clubs(conn)
    found, seen, apart = {}, set(), []
    for team, name, provider, national, country in _candidates(conn):
        seen.add(team)
        keep = match_team(pitch, name, bool(national), country, reviewed)
        if keep is not None:
            found.setdefault(team, (keep, provider, name))
        elif national:
            apart.append((team, name, provider))
    # National teams PitchAPI does not hold: twins of two sources are one team.
    for team, keep, provider, name in nation_twins([row for row in apart if row[0] not in found]):
        if keep not in found:
            found.setdefault(team, (keep, provider, name))
    clubs = _pitch_clubs(conn)
    by_club = {}
    for team, name, country in _archive_candidates(conn):
        seen.add(team)
        if team in found:
            continue
        keep, exact = _archive_match(clubs, name, country)
        if keep is not None:
            found[team] = (keep, "vega", name)
            by_club.setdefault(keep, []).append((team, club_parts(name)[1], exact))
    # A club PitchAPI names without a form ("Parma") cannot be both "Parma AC" and "Parma FC";
    # "Sassuolo Calcio" and "US Sassuolo Calcio" say nothing against each other.
    for teams in by_club.values():
        known = {forms for _, forms, _ in teams}
        if any(not (a <= b or b <= a) for a in known for b in known):
            for team, forms, exact in teams:
                if forms and not exact:
                    del found[team]
    drops = list(found)
    refused = set()
    if drops:
        for home, away in conn.execute(
            """WITH m AS (SELECT * FROM unnest(%s::int[], %s::int[]) m(team, club)),
                 x AS (SELECT team, club FROM m UNION SELECT club, club FROM m)
               SELECT DISTINCT a.team, b.team FROM core.matches mm
               JOIN x a ON a.team = mm.home_team_id JOIN x b ON b.team = mm.away_team_id WHERE a.club = b.club""",
            (drops, [found[team][0] for team in drops]),
        ):
            refused.update((home, away))
    return [(team, *found[team]) for team in drops if team not in refused], len(seen)


def team_columns(conn, teams):
    """The core columns naming a team in which one of these teams has rows."""
    columns = conn.execute(
        """SELECT c.conrelid::regclass::text, a.attname FROM pg_constraint c
           JOIN pg_attribute a ON a.attrelid = c.conrelid AND a.attnum = ANY(c.conkey)
           WHERE c.contype = 'f' AND c.confrelid = 'core.teams'::regclass AND c.conparentid = 0
             AND c.conrelid::regclass::text LIKE 'core.%%' ORDER BY 1, 2"""
    ).fetchall()
    return [
        (table, column)
        for table, column in columns
        if conn.execute(f"SELECT EXISTS (SELECT 1 FROM {table} WHERE {column} = ANY(%s))", (teams,)).fetchone()[0]
    ]


def merge_teams(conn, found, columns):
    """Move every fact of each source-only team onto its PitchAPI team, then remove it."""
    drops, keeps = [row[0] for row in found], [row[1] for row in found]
    for table, column in columns:
        conn.execute(
            f"""UPDATE {table} x SET {column} = m.kept FROM unnest(%s::int[], %s::int[]) m(gone, kept)
                WHERE x.{column} = m.gone""",
            (drops, keeps),
        )
    # One current key per provider and team: a moved key stays current only where the
    # PitchAPI team has none of that provider yet.
    conn.execute(
        """WITH moved AS (
             SELECT p.provider, p.provider_key, m.kept,
               row_number() OVER (PARTITION BY m.kept, p.provider ORDER BY p.is_current DESC, p.provider_key) AS n
             FROM core.provider_ids p JOIN unnest(%s::int[], %s::int[]) m(gone, kept) ON p.entity_id = m.gone
             WHERE p.entity_type = 'team'
           )
           UPDATE core.provider_ids p SET entity_id = moved.kept,
             is_current = moved.n = 1 AND NOT EXISTS (SELECT 1 FROM core.provider_ids k WHERE k.entity_type = 'team'
               AND k.entity_id = moved.kept AND k.provider = moved.provider AND k.is_current)
           FROM moved WHERE p.entity_type = 'team' AND p.provider = moved.provider AND p.provider_key = moved.provider_key""",
        (drops, keeps),
    )
    conn.execute(
        """INSERT INTO core.entity_names(entity_type, entity_id, name, normalized, kind, source)
           SELECT 'team', m.kept, e.name, e.normalized, e.kind, e.source
           FROM unnest(%s::int[], %s::int[]) m(gone, kept)
           JOIN core.entity_names e ON e.entity_type = 'team' AND e.entity_id = m.gone
           ON CONFLICT DO NOTHING""",
        (drops, keeps),
    )
    conn.execute("DELETE FROM core.entity_names WHERE entity_type = 'team' AND entity_id = ANY(%s)", (drops,))
    conn.execute(
        """INSERT INTO core.entity_names(entity_type, entity_id, name, normalized, kind, source)
           SELECT 'team', m.kept, m.name, lower(m.name), 'source_spelling', m.provider::core.provider
           FROM unnest(%s::int[], %s::text[], %s::text[]) m(kept, name, provider) WHERE btrim(m.name) <> ''
           ON CONFLICT DO NOTHING""",
        (keeps, [row[3] or "" for row in found], [row[2] for row in found]),
    )
    # A pointer, never a removal (094); a team merged before into one merged now points to
    # the team that stays, so a pointer never leads to another.
    conn.execute(
        """UPDATE core.teams t SET merged_into = m.kept, updated_at = now()
           FROM unnest(%s::int[], %s::int[]) m(gone, kept)
           WHERE t.id = m.gone OR t.merged_into = m.gone""",
        (drops, keeps),
    )


def _merge(conn, found, columns):
    try:
        with conn.transaction():
            merge_teams(conn, found, columns)
        return len(found)
    except (psycopg.errors.IntegrityError, psycopg.errors.DeadlockDetected):
        if len(found) == 1:
            return 0
        half = len(found) // 2
        return _merge(conn, found[:half], columns) + _merge(conn, found[half:], columns)


def duplicates(conn):
    """Cup-source matches PitchAPI also has, noted once in ops.data_warnings."""
    rows = conn.execute(
        """SELECT c.id, p.id, (SELECT k.provider_key FROM core.provider_ids k WHERE k.entity_type = 'match' AND k.entity_id = p.id
             AND k.provider = 'pitchapi' AND k.is_current), c.home_score, c.away_score,
             CASE WHEN p.home_team_id = c.home_team_id THEN p.home_score ELSE p.away_score END,
             CASE WHEN p.home_team_id = c.home_team_id THEN p.away_score ELSE p.home_score END
           FROM core.matches c
           JOIN core.competition_seasons cc ON cc.id = c.competition_season_id AND cc.cup_key IS NOT NULL
           JOIN core.matches p ON p.source = 'pitchapi'
             AND ((p.home_team_id = c.home_team_id AND p.away_team_id = c.away_team_id)
               OR (p.home_team_id = c.away_team_id AND p.away_team_id = c.home_team_id))
             AND p.match_date BETWEEN c.match_date - 1 AND c.match_date + 1
           WHERE c.source = ANY(%s::core.provider[])""",
        (list(CUP_PROVIDERS),),
    ).fetchall()
    for cup, _, public, ch, ca, ph, pa in rows:
        conn.execute(
            """INSERT INTO ops.data_warnings(match_id, kind, detail) VALUES (%s, 'duplicate_match', %s)
               ON CONFLICT (match_id, kind) DO UPDATE SET detail = EXCLUDED.detail""",
            (cup, public),
        )
        if None not in (ch, ca, ph, pa) and (ch, ca) != (ph, pa):
            conn.execute(
                """INSERT INTO ops.data_warnings(match_id, kind, detail) VALUES (%s, 'score_disagreement', %s)
                   ON CONFLICT (match_id, kind) DO UPDATE SET detail = EXCLUDED.detail""",
                (cup, f"{public} {ph}-{pa} / {ch}-{ca}"),
            )
    return len(rows)


def run(conn, get, scope, now):
    if scope != "teams":
        raise ValueError(scope)
    # No statement of the pass may run longer than STATEMENT_LIMIT: past it the pass fails,
    # is rolled back and retried later, and the daily pass that runs it goes on.
    conn.execute(f"SET LOCAL statement_timeout = '{STATEMENT_LIMIT}'")
    found, candidates = pairs(conn)
    if not MERGES:
        duplicates(conn)
        return 0, candidates
    columns = team_columns(conn, [row[0] for row in found]) if found else []
    merged = sum(_merge(conn, found[start:start + CHUNK], columns) for start in range(0, len(found), CHUNK))
    duplicates(conn)
    return merged, candidates - merged
