"""Reproduce E04k on a new database in a local PostgreSQL 18 instance."""
import argparse
import contextlib
from datetime import datetime, timedelta, timezone
from hashlib import sha256
import io
import json
from pathlib import Path
import sys
from types import SimpleNamespace
from unittest.mock import patch
from uuid import uuid4

SHA = '7ce5d605d4baa5939d50f53d5f42d28a656f01a7'
FOLDER = 'ENG_6_national-league-north'
ROOT = Path(__file__).resolve().parent
INPUT = ROOT / 'inputs'
sys.dont_write_bytecode = True

def encode(obj):
    return (json.dumps(obj, ensure_ascii=False, indent=2, default=str) + '\n')

def digest(rows):
    return sha256(encode(rows).encode()).hexdigest()

def native(db, store, year):
    """Unplayed native seasons do not participate. This single old finished match makes one due."""
    season = store(db).season(f'{year}/{year+1}')
    comp = db.execute('INSERT INTO core.competitions(name) VALUES (%s) RETURNING id', (f'Native control {year}',)).fetchone()[0]
    edition = db.execute('INSERT INTO core.competition_seasons(competition_id,season_id,native_label) VALUES (%s,%s,%s) RETURNING id',
                         (comp, season, f'{year}/{year+1}')).fetchone()[0]
    a, b = [db.execute('INSERT INTO core.teams(name) VALUES (%s) RETURNING id', (f'Control {year} {side}',)).fetchone()[0] for side in ['A','B']]
    when = datetime(year, 10, 1, 12, tzinfo=timezone.utc)
    db.execute("""INSERT INTO core.matches(competition_season_id,season_id,source,status,home_team_id,away_team_id,
                  home_score,away_score,match_date,kickoff_at) VALUES (%s,%s,'pitchapi','finished',%s,%s,1,0,%s,%s)""",
               (edition, season, a, b, when.date(), when))
    return season

def run(db, collect, calc, proof):
    from vega import power, sources, worker
    from vega.sources import identity, open_matchday
    from vega.store import Store
    # Whitelisted, recorded HTTP responses. The production source adapter, scheduler and writer run unchanged.
    origin = open_matchday.RAW
    clock = datetime(2026, 11, 17, 18, tzinfo=timezone.utc)
    stage = 'old'
    http = []
    def get(url, *, as_text=False):
        expected = {origin + 'build_summary.json': 'build_summary.json',
                    **{origin + 'data/' + FOLDER + '/' + f: f for f in ('fixtures_2627.csv', 'results_2627.csv')}}
        file = expected[url]
        raw = (INPUT / stage / file).read_bytes()
        http.append({'stage':stage,'file':file,'sha256':sha256(raw).hexdigest(),'at':clock})
        if as_text:
            return raw.decode()
        body = json.loads(raw)
        body['leagues'] = [row for row in body['leagues'] if row['folder'] == 'data/' + FOLDER]
        assert len(body['leagues']) == 1
        return body
    official = json.loads((INPUT / 'organizer-four.json').read_text())
    crosswalk = {'Bedford Town':'Bedford','Spennymoor Town':'Spennymoor'}
    expected = {}
    for row in official:
        a = row['attributes']
        assert a['competitionID'] == 373 and a['matchPeriod'] == 'FullTime'
        day = a['kickOffDateUTC'][:10]
        assert day == '2026-11-17'
        h, v = (a[key]['name'] for key in ('homeTeam','awayTeam'))
        expected[(day,crosswalk.get(h,h),crosswalk.get(v,v))] = (a['homeTeam']['score'],a['awayTeam']['score'],row['id'])
    assert len(expected) == 4
    object_worker = worker.Worker(Store(collect), SimpleNamespace(), clock=lambda:clock, calc_conn=calc, source_get=get)
    def snapshot():
        query = db.execute
        merge = {team:keep for team,keep,*_ in identity.pairs(db)[0]}
        admitted = power.elo_matches(power.merged_rows(query(power.ELO_MATCHES).fetchall(), merge))
        pairs = {(r[0], side) for r in admitted for side in r[3:5]}
        stored = query('SELECT match_id,team_id,run_id FROM agg.team_elo ORDER BY 1,2').fetchall()
        pubs = query("SELECT id,status,matches FROM agg.power_runs WHERE kind='elo' ORDER BY id").fetchall()
        byid = {p[0] for p in pubs if p[1]=='published'}
        published = {(m,t) for m,t,r in stored if r in byid}
        finished = query("""SELECT m.id,m.match_date::text,m.home_team_name,m.away_team_name,m.home_score,m.away_score,m.home_team_id,m.away_team_id
          FROM core.matches m WHERE source='open_matchday' AND status='finished' ORDER BY m.id""").fetchall()
        target = []
        for mid,day,h,v,hs,vs,hid,vid in finished:
            if (day,h,v) not in expected:
                continue
            ehs,evs,match_id = expected[(day,h,v)]
            assert (hs,vs) == (ehs,evs)
            target.append({'id':mid, 'organizer_id':match_id, 'date':day, 'home':h, 'away':v, 'score':[hs,vs],
                           'eligible_sides':len({(mid,hid),(mid,vid)} & pairs),'published_sides':len({(mid,hid),(mid,vid)} & published)})
        missing = pairs - published
        return {'at':clock,'due':worker.due_seasons(calc,clock),'sources':query('SELECT source::text,scope,status,rows_written,unmatched,last_success_at FROM ops.source_runs ORDER BY 1,2').fetchall(),
                'last_levels':query("SELECT cohort_definition,status FROM agg.calc_runs WHERE kind='levels' ORDER BY id").fetchall(),
                'native_finished':query("SELECT count(*) FROM core.matches WHERE source='pitchapi' AND status='finished'").fetchone()[0],
                'supplemental_finished':len(finished),'supplemental_ids': [r[0] for r in finished], 'four':target,
                'eligible_matches':len(admitted),'eligible_sides':len(pairs),'published_sides':len(published),'extra_sides':len(published-pairs),'missing_sides':len(missing),
                'missing_keys':sorted(missing),'elo_runs':pubs,'stored_key_sha256':digest(stored)}
    proof['passes'] = []
    proof['fetches'] = http
    # Only the scope catalogue is filtered. Worker.daily still calls sources.run_due, its due function, and the unchanged writer.
    def daily(label):
        before = snapshot()
        calls_before = len(http)
        out = io.StringIO()
        with contextlib.redirect_stdout(out), patch.object(sources,'adapters',lambda:{'open_matchday':open_matchday}):
            selected = object_worker.daily()
        after = snapshot()
        item = dict(label=label, before=before, worker_return=selected, after=after,
                    fetch_count=len(http)-calls_before, stdout=out.getvalue())
        proof['passes'].append(item)
        print(label, 'seasons', selected,'Elo', after['elo_runs'], 'missing', after['missing_sides'], flush=True)
        assert 'error=' not in item['stdout'],item['stdout']
        return item
    with db.transaction():
        first = native(db, Store, 2019)
    baseline = daily('baseline_native_plus_previous_source')
    first_result = baseline['after']
    assert baseline['worker_return'] == [first] and first_result['due'] == []
    assert first_result['supplemental_finished'] == 124 and first_result['eligible_matches'] == 125 and first_result['published_sides'] == 250
    assert not first_result['four'] and first_result['missing_sides'] == 0
    stage = 'current'
    clock += timedelta(hours=14)
    changed = daily('complementary_change_only')
    clock += timedelta(hours=1)
    ordinary = daily('ordinary_no_native_due')
    clock += timedelta(hours=6)
    reread = daily('same_csv_read_again_no_native_due')
    assert [c['fetch_count'] for c in (baseline,changed,ordinary,reread)] == [3,3,0,3]
    for case in (changed,ordinary,reread):
        c = case['after']
        assert case['before']['due'] == case['worker_return'] == c['due'] == []
        assert c['sources'][0][2] == 'ok' and c['sources'][0][4] == 0
        assert c['supplemental_finished'] == 128 and set(first_result['supplemental_ids']) <= set(c['supplemental_ids'])
        assert c['eligible_matches'] == 129 and c['missing_sides'] == 8 and c['extra_sides'] == 0
        assert c['elo_runs'] == first_result['elo_runs'] and c['stored_key_sha256'] == first_result['stored_key_sha256']
        assert len(c['four']) == 4 and all((r['eligible_sides'],r['published_sides']) == (2,0) for r in c['four'])
    with db.transaction():
        second = native(db, Store, 2020)
    clock += timedelta(hours=1)
    positive = daily('second_native_deadline')
    c = positive['after']
    assert positive['fetch_count'] == 0 and positive['before']['due'] == positive['worker_return'] == [second] and c['due'] == []
    assert c['eligible_matches'] == 130 and c['published_sides'] == 260 and c['missing_sides'] == c['extra_sides'] == 0
    assert len(c['four'])==4 and all((r['eligible_sides'],r['published_sides']) == (2,2) for r in c['four'])
    assert len(c['elo_runs']) == 2 and c['elo_runs'][0][1] == 'superseded' and c['elo_runs'][1][1:] == ('published',130)
    clock += timedelta(hours=1)
    settled = daily('ordinary_after_catchup')
    assert settled['fetch_count'] == 0 and settled['worker_return'] == [] and settled['after']['elo_runs'] == c['elo_runs']
    assert settled['after']['stored_key_sha256'] == c['stored_key_sha256']
    proof['verdict'] = 'Isolated supplemental trigger fails; independent native deadline publishes all eligible sides.'

def require(condition, message):
    if not condition:
        raise SystemExit(message)

def check_package():
    """Check immutable inventory and source/review provenance before accessing PostgreSQL."""
    expected = json.loads((ROOT/'MANIFESTE.json').read_bytes())
    seen = {}
    for p in sorted(ROOT.rglob('*')):
        rel = p.relative_to(ROOT).as_posix()
        require(not p.is_symlink(), f'refused symlink: {rel}')
        if p.is_file() and rel != 'MANIFESTE.json':
            seen[rel] = sha256(p.read_bytes()).hexdigest()
    require(set(expected)==set(seen), f'inventory mismatch: {sorted(set(expected)^set(seen))}')
    for rel, wanted in expected.items():
        require(seen[rel]==wanted, f'SHA-256 mismatch: {rel}')
    blobs = json.loads((ROOT/'BLOBS.json').read_bytes())
    require(blobs['commit']==SHA, 'unexpected source revision')
    require(set(blobs['files'])=={p for p in expected if p.startswith('backend/')}, 'source inventory mismatch')
    from hashlib import sha1
    for name, facts in blobs['files'].items():
        raw = (ROOT/name).read_bytes()
        header = b'blob ' + str(len(raw)).encode() + b'\0'
        require(sha1(header+raw).hexdigest()==facts['blob'] and seen[name]==facts['sha256'] and len(raw)==facts['bytes'],
                f'source blob mismatch: {name}')
    prov = json.loads((INPUT/'provenance.json').read_bytes())
    for p in prov:
        require(seen['inputs/'+p['local']]==p.get('excerpt_sha256',p['sha256']), f"source receipt mismatch: {p['local']}")
    organizer = prov[-1]
    raw = (INPUT/organizer['file']).read_bytes()
    require(sha256(raw).hexdigest()==organizer['sha256'],'full organizer file mismatch')
    body = json.loads(raw)
    require(body['meta']['count']==len(body['data'])==body['meta']['totalCount']==552,'organizer count mismatch')
    selected = [m for m in body['data'] if m['attributes']['kickOffDateUTC'].startswith('2026-11-17')
                and m['attributes']['matchPeriod']=='FullTime']
    require(selected==json.loads((INPUT/'organizer-four.json').read_bytes()),'organizer cut mismatch')
    first, second = [json.loads((ROOT/f'run-{i}/resultat.json').read_bytes()) for i in (1,2)]
    require(first['database_absent_after'] and second['database_absent_after'] and first['temporary_database']!=second['temporary_database'],
            'historical databases or cleanup inconsistent')
    require(first['passes']==second['passes'] and first['fetches']==second['fetches'] and first['sha']==second['sha']==SHA,
            'original receipts diverge')
    return first, len(expected)

def main():
    parser = argparse.ArgumentParser(description=__doc__)
    group = parser.add_mutually_exclusive_group(required=True)
    group.add_argument('--verify-only',action='store_true')
    group.add_argument('--out',type=Path)
    parser.add_argument('--port',type=int,default=5432)
    args = parser.parse_args()
    baseline, verified = check_package()
    print(f'verified {verified} files and {len(baseline["passes"])} reference passes')
    if args.verify_only:
        return
    require(__debug__, 'Python optimization disables scientific assertions; remove -O')
    require(1 <= args.port <= 65535, 'invalid port')
    out = args.out.resolve()
    require(not out.is_relative_to(ROOT), 'choose an output directory outside the capsule')
    require(not out.exists(), 'output directory already exists')
    import psycopg
    from psycopg import sql
    sys.path.insert(0,str(ROOT/'backend'))
    from vega.store import connect_local, migrate
    proof = {'sha':SHA,'python':sys.version,'psycopg':psycopg.__version__,'real_start':datetime.now(timezone.utc),
             'loopback':'127.0.0.1','port':args.port,'verified_files':verified}
    base = f'postgresql://postgres@127.0.0.1:{args.port}/'
    name = 'vega_v2_e04k_' + uuid4().hex[:12]
    with psycopg.connect(base+'postgres',autocommit=True,connect_timeout=3) as owner:
        require(owner.info.server_version//10000 == 18, 'PostgreSQL 18 required')
        proof['postgres'] = owner.execute('SELECT version()').fetchone()[0]
        proof['temporary_database'] = name
        out.mkdir(parents=True,exist_ok=False)
        owner.execute(sql.SQL('CREATE DATABASE {}').format(sql.Identifier(name)))
        try:
            with connect_local(base+name) as db, connect_local(base+name) as collect, connect_local(base+name) as calc:
                migrate(db)
                proof['migrations'] = db.execute('SELECT count(*),max(version) FROM ops.schema_migrations').fetchone()
                collect.execute('SET ROLE vega_collect')
                calc.execute('SET ROLE vega_calc')
                proof['roles'] = [c.execute('SELECT current_user').fetchone()[0] for c in (collect,calc)]
                run(db,collect,calc,proof)
                observed = json.loads(encode(proof))
                require(all(observed[k]==baseline[k] for k in ('passes','fetches','verdict','migrations','roles')),
                        'observed passes, fetches, verdict, migrations or roles differ from original receipt')
                roots = [Path(m.__file__).resolve().is_relative_to(ROOT/'backend')
                         for n,m in sys.modules.items() if n=='vega' or n.startswith('vega.')]
                require(roots and all(roots),'unexpected module source')
                proof['vega_modules_loaded_from_capsule'] = len(roots)
                proof['matches_original_receipts'] = True
        finally:
            owner.execute(sql.SQL('DROP DATABASE {}').format(sql.Identifier(name)))
            proof['database_absent_after'] = owner.execute('SELECT NOT EXISTS(SELECT 1 FROM pg_database WHERE datname=%s)',(name,)).fetchone()[0]
            proof['real_end'] = datetime.now(timezone.utc)
            (out/'resultat.json').write_text(encode(proof))
    require(proof['database_absent_after'], 'temporary database remains')

if __name__ == '__main__':
    main()
