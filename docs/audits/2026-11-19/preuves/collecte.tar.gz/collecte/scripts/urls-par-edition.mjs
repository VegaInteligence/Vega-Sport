// Lists the URL each edition's projection fetches (fetch spied, answering 404): which editions share a file.
import { readFileSync } from "node:fs";
const editions = JSON.parse(readFileSync(process.argv[2], "utf8"));
const root = process.argv[3];
const out = {};
for (const [kind, query] of editions) {
  const seen = [];
  globalThis.fetch = async (url) => { seen.push(String(url)); return new Response("Not Found", { status: 404 }); };
  const { GET } = await import(`${root}/backend/sources/projections/${kind}.mjs`);
  await GET(new Request(`http://bridge/api/${kind}?${query}`));
  out[`${kind}?${query}`] = seen;
}
const byUrl = {};
for (const [e, urls] of Object.entries(out)) for (const u of urls) (byUrl[u] ||= []).push(e);
console.log(JSON.stringify({ editions: Object.keys(out).length, urls: Object.keys(byUrl).length,
  shared: Object.fromEntries(Object.entries(byUrl).filter(([, es]) => es.length > 1)) }, null, 1));
