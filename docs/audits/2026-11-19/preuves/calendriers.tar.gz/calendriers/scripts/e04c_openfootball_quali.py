"""E04c: how many of the 2,489 finished UEFA qualifiers (capsule qualifications-2489) appear in openfootball/champions-league
clq/elq/confq (2024-25, 2025-26). Match key: (local day, total score oriented) + one name token overlap."""
import csv, json, re, sys, unicodedata, pathlib, collections, datetime
S = pathlib.Path(sys.argv[1]); Q = S/'prior/q2489/source'; T = S/'telechargements/of-cl'
MON = {m: i+1 for i, m in enumerate('Jan Feb Mar Apr May Jun Jul Aug Sep Oct Nov Dec'.split())}
def norm(s): return set(w for w in re.sub(r'[^a-z0-9 ]', ' ', unicodedata.normalize('NFKD', s).encode('ascii', 'ignore').decode().lower()).split() if len(w) > 2 and w not in {'fc', 'fk', 'club', 'the', 'sport'})
def parse(path, startyear):
    out, day, rnd, year = [], None, None, startyear
    for line in open(path, encoding='utf-8'):
        if line.startswith('▪'): rnd = line[1:].strip(); continue
        m = re.match(r'^\s+(?:[A-Z][a-z]{2}) ([A-Z][a-z]{2}) (\d{1,2})(?: (\d{4}))?\s*$', line)
        if m:
            if m.group(3): year = int(m.group(3))
            day = datetime.date(year, MON[m.group(1)], int(m.group(2))); continue
        m = re.match(r'^\s+(?:\d\d:\d\d)?\s+(.+?)\s+v\s+(.+?)\s{2,}(.*)$', line)
        if m and day:
            score = m.group(3).strip()
            ft = re.search(r'(\d+)-(\d+)(?: a\.e\.t\.)?(?: \(|$)', score)
            pen = re.search(r'(\d+)-(\d+) pen\.', score)
            aet = re.search(r'(\d+)-(\d+) a\.e\.t\.', score)
            ht = re.search(r'\((\d+)-(\d+)', score)
            sc = aet or ft
            if pen and not aet: sc = re.search(r'pen\. (\d+)-(\d+)', score) or sc
            out.append({'day': day.isoformat(), 'home': m.group(1), 'away': m.group(2), 'raw': score, 'round': rnd,
                        'total': [int(sc.group(1)), int(sc.group(2))] if sc else None, 'pen': bool(pen), 'aet': bool(aet), 'ht': bool(ht)})
    return out
names = {r['id']: (r['home'], r['away']) for r in csv.DictReader(open(Q/'rds/global-search.csv'))}
off = [r for r in csv.DictReader(open(Q/'official-fixtures.csv')) if r['phase'] == 'QUALIFYING' and r['status'] == 'FINISHED']
FILES = {('UCL', '2024'): '2024-25-clq', ('UEL', '2024'): '2024-25-elq', ('UECL', '2024'): '2024-25-confq',
         ('UCL', '2025'): '2025-26-clq', ('UEL', '2025'): '2025-26-elq', ('UECL', '2025'): '2025-26-confq'}
res = {}; detail = []
for (comp, yr), fn in FILES.items():
    ofm = parse(T/f'{fn}.txt', int(yr)); used = set()
    o = [r for r in off if r['comp'] == comp and r['year'] == yr]
    c = collections.Counter(official=len(o), openfootball_rows=len(ofm), openfootball_with_score=sum(1 for x in ofm if x['total']),
                            openfootball_ht=sum(1 for x in ofm if x['ht']), openfootball_pen=sum(1 for x in ofm if x['pen']), openfootball_aet=sum(1 for x in ofm if x['aet']))
    for r in o:
        h, a = names.get(r['id'], ('', '')); tot = json.loads(r['total'])
        cands = [i for i, x in enumerate(ofm) if i not in used and abs((datetime.date.fromisoformat(x['day']) - datetime.date.fromisoformat(r['local'])).days) <= 1
                 and (norm(x['home']) & norm(h) or norm(x['away']) & norm(a))]
        if not cands: c['absent'] += 1; detail.append({'comp': comp, 'year': yr, 'uefa_id': r['id'], 'day': r['local'], 'home': h, 'away': a, 'found': ''}); continue
        def rank(i):
            x = ofm[i]
            return (bool(norm(x['home']) & norm(h)) + bool(norm(x['away']) & norm(a)), x['day'] == r['local'], x['total'] == tot)
        i = max(cands, key=rank); used.add(i); x = ofm[i]
        same = x['total'] == tot
        c['found'] += 1; c['found_same_total_score' if same else 'found_score_differs'] += 1
        detail.append({'comp': comp, 'year': yr, 'uefa_id': r['id'], 'day': r['local'], 'home': h, 'away': a, 'found': f"{x['day']} {x['home']} v {x['away']} {x['raw']}", 'same_score': same})
    c['openfootball_unmatched'] = len(ofm) - len(used)
    res[f'{comp} {yr}/{int(yr)+1}'] = dict(c)
tot = collections.Counter()
for v in res.values(): tot.update(v)
res['total_2024_2025'] = dict(tot)
res['official_finished_qualifiers_all_six_seasons'] = len(off)
res['official_finished_qualifiers_seasons_without_openfootball_quali_file'] = sum(1 for r in off if r['year'] not in ('2024', '2025'))
json.dump(res, open(S/'e04c-openfootball-qualifs.json', 'w'), indent=1)
with open(S/'e04c-openfootball-qualifs-detail.csv', 'w', newline='') as f:
    w = csv.DictWriter(f, ['comp', 'year', 'uefa_id', 'day', 'home', 'away', 'found', 'same_score']); w.writeheader(); w.writerows(detail)
print(json.dumps(res, indent=1))
