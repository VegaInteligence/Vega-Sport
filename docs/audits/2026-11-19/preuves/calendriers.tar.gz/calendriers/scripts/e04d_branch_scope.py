"""Replays parseInternationalResults (branch claude/week-internationals 61121c8fb5) filters on today's results.csv, 2026/27 and, for comparison, earlier seasons."""
import csv, json, sys, pathlib, collections
S = pathlib.Path(sys.argv[1]); rows = list(csv.DictReader(open(S/'telechargements/intl/results.csv', encoding='utf-8')))
OWN = {"UEFA Nations League", "FIFA World Cup"}
WIN = [("African Cup of Nations", "2022-01-01", "2022-02-28"), ("African Cup of Nations", "2024-01-01", "2024-02-29"), ("African Cup of Nations", "2025-12-01", "2026-01-31"),
       ("Copa América", "2024-06-01", "2024-07-31"), ("AFC Asian Cup", "2024-01-01", "2024-02-29"), ("Gold Cup", "2023-06-01", "2023-07-31"), ("Gold Cup", "2025-06-01", "2025-07-31")]
out = {}
for start in range(2021, 2027):
    a, b = f"{start}-07-01", f"{start+1}-06-30"
    kept = [r for r in rows if a <= r['date'] <= b and r['tournament'] not in OWN and not any(r['tournament'] == t and f <= r['date'] <= l for t, f, l in WIN)
            and r['home_score'].isdigit() and r['away_score'].isdigit()]
    out[f"{start}/{start+1}"] = {'kept': len(kept), 'by_tournament': collections.Counter(r['tournament'] for r in kept).most_common(15)}
json.dump(out, open(S/'e04d-branche-week-internationals-portee.json', 'w'), indent=1, ensure_ascii=False)
print(json.dumps(out['2026/2027'], indent=1, ensure_ascii=False)); print({k: v['kept'] for k, v in out.items()})
