"""E04d: what martj42/international_results results.csv + shootouts.csv hold for the national-team competitions since 2021/22."""
import csv, json, sys, pathlib, collections
S = pathlib.Path(sys.argv[1]); D = S/'telechargements/intl'
rows = list(csv.DictReader(open(D/'results.csv', encoding='utf-8')))
sh = {(r['date'], r['home_team'], r['away_team']): r for r in csv.DictReader(open(D/'shootouts.csv', encoding='utf-8'))}
out = {'results_rows': len(rows), 'results_last_date': max(r['date'] for r in rows), 'shootouts_rows': len(sh), 'results_columns': list(rows[0]), 'shootouts_columns': list(next(iter(sh.values())))}
since = [r for r in rows if r['date'] >= '2021-07-01']
c = collections.Counter(r['tournament'] for r in since)
out['since_2021_07_01_rows'] = len(since); out['since_2021_07_01_by_tournament_top'] = c.most_common(40)
def win(t, a, b): return [r for r in rows if r['tournament'] == t and a <= r['date'] <= b]
def score_ok(r): return r['home_score'].isdigit() and r['away_score'].isdigit()
cycles = {
    'WCQ 2022 cycle (2019-06-01..2022-06-30)': win('FIFA World Cup qualification', '2019-06-01', '2022-06-30'),
    'WCQ 2026 cycle (2023-09-01..2026-04-30)': win('FIFA World Cup qualification', '2023-09-01', '2026-04-30'),
    'WCQ after 2026-04-30 (2030 cycle?)': win('FIFA World Cup qualification', '2026-05-01', '2099-12-31'),
    'UEFA Euro qualification 2024 (2023-03-01..2024-03-31)': win('UEFA Euro qualification', '2023-03-01', '2024-03-31'),
    'UEFA Euro qualification after 2024-04': win('UEFA Euro qualification', '2024-04-01', '2099-12-31'),
    'UEFA Euro 2024 final tournament': win('UEFA Euro', '2024-06-01', '2024-07-31'),
    'UEFA Nations League 2022/23 (2022-06..2023-06)': win('UEFA Nations League', '2022-06-01', '2023-06-30'),
    'UEFA Nations League 2024/25 (2024-09..2025-06)': win('UEFA Nations League', '2024-09-01', '2025-06-30'),
    'UEFA Nations League 2026/27 so far (2026-09..)': win('UEFA Nations League', '2026-09-01', '2099-12-31'),
    'African Cup of Nations qualification since 2021-07': win('African Cup of Nations qualification', '2021-07-01', '2099-12-31'),
    'African Cup of Nations (finals, all dates since 2021-07)': win('African Cup of Nations', '2021-07-01', '2099-12-31'),
    'Copa América 2024': win('Copa América', '2024-06-01', '2024-07-31'),
    'AFC Asian Cup 2023 (played 2024)': win('AFC Asian Cup', '2024-01-01', '2024-02-29'),
    'AFC Asian Cup qualification since 2021-07': win('AFC Asian Cup qualification', '2021-07-01', '2099-12-31'),
    'Gold Cup since 2021-07': win('Gold Cup', '2021-07-01', '2099-12-31'),
    'Gold Cup qualification since 2021-07': win('Gold Cup qualification', '2021-07-01', '2099-12-31'),
    'CONCACAF Nations League since 2021-07': win('CONCACAF Nations League', '2021-07-01', '2099-12-31'),
    'FIFA World Cup 2022 finals': win('FIFA World Cup', '2022-11-01', '2022-12-31'),
    'FIFA World Cup 2026 finals': win('FIFA World Cup', '2026-06-01', '2026-07-31'),
    'Friendly since 2021-07': win('Friendly', '2021-07-01', '2099-12-31'),
}
res = {}
for k, v in cycles.items():
    res[k] = {'rows': len(v), 'with_integer_score': sum(map(score_ok, v)), 'with_shootout_row': sum(1 for r in v if (r['date'], r['home_team'], r['away_team']) in sh),
              'first': min((r['date'] for r in v), default=None), 'last': max((r['date'] for r in v), default=None)}
out['by_scope'] = res
# What the eight editions read today give (TOURNAMENT_EDITIONS + Nations League B-D window)
read = {'afcon 2021': ('African Cup of Nations', '2022-01-01', '2022-02-28'), 'afcon 2023': ('African Cup of Nations', '2024-01-01', '2024-02-29'),
        'afcon 2025': ('African Cup of Nations', '2025-12-01', '2026-01-31'), 'copa-america 2024': ('Copa América', '2024-06-01', '2024-07-31'),
        'asian-cup 2023': ('AFC Asian Cup', '2024-01-01', '2024-02-29'), 'gold-cup 2023': ('Gold Cup', '2023-06-01', '2023-07-31'),
        'gold-cup 2025': ('Gold Cup', '2025-06-01', '2025-07-31')}
out['read_editions'] = {k: {'rows': len(win(*v)), 'shootout_rows': sum(1 for r in win(*v) if (r['date'], r['home_team'], r['away_team']) in sh)} for k, v in read.items()}
out['copa_2024_shootouts'] = [dict(sh[(r['date'], r['home_team'], r['away_team'])]) | {'score': f"{r['home_score']}-{r['away_score']}"} for r in win('Copa América', '2024-06-01', '2024-07-31') if (r['date'], r['home_team'], r['away_team']) in sh]
out['copa_2024_final'] = [r for r in win('Copa América', '2024-07-14', '2024-07-14')]
json.dump(out, open(S/'e04d-international-results.json', 'w'), indent=1, ensure_ascii=False)
print(json.dumps({k: v for k, v in out.items() if k != 'since_2021_07_01_by_tournament_top'}, indent=1, ensure_ascii=False))
