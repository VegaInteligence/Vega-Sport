"""E04d: the 701 European qualifiers (WCQ 2022 UEFA 258, Euro 2024 Q 239, WCQ 2026 UEFA 204) in results.csv. UEFA members = teams of Euro 2024 qualification + Russia + Germany (host of Euro 2024)."""
import csv, json, sys, pathlib
S = pathlib.Path(sys.argv[1]); rows = list(csv.DictReader(open(S/'telechargements/intl/results.csv', encoding='utf-8')))
uefa = {t for r in rows if r['tournament'] == 'UEFA Euro qualification' and r['date'] >= '2023-03-01' for t in (r['home_team'], r['away_team'])} | {'Russia', 'Germany'}
def n(t, a, b): return [r for r in rows if r['tournament'] == t and a <= r['date'] <= b and r['home_team'] in uefa and r['away_team'] in uefa]
out = {'uefa_teams': len(uefa),
       'WCQ 2022 UEFA (2021-03-01..2022-06-30)': len(n('FIFA World Cup qualification', '2021-03-01', '2022-06-30')),
       'Euro 2024 qualification (2023-03-01..2024-03-31)': len(n('UEFA Euro qualification', '2023-03-01', '2024-03-31')),
       'WCQ 2026 UEFA (2025-03-01..2026-04-30)': len(n('FIFA World Cup qualification', '2025-03-01', '2026-04-30'))}
out['total'] = sum(v for k, v in out.items() if k.startswith(('WCQ', 'Euro')))
json.dump(out, open(S/'e04d-eliminatoires-europe-701.json', 'w'), indent=1); print(out)
