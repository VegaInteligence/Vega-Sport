"""E04a: how many of the 236 official results absent from Vega appear in ANY published version (git history) of the Open Matchday file."""
import csv, json, sys, zlib, pathlib, collections, glob
S = pathlib.Path(sys.argv[1]); P = S/'prior/ang575'; H = S/'telechargements/om/hist'
SL = {'north': 'ENG_6_national-league-north', 'south': 'ENG_6_national-league-south', 'npl': 'ENG_7_northern-premier-league'}
xw = json.loads((P/'inputs/review/organizer/name-crosswalk.json').read_text())
j = json.loads(zlib.decompress((P/'inputs/review/rds-3/inputs.json.zlib').read_bytes()))
names = {}
for r in (dict(zip(j['fixtures']['columns'], x)) for x in j['fixtures']['rows']):
    if r['competition_season_id'] in (332, 333, 334):
        for s in ('home', 'away'): names[xw.get(r[s], r[s])] = r[s+'_team_id']
rows = list(csv.DictReader(open(S/'e04a-angleterre-575-aujourdhui.csv')))
official = {r['official_id']: r for r in csv.DictReader((P/'outputs/official-finished.csv').open())}
out = {}; unknown = set(); detail = []
for lg, slug in SL.items():
    seen = {}; versions = sorted(glob.glob(str(H/f'{slug}@*.csv')))
    earliest = None
    for v in versions:
        for r in csv.DictReader(open(v)):
            h = names.get(xw.get(r['home'], r['home'])); a = names.get(xw.get(r['away'], r['away']))
            if h is None or a is None: unknown.add((r['home'], r['away'])); continue
            seen.setdefault((r['date'], h, a), set()).add((int(r['ft_home']), int(r['ft_away'])))
            earliest = min(earliest or r['date'], r['date'])
    c = collections.Counter(versions=len(versions), earliest_date_any_version=0)
    c.pop('earliest_date_any_version')
    for r in (x for x in rows if x['league'] == lg and x['api_today'] == 'absent'):
        o = official[r['official_id']]; k = (o['date'], int(o['home_id']), int(o['away_id'])); sc = (int(o['hs']), int(o['aws']))
        got = seen.get(k)
        st = 'never_published' if not got else ('published_exact' if got == {sc} else 'published_other_score')
        c[st] += 1; c[f"{st}|{r['classification_18nov']}"] += 1
        detail.append({'league': lg, 'official_id': r['official_id'], 'date': o['date'], 'home': o['home'], 'away': o['away'], 'official': f'{sc[0]}-{sc[1]}', 'git_history': st, 'classification_18nov': r['classification_18nov']})
        if not got: c['never_published_month_' + o['date'][:7]] += 1
    out[lg] = dict(c) | {'earliest_date_any_version': earliest}
tot = collections.Counter()
for v in out.values(): tot.update({k: n for k, n in v.items() if isinstance(n, int)})
out['total'] = dict(tot); out['unknown_names'] = sorted(unknown)
json.dump(out, open(S/'e04a-angleterre-historique-git.json', 'w'), indent=1)
with open(S/'e04a-angleterre-236-historique-git.csv', 'w', newline='') as f:
    w = csv.DictWriter(f, detail[0].keys()); w.writeheader(); w.writerows(detail)
print(json.dumps(out, indent=1))
