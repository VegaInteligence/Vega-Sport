import json, sys
for f in sys.argv[1:]:
    d = json.load(open(f)); ms = d['data']['matches'] if isinstance(d.get('data'), dict) else d.get('matches', [])
    print(f, len(ms), d.get('pagination', {}).get('nextCursor'))
    for x in ms:
        h, a = x.get('home_team'), x.get('away_team')
        n = lambda t: t.get('name') if isinstance(t, dict) else t
        lg = x.get('league'); lg = (lg.get('name'), lg.get('id')) if isinstance(lg, dict) else lg
        print('  ', x.get('id'), x.get('date'), lg, n(h), n(a), x.get('score_home', x.get('score')), x.get('score_away'), x.get('status'))
