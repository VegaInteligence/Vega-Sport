"""E04a: compare the 575 official results (capsule angleterre-575, 18 Nov) with today's API cup-table and today's Open Matchday CSV."""
import csv, json, sys, zlib, pathlib, collections
S = pathlib.Path(sys.argv[1]); P = S/'prior/ang575'
SL = {'north': 'ENG_6_national-league-north', 'south': 'ENG_6_national-league-south', 'npl': 'ENG_7_northern-premier-league'}
xw = json.loads((P/'inputs/review/organizer/name-crosswalk.json').read_text())
j = json.loads(zlib.decompress((P/'inputs/review/rds-3/inputs.json.zlib').read_bytes()))
names = {}
for r in (dict(zip(j['fixtures']['columns'], x)) for x in j['fixtures']['rows']):
    if r['competition_season_id'] in (332, 333, 334):
        for s in ('home', 'away'):
            names[xw.get(r[s], r[s])] = r[s+'_team_id']
official = list(csv.DictReader((P/'outputs/official-finished.csv').open()))
out = {}; rows_out = []
unknown = set()
for lg, slug in SL.items():
    api = json.load(open(S/f'api/{slug}-results.json'))
    a = {}
    for r in api:
        h = names.get(xw.get(r['home'], r['home'])); w = names.get(xw.get(r['away'], r['away']))
        if h is None or w is None: unknown.add(('api', r['home'], r['away'])); continue
        a[(r['date'], h, w)] = (int(r['ft_home']), int(r['ft_away']))
    src = {}
    for r in csv.DictReader(open(S/f'telechargements/om/{slug}-results_2627.csv')):
        h = names.get(xw.get(r['home'], r['home'])); w = names.get(xw.get(r['away'], r['away']))
        if h is None or w is None: unknown.add((r['home'], r['away'])); continue
        src[(r['date'], h, w)] = (int(r['ft_home']), int(r['ft_away']))
    c = collections.Counter(); offkeys = set()
    for o in (o for o in official if o['league'] == lg):
        k = (o['date'], int(o['home_id']), int(o['away_id'])); offkeys.add(k); sc = (int(o['hs']), int(o['aws']))
        av = 'absent' if k not in a else ('exact' if a[k] == sc else 'different_score')
        sv = 'absent' if k not in src else ('exact' if src[k] == sc else 'different_score')
        c['official'] += 1; c['api_'+av] += 1; c['source_'+sv] += 1
        c[f'api_{av}|source_{sv}|prev_{o["classification"]}'] += 1
        rows_out.append({'league': lg, 'official_id': o['official_id'], 'date': o['date'], 'home': o['home'], 'away': o['away'], 'official': f'{sc[0]}-{sc[1]}',
                         'api_today': av, 'api_score': '-'.join(map(str, a.get(k, ()))), 'source_today': sv, 'classification_18nov': o['classification']})
    c['api_rows_total'] = len(a); c['api_rows_after_18nov_cutoff'] = sum(1 for k in a if k[0] > '2026-11-18')
    c['api_rows_not_in_official_575'] = sum(1 for k in a if k not in offkeys)
    c['source_rows_total'] = len(src); c['source_min_date'] = min(k[0] for k in src); c['source_max_date'] = max(k[0] for k in src)
    out[lg] = dict(c)
tot = collections.Counter()
for v in out.values():
    for k, n in v.items():
        if isinstance(n, int): tot[k] += n
out['total'] = dict(tot); out['source_rows_with_unknown_names'] = sorted(unknown)
json.dump(out, open(S/'e04a-angleterre-aujourdhui.json', 'w'), indent=1)
with open(S/'e04a-angleterre-575-aujourdhui.csv', 'w', newline='') as f:
    w = csv.DictWriter(f, rows_out[0].keys()); w.writeheader(); w.writerows(rows_out)
print(json.dumps(out['total'], indent=1)); print('unknown', unknown)
