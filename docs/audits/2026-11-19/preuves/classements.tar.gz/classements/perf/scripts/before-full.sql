\timing off
BEGIN;

CREATE OR REPLACE FUNCTION api.nation_list(season_key smallint)
RETURNS TABLE(team_id text, team_key integer, name text, image_url text, matches integer, last_match date,
  elo float8, elo_at date, rank integer, season_elo float8, elo_change float8, season_matches integer,
  wins integer, draws integer, losses integer, result_sum float8, expected_sum float8)
LANGUAGE sql STABLE STRICT SECURITY DEFINER SET search_path = pg_catalog AS $$
  WITH nations AS MATERIALIZED (
    SELECT t.id, t.name, t.crest_asset_id FROM core.teams t WHERE t.is_national AND t.merged_into IS NULL
  ), games AS MATERIALIZED (
    SELECT n.id AS team, coalesce(m.match_date, m.kickoff_at::date) AS d,
      least(m.home_team_id, m.away_team_id) AS a, greatest(m.home_team_id, m.away_team_id) AS b, m.id AS match
    FROM nations n JOIN core.matches m ON m.home_team_id = n.id
    UNION ALL
    SELECT n.id, coalesce(m.match_date, m.kickoff_at::date),
      least(m.home_team_id, m.away_team_id), greatest(m.home_team_id, m.away_team_id), m.id
    FROM nations n JOIN core.matches m ON m.away_team_id = n.id
  ), played AS MATERIALIZED (
    -- A match without a date is its own match.
    SELECT team, count(DISTINCT coalesce(d::text || ':' || a || ':' || b, 'm' || match))::integer AS matches, max(d) AS last_match
    FROM games GROUP BY team
  )
  SELECT api.public_id('team', n.id), n.id, n.name, cr.source_url, p.matches, p.last_match,
    e.elo_after::numeric::float8, e.kickoff_at::date,
    tp.rank, tp.elo::numeric::float8, tp.elo_change::numeric::float8, tp.matches, tp.wins, tp.draws, tp.losses,
    tp.result_sum::numeric::float8, tp.expected_sum::numeric::float8
  FROM nations n
  JOIN played p ON p.team = n.id
  LEFT JOIN core.assets cr ON cr.id = n.crest_asset_id
  LEFT JOIN LATERAL (
    SELECT x.elo_after, x.kickoff_at FROM agg.team_elo x WHERE x.team_id = n.id ORDER BY x.kickoff_at DESC NULLS LAST LIMIT 1
  ) e ON true
  LEFT JOIN agg.team_power tp ON tp.season_id = season_key AND tp.team_id = n.id AND tp.scope = 'nations'
$$;
CREATE OR REPLACE FUNCTION api.nation_matches(team_key integer)
RETURNS TABLE(match_id text, match_date date, season text, competition text, edition text, round text, status text,
  collected boolean, home_id text, home_name text, home_image text, away_id text, away_name text, away_image text,
  home_score integer, away_score integer, home_penalties integer, away_penalties integer)
LANGUAGE sql STABLE STRICT SECURITY DEFINER SET search_path = pg_catalog AS $$
  WITH own AS MATERIALIZED (
    SELECT m.id, m.season_id, m.competition_season_id, m.round_id, m.status, m.home_team_id, m.away_team_id,
      m.home_score, m.away_score, m.home_penalty_score, m.away_penalty_score, coalesce(m.match_date, m.kickoff_at::date) AS d
    FROM core.matches m WHERE m.home_team_id = team_key
    UNION ALL
    SELECT m.id, m.season_id, m.competition_season_id, m.round_id, m.status, m.home_team_id, m.away_team_id,
      m.home_score, m.away_score, m.home_penalty_score, m.away_penalty_score, coalesce(m.match_date, m.kickoff_at::date)
    FROM core.matches m WHERE m.away_team_id = team_key AND m.home_team_id <> team_key
  ), copies AS (
    SELECT o.*, cs.cup_key, cs.archive_key, co.name AS competition_name, r.name AS round_name,
      least(o.home_team_id, o.away_team_id) AS lo, greatest(o.home_team_id, o.away_team_id) AS hi,
      -- Each copy's penalties by team: the lower team id's, then the other's.
      CASE WHEN o.home_team_id <= o.away_team_id THEN o.home_penalty_score ELSE o.away_penalty_score END AS pens_lo,
      CASE WHEN o.home_team_id <= o.away_team_id THEN o.away_penalty_score ELSE o.home_penalty_score END AS pens_hi
    FROM own o
    JOIN core.competition_seasons cs ON cs.id = o.competition_season_id
    JOIN core.competitions co ON co.id = cs.competition_id
    LEFT JOIN core.rounds r ON r.id = o.round_id
  ), picked AS (
    SELECT c.*,
      row_number() OVER w AS pick,
      max(c.round_name) OVER (PARTITION BY coalesce(c.d::text, 'm' || c.id), c.lo, c.hi) AS any_round,
      max(c.pens_lo) OVER (PARTITION BY coalesce(c.d::text, 'm' || c.id), c.lo, c.hi) AS any_pens_lo,
      max(c.pens_hi) OVER (PARTITION BY coalesce(c.d::text, 'm' || c.id), c.lo, c.hi) AS any_pens_hi
    FROM copies c
    WINDOW w AS (
      PARTITION BY coalesce(c.d::text, 'm' || c.id), c.lo, c.hi
      ORDER BY (c.cup_key IS NULL AND c.archive_key IS NULL) DESC, (c.home_score IS NOT NULL) DESC, c.id
    )
  )
  SELECT api.public_id('match', p.id), p.d, se.label, p.competition_name, coalesce(p.cup_key, p.archive_key),
    coalesce(p.round_name, p.any_round), p.status::text, p.cup_key IS NULL AND p.archive_key IS NULL,
    api.public_id('team', p.home_team_id), h.name, hc.source_url, api.public_id('team', p.away_team_id), a.name, ac.source_url,
    p.home_score::integer, p.away_score::integer,
    coalesce(p.home_penalty_score, CASE WHEN p.home_team_id = p.lo THEN p.any_pens_lo ELSE p.any_pens_hi END)::integer,
    coalesce(p.away_penalty_score, CASE WHEN p.away_team_id = p.lo THEN p.any_pens_lo ELSE p.any_pens_hi END)::integer
  FROM picked p
  JOIN core.seasons se ON se.id = p.season_id
  JOIN core.teams h ON h.id = p.home_team_id
  JOIN core.teams a ON a.id = p.away_team_id
  LEFT JOIN core.assets hc ON hc.id = h.crest_asset_id
  LEFT JOIN core.assets ac ON ac.id = a.crest_asset_id
  WHERE p.pick = 1
$$;
CREATE OR REPLACE VIEW api.standings AS
WITH excluded AS MATERIALIZED (
  SELECT competition_season_id FROM api.j1_standings_exclusion()
), authority AS NOT MATERIALIZED (
  SELECT o.* FROM core.standings_official o
  WHERE o.source = 'sportscore' AND o.stage IS NULL
    AND NOT EXISTS (SELECT 1 FROM excluded x WHERE x.competition_season_id = o.competition_season_id)
), unqualified AS NOT MATERIALIZED (
  SELECT e.competition_season_id
  FROM (SELECT DISTINCT o.competition_season_id FROM authority o) e
  WHERE EXISTS (SELECT 1 FROM agg.standings a WHERE a.competition_season_id = e.competition_season_id)
    AND EXISTS (
      WITH counted AS MATERIALIZED (
        SELECT team_id, results FROM core.table_results(e.competition_season_id)
      ), calculated AS (
        SELECT a.team_id, ARRAY[sum(a.played), sum(a.won), sum(a.drawn), sum(a.lost),
                                sum(a.goals_for), sum(a.goals_against)] AS results
        FROM agg.standings a WHERE a.competition_season_id = e.competition_season_id
        GROUP BY a.team_id
      ), officials AS NOT MATERIALIZED (
        SELECT * FROM authority o WHERE o.competition_season_id = e.competition_season_id
      )
      SELECT 1
      -- An aggregate built before a finished or corrected result is not a current fallback.
      WHERE NOT EXISTS (
        SELECT 1 FROM counted c FULL JOIN calculated a USING (team_id)
        WHERE (c.results::bigint[]) IS DISTINCT FROM a.results
      )
      -- Keep a table the native fixture inventory was already too short to supersede. An
      -- annulment can legitimately lower the count of a club whose earlier basis covered it.
      AND NOT EXISTS (
        SELECT 1 FROM officials o LEFT JOIN counted c USING (team_id)
        WHERE o.played > coalesce(c.results[1], 0) AND (o.basis IS NULL OR o.played > o.basis[1])
      )
      AND EXISTS (
        SELECT 1 FROM counted c FULL JOIN officials o USING (team_id)
        WHERE o.team_id IS NULL
          OR (
            -- An official row already reflects the current results when all its known fields agree.
            EXISTS (
              SELECT 1 FROM unnest(
                ARRAY[o.played, o.won, o.drawn, o.lost, o.goals_for, o.goals_against],
                coalesce(c.results, '{0,0,0,0,0,0}')
              ) AS s(official, native)
              WHERE s.official IS NOT NULL AND s.official <> s.native
            )
            AND ((o.basis IS NOT NULL AND o.basis IS DISTINCT FROM coalesce(c.results, '{0,0,0,0,0,0}'))
              OR (o.basis IS NULL AND EXISTS (
                SELECT 1 FROM core.matches m LEFT JOIN core.rounds r ON r.id = m.round_id
                WHERE m.competition_season_id = e.competition_season_id AND m.first_finished_at > o.as_of
                  AND m.status = 'finished' AND m.home_score IS NOT NULL AND m.away_score IS NOT NULL
                  AND coalesce(r.stage, 'regular') IN ('regular', 'group'))))
          )
      )
    )
), merged AS (
  SELECT o.competition_season_id, o.stage, o.group_name, o.team_id, o.position, o.played, o.won, o.drawn,
    o.lost, o.goals_for, o.goals_against, o.points, o.source::text, o.as_of
  FROM authority o
  WHERE NOT EXISTS (SELECT 1 FROM unqualified u WHERE u.competition_season_id = o.competition_season_id)
  UNION ALL
  SELECT a.competition_season_id, a.stage, a.group_name, a.team_id, a.position, a.played, a.won, a.drawn,
    a.lost, a.goals_for, a.goals_against, a.points, 'vega', a.updated_at
  FROM agg.standings a
  WHERE NOT EXISTS (SELECT 1 FROM excluded x WHERE x.competition_season_id = a.competition_season_id)
    AND (NOT EXISTS (SELECT 1 FROM authority o WHERE o.competition_season_id = a.competition_season_id)
         OR EXISTS (SELECT 1 FROM unqualified u WHERE u.competition_season_id = a.competition_season_id))
)
SELECT merged.*, api.public_id('team', merged.team_id) AS team_public_id, t.name AS team_name,
  cr.s3_key AS crest_key, z.zone::text AS zone
FROM merged
JOIN core.teams t ON t.id = merged.team_id
LEFT JOIN core.assets cr ON cr.id = t.crest_asset_id
LEFT JOIN core.competition_zones z ON z.competition_season_id = merged.competition_season_id
  AND merged.position BETWEEN z.position_from AND z.position_to AND merged.group_name IS NULL;


SET jit = off; SET max_parallel_workers_per_gather = 0; SET statement_timeout = '30s'; SET search_path = api; SET ROLE vega_read;
PREPARE standings(text, text) AS WITH edition AS (
       SELECT k.competition_season_id FROM api.edition_keys k
       CROSS JOIN LATERAL (
         SELECT r.season,r.native_label,r.is_current FROM api.standing_rows r
         WHERE r.competition_season_id=k.competition_season_id
         UNION ALL
         SELECT x.season,x.native_label,x.is_current FROM api.j1_standings_exclusion() x
         WHERE x.competition_season_id=k.competition_season_id
         LIMIT 1) s
       WHERE k.league_id=$1 AND ($2::text IS NULL OR s.season=$2 OR s.native_label=$2)
       ORDER BY s.is_current DESC,s.season DESC LIMIT 1)
     SELECT r.* FROM api.standing_rows r WHERE r.competition_season_id=(SELECT competition_season_id FROM edition)
     ORDER BY r.stage NULLS FIRST,r.group_name NULLS FIRST,r.position,r.name;
PREPARE nlist(text) AS SELECT * FROM api.nation_list((SELECT season_id FROM api.season_keys WHERE season=$1));
PREPARE nmatches(integer) AS SELECT * FROM api.nation_matches($1::integer) ORDER BY match_date DESC NULLS LAST;
\echo == standings l_000100 - #1
EXPLAIN (ANALYZE, BUFFERS) EXECUTE standings('l_000100', NULL);
\echo == standings l_000100 - #2
EXPLAIN (ANALYZE, BUFFERS) EXECUTE standings('l_000100', NULL);
\echo == standings l_000100 - #3
EXPLAIN (ANALYZE, BUFFERS) EXECUTE standings('l_000100', NULL);
\echo == standings l_000100 - #4
EXPLAIN (ANALYZE, BUFFERS) EXECUTE standings('l_000100', NULL);
\echo == standings l_000100 - #5
EXPLAIN (ANALYZE, BUFFERS) EXECUTE standings('l_000100', NULL);
\echo == standings l_000150 2025 #1
EXPLAIN (ANALYZE, BUFFERS) EXECUTE standings('l_000150', '2025');
\echo == standings l_000150 2025 #2
EXPLAIN (ANALYZE, BUFFERS) EXECUTE standings('l_000150', '2025');
\echo == standings l_000150 2025 #3
EXPLAIN (ANALYZE, BUFFERS) EXECUTE standings('l_000150', '2025');
\echo == standings l_000150 2025 #4
EXPLAIN (ANALYZE, BUFFERS) EXECUTE standings('l_000150', '2025');
\echo == standings l_000150 2025 #5
EXPLAIN (ANALYZE, BUFFERS) EXECUTE standings('l_000150', '2025');
\echo == standings l_000200 - #1
EXPLAIN (ANALYZE, BUFFERS) EXECUTE standings('l_000200', NULL);
\echo == standings l_000200 - #2
EXPLAIN (ANALYZE, BUFFERS) EXECUTE standings('l_000200', NULL);
\echo == standings l_000200 - #3
EXPLAIN (ANALYZE, BUFFERS) EXECUTE standings('l_000200', NULL);
\echo == standings l_000200 - #4
EXPLAIN (ANALYZE, BUFFERS) EXECUTE standings('l_000200', NULL);
\echo == standings l_000200 - #5
EXPLAIN (ANALYZE, BUFFERS) EXECUTE standings('l_000200', NULL);
\echo == nation_list #1
EXPLAIN (ANALYZE, BUFFERS) EXECUTE nlist('2026/2027');
\echo == nation_list #2
EXPLAIN (ANALYZE, BUFFERS) EXECUTE nlist('2026/2027');
\echo == nation_list #3
EXPLAIN (ANALYZE, BUFFERS) EXECUTE nlist('2026/2027');
\echo == nation_list #4
EXPLAIN (ANALYZE, BUFFERS) EXECUTE nlist('2026/2027');
\echo == nation_list #5
EXPLAIN (ANALYZE, BUFFERS) EXECUTE nlist('2026/2027');
\echo == nation_matches 100001 #1
EXPLAIN (ANALYZE, BUFFERS) EXECUTE nmatches(100001);
\echo == nation_matches 100001 #2
EXPLAIN (ANALYZE, BUFFERS) EXECUTE nmatches(100001);
\echo == nation_matches 100001 #3
EXPLAIN (ANALYZE, BUFFERS) EXECUTE nmatches(100001);
\echo == nation_matches 100001 #4
EXPLAIN (ANALYZE, BUFFERS) EXECUTE nmatches(100001);
\echo == nation_matches 100001 #5
EXPLAIN (ANALYZE, BUFFERS) EXECUTE nmatches(100001);
\echo == count api.standings #1
EXPLAIN (ANALYZE, BUFFERS) SELECT count(*) FROM api.standings;
\echo == count api.standings #2
EXPLAIN (ANALYZE, BUFFERS) SELECT count(*) FROM api.standings;
\echo == count api.standings #3
EXPLAIN (ANALYZE, BUFFERS) SELECT count(*) FROM api.standings;
\echo == count api.standings #4
EXPLAIN (ANALYZE, BUFFERS) SELECT count(*) FROM api.standings;
\echo == count api.standings #5
EXPLAIN (ANALYZE, BUFFERS) SELECT count(*) FROM api.standings;
SET plan_cache_mode = force_generic_plan;
\echo == generic standings l_000200 -
EXPLAIN (ANALYZE, BUFFERS) EXECUTE standings('l_000200', NULL);
\echo == generic nation_matches 100001
EXPLAIN (ANALYZE, BUFFERS) EXECUTE nmatches(100001);
RESET plan_cache_mode;
\echo == rows
EXECUTE standings('l_000100', NULL);
SELECT count(*), sum(matches) FROM api.nation_list(2026::smallint);
SELECT count(*) FROM api.nation_matches(100001);
ROLLBACK;
