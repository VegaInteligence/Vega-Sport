"""Medians of the execution times of each statement in the given .out files: one table, a column per file."""
import re, statistics, sys
cols = {}
for f in sys.argv[1:]:
    label, times = None, {}
    for line in open(f):
        m = re.match(r"== (.+?)( #\d+)?$", line.strip())
        if m:
            label = m[1]
        t = re.search(r"Execution Time: ([\d.]+) ms", line)
        if t and label:
            times.setdefault(label, []).append(float(t[1]))
    cols[f.rsplit("/", 1)[-1].replace(".out", "")] = {k: statistics.median(v) for k, v in times.items()}
labels = list(dict.fromkeys(k for c in cols.values() for k in c))
print("| statement | " + " | ".join(cols) + " |")
print("|---|" + "---|" * len(cols))
for l in labels:
    print(f"| {l} | " + " | ".join(f"{c.get(l, float('nan')):.1f}" for c in cols.values()) + " |")
