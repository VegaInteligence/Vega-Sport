"""Builds the measurement scripts: <variant>-<volume>.sql, each one transaction rolled back, on classements_perf
(a copy of relecture_b_159, migrated with the first 159). Variants: before (119/120/150 as the review recreated them,
baseline_defs.sql), first159 (the base as it is), new159 (the worktree's 159). Volumes: full; small (the International
Results archive removed, as the review's explain_nations_small.sql)."""
import re, sys
R = "/home/romai/Agents/scratch/passation-audit-20261119/evidence/relecture-2/"
W = "/home/romai/Agents/worktrees/vega-audit-classements-20261119/"
OUT = sys.argv[1]
REPEAT = 5
baseline = open(R + "baseline_defs.sql").read().replace("BEGIN;", "", 1)
new = open(W + "backend/sql/159_standings_rank_conflicts.sql").read()
new = new.replace("CREATE FUNCTION api.standings_rank_conflicts()", "CREATE OR REPLACE FUNCTION api.standings_rank_conflicts()")
new = new[:new.index("-- The editions withheld now")] + new[new.index("-- §43.2"):]
new = "DROP FUNCTION IF EXISTS api.standings_withheld();\n" + new
route = open(W + "backend/api/src/routes/reference.mjs").read()
new_sql = re.search(r"const rows = await read\(\s*`([\s\S]*?)`,\s*\[competition, season", route)[1]
old_sql = new_sql.replace("api.standings_withheld(k.competition_season_id) x",
                          "api.standings_withheld() x\n         WHERE x.competition_season_id=k.competition_season_id")
j1_sql = new_sql.replace("api.standings_withheld(k.competition_season_id) x",
                         "api.j1_standings_exclusion() x\n         WHERE x.competition_season_id=k.competition_season_id")
defs = {"before": (baseline, j1_sql), "first159": ("", old_sql), "new159": (new, new_sql)}
SMALL = """SET LOCAL session_replication_role = replica;
DELETE FROM core.matches WHERE id >= 3000000 AND id < 4000000;
ANALYZE core.matches;
"""
for variant, (sql, statement) in defs.items():
    for volume in ("full", "small"):
        body = ["\\timing off", "BEGIN;", sql, SMALL if volume == "small" else "",
                "SET jit = off; SET max_parallel_workers_per_gather = 0; SET statement_timeout = '30s'; SET search_path = api; SET ROLE vega_read;",
                f"PREPARE standings(text, text) AS {statement};",
                "PREPARE nlist(text) AS SELECT * FROM api.nation_list((SELECT season_id FROM api.season_keys WHERE season=$1));",
                "PREPARE nmatches(integer) AS SELECT * FROM api.nation_matches($1::integer) ORDER BY match_date DESC NULLS LAST;"]
        runs = [("standings l_000100 -", "EXECUTE standings('l_000100', NULL)"), ("standings l_000150 2025", "EXECUTE standings('l_000150', '2025')"),
                ("standings l_000200 -", "EXECUTE standings('l_000200', NULL)"), ("nation_list", "EXECUTE nlist('2026/2027')"),
                ("nation_matches 100001", "EXECUTE nmatches(100001)"), ("count api.standings", "SELECT count(*) FROM api.standings")]
        for label, q in runs:
            for n in range(REPEAT):
                body += [f"\\echo == {label} #{n + 1}", f"EXPLAIN (ANALYZE, BUFFERS) {q};"]
        body += ["SET plan_cache_mode = force_generic_plan;", "\\echo == generic standings l_000200 -",
                 "EXPLAIN (ANALYZE, BUFFERS) EXECUTE standings('l_000200', NULL);", "\\echo == generic nation_matches 100001",
                 "EXPLAIN (ANALYZE, BUFFERS) EXECUTE nmatches(100001);", "RESET plan_cache_mode;",
                 "\\echo == rows", "EXECUTE standings('l_000100', NULL);", "SELECT count(*), sum(matches) FROM api.nation_list(2026::smallint);",
                 "SELECT count(*) FROM api.nation_matches(100001);", "ROLLBACK;"]
        open(f"{OUT}/{variant}-{volume}.sql", "w").write("\n".join(body) + "\n")
