#!/usr/bin/env bash
# Runs the measurement scripts on classements_perf (port 55535, a copy of relecture_b_159), each statement five times,
# and prints the median execution times (summarize.py). Usage: run.sh before-full first159-full new159-full ...
P=/home/romai/Agents/scratch/passation-audit-20261119/evidence/classements/perf
python3 -I $P/scripts/make.py $P/scripts
for f in "$@"; do
  psql -h 127.0.0.1 -p 55535 -U postgres -d classements_perf -v ON_ERROR_STOP=1 -f $P/scripts/$f.sql > $P/$f.out 2>&1
  grep -m3 ERROR $P/$f.out
done
python3 -I $P/scripts/summarize.py $(for f in "$@"; do echo $P/$f.out; done)
