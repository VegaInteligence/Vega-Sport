"""The scans of core.standings_official in the route's standings statement that have no edition condition, with the
new 159 applied in a rolled-back transaction on classements_perf. Usage: python3 shape.py <league> [generic]"""
import json, re, sys, psycopg
W = "/home/romai/Agents/worktrees/vega-audit-classements-20261119/"
defs = open(sys.argv[0].rsplit('/', 1)[0] + "/new159-full.sql").read()
defs = defs[defs.index("BEGIN;") + 6:defs.index("SET jit = off")]
route = open(W + "backend/api/src/routes/reference.mjs").read()
sql = re.search(r"const rows = await read\(\s*`([\s\S]*?)`,\s*\[competition, season", route)[1]
with psycopg.connect("postgresql://postgres@127.0.0.1:55535/classements_perf") as db:
    db.execute(defs)
    db.execute("SET jit=off; SET max_parallel_workers_per_gather=0; SET search_path=api; SET enable_seqscan=off")
    if len(sys.argv) > 2:
        db.execute("SET plan_cache_mode=force_generic_plan")
        db.execute(f"PREPARE s(text, text) AS {sql}")
        plan = db.execute(f"EXPLAIN (FORMAT JSON) EXECUTE s('{sys.argv[1]}', NULL)").fetchone()[0][0]["Plan"]
    else:
        plan = db.execute("EXPLAIN (FORMAT JSON) " + sql.replace("$1", "%s").replace("$2::text", "%s::text"), (sys.argv[1], None)).fetchone()[0][0]["Plan"]
    def walk(n, path):
        here = path + [n["Node Type"] + (f"({n['Subplan Name']})" if n.get("Subplan Name") else "") + (f"[{n['Alias']}]" if n.get("Alias") else "")]
        if n.get("Relation Name") == "standings_official":
            c = n.get("Index Cond", "") + "".join(x.get("Index Cond", "") for x in n.get("Plans", [])) + n.get("Recheck Cond", "")
            print(("OK  " if "competition_season_id" in c else "ALL ") + " > ".join(here[-7:]))
        for x in n.get("Plans", []):
            walk(x, here)
    walk(plan, [])
    db.rollback()
