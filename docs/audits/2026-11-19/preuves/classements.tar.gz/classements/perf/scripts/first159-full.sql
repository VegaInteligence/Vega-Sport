\timing off
BEGIN;


SET jit = off; SET max_parallel_workers_per_gather = 0; SET statement_timeout = '30s'; SET search_path = api; SET ROLE vega_read;
PREPARE standings(text, text) AS WITH edition AS (
       SELECT k.competition_season_id FROM api.edition_keys k
       CROSS JOIN LATERAL (
         SELECT r.season,r.native_label,r.is_current FROM api.standing_rows r
         WHERE r.competition_season_id=k.competition_season_id
         UNION ALL
         SELECT x.season,x.native_label,x.is_current FROM api.standings_withheld() x
         WHERE x.competition_season_id=k.competition_season_id
         LIMIT 1) s
       WHERE k.league_id=$1 AND ($2::text IS NULL OR s.season=$2 OR s.native_label=$2)
       ORDER BY s.is_current DESC,s.season DESC LIMIT 1)
     SELECT r.* FROM api.standing_rows r WHERE r.competition_season_id=(SELECT competition_season_id FROM edition)
     ORDER BY r.stage NULLS FIRST,r.group_name NULLS FIRST,r.position,r.name;
PREPARE nlist(text) AS SELECT * FROM api.nation_list((SELECT season_id FROM api.season_keys WHERE season=$1));
PREPARE nmatches(integer) AS SELECT * FROM api.nation_matches($1::integer) ORDER BY match_date DESC NULLS LAST;
\echo == standings l_000100 - #1
EXPLAIN (ANALYZE, BUFFERS) EXECUTE standings('l_000100', NULL);
\echo == standings l_000100 - #2
EXPLAIN (ANALYZE, BUFFERS) EXECUTE standings('l_000100', NULL);
\echo == standings l_000100 - #3
EXPLAIN (ANALYZE, BUFFERS) EXECUTE standings('l_000100', NULL);
\echo == standings l_000100 - #4
EXPLAIN (ANALYZE, BUFFERS) EXECUTE standings('l_000100', NULL);
\echo == standings l_000100 - #5
EXPLAIN (ANALYZE, BUFFERS) EXECUTE standings('l_000100', NULL);
\echo == standings l_000150 2025 #1
EXPLAIN (ANALYZE, BUFFERS) EXECUTE standings('l_000150', '2025');
\echo == standings l_000150 2025 #2
EXPLAIN (ANALYZE, BUFFERS) EXECUTE standings('l_000150', '2025');
\echo == standings l_000150 2025 #3
EXPLAIN (ANALYZE, BUFFERS) EXECUTE standings('l_000150', '2025');
\echo == standings l_000150 2025 #4
EXPLAIN (ANALYZE, BUFFERS) EXECUTE standings('l_000150', '2025');
\echo == standings l_000150 2025 #5
EXPLAIN (ANALYZE, BUFFERS) EXECUTE standings('l_000150', '2025');
\echo == standings l_000200 - #1
EXPLAIN (ANALYZE, BUFFERS) EXECUTE standings('l_000200', NULL);
\echo == standings l_000200 - #2
EXPLAIN (ANALYZE, BUFFERS) EXECUTE standings('l_000200', NULL);
\echo == standings l_000200 - #3
EXPLAIN (ANALYZE, BUFFERS) EXECUTE standings('l_000200', NULL);
\echo == standings l_000200 - #4
EXPLAIN (ANALYZE, BUFFERS) EXECUTE standings('l_000200', NULL);
\echo == standings l_000200 - #5
EXPLAIN (ANALYZE, BUFFERS) EXECUTE standings('l_000200', NULL);
\echo == nation_list #1
EXPLAIN (ANALYZE, BUFFERS) EXECUTE nlist('2026/2027');
\echo == nation_list #2
EXPLAIN (ANALYZE, BUFFERS) EXECUTE nlist('2026/2027');
\echo == nation_list #3
EXPLAIN (ANALYZE, BUFFERS) EXECUTE nlist('2026/2027');
\echo == nation_list #4
EXPLAIN (ANALYZE, BUFFERS) EXECUTE nlist('2026/2027');
\echo == nation_list #5
EXPLAIN (ANALYZE, BUFFERS) EXECUTE nlist('2026/2027');
\echo == nation_matches 100001 #1
EXPLAIN (ANALYZE, BUFFERS) EXECUTE nmatches(100001);
\echo == nation_matches 100001 #2
EXPLAIN (ANALYZE, BUFFERS) EXECUTE nmatches(100001);
\echo == nation_matches 100001 #3
EXPLAIN (ANALYZE, BUFFERS) EXECUTE nmatches(100001);
\echo == nation_matches 100001 #4
EXPLAIN (ANALYZE, BUFFERS) EXECUTE nmatches(100001);
\echo == nation_matches 100001 #5
EXPLAIN (ANALYZE, BUFFERS) EXECUTE nmatches(100001);
\echo == count api.standings #1
EXPLAIN (ANALYZE, BUFFERS) SELECT count(*) FROM api.standings;
\echo == count api.standings #2
EXPLAIN (ANALYZE, BUFFERS) SELECT count(*) FROM api.standings;
\echo == count api.standings #3
EXPLAIN (ANALYZE, BUFFERS) SELECT count(*) FROM api.standings;
\echo == count api.standings #4
EXPLAIN (ANALYZE, BUFFERS) SELECT count(*) FROM api.standings;
\echo == count api.standings #5
EXPLAIN (ANALYZE, BUFFERS) SELECT count(*) FROM api.standings;
SET plan_cache_mode = force_generic_plan;
\echo == generic standings l_000200 -
EXPLAIN (ANALYZE, BUFFERS) EXECUTE standings('l_000200', NULL);
\echo == generic nation_matches 100001
EXPLAIN (ANALYZE, BUFFERS) EXECUTE nmatches(100001);
RESET plan_cache_mode;
\echo == rows
EXECUTE standings('l_000100', NULL);
SELECT count(*), sum(matches) FROM api.nation_list(2026::smallint);
SELECT count(*) FROM api.nation_matches(100001);
ROLLBACK;
