| statement | before-full | first159-full | new159-full | before-small | first159-small | new159-small |
|---|---|---|---|---|---|---|
| standings l_000100 - | 42.1 | 128.0 | 31.1 | 36.4 | 67.0 | 19.6 |
| standings l_000150 2025 | 36.9 | 159.5 | 49.8 | 33.7 | 85.5 | 29.9 |
| standings l_000200 - | 38.0 | 134.7 | 43.3 | 21.0 | 79.4 | 35.6 |
| nation_list | 440.2 | 2671.0 | 597.9 | 168.5 | 395.4 | 241.7 |
| nation_matches 100001 | 24.7 | 649.0 | 27.4 | 6.2 | 23.3 | 5.6 |
| count api.standings | 4032.1 | 3879.5 | 4034.4 | 1837.2 | 2127.6 | 2590.1 |
| generic standings l_000200 - | 38.2 | 128.1 | 29.8 | 19.2 | 139.3 | 31.1 |
| generic nation_matches 100001 | 27.6 | 711.3 | 31.5 | 5.5 | 51.2 | 7.4 |
