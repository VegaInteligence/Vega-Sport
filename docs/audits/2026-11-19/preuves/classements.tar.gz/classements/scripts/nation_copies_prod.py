"""Read-only count, on the public API, of the nations whose page lists a match twice by §43.2's rule: the same two
teams, the same score by team, days one apart, two editions (`edition` key, or null for the native one), one native.
Also counts the archive matches labelled with a competition name that is not their edition's year.
Usage: python3 -I nation_copies_prod.py <out dir>   (one GET per 1.1 s)"""
import json, sys, time, urllib.request
from datetime import date, datetime, timezone

BASE = "https://dngp6kh9jx2bl.cloudfront.net"
SEASON = "2026%2F2027"
out = sys.argv[1]


def get(path):
    at = datetime.now(timezone.utc).strftime("%Y-%m-%dT%H:%M:%SZ")
    with urllib.request.urlopen(urllib.request.Request(BASE + path, headers={"User-Agent": "audit-read"}), timeout=60) as r:
        body = r.read()
    time.sleep(1.1)
    return at, json.loads(body)


at, listing = get(f"/api/nations?season={SEASON}")
json.dump({"at": at, "body": listing}, open(f"{out}/nations.json", "w"))
report = {"listed_at": at, "nations": len(listing["data"]["nations"]), "touched": {}, "labels": {}}
for n in listing["data"]["nations"]:
    at, page = get(f"/api/nations/{n['id']}?season={SEASON}")
    json.dump({"at": at, "body": page}, open(f"{out}/nation-{n['id']}.json", "w"))
    ms = page["data"]["matches"]
    def key(m):
        pair = sorted([(m["home"]["id"], m["homeScore"]), (m["away"]["id"], m["awayScore"])])
        return tuple(pair)
    copies = []
    for c in ms:
        if not c["edition"] or not c["date"]:
            continue
        for k in ms:
            if k["edition"] is None and k["date"] and key(k) == key(c) and abs((date.fromisoformat(k["date"]) - date.fromisoformat(c["date"])).days) == 1:
                copies.append({"copy": c["date"], "native": k["date"], "edition": c["edition"], "competition": c["competition"],
                               "teams": [c["home"]["name"], c["away"]["name"]], "score": [c["homeScore"], c["awayScore"]]})
                break
    if copies:
        report["touched"][n["id"]] = {"name": n["name"], "listed": len(ms), "list_count": n["matches"], "copies": copies}
    wrong = sum(1 for m in ms if m["edition"] and m["edition"].rsplit(":", 1)[-1][:4].isdigit()
                and m["edition"].rsplit(":", 1)[-1][:4] not in (m["competition"] or ""))
    if wrong:
        report["labels"][n["id"]] = wrong
report["touched_count"] = len(report["touched"])
report["copies_total"] = sum(len(v["copies"]) for v in report["touched"].values())
report["mislabelled_nations"] = len(report["labels"])
report["mislabelled_matches"] = sum(report["labels"].values())
report["finished_at"] = datetime.now(timezone.utc).strftime("%Y-%m-%dT%H:%M:%SZ")
json.dump(report, open(f"{out}/../../nation-copies-prod.json", "w"), indent=1, ensure_ascii=False)
print(json.dumps({k: v for k, v in report.items() if k not in ("touched", "labels")}))
