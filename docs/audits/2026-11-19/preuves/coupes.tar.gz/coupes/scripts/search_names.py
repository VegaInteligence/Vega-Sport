"""GET /api/search (production, anonymous, <= 1 request/s) for each new name's core word over six seasons; cached."""
import json, os, re, sys, time, unicodedata, urllib.parse, urllib.request
E = sys.argv[1]
names = [n for n, x in json.load(open(f"{E}/names-raw.json")).items() if not x["prod"]]
extra = sys.argv[2:]  # additional raw terms
FORMS = {"fc", "afc", "cf", "sc", "ac", "ssc", "cd", "ud", "sv", "fk", "sk", "bk", "if", "as", "us", "rc", "ca", "cfc", "club", "calcio",
         "football", "futbol", "sd", "ad", "ce", "ue", "cp", "cda", "cde", "cfi", "cfj", "tsv", "tsg", "vfl", "vfb", "spvgg", "fv", "tus", "usv", "atsv", "sg"}
def core(name):
    folded = unicodedata.normalize("NFKD", name).encode("ascii", "ignore").decode().lower()
    words = [w for w in re.split(r"[^a-z0-9]+", folded) if w and w not in FORMS and not w.isdigit()]
    return max(words, key=len) if words else folded
SEASONS = ["2021/2022", "2022/2023", "2023/2024", "2024/2025", "2025/2026", "2026/2027"]
terms = sorted({core(n) for n in names if "[" not in n} | set(extra))
log = open(f"{E}/prod/search/MANIFEST.txt", "a")
for t in terms:
    for s in SEASONS:
        path = f"{E}/prod/search/{t}__{s.replace('/', '-')}.json"
        if os.path.exists(path): continue
        url = "https://dngp6kh9jx2bl.cloudfront.net/api/search?" + urllib.parse.urlencode({"q": t, "season": s})
        req = urllib.request.Request(url, headers={"User-Agent": "generic-client"})
        try:
            body = urllib.request.urlopen(req, timeout=30).read()
        except Exception as e:
            body = json.dumps({"error": str(e)}).encode()
        open(path, "wb").write(body)
        log.write(f"{time.strftime('%Y-%m-%dT%H:%M:%SZ', time.gmtime())} {url} {len(body)}\n"); log.flush()
        time.sleep(1.05)
json.dump({n: core(n) for n in names}, open(f"{E}/prod/search/terms.json", "w"), ensure_ascii=False, indent=1)
print("done", len(terms))
