// Parse every downloaded cup file with the repository's own parser; print rounds and names (data only).
import { readFileSync, readdirSync } from "node:fs";
const W = process.argv[2], D = process.argv[3];
const { parseOpenCupText } = await import(W + "/dashboard/frontend/src/services/openfootball-cups.js");
const out = {};
for (const f of readdirSync(D).filter((f) => /_(cup|facup|eflcup|chcup)\.txt$/.test(f)).sort()) {
  const y = Number(f.match(/_(\d{4})-/)[1]);
  let m; try { m = parseOpenCupText(readFileSync(D + "/" + f, "utf8"), y, {}); } catch (e) { out[f] = { error: String(e.message) }; continue; }
  const rounds = {};
  for (const x of m) { rounds[x.round] ??= { matches: 0, scored: 0, pen: 0, et: 0, pairs: new Set() }; const r = rounds[x.round]; r.matches++; if (x.score) r.scored++; if (x.score?.p) r.pen++; if (x.score?.et) r.et++; r.pairs.add([x.team1, x.team2].sort().join("|")); }
  out[f] = { matches: m.length, rounds: Object.fromEntries(Object.entries(rounds).map(([k, v]) => [k, { ...v, ties: v.pairs.size, pairs: undefined }])), names: [...new Set(m.flatMap((x) => [x.team1, x.team2]))].sort(), first: m[0].date, last: m.at(-1).date };
}
process.stdout.write(JSON.stringify(out, null, 1));
