"""GET /api/read/clubs (production, anonymous, <= 1 request/s): every club with a match in each season, all countries; cached."""
import json, os, sys, time, urllib.parse, urllib.request
E = sys.argv[1]
SEASONS = ["2021/2022", "2022/2023", "2023/2024", "2024/2025", "2025/2026", "2026/2027"]
os.makedirs(f"{E}/prod/clubs", exist_ok=True)
log = open(f"{E}/prod/clubs/MANIFEST.txt", "a")
for s in SEASONS:
    page, pages = 1, 1
    while page <= pages:
        path = f"{E}/prod/clubs/{s.replace('/', '-')}-p{page:03d}.json"
        if not os.path.exists(path):
            url = "https://dngp6kh9jx2bl.cloudfront.net/api/read/clubs?" + urllib.parse.urlencode({"season": s, "limit": 100, "page": page})
            body = urllib.request.urlopen(urllib.request.Request(url, headers={"User-Agent": "generic-client"}), timeout=60).read()
            open(path, "wb").write(body)
            log.write(f"{time.strftime('%Y-%m-%dT%H:%M:%SZ', time.gmtime())} {url} {len(body)}\n"); log.flush()
            time.sleep(1.05)
        pages = json.load(open(path))["pagination"]["pages"]
        page += 1
    print(s, pages, flush=True)
