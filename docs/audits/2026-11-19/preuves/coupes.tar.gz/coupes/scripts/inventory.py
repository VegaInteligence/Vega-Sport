"""Inventory of the team names of the cup files to add, against production's 2024/25 OpenFootball names (data only)."""
import json, sys
E = sys.argv[1]
parsed = json.load(open(f"{E}/parse-all.json"))
known = {}
for f in ["austria", "germany", "fa", "efl", "copa", "coppa", "swiss"]:
    for m in json.load(open(f"{E}/prod/edition-{f}.json"))["matches"]:
        for side, name in (("home", m["team1"]), ("away", m["team2"])):
            if name: known.setdefault(name, set()).add((m["sides"][side]["id"], f))
fr = json.load(open("/home/romai/Agents/scratch/passation-audit-20261119/evidence/identites/prod/cup-france-2024.json"))
for m in fr["matches"]:
    for side, name in (("home", m.get("team1")), ("away", m.get("team2"))):
        if name and m.get("sides"): known.setdefault(name, set()).add((m["sides"][side]["id"], "france"))
out = {}
for f, v in parsed.items():
    if "names" not in v or "2024-25" in f: continue
    for n in v["names"]:
        out.setdefault(n, {"files": [], "prod": sorted(known.get(n, []))})["files"].append(f)
json.dump(out, open(f"{E}/names-raw.json", "w"), ensure_ascii=False, indent=1)
new = {n: x for n, x in out.items() if not x["prod"]}
print(len(out), "names;", len(out) - len(new), "already in 2024/25;", len(new), "new")
conflict = {n: x["prod"] for n, x in out.items() if len({i for i, _ in x["prod"]}) > 1}
print("names with two prod ids:", conflict)
by = {}
for n, x in new.items():
    for f in x["files"]: by.setdefault(f.split("_")[0] + ("-efl" if "efl" in f else "-fa" if "facup" in f else ""), set()).add(n)
print({k: len(v) for k, v in by.items()})
