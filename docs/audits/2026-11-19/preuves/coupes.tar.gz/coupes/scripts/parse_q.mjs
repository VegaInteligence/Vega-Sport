import { readFileSync } from "node:fs";
const [W, D] = process.argv.slice(2);
const { parseOpenCupText } = await import(W + "/dashboard/frontend/src/services/openfootball-cups.js");
const out = {};
for (const f of ["2024-25-clq.txt", "2024-25-elq.txt", "2024-25-confq.txt", "2025-26-clq.txt", "2025-26-elq.txt", "2025-26-confq.txt", "2021-22-conf.txt", "2022-23-conf.txt"]) {
  try {
    const m = parseOpenCupText(readFileSync(D + "/" + f, "utf8"), Number(f.slice(0, 4)), {});
    const rounds = {};
    for (const x of m) { const r = rounds[x.round] ??= { n: 0, scored: 0, et: 0, p: 0, ft90: 0 }; r.n++; if (x.score) r.scored++; if (x.score?.et) r.et++; if (x.score?.p) r.p++; if (x.score?.et && x.score?.ft) r.ft90++; }
    out[f] = { matches: m.length, rounds, names: [...new Set(m.flatMap((x) => [x.team1, x.team2]))].sort(), odd: m.filter((x) => !x.score || /\[/.test(x.team2)) };
  } catch (e) { out[f] = { error: e.message }; }
}
process.stdout.write(JSON.stringify(out, null, 1));
