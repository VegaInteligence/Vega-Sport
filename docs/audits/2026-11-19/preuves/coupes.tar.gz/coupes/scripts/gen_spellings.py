"""Print curated.CUP_SPELLINGS' lines from decisions.py (the spellings of the files added), with their proof."""
import csv, sys
E = sys.argv[1]
sys.argv = ["decisions.py"] + sys.argv[1:]
exec(open(f"{E}/scripts/decisions.py").read().split('if __name__ == "__main__":')[0])
LABEL = {"italy": "Coppa Italia", "deutschland": "DFB-Pokal", "austria": "ÖFB-Cup", "espana": "Copa del Rey", "clq": "UCL qualifying",
         "elq": "UEL qualifying", "confq": "UECL qualifying"}
where = {}
for r in csv.DictReader(open(f"{E}/noms.csv")):
    if r["décision"] == "graphie ajoutée" and r["fichier"] not in NOT_ADDED:
        f = r["fichier"]
        if f.startswith("20"):
            label = f"{LABEL[f[8:-4]]} {f[:7].replace('-', '/')}"
        else:
            repo, season, kind = f.split("_")[:3]
            label = f"{'FA Cup' if 'facup' in kind else 'EFL Cup' if 'efl' in kind else LABEL[repo]} {season.replace('-', '/')}"
        where.setdefault(r["nom"], []).append(label)
used = set(where)
groups = {"pitch-nat": [], "om": [], "uefa": []}
for name, (target, proof) in SPELLINGS.items():
    if name in used:
        g = "uefa" if name.endswith(")") and isinstance(target, str) else "om" if not isinstance(target, str) else "pitch-nat"
        groups[g].append((name, target, proof))
import glob, json
ids = {}
for f in glob.glob(f"{E}/prod/edition-om-*.json") + glob.glob(f"{E}/prod/cup-l_v*.json"):
    d = json.load(open(f))
    for m in d.get("results", []) + d.get("fixtures", []):
        for side in ("home", "away"):
            if m.get("sides"):
                ids[m[side]] = m["sides"][side]["id"]
for g, rows in groups.items():
    print(f"    # --- {g} ({len(rows)})")
    for name, target, proof in rows:
        t = f'"{target}"' if isinstance(target, str) else f'("{target[0]}", "{target[1]}")'
        n = '"' + name + '"' if '"' not in name else "'" + name + "'"
        country = {"italy": "ITA", "deutschland": "GER", "austria": "AUT", "espana": "ESP"}
        head = proof.split("; ", 1)[1] if "; " in proof else proof
        cc = name[-4:-1] if name.endswith(")") else next((v for k, v in {"Coppa": "ITA", "DFB": "GER", "ÖFB": "AUT", "Copa": "ESP", "FA ": "ENG", "EFL": "ENG"}.items() if where[name][0].startswith(k)), "")
        proof = f"{cc}, {', '.join(where[name])}; {head}"
        if not isinstance(target, str):
            proof += f", production {ids[target[1][5:]]}"
        print(f"    {n}: {t},  # {proof}")
