"""The reviewed decision for every team name of the files added (E04b, E04c), written by hand from decide.txt and
decide-q.txt, and noms.csv built from it. Data only (reads the parsed files and the production reads).

  python -I decisions.py <evidence dir> <worktree>
"""
import csv, json, sys
E, W = sys.argv[1], sys.argv[2]
sys.path.insert(0, W + "/backend")
from vega.sources import normalize  # noqa: E402

# Editions added, by file (the national cups) — Copa del Rey 2023/24 and the Swiss Cup 2023/24 are not added (DOUBT).
NATIONAL = ["italy_2021-22_cup.txt", "italy_2022-23_cup.txt", "italy_2023-24_cup.txt",
            "deutschland_2021-22_cup.txt", "deutschland_2022-23_cup.txt", "deutschland_2023-24_cup.txt",
            "austria_2021-22_cup.txt", "austria_2022-23_cup.txt", "austria_2023-24_cup.txt",
            "england_2021-22_eflcup.txt", "england_2022-23_eflcup.txt", "england_2023-24_eflcup.txt",
            "england_2021-22_facup.txt", "england_2022-23_facup.txt", "england_2023-24_facup.txt",
            "espana_2021-22_cup.txt", "espana_2022-23_cup.txt"]
NOT_ADDED = ["espana_2023-24_cup.txt", "europe_switzerland_2023-24_chcup.txt"]
UEFA = ["2024-25-clq.txt", "2024-25-elq.txt", "2024-25-confq.txt", "2025-26-clq.txt", "2025-26-elq.txt", "2025-26-confq.txt"]

# The names whose club is in doubt: the editions holding them are not added.
DOUBT = {
    "CD Quintanar": "Copa del Rey 2023/24: « Quintanar del Rey » in 2022/23; the same club (CD Quintanar del Rey) or CD Quintanar (Quintanar de la Orden)? Not established.",
    "UD Melilla": "Copa del Rey 2023/24: « Melilla CD » is in 2024/25 (t_v0001687); whether it is UD Melilla renamed is not established.",
    "AC Malcantone": "Swiss Cup 2023/24: « FC Malcantone » is in 2024/25 (t_v0002119); the same club or another is not established.",
}

# Reviewed spellings: name -> (target, proof). A target is a PitchAPI public key or (provider, key) of a source team.
P = "PitchAPI"
SPELLINGS = {
    # Coppa Italia (ITA).
    "Ascoli Calcio": ("t_1C8A0F", "ITA, Coppa Italia 2021/22-2023/24; Ascoli Calcio 1898 FC, PitchAPI « Ascoli » (Serie B)"),
    "Benevento Calcio": ("t_3dB5ms", "ITA, Coppa Italia 2021/22-2023/24; PitchAPI « Benevento » (Serie B)"),
    "Delfino Pescara": ("t_0jNGVM", "ITA, Coppa Italia 2021/22; Delfino Pescara 1936, PitchAPI « Pescara » (Serie B)"),
    "L.R. Vicenza": ("t_3ve04n", "ITA, Coppa Italia 2021/22; PitchAPI « LR Vicenza », the club CLUB_ALIASES names for « Vicenza »"),
    "Virtus Entella": ("t_35OKws", "ITA, Coppa Italia 2021/22; PitchAPI « Virtus Entella » (Serie B), same name"),
    # DFB-Pokal (GER).
    "SpVgg Unterhaching": ("t_0gVJgL", "GER, DFB-Pokal 2021/22-2023/24; PitchAPI « Unterhaching » (3. Liga)"),
    "TSV 1860 München": ("t_1yBcnD", "GER, DFB-Pokal 2021/22-2023/24; PitchAPI « 1860 München » (3. Liga), CLUB_ALIASES' spelling"),
    "Viktoria Köln": ("t_1h1kpN", "GER, DFB-Pokal 2021/22-2023/24; PitchAPI « Viktoria Köln » (3. Liga), same name"),
    "Waldhof Mannheim": ("t_2dfYko", "GER, DFB-Pokal 2021/22-2023/24; PitchAPI « Waldhof Mannheim » (3. Liga), same name"),
    # England.
    "Hartlepool United": ("t_3nlg9f", "ENG, FA Cup and EFL Cup 2021/22-2023/24; PitchAPI « Hartlepool United » (League Two), same name"),
    "Everton FC": ("t_21IR9d", "ENG, FA Cup and EFL Cup 2021/22-2023/24; Everton (Premier League); the key is bound to t_v0001626 since 2024/25"),
    # Copa del Rey (ESP).
    "Athletic Bilbao": ("t_3kZPrE", "ESP, Copa del Rey 2021/22-2022/23; Athletic Club (LaLiga)"),
    "CE Sabadell": ("t_0zUYIo", "ESP, Copa del Rey 2021/22; Centre d'Esports Sabadell, PitchAPI « Sabadell »"),
    "CD Leonesa": ("t_0cLux8", "ESP, Copa del Rey 2021/22; Cultural y Deportiva Leonesa, « Cultural Leonesa » in the 2024/25 file and PitchAPI"),
}
# Open Matchday's teams (2026/27 folders ENG_5/6/7, ENG_CUP, WAL_1, UKR_1): the same English non-league, Welsh and Ukrainian clubs.
OM = {"AFC Fylde": "AFC Fylde", "Altrincham FC": "Altrincham", "Alvechurch FC": "Alvechurch", "Buxton FC": "Buxton", "Chester FC": "Chester",
      "Eastleigh FC": "Eastleigh", "Farnborough FC": "Farnborough", "Gateshead FC": "Gateshead", "Halifax Town": "FC Halifax Town",
      "Hereford FC": "Hereford", "Kidderminster Harriers": "Kidderminster Harriers", "King's Lynn": "King’s Lynn", "Marine AFC": "Marine",
      "Merthyr Town": "Merthyr Town", "Needham Market": "Needham Market", "Oxford City": "Oxford City", "Scunthorpe United": "Scunthorpe United",
      "Sheppey United": "Sheppey United", "South Shields FC": "South Shields", "Weymouth FC": "Weymouth", "Yate Town": "Yate Town",
      "Yeovil Town": "Yeovil Town",
      "Caernarfon Town (WAL)": "Caernarfon", "Connah's Quay Nomads (WAL)": "Connahs Q.", "Haverfordwest County (WAL)": "Haverfordwest",
      "Penybont FC (WAL)": "Penybont",
      # Open Matchday's ÖFB-Cup and Copa del Rey 2026/27 (AUT_CUP, ESP_CUP). Left out: « Extremadura UD » is not « CD Extremadura »
      # (the club refounded in 2022), « SV Schaffhausen » not « Schaffhausen » (FC Schaffhausen).
      "FC Lauterach": "Lauterach", "FC Lustenau": "FC Lustenau", "FC Wacker Innsbruck": "Wacker Innsbruck", "SC Kalsdorf": "Kalsdorf",
      "SV Kuchl": "Kuchl", "SV Seekirchen": "Seekirchen", "Vorwärts Steyr": "Vorwarts Steyr", "Wiener Sport-Club": "Wiener Sport-Club",
      "Atlético Baleares": "Atlético Baleares", "CD Alcoyano": "Alcoyano", "CD Badajoz": "Badajoz", "CS Puertollano CF": "CS Puertollano",
      "Peña Sport FC": "Peña Sport", "Rayo Majadahonda": "Rayo Majadahonda", "CD Manacor": "Manacor", "Coruxo FC": "Coruxo",
      "Gimnástica Torrelavega": "Gimnástica Torrelavega", "Recreativo Huelva": "Recreativo Huelva", "Antequera CF": "Antequera CF",
      "Arosa SC": "Arosa", "CD Covadonga": "Covadonga", "CD Varea": "CD Varea", "Polissya Zhytomyr (UKR)": "Polissya Zhytomyr", "Kryvbas Kryvyi Rih (UKR)": "Kryvbas"}
for name, om in OM.items():
    SPELLINGS[name] = (("open_matchday", f"name:{om}"), f"Open Matchday 2026/27 « {om} »: the same club, no other club of that name in its country's folders")
# UEFA qualifying (« Name (XXX) »): PitchAPI clubs of the same country under another spelling, or two PitchAPI records of one
# club (the league's, whose country is known, is chosen).
Q = {
    "AC Sparta Praha (CZE)": ("t_19pSyq", "Sparta Prague"), "Aberdeen FC (SCO)": ("t_1etTie", "Aberdeen"), "Aris Saloniki (GRE)": ("t_48GNlO", "Aris Thessaloniki"),
    "BK Häcken (SWE)": ("t_16Q0cn", "Häcken"), "CS Universitatea Craiova (ROU)": ("t_2SZyGH", "Universitatea Craiova"), "Celtic FC (SCO)": ("t_3k7Fcc", "Celtic"),
    "Club Brugge KV (BEL)": ("t_1mTmMO", "Club Brugge"), "Crvena Zvezda (SRB)": ("t_4W9DaV", "FK Crvena Zvezda"), "Drita Gjilan (KOS)": ("t_30PMPP", "Drita"),
    "KF Drita (KOS)": ("t_30PMPP", "Drita"), "Egnatia Rrogozhine (ALB)": ("t_2ZXaNY", "Egnatia"), "FC Ararat-Armenia (ARM)": ("t_2cGY1H", "Ararat Armenia"),
    "FC Corvinul Hunedoara (ROU)": ("t_3bSy8A", "Corvinul Hunedoara"), "FC DAC 1904 (SVK)": ("t_0uX2Oj", "DAC 1904"), "FC Flora (EST)": ("t_2HEdXg", "Flora Tallinn"),
    "FC Košice (SVK)": ("t_21dxOD", "Košice"), "FK Astana (KAZ)": ("t_4cQ4Gl", "FC Astana"), "FK Bodø/Glimt (NOR)": ("t_0SGPHB", "Bodø/Glimt"),
    "FK Kairat (KAZ)": ("t_0Gz1mu", "Kairat Almaty"), "FK Mladá Boleslav (CZE)": ("t_4T4c7t", "Mladá Boleslav"), "FK Novi Pazar (SRB)": ("t_47DAlu", "Novi Pazar"),
    "FK RFS (LVA)": ("t_4EfjSE", "RFS"), "FK Radnički 1923 (SRB)": ("t_39pqEa", "Radnički 1923 (Kragujevac), not Radnički Niš"),
    "FK Žalgiris (LTU)": ("t_0ZYTV2", "Zalgiris Vilnius, not FK Kauno Žalgiris"), "Fredrikstad FK (NOR)": ("t_4buU5Q", "Fredrikstad"),
    "HNK Rijeka (CRO)": ("t_2RYv68", "Rijeka"), "Hibernian FC (SCO)": ("t_2pkWY0", "Hibernian"), "IF Elfsborg (SWE)": ("t_1A5Ku8", "Elfsborg"),
    "Ilves Tampere (FIN)": ("t_2XIoEC", "Ilves"), "KAA Gent (BEL)": ("t_3CeUfH", "Gent"), "KF Ballkani (KOS)": ("t_3Di3T4", "Ballkani"),
    "KF Shkëndija 79 (MKD)": ("t_2H7cEh", "KF Shkendija"), "KRC Genk (BEL)": ("t_3o2Gex", "Genk"), "Kauno Žalgiris (LTU)": ("t_4Unxj2", "FK Kauno Žalgiris"),
    "Kilmarnock FC (SCO)": ("t_2lf4Qe", "Kilmarnock"), "KÍ Klaksvík (FRO)": ("t_4SnD7C", "Klaksvik"), "Larne FC (NIR)": ("t_2UAUxE", "Larne"),
    "Lincoln Red Imps (GIB)": ("t_0xrE2R", "Lincoln Red Imps FC"), "MFK Ružomberok (SVK)": ("t_1FqVl0", "Ružomberok"),
    "Maccabi Petach-Tikva (ISR)": ("t_1EA8WC", "Maccabi Petah Tikva"), "Molde FK (NOR)": ("t_14EJ9t", "Molde"), "MŠK Žilina (SVK)": ("t_3fpGQL", "Žilina"),
    "NK Osijek (CRO)": ("t_0tQnN0", "Osijek"), "NK Varaždin (CRO)": ("t_2dYbzd", "Varaždin (HNL)"), "PAOK Saloniki (GRE)": ("t_2LBMDR", "PAOK Thessaloniki"),
    "Partizan (SRB)": ("t_25ex0s", "Partizan Beograd"), "Pyunik FC (ARM)": ("t_4TYY0u", "Pyunik"), "RSC Anderlecht (BEL)": ("t_2J5yFC", "Anderlecht"),
    "Rangers FC (SCO)": ("t_0TPUj3", "Rangers"), "Rosenborg BK (NOR)": ("t_18X5R3", "Rosenborg"), "SK Brann (NOR)": ("t_1XFW8M", "Brann"),
    "SK Dnipro-1 (UKR)": ("t_15QrkI", "SC Dnipro-1"), "Shelbourne FC (IRL)": ("t_0vq5Vy", "Shelbourne (league record; t_2aDqfi is a second record)"),
    "Silkeborg IF (DEN)": ("t_3rFzZU", "Silkeborg"), "Slavia Praha (CZE)": ("t_41GCDg", "Slavia Prague"), "St. Mirren FC (SCO)": ("t_0DQtXp", "St. Mirren"),
    "Tromsø IL (NOR)": ("t_2K3SfK", "Tromsø"), "UMF Stjarnan (ISL)": ("t_1u3jjy", "Stjarnan"), "Union Saint-Gilloise (BEL)": ("t_3pK6v1", "Union St.Gilloise"),
    "Valur Reykjavík (ISL)": ("t_2g4lNs", "Valur"), "Viking FK (NOR)": ("t_0jjyWh", "Viking"), "İstanbul Başakşehir (TUR)": ("t_0vXWmF", "Başakşehir"),
    "AEK Athen (GRE)": ("t_2jeqmO", "AEK Athens"), "Ferencvárosi TC (HUN)": ("t_0Ep5Xd", "Ferencváros"), "HJK Helsinki (FIN)": ("t_4ZLBuu", "HJK"),
    "Kuopion PS (FIN)": ("t_0dvYbV", "KuPS"), "SJK Seinäjoki (FIN)": ("t_1PzXfs", "SJK"), "Vaasan PS (FIN)": ("t_1tYJyR", "VPS"),
    "Breiðablik (ISL)": ("t_0Nh6WP", "Breidablik (league record; t_0SYp29 is a second record)"), "KA Akureyri (ISL)": ("t_42t8st", "KA"),
    "Dinamo Kiev (UKR)": ("t_2YGh1d", "Dynamo Kyiv"), "Djurgårdens IF (SWE)": ("t_3EsmDL", "Djurgården"), "Paphos FC (CYP)": ("t_3zsN4F", "Pafos FC"),
    "The New Saints (WAL)": ("t_2eymRi", "TNS"), "PFC Ludogorets Razgrad (BUL)": ("t_35Zfsh", "Ludogorets Razgrad"),
    "APOEL Nikosia (CYP)": ("t_07oLpq", "APOEL Nicosia"), "Omonia Nikosia (CYP)": ("t_0YNrpr", "Omonia Nicosia"), "FC Iberia 1999 (GEO)": ("t_15rkti", "Iberia 1999"),
    "Shamrock Rovers (IRL)": ("t_4YIcUe", "Shamrock Rovers (league record; t_03vYx2 is a second record, so the identity pass finds two)"),
    "Víkingur Reykjavík (ISL)": ("t_4C1Jtt", "Víkingur Reykjavík (league record; t_2YrTje is a second record)"),
}
for name, (key, what) in Q.items():
    SPELLINGS[name] = (key, f"{name[-4:-1]}, UEFA qualifying 2024/25-2025/26; PitchAPI « {what} »")

if __name__ == "__main__":
    parsed = json.load(open(f"{E}/parse-all.json"))
    q = json.load(open(f"{E}/parse-q.json"))
    raw = json.load(open(f"{E}/names-raw.json"))
    dq = {o["name"]: o for o in json.load(open(f"{E}/decide-q.json"))}
    dn = {o["name"]: o for o in json.load(open(f"{E}/decide.json"))}
    rows, doubts = [], 0
    for f in NATIONAL + NOT_ADDED + UEFA:
        names = (parsed.get(f) or q.get(f))["names"]
        for n in names:
            n = n.split("  ")[0]  # « Rochdale AFC   [cancelled] » read by the old parser
            if n in DOUBT:
                rows.append((n, f, "à relire", "", DOUBT[n])); doubts += 1; continue
            if n in SPELLINGS:
                target, proof = SPELLINGS[n]
                rows.append((n, f, "graphie ajoutée", target if isinstance(target, str) else f"{target[0]} {target[1]}", proof)); continue
            if n in raw and raw[n]["prod"]:
                ids = {i for i, _ in raw[n]["prod"]}
                rows.append((n, f, "résolu (clé OpenFootball de 2024/25)", ",".join(sorted(ids)), "production, /api/cups/edition 2024/2025")); continue
            if n in dn and len(dn[n]["auto"]) == 1:
                c = dn[n]["auto"][0]
                rows.append((n, f, "résolu (règle du dépôt : même nom)", c[0], f"{c[1]} {c[2]}")); continue
            if n in dq and len(dq[n]["auto"]) == 1:
                c = dq[n]["auto"][0]
                rows.append((n, f, "résolu (règle du dépôt : même nom, même pays)", c[0], f"{c[1]} {c[2]}")); continue
            if n in dq and len(dq[n]["auto"]) > 1:
                raise SystemExit(f"ambiguous without review: {n}")
            rows.append((n, f, "club réellement nouveau", "", "aucun club du même pays sous ce nom ou un autre dans la base (lecture /api/read/clubs 2021/22-2026/27)"))
    with open(f"{E}/noms.csv", "w", newline="") as out:
        w = csv.writer(out)
        w.writerow(["nom", "fichier", "décision", "identifiant public visé", "preuve"])
        w.writerows(rows)
    from collections import Counter
    print(Counter(r[2] for r in rows), "rows", len(rows), "distinct names", len({r[0] for r in rows}))
    print(Counter((r[1], r[2]) for r in rows if r[2] == "à relire"))
