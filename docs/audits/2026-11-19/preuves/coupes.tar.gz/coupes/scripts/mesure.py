"""Point 4 of the brief: the added editions on a local base standing in for production's teams (E04b, E04c).

  NODE_OPTIONS=--import=<worktree>/backend/tests/fake_openfootball_cups_fetch.mjs PYTHONPATH=<worktree>/backend \
    python mesure.py <dsn of vega_v2_coupes_mesure> <evidence dir>

1. The PitchAPI clubs production shows (prod/clubs-all.json: /api/read/clubs 2021/22-2026/27, national teams left out),
   with their keys and countries; Open Matchday's teams of the 2026/27 editions read (prod/edition-om-*.json,
   cup-l_v*.json), by their key, on the PitchAPI club when production shows it merged; « Everton FC » bound to a
   source-only team as in production.
2. The 2024/25 OpenFootball editions through the real bridge and projection (run_due, vega_collect), the curated
   aliases and the identity pass, as in production.
3. The 23 added editions; then the identity pass; per edition: matches created, sides on a club the base held before,
   teams created; the sides the Elo would read (power.ELO_MATCHES, elo_matches); then Worker.daily twice.
4. Each name's team compared with noms.csv's decision.
"""
import contextlib, csv, glob, io, json, sys
from collections import Counter
from datetime import datetime, timedelta, timezone
from types import SimpleNamespace

DSN, E = sys.argv[1], sys.argv[2]
from vega import power, sources  # noqa: E402
from vega.sources import cups, curated, identity  # noqa: E402
from vega.store import Store, connect_local, migrate  # noqa: E402
from vega.worker import Worker  # noqa: E402

NOW = datetime(2026, 11, 19, 20, tzinfo=timezone.utc)
db = connect_local(DSN)
db.execute("DROP SCHEMA IF EXISTS api,ops,agg,core CASCADE")
migrate(db)
x = db.execute
collect, calc = connect_local(DSN), connect_local(DSN)
collect.execute("SET ROLE vega_collect")
calc.execute("SET ROLE vega_calc")

# 1. Production's teams.
clubs = [c for c in json.load(open(f"{E}/prod/clubs-all.json")) if c["leagues"] != ["World Cup"]]
pitch = {}
for c in clubs:
    country = c["country"] if c["country"] not in ("unknown", None) else None
    if country:
        x("INSERT INTO core.countries(code) VALUES (%s) ON CONFLICT DO NOTHING", (country,))
    team = x("INSERT INTO core.teams(name, country_code, is_national) VALUES (%s, %s, false) RETURNING id", (c["name"], country)).fetchone()[0]
    x("INSERT INTO core.provider_ids(entity_type, provider, provider_key, entity_id) VALUES ('team','pitchapi',%s,%s)", (c["id"], team))
    pitch[c["id"]] = team
om = {}
for f in glob.glob(f"{E}/prod/edition-om-*.json") + glob.glob(f"{E}/prod/cup-l_v*.json"):
    d = json.load(open(f))
    for m in d.get("results", []) + d.get("fixtures", []):
        for side in ("home", "away"):
            if m.get("sides"):
                om[m[side]] = m["sides"][side]["id"]
for name, public in sorted(om.items()):
    team = pitch.get(public) or x("INSERT INTO core.teams(name) VALUES (%s) RETURNING id", (name,)).fetchone()[0]
    x("""INSERT INTO core.provider_ids(entity_type, provider, provider_key, entity_id, is_current)
         VALUES ('team','open_matchday',%s,%s, NOT EXISTS (SELECT 1 FROM core.provider_ids WHERE entity_type='team' AND entity_id=%s
           AND provider='open_matchday' AND is_current))""", (f"name:{name}", team, team))
everton_bound = x("INSERT INTO core.teams(name) VALUES ('Everton FC') RETURNING id").fetchone()[0]
x("INSERT INTO core.provider_ids(entity_type, provider, provider_key, entity_id) VALUES ('team','openfootball','name:Everton FC',%s)", (everton_bound,))
print(f"seeded: {len(pitch)} PitchAPI clubs, {len(om)} Open Matchday teams, Everton FC bound to {everton_bound}")


def due(keys, at):
    scopes = {f"open-cups:{k}": timedelta(seconds=1) for k in keys}
    original = cups.scopes
    cups.scopes = lambda now: scopes
    try:
        return sources.run_due(collect, None, at, names={"openfootball"})
    finally:
        cups.scopes = original


def identity_pass(at):
    with collect.transaction():
        curated.club_aliases(collect)
    with collect.transaction():
        curated.country_names(collect)
    with collect.transaction():
        return identity.run(collect, None, "teams", at)


# 2. The 2024/25 editions, as production holds them.
before_keys = [f"{c}:2024/2025" for c in cups.NATIONAL_CUP_ARCHIVES]
print("2024/25:", Counter(due(before_keys, NOW).values()))
print("identity pass:", identity_pass(NOW))
teams_before = {r[0] for r in x("SELECT id FROM core.teams")}

# 3. The added editions.
added = [f"{c}:{s}" for k, c, s in cups.EDITIONS if k == "open-cups" and (c.endswith("-qualifying") or (c.endswith("-archive") and s != "2024/2025"))]
outcome = due(added, NOW + timedelta(hours=1))
print("added:", Counter(outcome.values()))
created = {r[0] for r in x("SELECT id FROM core.teams")} - teams_before
print("identity pass:", identity_pass(NOW + timedelta(hours=2)))
merged = dict(x("SELECT id, merged_into FROM core.teams WHERE merged_into IS NOT NULL").fetchall())
rows = x("""SELECT cs.cup_key, m.id, m.status::text, m.home_team_id, m.away_team_id, m.home_team_name, m.away_team_name
            FROM core.matches m JOIN core.competition_seasons cs ON cs.id = m.competition_season_id
            WHERE cs.cup_key = ANY(%s)""", ([f"open-cups:{k}" for k in added],)).fetchall()
merge = {team: keep for team, keep, *_ in identity.pairs(db)[0]}
admitted = {r[0] for r in power.elo_matches(power.merged_rows(x(power.ELO_MATCHES).fetchall(), merge))}
public = dict(x("SELECT t.id, api.public_id('team', t.id) FROM core.teams t").fetchall())
table = []
for key in added:
    mine = [r for r in rows if r[0] == f"open-cups:{key}"]
    sides = [(r[3], r[5]) for r in mine] + [(r[4], r[6]) for r in mine]
    final = lambda t: merged.get(t, t)
    held = sum(1 for t, _ in sides if t in teams_before)
    new_teams = {t for t, _ in sides if t in created}
    new_kept = {t for t in new_teams if final(t) == t}
    table.append({"edition": key, "matches": len(mine), "finished": sum(r[2] == "finished" for r in mine),
                  "awarded": sum(r[2] == "awarded" for r in mine), "canceled": sum(r[2] == "canceled" for r in mine),
                  "sides": len(sides), "sides_on_held_team": held, "teams_created": len(new_teams),
                  "created_then_merged": len(new_teams - new_kept), "elo_matches": sum(r[1] in admitted for r in mine),
                  "elo_sides": 2 * sum(r[1] in admitted for r in mine), "outcome": outcome.get(("openfootball", f"open-cups:{key}"))})
for t in table:
    print(t)
total = {k: sum(t[k] for t in table) for k in table[0] if isinstance(table[0][k], int)}
print("total", total, "teams created (distinct):", len(created), "of them merged by the identity pass:", sum(1 for t in created if t in merged))

# 4. Each name's team against noms.csv.
names = {}
for r in rows:
    for team, name in ((r[3], r[5]), (r[4], r[6])):
        names.setdefault(name, set()).add(public[merged.get(team, team)])
check = Counter()
problems = []
for r in csv.DictReader(open(f"{E}/noms.csv")):
    if r["nom"] not in names:
        continue
    got = names[r["nom"]]
    want = r["identifiant public visé"]
    if r["décision"] == "graphie ajoutée" and want.startswith("t_"):
        ok = got == {want}
    elif r["décision"] == "graphie ajoutée":
        provider, key = want.split(" ", 1)
        team = x("SELECT entity_id FROM core.provider_ids WHERE entity_type='team' AND provider=%s AND provider_key=%s", (provider, key)).fetchone()
        ok = team is not None and got == {public[merged.get(team[0], team[0])]}
    elif r["décision"].startswith("résolu (règle"):
        ok = got == {want}
    elif r["décision"].startswith("résolu (clé"):
        ok = len(got) == 1  # the 2024/25 key's team (production's id is not this base's)
    else:  # club réellement nouveau
        ok = len(got) == 1 and next(iter(got)).startswith("t_v")
    check[(r["décision"], ok)] += 1
    if not ok:
        problems.append((r["nom"], r["décision"], want, sorted(got)))
print("noms.csv against the base:", dict(check))
for p in problems[:40]:
    print("  MISMATCH", p)

# 5. The daily pass wakes the Elo once.
clock = [NOW + timedelta(hours=3)]
worker = Worker(Store(collect), SimpleNamespace(), clock=lambda: clock[0], calc_conn=calc, source_get=None)
for n in range(2):
    with contextlib.redirect_stdout(io.StringIO()):
        worker.daily()
    print(f"daily {n + 1}:", x("SELECT id, status, matches FROM agg.power_runs WHERE kind = 'elo' ORDER BY id").fetchall())
    clock[0] += timedelta(days=1)
json.dump({"editions": table, "total": total, "noms": {f"{k[0]}|{k[1]}": v for k, v in check.items()}, "problems": problems},
          open(f"{E}/mesure.json", "w"), ensure_ascii=False, indent=1)
