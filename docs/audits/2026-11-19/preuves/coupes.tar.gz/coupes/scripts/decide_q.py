"""Candidates for each UEFA qualifying team « Name (XXX) »: what identity.match_team would do (its country, exact
normalized name, a reviewed spelling), and the PitchAPI clubs of that country sharing a word. Data only.

  python -I decide_q.py <evidence dir> <worktree>
"""
import json, sys
E, W = sys.argv[1], sys.argv[2]
sys.path.insert(0, W + "/backend")
from vega.sources import normalize  # noqa: E402
from vega.sources.identity import COUNTRY_SUFFIX, WORLD_CLUB_SPELLINGS, WORLD_CLUB_KEYS, club_parts  # noqa: E402
from vega.sources.curated import CLUB_ALIASES  # noqa: E402

clubs = json.load(open(f"{E}/prod/clubs-all.json"))
codes = {c["country"] for c in clubs}
parsed = json.load(open(f"{E}/parse-q.json"))
names = {}
for f, v in parsed.items():
    if "q.txt" in f:
        for n in v["names"]:
            names.setdefault(n, []).append(f)
STOP = {"club", "city", "united", "sport", "football", "futbol", "calcio", "dinamo", "dynamo", "sporting", "real", "athletic"}


def words(name):
    return {normalize(w) for w in name.replace("/", " ").replace("-", " ").split() if len(normalize(w)) >= 4 and normalize(w) not in STOP}


out = []
for n, files in sorted(names.items()):
    m = COUNTRY_SUFFIX.match(n)
    base, country = m.group(1), m.group(2)
    targets = {normalize(base)} | ({normalize(WORLD_CLUB_SPELLINGS[n])} if n in WORLD_CLUB_SPELLINGS else set()) \
        | ({normalize(CLUB_ALIASES[base])} if base in CLUB_ALIASES else set())
    auto = [c for c in clubs if normalize(c["name"]) in targets and c["country"] in (country, None, "unknown")]
    near = [c for c in clubs if c["country"] in (country, "unknown") and c not in auto and (words(base) & words(c["name"]) or club_parts(base)[0] == club_parts(c["name"])[0])]
    out.append({"name": n, "country": country, "known_country": country in codes, "files": files, "key": WORLD_CLUB_KEYS.get(n),
                "auto": [(c["id"], c["name"], c["country"]) for c in auto], "near": [(c["id"], c["name"], c["leagues"]) for c in near]})
json.dump(out, open(f"{E}/decide-q.json", "w"), ensure_ascii=False, indent=1)
for o in out:
    if o["auto"] or o["near"] or o["key"]:
        print(f"{o['name']} | auto {o['auto']} | near {[(i, nm) for i, nm, _ in o['near']]}")
print("countries without any PitchAPI club:", sorted({o["country"] for o in out if not o["known_country"]}))
print(len(out), "names;", sum(bool(o["auto"]) for o in out), "auto;", sum(bool(o["near"]) and not o["auto"] for o in out), "near only")
