"""Team names of the score-in-the-middle cup files (rough reader for the inventory only; the projection is the authority)."""
import json, re, sys
E = sys.argv[1]
L = re.compile(r"^\s*(?:\d{1,2}:\d{2}\s+)?(.+?)\s{2,}(\d+-\d+(?: pen\.)?(?: \d+-\d+)?(?: a\.e\.t\.)?(?: \(\d+-\d+(?:, \d+-\d+)?\))?)\s{2,}(.+?)(?:\s{2,}(\[\w+\]))?\s*$")
parsed = json.load(open(f"{E}/parse-all.json"))
for f, v in list(parsed.items()):
    if "error" not in v: continue
    names, n, rounds, rnd = set(), 0, {}, None
    for line in open(f"{E}/dl/files/{f}", encoding="utf8"):
        s = re.match(r"^\s*▪\s*(.+?)\s*$", line)
        if s: rnd = s.group(1); continue
        m = L.match(line)
        if m and not re.match(r"^\s*(Mon|Tue|Wed|Thu|Fri|Sat|Sun)\b", line):
            n += 1; names |= {m.group(1), m.group(3)}
            r = rounds.setdefault(rnd, {"matches": 0, "pairs": set()}); r["matches"] += 1; r["pairs"].add(tuple(sorted((m.group(1), m.group(3)))))
    decl = re.search(r"#\s*Matches\s+(\d+)", open(f"{E}/dl/files/{f}", encoding="utf8").read()).group(1)
    parsed[f] = {"rough": True, "matches": n, "declared": int(decl), "names": sorted(names),
                 "rounds": {k: {"matches": r["matches"], "ties": len(r["pairs"])} for k, r in rounds.items()}}
    print(f, n, decl, {k: (r["matches"], len(r["pairs"])) for k, r in rounds.items()})
json.dump(parsed, open(f"{E}/parse-all.json", "w"), ensure_ascii=False, indent=1)
