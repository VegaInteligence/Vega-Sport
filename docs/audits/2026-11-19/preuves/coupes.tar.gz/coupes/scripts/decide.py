"""Candidates for each new national-cup name: what the identity pass would do (exact normalized name or reviewed
spelling, no country: the cup editions have none), the PitchAPI clubs of the cup's country sharing the name's core,
and the 2024/25 OpenFootball names of the same cup sharing it. Data only; the decision is written by hand in noms.csv.

  python -I decide.py <evidence dir> <worktree>
"""
import json, sys
E, W = sys.argv[1], sys.argv[2]
sys.path.insert(0, W + "/backend")
from vega.sources import normalize  # noqa: E402
from vega.sources.identity import club_parts  # noqa: E402
from vega.sources.curated import CLUB_ALIASES  # noqa: E402

COUNTRY = {"austria": "AUT", "deutschland": "GER", "england": "ENG", "espana": "ESP", "italy": "ITA", "europe": "SUI"}
EDITION = {"austria": "austria", "deutschland": "germany", "espana": "copa", "italy": "coppa", "europe": "swiss"}
clubs = json.load(open(f"{E}/prod/clubs-all.json"))
by_norm = {}
for c in clubs:
    by_norm.setdefault(normalize(c["name"]), []).append(c)
names = json.load(open(f"{E}/names-raw.json"))
prod = {}
for f in ["austria", "germany", "fa", "efl", "copa", "coppa", "swiss"]:
    for m in json.load(open(f"{E}/prod/edition-{f}.json"))["matches"]:
        for side, n in (("home", m["team1"]), ("away", m["team2"])):
            if n:
                prod.setdefault(f, {})[n] = m["sides"][side]["id"]


def words(name):
    return {w for w in club_parts(name)[0:1] if w} | {normalize(w) for w in name.replace("/", " ").replace("-", " ").split()
                                                     if len(normalize(w)) >= 4 and normalize(w) not in ("calcio", "club", "united", "town", "city", "real", "sport", "union", "atletico", "deportivo")}


out = []
for n, x in sorted(names.items()):
    if x["prod"]:
        continue
    repo = x["files"][0].split("_")[0]
    country = COUNTRY[repo]
    targets = {normalize(n)} | ({normalize(CLUB_ALIASES[n])} if n in CLUB_ALIASES else set())
    auto = [c for t in targets for c in by_norm.get(t, [])]
    w = words(n)
    near = [c for c in clubs if c["country"] == country and (w & words(c["name"]) or club_parts(c["name"])[0] == club_parts(n)[0])]
    cup = "fa" if "facup" in x["files"][0] else "efl" if "eflcup" in x["files"][0] else EDITION[repo]
    pool = {k: v for f in ([cup] + (["fa", "efl"] if repo == "england" else [])) for k, v in prod.get(f, {}).items()}
    same = [(k, v) for k, v in pool.items() if (w & words(k)) or club_parts(k)[0] == club_parts(n)[0]]
    # other new names of the same country sharing the core (two new spellings of one club)
    sibling = [m for m, y in names.items() if m != n and not y["prod"] and COUNTRY[y["files"][0].split("_")[0]] == country
               and ((w & words(m)) or club_parts(m)[0] == club_parts(n)[0])]
    out.append({"name": n, "files": x["files"], "country": country, "auto": [(c["id"], c["name"], c["country"], c["leagues"]) for c in auto],
                "near_pitch": [(c["id"], c["name"], c["leagues"], c["seasons"]) for c in near],
                "near_2425": same, "near_new": sibling})
json.dump(out, open(f"{E}/decide.json", "w"), ensure_ascii=False, indent=1)
for o in out:
    flag = "AUTO" if len(o["auto"]) == 1 else "AMBIG" if o["auto"] else "-"
    print(f"{o['country']} | {o['name']} | {flag} {o['auto'][:2]} | pitch~ {[(i, nm) for i, nm, *_ in o['near_pitch']][:4]} | 24/25~ {o['near_2425'][:3]} | new~ {o['near_new'][:3]}")
