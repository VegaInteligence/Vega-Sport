"""Constat 3 reproduction: a held match keeps the keys on 707, a later Copa re-read puts a moved side back on 707,
the next identity pass retries the journal INSERT. Run from the worktree root:
  set -a; . <evidence>/dsn.env; set +a; PYTHONPATH=backend:backend/tests python <this file>"""
import sys
from vega.store import connect_local
from vega.sources import cups, curated, identity
import test_identity_corrections as t

db = connect_local(t.DSN)
t.schema(db)
t.production_state(db)
x = db.execute
# One of the fifteen is held: its stored score differs from the reviewed one (a European archive match).
x("UPDATE core.matches SET home_score = 9 WHERE id = 730179")

def run_pass():
    x("SET ROLE vega_collect")
    try:
        with db.transaction():
            curated.club_aliases(db)
        with db.transaction():
            return identity.correct_sides(db) if False else identity.run(db, None, "teams", t.NOW)
    finally:
        x("RESET ROLE")

def side_2276():
    return x("SELECT home_team_id FROM core.matches WHERE id = 2276").fetchone()[0]

run_pass()
print("after pass 1: 2276 home =", side_2276(), "journal =", x("SELECT count(*) FROM core.team_side_corrections").fetchone()[0],
      "key name:FC Barcelona on", x("SELECT entity_id FROM core.provider_ids WHERE entity_type='team' AND provider='openfootball' AND provider_key='name:FC Barcelona'").fetchone()[0])
# A later re-read of the Copa edition (its digest changed: one more match of another club), under the collection role.
body = t.copa_body()
body["matches"].append({"round": "Round", "date": "2025-01-05", "team1": "Real Betis", "team2": "Valencia CF", "score": {"ft": [1, 0]}})
x("SET ROLE vega_collect")
with db.transaction():
    print("cups.save:", cups.save(db, "open-cups", "copa-del-rey-archive", "2024/2025", body, t.NOW))
x("RESET ROLE")
print("after the re-read: 2276 home =", side_2276())
for n in (2, 3):
    try:
        run_pass()
        print(f"pass {n}: ok, 2276 home =", side_2276(), "journal =", x("SELECT count(*) FROM core.team_side_corrections").fetchone()[0])
    except Exception as error:
        print(f"pass {n}: FAILED", type(error).__name__, getattr(error, "sqlstate", None), str(error).splitlines()[0])
print("journal of 2276:", x("SELECT match_id, side, from_team, to_team, applied_at IS NOT NULL FROM core.team_side_corrections WHERE match_id = 2276").fetchall())
