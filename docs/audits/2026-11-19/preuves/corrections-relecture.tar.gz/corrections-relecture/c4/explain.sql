-- failure_once's lookup, as the pg driver sends it (psycopg binds the three values server-side).
\timing on
\d ops.parse_failures
PREPARE once_null(integer, text, text) AS SELECT EXISTS (SELECT 1 FROM ops.parse_failures WHERE competition_season_id IS NOT DISTINCT FROM $1 AND error_code = $2 AND message = $3);
EXPLAIN (ANALYZE, BUFFERS, COSTS OFF) EXECUTE once_null(NULL, 'BIRTH_DATE_CONFLICT', 'player 42: 1990-01-01 (x); wikidata Q1: 1990-01-02');
EXPLAIN (ANALYZE, BUFFERS, COSTS OFF) EXECUTE once_null(17, 'EMPTY_AFTER_OBSERVATION', 'cup: detail');
