"""Constat 4: a migrated base (this worktree's migrations) on 127.0.0.1:55542/relecture_c4 with 300 000 ops.parse_failures rows."""
import sys
import psycopg
sys.path.insert(0, sys.argv[1] + "/backend")
from vega.store import migrate
with psycopg.connect("host=127.0.0.1 port=55542 user=postgres dbname=postgres", autocommit=True) as c:
    c.execute("DROP DATABASE IF EXISTS relecture_c4")
    c.execute("CREATE DATABASE relecture_c4")
with psycopg.connect("host=127.0.0.1 port=55542 user=postgres dbname=relecture_c4", autocommit=True) as c:
    migrate(c)
    c.execute("""INSERT INTO ops.parse_failures(competition_season_id, error_code, message, at)
                 SELECT CASE WHEN g % 3 = 0 THEN NULL ELSE g % 400 END, (ARRAY['HTTP_500','EMPTY_AFTER_OBSERVATION','BIRTH_DATE_CONFLICT','SCHEMA_CHANGED'])[1 + g % 4],
                        'message ' || g, now() - (g || ' minutes')::interval FROM generate_series(1, 300000) g""")
    c.execute("ANALYZE ops.parse_failures")
print("seeded")
