-- failure_once's lookup after 157, as it sends it (psycopg binds the values server-side), custom and generic plans.
\timing on
\d ops.parse_failures
PREPARE once_null(text, text) AS SELECT EXISTS (SELECT 1 FROM ops.parse_failures WHERE error_code = $1 AND competition_season_id IS NULL AND md5(message) = md5($2) AND message = $2);
PREPARE once_edition(text, integer, text) AS SELECT EXISTS (SELECT 1 FROM ops.parse_failures WHERE error_code = $1 AND competition_season_id = $2 AND md5(message) = md5($3) AND message = $3);
EXPLAIN (ANALYZE, BUFFERS, COSTS OFF) EXECUTE once_null('BIRTH_DATE_CONFLICT', 'player 42: 1990-01-01 (x); wikidata Q1: 1990-01-02');
EXPLAIN (ANALYZE, BUFFERS, COSTS OFF) EXECUTE once_edition('EMPTY_AFTER_OBSERVATION', 17, 'cup: detail');
SET plan_cache_mode = force_generic_plan;
EXPLAIN (ANALYZE, BUFFERS, COSTS OFF) EXECUTE once_null('BIRTH_DATE_CONFLICT', 'player 42: 1990-01-01 (x); wikidata Q1: 1990-01-02');
EXPLAIN (ANALYZE, BUFFERS, COSTS OFF) EXECUTE once_edition('EMPTY_AFTER_OBSERVATION', 17, 'cup: detail');
