"""Constat 5: a statistics row without a team (team_id NULL), graded by the daily path (refresh_elo, refresh_daily)
under vega_calc. Run with PYTHONPATH=<code>/backend:<worktree>/backend/tests, VEGA_V2_GRADES_TEST_DSN set.
Prints the row's grade, its power-match row and its exclusion, if any."""
import sys
from datetime import date
from vega import models, power, worker
from vega.store import Store, connect_local, migrate
import test_player_grade_reasons as t

db = connect_local(t.DSN)
db.execute("DROP SCHEMA IF EXISTS api,ops,agg,core CASCADE")
migrate(db)
with db.transaction():
    for label in ("2020/2021", "2021/2022"):
        Store(db).season(label)
x = db.execute
t.league(x, 1, "l_CALEND", "2021", range(1, 9), date(2021, 4, 1))
m = t.league(x, 2, "l_SEASON", "2021/2022", range(11, 19), date(2021, 8, 14))
x("INSERT INTO core.players(id,name) VALUES(9990,'No team')")
x("""INSERT INTO core.player_match_stats(season_id,match_id,team_id,player_id,position_id,minutes_played,touches,accurate_passes,accurate_passes_total)
     VALUES(2021,%s,NULL,9990,62,90,40,20,25)""", (m[11][0],))
calc = connect_local(t.DSN)
calc.execute("SET ROLE vega_calc")
power.refresh_elo(calc)
for season in worker.due_seasons(db, t.NOW):
    models.refresh_daily(calc, season, elo=False)
print("code:", power.__file__)
print("grade:", x("SELECT award_season, role, minutes, round(z::numeric, 6), round(first_z::numeric, 6) FROM agg.player_match_grades WHERE player_id=9990").fetchall())
print("power match:", x("SELECT role, minutes, round(contribution::numeric, 6), round(match_index::numeric, 6) FROM agg.player_power_matches WHERE player_id=9990").fetchall())
has = x("SELECT to_regclass('agg.player_grade_exclusions')").fetchone()[0]
print("exclusion:", x("SELECT reason FROM agg.player_grade_exclusions WHERE player_id=9990").fetchall() if has else "no table (before 155)")
if x("SELECT to_regclass('api.player_grade_status')").fetchone()[0]:
    print("status:", x("SELECT grade_status FROM api.player_grade_status WHERE player_id=9990").fetchall())
x("DROP SCHEMA IF EXISTS api,ops,agg,core CASCADE")
