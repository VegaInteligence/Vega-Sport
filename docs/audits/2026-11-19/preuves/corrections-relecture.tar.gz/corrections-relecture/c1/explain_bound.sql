-- Constat 1, proposed form: the participation key resolved from bound values (as pg sends them), not joined to target.
SHOW enable_seqscan;
\timing on
PREPARE gs(text, text, text) AS
SELECT gs.grade_status FROM api.player_grade_status gs
WHERE gs.season_id=$1::smallint AND gs.match_id=api.internal_id('match',$2) AND gs.player_id=api.internal_id('player',$3);
SET plan_cache_mode = force_custom_plan;
EXPLAIN (ANALYZE, BUFFERS, COSTS OFF) EXECUTE gs('2024','m_v0030003','p_v0000005');
SET plan_cache_mode = force_generic_plan;
EXPLAIN (ANALYZE, BUFFERS, COSTS OFF) EXECUTE gs('2024','m_v0030003','p_v0000005');
EXECUTE gs('2024','m_v0030003','p_v0000005');
