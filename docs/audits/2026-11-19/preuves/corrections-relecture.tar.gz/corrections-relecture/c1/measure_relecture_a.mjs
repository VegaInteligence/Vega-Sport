// Constat 1 on the review's base (127.0.0.1:55535/relecture_a, read only): the grade-status column as the route sent it
// before (joined to a materialized target) and as it sends it now (performance.mjs: bound season, internal_id of the
// bound public ids), with the read API's session settings (jit off, no parallel query; db.mjs) and enable_seqscan at its
// default. Usage: node measure_relecture_a.mjs <worktree>
import { createRequire } from "node:module";
const require = createRequire(process.argv[2] + "/backend/api/package.json");
const pg = require("pg");
const client = new pg.Client({ host: "127.0.0.1", port: 55535, user: "postgres", database: "relecture_a",
  options: "-c default_transaction_read_only=on -c statement_timeout=120000 -c jit=off -c max_parallel_workers_per_gather=0 -c search_path=api" });
await client.connect();
const BEFORE = `WITH target AS MATERIALIZED (SELECT $1::smallint AS season_id, api.internal_id('match',$2) AS match_id, api.internal_id('player',$3) AS player_id)
  SELECT (SELECT gs.grade_status FROM api.player_grade_status gs JOIN target t
           ON gs.season_id=t.season_id AND gs.match_id=t.match_id AND gs.player_id=t.player_id) AS grade_status`;
const AFTER = `SELECT (SELECT gs.grade_status FROM api.player_grade_status gs WHERE gs.season_id=$1::smallint
           AND gs.match_id=api.internal_id('match',$2)
           AND gs.player_id=api.internal_id('player',$3)) AS grade_status`;
const values = ["2024", "m_v0030003", "p_v0000005"];
const show = (await client.query("SELECT current_setting('enable_seqscan') s, current_setting('plan_cache_mode') p, version() v")).rows[0];
console.log("settings:", show);
const seq = (plan) => [...plan.matchAll(/Seq Scan on (\S+)/g)].map((m) => m[1]);
for (const [name, sql] of [["before", BEFORE], ["after", AFTER]]) {
  const runs = name === "before" ? 2 : 10;
  const times = [];
  let result;
  for (let i = 0; i < runs; i++) {
    const t = process.hrtime.bigint();
    result = (await client.query(sql, values)).rows[0];
    times.push(Number(process.hrtime.bigint() - t) / 1e6);
  }
  console.log(`\n== ${name}: result ${JSON.stringify(result)}, wall ms per call (pg driver, bound values): ${times.map((x) => x.toFixed(1)).join(", ")}`);
  const custom = (await client.query(`EXPLAIN (ANALYZE, BUFFERS, COSTS OFF) ${sql}`, values)).rows.map((r) => r["QUERY PLAN"]).join("\n");
  console.log(`-- ${name}, custom plan (bound values):\n${custom}`);
  console.log(`-- ${name}, custom plan: sequential scans: ${JSON.stringify(seq(custom))}`);
  await client.query(`PREPARE q_${name}(text, text, text) AS ${sql}`);
  await client.query("SET plan_cache_mode = force_generic_plan");
  const generic = (await client.query(`EXPLAIN (ANALYZE, BUFFERS, COSTS OFF) EXECUTE q_${name}('${values.join("','")}')`)).rows.map((r) => r["QUERY PLAN"]).join("\n");
  await client.query("RESET plan_cache_mode");
  console.log(`-- ${name}, generic plan (plan_cache_mode = force_generic_plan):\n${generic}`);
  console.log(`-- ${name}, generic plan: sequential scans: ${JSON.stringify(seq(generic))}`);
}
await client.end();
