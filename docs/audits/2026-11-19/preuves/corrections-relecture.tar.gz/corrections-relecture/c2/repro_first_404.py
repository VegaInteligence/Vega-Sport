"""Constat 2 reproduction: a first injuries read answered 404 by the real Reader (vega_collect), then the real route
under vega_read (tests/read_http.mjs). Run from the worktree root with dsn.env sourced:
  PYTHONPATH=backend:backend/tests python <this file>"""
import json, subprocess, sys
from pathlib import Path
from vega import transfermarkt as tm
from vega.store import connect_local, migrate
import test_writer_replays as w

db = connect_local(w.DSN)
db.execute("DROP SCHEMA IF EXISTS api,ops,agg,core CASCADE")
migrate(db)
x = db.execute
x("INSERT INTO core.players(id, name) VALUES (10, 'Kylian Mbappé')")
x("INSERT INTO core.provider_ids(entity_type, provider, provider_key, entity_id) VALUES ('player', 'transfermarkt', '342229', 10)")
x("INSERT INTO ops.transfermarkt_reads(kind, provider_key, priority, next_due_at) VALUES ('injuries', '342229', 1, now() - interval '1 minute')")
x("SET ROLE vega_collect")
reader = tm.Reader(db, lambda path, params=(): (404, {}, b""), interval=0, jitter=0, sleep=lambda s: None, log=lambda *a, **k: None)
print("reader outcome:", reader.read("injuries", [("342229", 1)]))
x("RESET ROLE")
print("unit:", x("SELECT read_at IS NOT NULL, error_code, last_http_status FROM ops.transfermarkt_reads WHERE kind='injuries'").fetchone())
public = x("SELECT api.public_id('player', 10)").fetchone()[0]
done = subprocess.run(["node", str(Path("backend/tests/read_http.mjs")), w.DSN, json.dumps([{"path": f"/api/players/{public}/injuries"}])],
                      capture_output=True, text=True, timeout=120)
print("route:", done.stdout.strip().splitlines()[-1] if done.stdout else done.stderr)
x("DROP SCHEMA IF EXISTS api,ops,agg,core CASCADE")
