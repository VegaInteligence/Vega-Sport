"""E02b reproduction: an empty native edition makes open_matchday.run (under vega_collect) drop a copy with finished matches.
Run from the worktree root: PYTHONPATH=backend:backend/tests python <this> (VEGA_V2_SOURCES_TEST_DSN set)."""
import os, sys
sys.path.insert(0, "backend"); sys.path.insert(0, "backend/tests")
from vega.store import connect_local, migrate, Store
from vega.sources import open_matchday
from test_open_matchday import fake_get, NOW
db = connect_local(os.environ["VEGA_V2_SOURCES_TEST_DSN"])
db.execute("DROP SCHEMA IF EXISTS api,ops,agg,core CASCADE"); migrate(db)
x = db.execute
with db.transaction():
    x("SET LOCAL ROLE vega_collect")
    print("run 1 (no native):", open_matchday.run(db, fake_get, "europe", NOW))
print("copy matches:", x("SELECT status, count(*) FROM core.matches m JOIN core.competition_seasons cs ON cs.id=m.competition_season_id WHERE cs.cup_key LIKE 'open-matchday:ENG_1%%' GROUP BY 1 ORDER BY 1").fetchall())
comp = x("INSERT INTO core.competitions(name) VALUES ('Premier League') RETURNING id").fetchone()[0]
x("INSERT INTO core.provider_ids(entity_type, provider, provider_key, entity_id) VALUES ('competition','pitchapi','l_4WFCIZ',%s)", (comp,))
x("INSERT INTO core.competition_seasons(competition_id, season_id, native_label) VALUES (%s,%s,'2026/2027')", (comp, Store(db).season("2026/2027")))
print("native edition matches:", x("SELECT count(*) FROM core.matches m JOIN core.competition_seasons cs ON cs.id=m.competition_season_id WHERE cs.competition_id=%s", (comp,)).fetchone())
with db.transaction():
    x("SET LOCAL ROLE vega_collect")
    print("run 2 (native present, empty):", open_matchday.run(db, fake_get, "europe", NOW))
print("copy matches after:", x("SELECT status, count(*) FROM core.matches m JOIN core.competition_seasons cs ON cs.id=m.competition_season_id WHERE cs.cup_key LIKE 'open-matchday:ENG_1%%' GROUP BY 1 ORDER BY 1").fetchall())
print("copy edition:", x("SELECT count(*) FROM core.competition_seasons WHERE cup_key LIKE 'open-matchday:ENG_1%%'").fetchone())
print("parse_failures:", x("SELECT error_code, message FROM ops.parse_failures").fetchall())
