"""Reproduction on a disposable PG18 base: run from the worktree root with
PYTHONPATH=backend python <this> postgresql://postgres@127.0.0.1:55535/vega_v2_notes_repro
Prints JSON of the observations."""
import json
import sys
import traceback
from datetime import datetime, timezone
from pathlib import Path

sys.path.insert(0, str(Path(__file__).parent))
import seed  # noqa: E402

import psycopg  # noqa: E402
from vega import models, power, worker  # noqa: E402
from vega.store import connect_local, migrate  # noqa: E402

dsn = sys.argv[1]
root = dsn.rsplit("/", 1)[0] + "/postgres"
with psycopg.connect(root, autocommit=True) as admin:
    admin.execute("DROP DATABASE IF EXISTS vega_v2_notes_repro WITH (FORCE)")
    admin.execute("CREATE DATABASE vega_v2_notes_repro")
db = connect_local(dsn)
migrate(db)
mls, eur = seed.build(db)
calc = connect_local(dsn)
calc.execute("SET ROLE vega_calc")
out = {"sha": sys.argv[2] if len(sys.argv) > 2 else None}
q = lambda sql, *a: db.execute(sql, a).fetchall()
now = datetime(2026, 11, 19, 12, tzinfo=timezone.utc)
out["due_seasons_before"] = worker.due_seasons(db, now)
# The ordinary daily pass of each due season, as Worker.daily runs it (Elo once, then refresh_daily(elo=False)).
power.refresh_elo(calc)
for season in out["due_seasons_before"]:
    models.refresh_daily(calc, season, elo=False)
out["due_seasons_after"] = worker.due_seasons(db, now)
out["previous_year_changed_2021"] = power.previous_year_changed(calc, 2021)
out["stale_rankings"] = power.stale_rankings(calc)
out["player_runs"] = q("SELECT season_id, status, method_version FROM agg.power_runs WHERE kind='players' ORDER BY id")
out["positive_minutes_by_award"] = q("""SELECT CASE WHEN m.match_date < '2021-08-01' THEN 2020 ELSE 2021 END, count(*)
  FROM core.player_match_stats s JOIN core.matches m ON m.id=s.match_id AND m.season_id=s.season_id WHERE s.minutes_played>0 GROUP BY 1 ORDER BY 1""")
out["grades_by_award"] = q("SELECT award_season, count(*) FROM agg.player_match_grades GROUP BY 1 ORDER BY 1")
out["pre_august_graded"] = q("""SELECT count(g.*), count(*) FROM core.player_match_stats s JOIN core.matches m ON m.id=s.match_id AND m.season_id=s.season_id
  LEFT JOIN agg.player_match_grades g ON g.season_id=s.season_id AND g.match_id=s.match_id AND g.player_id=s.player_id
  WHERE m.match_date < '2021-08-01' AND s.minutes_played > 0""")[0]
# What a direct run of award year 2020 would give (not on the ordinary path): its references.
try:
    n = power.refresh_players(calc, 2020)
    out["direct_2020"] = {"players": n, "grades": q("SELECT award_season, ref_season, count(*) FROM agg.player_match_grades GROUP BY 1,2 ORDER BY 1,2"),
                          "refs": q("SELECT ref_season, count(*) FROM agg.match_grade_roles GROUP BY 1 ORDER BY 1")}
except Exception as error:
    out["direct_2020"] = {"error": repr(error)}
# E04l (a): a third team's statistics row, with a position, in a match whose two Elo sides exist.
db.execute("INSERT INTO core.teams(id,name) VALUES(99,'Third club')")
db.execute("INSERT INTO core.players(id,name) VALUES(9999,'Third player')")
match = eur[5]
db.execute("""INSERT INTO core.player_match_stats(season_id,match_id,team_id,player_id,position_id,minutes_played,touches,accurate_passes,accurate_passes_total)
              VALUES(2021,%s,99,9999,62,90,40,20,25)""", (match,))
before = q("SELECT count(*), max(run_id) FROM agg.player_power_matches WHERE season_id=2021")[0]
out["elo_sides_of_match"] = q("SELECT team_id FROM agg.team_elo WHERE match_id=%s ORDER BY 1", match)
try:
    power.refresh_players(calc, 2021)
    out["third_team"] = {"error": None}
except Exception as error:
    out["third_team"] = {"error": f"{type(error).__name__} {getattr(error, 'sqlstate', None)} {str(error).splitlines()[0]}"}
after = q("SELECT count(*), max(run_id) FROM agg.player_power_matches WHERE season_id=2021")[0]
out["third_team"]["power_matches_before_after"] = [before, after]
out["third_team"]["grade_of_third"] = q("SELECT count(*) FROM agg.player_match_grades WHERE player_id=9999")
print(json.dumps(out, default=str, indent=1))
