"""Synthetic base for the notes lane: a calendar-year league stored in edition 2021 (MLS-like:
half its matches before 1 August 2021, award year 2020; half after, award year 2021) and an
August-May league 2021/22 (European-like). Used by repro.py (reproduction on 2088d36e60)."""
from datetime import date, timedelta

SQUAD = (("G", 11), ("D", 32), ("D", 33), ("D", 34), ("D", 35), ("M", 62), ("M", 63), ("M", 64), ("M", 65), ("O", 92), ("O", 93))


def league(x, cid, name, key, edition, label, teams, first_day, step_days):
    x("INSERT INTO core.competitions(id,name,kind) VALUES(%s,%s,'league')", (cid, name))
    x("INSERT INTO core.provider_ids(entity_type,provider,provider_key,entity_id) VALUES('competition','pitchapi',%s,%s)", (key, cid))
    x("INSERT INTO core.competition_seasons(id,competition_id,season_id,native_label) VALUES(%s,%s,%s,%s)", (cid, cid, edition, label))
    for t in teams:
        x("INSERT INTO core.teams(id,name) VALUES(%s,%s) ON CONFLICT DO NOTHING", (t, f"Club {t}"))
        for slot, (_, position) in enumerate(SQUAD):
            pid = t * 100 + slot
            x("INSERT INTO core.players(id,name) VALUES(%s,%s) ON CONFLICT DO NOTHING", (pid, f"P{pid}"))
    mids = []
    n = 0
    for home in teams:
        for away in teams:
            if home == away:
                continue
            mid = cid * 1000 + n
            day = first_day + timedelta(days=step_days * n)
            n += 1
            hs, as_ = (home * 3 + away) % 4, (away * 2 + home) % 3
            x("""INSERT INTO core.matches(id,competition_season_id,season_id,source,status,home_team_id,away_team_id,home_score,away_score,match_date,kickoff_at)
                 VALUES(%s,%s,%s,'pitchapi','finished',%s,%s,%s,%s,%s,%s::date + time '18:00')""", (mid, cid, edition, home, away, hs, as_, day, day))
            x("INSERT INTO core.match_coverage(season_id,match_id,player_stats) VALUES(%s,%s,'ok')", (edition, mid))
            for team in (home, away):
                for slot, (group, position) in enumerate(SQUAD):
                    pid = team * 100 + slot
                    x("INSERT INTO core.lineup_players(season_id,match_id,team_id,player_id,is_starter,position_id) VALUES(%s,%s,%s,%s,true,%s)",
                      (edition, mid, team, pid, position))
                    x("""INSERT INTO core.player_match_stats(season_id,match_id,team_id,player_id,minutes_played,goals,xg,total_shots,recoveries,interceptions,
                           tackles,clearances,shot_blocks,duels_won,duels_lost,accurate_passes,accurate_passes_total,touches,chances_created,
                           passes_into_final_third,dribbles_succeeded,touches_opp_box,saves,goals_prevented)
                         VALUES(%s,%s,%s,%s,90,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s)""",
                      (edition, mid, team, pid, int((pid + mid) % 5 == 0), round(0.01 * (pid % 17), 2), pid % 4, (pid * 7 + mid) % 9,
                       (pid + mid) % 4, (pid * 3 + mid) % 5, (pid + 2 * mid) % 6, pid % 3, (pid * 5 + mid) % 8, (pid + mid) % 7,
                       20 + pid % 30, 30 + pid % 30, 40 + (pid * 11 + mid) % 25, (pid + mid) % 4, (pid * 2 + mid) % 6, pid % 5,
                       (pid + mid) % 3, (pid + mid) % 6 if group == "G" else None, 0.1 * ((pid + mid) % 3) if group == "G" else None))
            mids.append(mid)
    return mids


def build(db):
    from vega.store import Store

    with db.transaction():
        store = Store(db)
        for label in ("2020/2021", "2021/2022"):
            store.season(label)
    x = db.execute
    # Calendar-year league, edition 2021 (native "2021"): 56 matches, one every 4 days from 1 April 2021:
    # the first 30 before 1 August 2021 (award year 2020), the other 26 after (award year 2021).
    mls = league(x, 1, "Calendar League", "l_CALEND", 2021, "2021", range(1, 9), date(2021, 4, 1), 4)
    # August-May league 2021/22: 56 matches from 14 August 2021, one every 4 days.
    eur = league(x, 2, "Season League", "l_SEASON", 2021, "2021/2022", range(11, 19), date(2021, 8, 14), 4)
    return mls, eur
