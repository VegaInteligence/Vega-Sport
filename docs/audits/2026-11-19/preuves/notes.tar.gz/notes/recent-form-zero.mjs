// Item 4 (VI-32): what RecentForm (PlayerScoutOverview.jsx:491-505) writes with no rated match, on this checkout.
// Rerun: node <this> <worktree>
import path from "node:path";
const root = process.argv[2];
const { seasonGrade } = await import(path.join(root, "dashboard/frontend/src/services/grades.js"));
const recent = [];
const computed = seasonGrade(recent).grade;
const average = computed ?? 50; // the component's fallback, line 501
console.log(JSON.stringify({ seasonGradeOfNoMatch: computed ?? null, averageShown: average, text: `${recent.length} derniers matchs · moy. ${Math.round(average)}` }));
